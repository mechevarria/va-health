#!/usr/bin/env python
import logging
from logging import NullHandler
__import__('pkg_resources').declare_namespace(__name__)


LOGGER = logging.getLogger(__name__)
LOGGER.addHandler(NullHandler())
