from __future__ import absolute_import, unicode_literals, division, print_function
import logging
import requests
from ayasdi._version import __version__

LOGGER = logging.getLogger(__name__)


class Session(requests.Session):
    """
    A wrapper around the Requests library Session object. This allows us to
    store and/or modify HTTP request and response state as they go between
    caller and the API server.

    >>> test_session_traceid()
    'mock-traceid-1234'
    """
    last_traceid = None
    GET_TIMEOUT = 600
    POST_TIMEOUT = None
    PUT_TIMEOUT = None
    DELETE_TIMEOUT = 600
    trace_id = None

    def request(self, *args, **kwargs):
        if 'headers' not in kwargs:
            kwargs['headers'] = {'User-Agent': 'ayasdi-sdk-{}'.format(__version__)}
        else:
            kwargs['headers']['User-Agent'] = 'ayasdi-sdk-{}'.format(__version__)

        resp = super(Session, self).request(*args, **kwargs)
        self.last_traceid = resp.headers.get('x-traceid')
        LOGGER.debug(
            '{method} {url}, {response}, X-trace-ID: {trace_id}'.format(
                method=args[0], url=args[1], response=resp.status_code,
                trace_id=self.last_traceid))
        LOGGER.debug('Request Headers: {headers}'.format(headers=resp.request.headers))
        LOGGER.debug('Response Headers: {headers}'.format(headers=resp.headers))
        return resp

    def get(self, *args, **kwargs):
        if 'timeout' not in kwargs:
            kwargs['timeout'] = self.GET_TIMEOUT

        return super(Session, self).get(*args, **kwargs)

    def post(self, *args, **kwargs):
        if 'timeout' not in kwargs:
            kwargs['timeout'] = self.POST_TIMEOUT
        return super(Session, self).post(*args, **kwargs)

    def put(self, *args, **kwargs):
        if 'timeout' not in kwargs:
            kwargs['timeout'] = self.PUT_TIMEOUT
        return super(Session, self).put(*args, **kwargs)

    def delete(self, *args, **kwargs):
        if 'timeout' not in kwargs:
            kwargs['timeout'] = self.DELETE_TIMEOUT
        return super(Session, self).delete(*args, **kwargs)


def test_session_traceid():
    import mock
    m = mock.MagicMock()
    m.headers = {'x-traceid': 'mock-traceid-1234'}
    requests.Session.request = mock.MagicMock(return_value=m)
    s = Session()
    s.request('GET', 'http://fake.com')
    return s.last_traceid
