from __future__ import absolute_import, division, print_function

import logging
import sys

import requests
from requests.exceptions import SSLError

from ayasdi.sysmgmt import exceptions

LOGGER = logging.getLogger(__name__)


def Client(host, username=None, password=None, api_version='1',
           cookie_dict=None, cookie_domain="", verify=True):
    """Instantiate a new connection.

       Args:

        host (str) : Url for the host to be connected
        username (str) : Your Ayasdi Core username
        password (str) :  Your Ayasdi Core password
        cookie_dict (dict) : Cookie based login for SSO
        cookie_domain (str) : Domain for cookie based login

       Returns:

        Client connection (:class:`Client) :  The Client connection

       :Example:

       >>> connection = Client(host, username, password)

       """
    imp_path = 'ayasdi.sysmgmt.v%s.client.Client' % api_version
    mod_str, dot, class_str = imp_path.rpartition('.')
    __import__(mod_str)
    try:
        class_object = getattr(sys.modules[mod_str], class_str)
    except AttributeError:
        error_message = 'No such class %s' % imp_path
        LOGGER.exception(error_message)
        raise ImportError(error_message)
    return class_object(host, username=username, password=password,
                        cookie_dict=cookie_dict, cookie_domain=cookie_domain,
                        verify=verify)


class HTTPClient(object):
    def __init__(self, host, username=None, password=None, api_version=1,
                 cookie_dict=None, cookie_domain="", verify=True):

        self.host = host
        self.api_version = api_version
        self.verify = verify
        requests_session = requests.session()
        if cookie_dict:
            self.cookies = requests_session.cookies
            for name, value in cookie_dict.items():
                self.cookies.set(name, value, domain=cookie_domain)
        else:
            try:
                self.auth = requests_session.post(
                    'https://{}/admin/login'.format(host),
                    data={'username': username, 'passphrase': password})

            except SSLError as e:
                error_message = "SSLError: {}".format(e)
                LOGGER.exception(error_message)

                requests_session.verify = False
                self.auth = requests_session.post(
                    'https://{}/admin/login'.format(host),
                    data={'username': username, 'passphrase': password})
            self.auth.raise_for_status()
            self.cookies = self.auth.cookies

    def request(self, url, method, json=None, params=None, basic_auth=False):
        # Build the request
        uri = 'https://{host}/admin/v{api_version}{url_path}'.format(
            host=self.host, api_version=self.api_version, url_path=url)
        headers = {'content-type': 'application/json',
                   'accept': 'application/json'} if json else None
        kwargs = dict(json=json, params=params, headers=headers,
                      verify=self.verify)
        if basic_auth:
            kwargs['auth'] = self.auth
        else:
            kwargs['cookies'] = self.cookies

        # Issue the request
        resp = requests.request(method, uri, **kwargs)
        last_traceid = resp.headers.get('x-traceid')

        LOGGER.debug(
            '{method} {url}, {response}, X-trace-ID: {trace_id}'.format(
                method=method, url=url, response=resp.status_code,
                trace_id=last_traceid))

        if resp.status_code >= 400:
            msg = 'Server gave %s: %s' % (
                resp.status_code, resp.json()['message'])
            raise exceptions.HTTPException(msg)

        return resp
