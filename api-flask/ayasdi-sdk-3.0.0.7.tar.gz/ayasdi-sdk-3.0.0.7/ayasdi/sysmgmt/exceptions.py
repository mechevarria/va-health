from __future__ import absolute_import, division, print_function
import logging

LOGGER = logging.getLogger(__name__)


class HTTPException(Exception):
    pass
