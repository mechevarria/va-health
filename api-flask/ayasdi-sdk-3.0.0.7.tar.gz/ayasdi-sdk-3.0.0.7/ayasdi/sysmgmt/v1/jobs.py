from __future__ import absolute_import, division, print_function
import logging

from ayasdi.sysmgmt import base

LOGGER = logging.getLogger(__name__)


class Job(base.Resource):
    def __repr__(self):
        return '<Job: %s>' % self.id


class JobManager(base.Manager):
    resource_class = Job

    def list(self, params=None):
        return self._list('/jobs', 'jobs', params=params)

    def get(self, job_id):
        return self._get('/jobs/%s' % job_id)
