from __future__ import absolute_import, division, print_function
import logging
from ayasdi.sysmgmt import base

LOGGER = logging.getLogger(__name__)


class Role(base.Resource):
    def __repr__(self):
        return '<Role: %s>' % self.id


class RolesManager(base.Manager):
    resource_class = Role

    def create(self, name, rights):
        """Creates a new role and returns it.

        Args:
            name: the role name
            rights: the list of rights

        Returns:
            a role object

        :Example:

        >>> connection = Client(host, username, password) # doctest: +SKIP
        >>> rights = [{'id': 3, 'name': 'update_self',
        ...            'description': 'Change Password' },
        ...           {'id': 7, 'name': 'PREDICT',
        ...            'description' : 'Access - Predict' }] # doctest: +SKIP
        >>> role = connection.roles.create(role_name, rights) # doctest: +SKIP

        """
        body = {
            'name': name,
            'rights': rights
        }
        return self._create('/roles', body)

    def list(self, params=None):
        """Returns a list of roles

        Args:
            params

        Returns:
            roles (list) : A list of role objects.

        :Example:

        >>> connection = Client(host, username, password) # doctest: +SKIP
        >>> connection.roles.list() # doctest: +SKIP
        [<Role: 1>, <Role: 2>, <Role: 3>, <Role: 4>, <Role: 9>, <Role: 10>,
         <Role: 11>, <Role: 12>]
        >>> roles_list = connection.roles.list() # doctest: +SKIP
        >>> role = roles_list[0] # doctest: +SKIP
        >>> role.name # doctest: +SKIP
        'Workbench Access only'

        """
        return self._list('/roles?all=true&orderBy=id', 'roles', params=params)

    def get(self, role_id):
        """Return a role with a given role id

        Args:
            role_id: the role id

        Returns:
            a role object

        :Example:

        >>> connection = Client(host, username, password) # doctest: +SKIP
        >>> role = connection.roles.get(role_id) # doctest: +SKIP
        >>> role.name # doctest: +SKIP
        'Workbench Access only'
        >>> role.rights # doctest: +SKIP
        [{u'description': u'Access - Workbench', u'id': 4, u'name': u'CORE'}]

        """
        return self._get('/roles/%s' % role_id)

    def delete(self, role_id):
        """Deletes a role with a given role id.

        Args:
            role_id: the role id that needs to be deleted

        Returns:
            None

        :Example:

        >>> role = connection.roles.delete(role_id) # doctest: +SKIP

        """

        self._delete('/roles/%s' % role_id)
