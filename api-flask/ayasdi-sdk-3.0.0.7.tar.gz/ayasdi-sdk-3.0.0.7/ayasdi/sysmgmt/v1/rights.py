from __future__ import absolute_import, division, print_function
import logging
from ayasdi.sysmgmt import base

LOGGER = logging.getLogger(__name__)


class Right(base.Resource):
    def __repr__(self):
        return '<Right: %s>' % self.id


class RightsManager(base.Manager):
    resource_class = Right

    def list(self, params=None):
        """Returns a list of rights

        Args:
            None

        Returns:
            rights (list) : A list of right objects.

        :Example:

        >>> connection = Client(host, username, password) # doctest: +SKIP
        >>> connection.rights.list() # doctest: +SKIP
        [Right: 1>, <Right: 2>, <Right: 3>, <Right: 4>, <Right: 6>,
         <Right: 7>, <Right: 8>, <Right: 9>]
        >>> rights_list = connection.rights.list() # doctest: +SKIP
        >>> right = rights_list[0] # doctest: +SKIP
        >>> right.name # doctest: +SKIP
        'CARE'

        """
        return self._list('/rights?all=true&orderBy=id', 'rights',
                          params=params)

    def get(self, right_id):
        """Return a right with a given right id

        Args:
            right_id: the right id

        Returns:
            a right object

        :Example:

        >>> connection = Client(host, username, password) # doctest: +SKIP
        >>> right = connection.rights.get(right_id) # doctest: +SKIP
        >>> right.name # doctest: +SKIP
        'CARE'
        >>> right.description # doctest: +SKIP
        'Access - Care'
        >>> right.createTimestamp # doctest: +SKIP
        2016-07-29T00:35:54.841Z
        >>> right.updateTimestamp # doctest: +SKIP
        2016-08-31T20:18:20.483Z

        """
        return self._get('/rights/%s' % right_id)
