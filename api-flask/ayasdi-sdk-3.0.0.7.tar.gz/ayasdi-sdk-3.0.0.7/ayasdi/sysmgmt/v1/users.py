from __future__ import absolute_import, division, print_function
import logging
from ayasdi.sysmgmt import base

LOGGER = logging.getLogger(__name__)


class User(base.Resource):
    def __repr__(self):
        return '<User: %s>' % self.id

    def delete(self):
        self.manager.delete(self)


class UserManager(base.Manager):
    resource_class = User

    def create(self, email, password, org, team=None):
        body = {
            'email': email,
            'password': password,
            'organization': {
                'id': base.getid(org)
            }
        }

        if team:
            body['primaryTeam'] = {
                'id': base.getid(team)
            }

        return self._create('/users', body)

    def list(self, params=None):
        return self._list('/users', 'users', params=params)

    def get(self, user_id):
        return self._get('/users/%s' % user_id)

    def get_user_by_email(self, email):
        return self._get('/users', params={'email': email})

    def delete(self, org):
        self._delete('/users/%s' % base.getid(org))

    def update(self, org, **kwargs):
        self._update('/users/%s' % base.getid(org), kwargs)

    def get_current_user(self):
        """Login with the user to get user details such as roles,
                rights, team, primaryTeam
            Args:
                None

            Returns:
                User object

            :Example:

            >>> connection = Client(host, username, password) # doctest: +SKIP
            >>> user = connection.users.get_current_user() # doctest: +SKIP
            >>> user.roles # doctest: +SKIP
            [{u'id': 3, u'name': u'user'}]
            >>> user.teams # doctest: +SKIP
            [{u'organization': {u'id': 3, u'name':
                                u'Organization for group admin'},
              u'isDefaultTeam': False, u'id': 9, u'name': u'test team'}]
            >>> user.primaryTeam # doctest: +SKIP
            {u'organization': {u'id': 3, u'name':
                               u'Organization for group admin'},
             u'isDefaultTeam': False, u'id': 9, u'name': u'test team'}
            >>> user.organization # doctest: +SKIP
            {u'id': 3, u'name': u'Organization for group admin'}
            >>> user.id # doctest: +SKIP
            10
            >>> user.oldId # doctest: +SKIP
            -9081290465210320811
            >>> user.isSiteAdmin # doctest: +SKIP
            false
            >>> user.isOrgAdmin # doctest: +SKIP
            false
            >>> user.enabled # doctest: +SKIP
            true
            >>> user.name # doctest: +SKIP
            test user
            >>> user.email # doctest: +SKIP
            test.user@ayasdi.com
            >>> user.locked # doctest: +SKIP
            false
            >>> user.settings # doctest: +SKIP
            {\"settings\":{\"mode\":\"normal\",\"theme\":\"dark\"}}
            >>> user.rights # doctest: +SKIP
            [{u'description': u'Real-time Prediction', u'id': 27,
              u'name': u'7032'}, {u'description': u'Legacy Site Admin',
                                  u'id': 23, u'name': u'7016'}]
            >>> user.createTimestamp # doctest: +SKIP
            2016-01-18T19:42:15Z
            >>> user.updateTimestamp # doctest: +SKIP
            2016-09-14T18:03:07.057Z

            """
        return self._get('/self')
