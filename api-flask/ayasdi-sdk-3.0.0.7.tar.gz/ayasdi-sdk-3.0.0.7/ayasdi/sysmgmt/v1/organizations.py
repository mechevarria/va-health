from __future__ import absolute_import, division, print_function

import logging

from ayasdi.sysmgmt import base

LOGGER = logging.getLogger(__name__)


class Org(base.Resource):
    def __repr__(self):
        return '<Org: %s>' % self.id

    def update(self, **kwargs):
        self.manager.update(self, **kwargs)

    def delete(self):
        self.manager.delete(self)


class OrgManager(base.Manager):
    resource_class = Org

    def create(self, name, max_seats, notes=''):
        body = {'name': name,
                'maxSeats': max_seats,
                'notes': notes
                }

        return self._create('/organizations', body)

    def list(self, params=None):
        return self._list('/organizations', 'organizations', params=params)

    def get(self, org_id):
        return self._get('/organizations/%s' % org_id)

    def delete(self, org):
        self._delete('/organizations/%s' % base.getid(org))

    def update(self, org, **kwargs):
        return self._update('/organizations/%s' % base.getid(org), kwargs)
