from __future__ import absolute_import, division, print_function
import logging

from ayasdi.sysmgmt import client
from ayasdi.sysmgmt.v1 import internal
from ayasdi.sysmgmt.v1 import jobs
from ayasdi.sysmgmt.v1 import organizations
from ayasdi.sysmgmt.v1 import rights
from ayasdi.sysmgmt.v1 import roles
from ayasdi.sysmgmt.v1 import teams
from ayasdi.sysmgmt.v1 import users

LOGGER = logging.getLogger(__name__)


class Client(object):

    def __init__(self, host, username='', password='', cookie_dict=None,
                 cookie_domain='', verify=True):
        self.version = '1'
        self.client = client.HTTPClient(host, username, password,
                                        self.version, cookie_dict,
                                        cookie_domain, verify=verify)

        self.internal = internal.InternalManager(self)
        self.users = users.UserManager(self)
        self.orgs = organizations.OrgManager(self)
        self.teams = teams.TeamManager(self)
        self.rights = rights.RightsManager(self)
        self.roles = roles.RolesManager(self)
        self.jobs = jobs.JobManager(self)
