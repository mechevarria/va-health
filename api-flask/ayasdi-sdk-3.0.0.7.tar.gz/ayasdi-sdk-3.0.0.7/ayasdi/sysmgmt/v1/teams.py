from __future__ import absolute_import, division, print_function

import logging

from ayasdi.sysmgmt import base

LOGGER = logging.getLogger(__name__)


class Team(base.Resource):
    def __repr__(self):
        return '<Team: %s>' % self.id

    def delete(self):
        self.manager.delete(self)

    def update(self, **kwargs):
        self.manager.update(self, **kwargs)


class TeamManager(base.Manager):
    resource_class = Team

    def create(self, name, org, role_ids=None):
        """
        Creates a team with the name, org id, and roles.

        :param name (str): name of the new team
        :param org (str): id of org that will manage the team
        :param role_ids (list, optional): List of role ids to add to the team.
            Defaults to `user` role.
        :return: Team Object

        Example:
            >>> from ayasdi.sysmgmt.client import Client # doctest: +SKIP
            >>> connection = Client(host, username, password) # doctest: +SKIP
            >>> user = connection.users.get_current_user() # doctest: +SKIP
            >>> org_id = user.organization['id'] # doctest: +SKIP
            >>> connection.teams.create('team_name', \
                org_id, role_ids=[6, 7]) # doctest: +SKIP
        """
        if not role_ids:
            roles = []
        else:
            if not isinstance(role_ids, list):
                raise Exception('roles_id must be a list of integers')
            roles = [{'id': id} for id in role_ids]

        body = {
            'name': name,
            'organization': {
                'id': base.getid(org)
            },
            'roles': roles
        }
        return self._create('/teams', body)

    def list(self, params=None):
        return self._list('/teams', 'teams', params=params)

    def get(self, team_id):
        return self._get('/teams/%s' % team_id)

    def delete(self, team):
        self._delete('/teams/%s' % base.getid(team))

    def update(self, team_id, name=None, role_ids=None):
        """
        Updates a team's name and/or roles.

        :param team_id(int or str): ID of team that will be updated
        :param name (str, optional): New team name
        :param role_ids (list, optional): List of role ids that the team
            will be assigned.
        :return: Team Object

        Example:
            >>> team = connection.teams.list()[0] # doctest: +SKIP
            >>> connection.teams.update(team.id, name='new name', \
                role_ids=[1, 2]) # doctest: +SKIP
        """
        body = {}
        if not (name or role_ids):
            raise Exception(
                'Updating teams requires either a name or list of roles.')

        if name:
            body['name'] = name

        if role_ids:
            if not isinstance(role_ids, list):
                raise Exception('roles_id must be a list of integers')
            roles = [{'id': id} for id in role_ids]
            body['roles'] = roles

        return self._update('/teams/%s' % base.getid(team_id), body=body)

    def add_user(self, team_id, user_id):
        payload = {'actors': [{'id': user_id}]}
        self._post('/teams/%s/actors' % team_id, payload)

    def remove_user(self, team_id, user_id):
        payload = {'actors': [{'id': user_id}]}
        self._delete('/teams/%s/actors' % team_id, payload)
