from __future__ import absolute_import, division, print_function
import logging

from ayasdi.sysmgmt import base

LOGGER = logging.getLogger(__name__)


class InternalManager(base.Manager):
    def create_site_admin(self):
        self.api.client.request('/internal/site-admin', 'POST')
