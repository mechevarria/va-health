from __future__ import absolute_import, division, print_function
import logging

LOGGER = logging.getLogger(__name__)


def getid(obj):
    try:
        return obj.id
    except AttributeError:
        return obj


class Resource(object):
    def __init__(self, manager, info):
        self.manager = manager
        self._add_details(info)

    def __getattr__(self, k):
        if k not in self.__dict__:
            raise AttributeError(k)
        else:
            return self.__dict__[k]

    def _add_details(self, info):
        for k, v in info.items():
            setattr(self, k, v)


class Manager(object):
    resource_class = None

    def __init__(self, api):
        self.api = api

    def _list(self, url, response_key, params=None):
        resp = self.api.client.request(url, 'GET', params=params)
        resources = resp.json()[response_key]
        return [self.resource_class(self, res) for res in resources]

    def _get(self, url, params=None):
        doc = self.api.client.request(url, 'GET', params=params).json()
        return self.resource_class(self, doc)

    def _post(self, url, body):
        doc = self.api.client.request(url, 'POST', json=body).json()
        return self._get(doc['url'])

    def _create(self, url, body):
        return self._post(url, body)

    def _delete(self, url, body=None):
        return self.api.client.request(url, 'DELETE', json=body)

    def _update(self, url, body):
        doc = self.api.client.request(url, 'PUT', json=body).json()
        return self._get(doc['url'])

    def _create_with_resource(self, url):
        doc = self.api.client.request(url, 'POST', basic_auth=True).json()
        return self.resource_class(self, doc)
