import warnings

from ayasdi.core import json_funcs
from ayasdi.core import message_funcs
from ayasdi.core.models import utilities
from ayasdi.core.models.gbdt_spec import GbdtSpec
from ayasdi.core.models.validation_statistics import ValidationStatistics
from ayasdi.core.models.classification_model import ClassificationModel
from ayasdi.core.models.regression_model import RegressionModel


class GBDT(ClassificationModel, RegressionModel, ValidationStatistics):
    """
    Gradient Boosting Decision Tree (GBDT) models are the best choice for high dimensional data, are robust, and easy to use. Create, retrieve, and predict with a GBDT model.
    Use static function :func:`GBDT.create` to train a model, or use
    :func:`GBDT.get_model` to retrieve an existing model.
    Given a GBDT instance, use :func:`predict_proba` or :func:`predict_values`
    to predict.
    """

    def __init__(self, connection):
        """
        Initialize GBDT

        Args:
            connection : an instance of class ayasdi.core.api.Api
        """
        ClassificationModel.__init__(self)
        RegressionModel.__init__(self)
        self.json = None
        self.__ready = None
        self.async_job = None
        self.connection = connection
        # either classification or regression
        self._kind = None

    @staticmethod
    def get_model(connection, model_id):
        """
        Retrieve model and create an instance

        Args:
            connection : an instance of class ayasdi.core.api.Api
            model_id: Model ID

        Returns:
            An instance of GBDT

        :Example:

        >>> source = connection.upload_source("./test/iris_binomial.csv")
        >>> source.sync()
        >>> import uuid
        >>> model = GBDT.create(connection, source.id,
        ...                             name='model_' + str(uuid.uuid4()),
        ...                             outcome_column_index=source.colname_to_ids['setosa'])
        >>> model_id = model.model_id
        >>> model2 = GBDT.get_model(connection, model_id)
        >>> connection.delete_source(source.id)
        """
        utilities._check_connection(connection)
        model = utilities._get_model(connection, model_id, GBDT)
        if model.type != 'GBDT':
            raise AttributeError('Model is not a GBDT (it is a ' + model.type + ').')
        return model

    @staticmethod
    def get_models(connection, scope="team"):
        """
        Retrieve all GBDT models

        Args:
            connection : an instance of class ayasdi.core.api.Api
            scope: how widely to search - takes "user" or "team". Default value is "team"

        Returns:
            List of GBDT models
        """
        utilities._check_connection(connection)
        url = connection.CORE_REQUEST_STUB + 'models?type=gbdt&scope=' + scope
        res = json_funcs._get_(connection.session, url)
        all_models = []
        for m in res['models']:
            model = GBDT(connection)
            model.__fill_body__(m)
            all_models.append(model)
        return all_models

    @staticmethod
    def _create_model(connection,
                      name,
                      data_spec,
                      model_spec,
                      outcome_column_index,
                      async_=False,
                      description=None,
                      metadata={},
                      ignore_null_outcomes=True):
        return GBDT.create(connection=connection,
                           source_id=data_spec.source_id,
                           name=name,
                           outcome_column_index=outcome_column_index,
                           column_set_id=data_spec.column_set_id,
                           group_id=data_spec.group_id,
                           spec=model_spec,
                           async_=async_,
                           description=description,
                           metadata=metadata,
                           ignore_null_outcomes=ignore_null_outcomes)

    @staticmethod
    def create(connection,
               source_id,
               name,
               outcome_column_index,
               column_set_id=None,
               group_id=None,
               spec=GbdtSpec(),
               async_=False,
               description=None,
               metadata={},
               ignore_null_outcomes=True):
        """
        Create and train random forest

        Args:
            connection : an instance of class ayasdi.core.api.Api
            source_id (string): ID of source on which to create the model
            name (string): Name of model
            outcome_column_index(int): Index of column to use as outcome/label
            column_set_id (str, optional): ID of columnset
                specifying training features
            group_id (str, optional): ID of rowgroup
                specifying training rows
            spec (GbdtSpec): a :class:`ayasdi.core.models.gbdt_spec.GbdtSpec` for passing Gbdt params
            async\_ (boolean, optional): whether to run in async mode [default=False]; if
                run in async mode, sync on the async object
            description (string, optional): user provided information about the model
            metadata (dict): Metadata for the column set stored as key-value pairs (optional).
            ignore_null_outcomes (boolean, optional): whether to exclude rows where outcome value is null

        Returns:
            An instance of GBDT
        """
        warnings.warn(message_funcs._show_labs("GBDT algorithm"))
        utilities._check_connection(connection)
        # noinspection PyProtectedMember
        ext_params = spec._ext_params or {}
        rest_args = {
            'model_type': 'gbdt',
            'model_name': name,
            'model_description': description,
            'gbdt_params': {
                'source_view': {
                    'source_id': source_id,
                    'column_set_id': column_set_id,
                    'group_id': group_id,
                    'ignore_null_outcomes': ignore_null_outcomes
                },
                'outcome_column_index': outcome_column_index,
                'gbdt_spec': spec.serialize(),
                'ext_params': ext_params
            },
            'metadata': metadata
        }

        if async_:
            url = connection.CORE_REQUEST_STUB + 'models/async'
            jobid = json_funcs._post_(connection.session,
                                      url, rest_args)
            print('Training is running in asynchronous mode.')
            print('Remember to call ready() to check status.')

            model = GBDT(connection)
            model.__set_async_job__(jobid, url)
            return model
        else:
            url = connection.CORE_REQUEST_STUB + 'models'
            res = json_funcs._post_(connection.session,
                                    url, rest_args)
            model = GBDT(connection)
            model.__fill_body__(res)
            return model

    def get_training_columns(self):
        """
        Gets the columns that were used for training the model.

        Args:
            None

        Returns:
            List of column names used for training.

        """
        if 'training_schema' in self.model_info:
            return self.model_info['training_schema']['training_column_names']
        else:
            return self.model_info['training_columns']

    def __fill_body__(self, res):
        self.__set_base_properties__(res)
        self.json = res
        self._classes = self._model_info.get('domain', None)
        self._feature_importances = self._model_info.get('feature_importances', None)
        self.__ready = True
        self._kind = self._model_info.get('params')['problemKind']

    @property
    def feature_importances(self):
        """
        Feature importances computed during training.
        A dictionary from feature name to importance value which is in [0, 1] range.

        Example:
            {u'sepal_width': 0.03461609408259392, u'petal_width': 1.0,
            u'sepal_length': 0.17813679575920105, u'petal_length': 0.8722841143608093}
        """
        return getattr(self, '_feature_importances', None)

    def get_statistics_type(self):
        if hasattr(self, '_kind') and self._kind == 'Regression':
            return RegressionModel.get_statistics_type(self)
        else:
            return ClassificationModel.get_statistics_type(self)

    @property
    def training_metrics(self):
        if 'training_metrics' in self.model_info:
            return self.model_info['training_metrics']
        else:
            return None
