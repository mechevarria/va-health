from ayasdi.core.models.logistic_regression_spec import LogisticRegressionSpec


class LinearRegressionSpec(LogisticRegressionSpec):
    """
    Specifies parameters for building linear regression model. Can be used to build
    :class:`ayasdi.core.models.ensemble_model.EnsembleModel` model.

    Args:
        See :class:`ayasdi.core.models.logistic_regression_spec.LogisticRegressionSpec` for details.
    """
    def __init__(self, intercept=True, max_iterations=0, regularization='NoPenalty', lambda_=0.0, random_seed=0,
                 epsilon=0.0001):
        super(LinearRegressionSpec, self).__init__(intercept=intercept, max_iterations=max_iterations,
                                                   regularization=regularization, lambda_=lambda_,
                                                   random_seed=random_seed, epsilon=epsilon)

    def spec_type(self):
        """returns a key used in the ensemble model request"""
        return 'linear_regression_spec'
