from ayasdi.core.models.model_spec import ModelSpec


class GbdtSpec(ModelSpec):

    """
    A Gradient Boosting Decision Tree (GBDT) spec is a class having fields as the parameters for GBDT algorithm.
    """

    def __init__(self, col_sample_rate=None, col_sample_rate_per_tree=None, grow_policy=None, learn_rate=None,
                 max_depth=None, max_leaves=None, min_nodes=None, min_split_improvement=None, number_of_trees=None,
                 random_seed=None, reg_lambda=None, sample_rate=None, tree_method=None, **kwargs):
        self._number_of_trees = number_of_trees
        self._max_depth = max_depth
        self._min_nodes = min_nodes
        self._random_seed = random_seed
        self._learn_rate = learn_rate
        self._sample_rate = sample_rate
        self._col_sample_rate = col_sample_rate
        self._col_sample_rate_per_tree = col_sample_rate_per_tree
        self._min_split_improvement = min_split_improvement
        self._tree_method = tree_method
        self._grow_policy = grow_policy
        self._max_leaves = max_leaves
        self._reg_lambda = reg_lambda
        self._ext_params = kwargs.get('_ext_params') or {}

    @property
    def number_of_trees(self):
        """ (int, optional): number of trees to train """
        return getattr(self, '_number_of_trees', None)

    @property
    def max_depth(self):
        """ (int, optional): maximum depth of a tree """
        return getattr(self, '_max_depth', None)

    @property
    def min_nodes(self):
        """ (int, optional): minimum number of data rows for a leaf """
        return getattr(self, '_min_nodes', None)

    @property
    def random_seed(self):
        """ (int, optional): a number used to initialize a pseudo random number generator """
        return getattr(self, '_random_seed', None)

    @property
    def learn_rate(self):
        """ (double, optional): after each boosting step, shrinks the feature weights to make the boosting
            process more conservative.  range 0.0 to 1.0. Default = 0.3 """
        return getattr(self, '_learn_rate', None)

    @property
    def sample_rate(self):
        """ (double, optional): Subsample ratio of the training instances. Setting it to 0.5 means that the
            algorithm would randomly sample half of the training data prior to growing trees (prevents overfitting).
            Subsampling will occur once in every boosting iteration. range: (0,1]. Default = 1 """
        return getattr(self, '_sample_rate', None)

    @property
    def col_sample_rate(self):
        """ (double, optional): subsample ratio of columns for each level. Subsampling occurs once for
            every new depth level reached in a tree, based on the specified column_set_id.
            Range of (0, 1], default = 1 """
        return getattr(self, '_col_sample_rate', None)

    @property
    def col_sample_rate_per_tree(self):
        """ (double, optional): subsample ratio of columns when constructing each tree.
            Subsampling occurs once for every tree constructed. range of (0, 1]. Default = 1. """
        return getattr(self, '_col_sample_rate_per_tree', None)

    @property
    def min_split_improvement(self):
        """ (double, optional): TMinimum loss reduction required to make a further partition
            on a leaf node of the tree. The larger this is, the more conservative the algorithm will be.
            range: [0,infinity]. Default = 0 """
        return getattr(self, '_min_split_improvement', None)

    @property
    def tree_method(self):
        """ (string, optional): The tree construction algorithm used in XGBoost.
            See description in the `reference paper <http://arxiv.org/abs/1603.02754>`_.

            Choices:
                - ``auto``: Use heuristic to choose the fastest method.
                - ``exact``: Exact greedy algorithm.
                - ``approx``: Approximate greedy algorithm using quantile sketch and gradient histogram.
                - ``hist``: Fast histogram optimized approximate greedy algorithm. It uses some performance improvements
                  such as bins caching.
                - ``gpu_exact``: GPU implementation of ``exact`` algorithm.
                - ``gpu_hist``: GPU implementation of ``hist`` algorithm. """
        return getattr(self, '_tree_method', None)

    @property
    def grow_policy(self):
        """ (string, optional): Controls a way new nodes are added to the tree. Only relevant when
            ``tree_method=hist``.

            Choices:
                - ``depthwise``: split at nodes closest to the root.
                - ``lossguide``: split at nodes with highest loss change.
            Default = ``depthwise`` """
        return getattr(self, '_grow_policy', None)

    @property
    def max_leaves(self):
        """ (int, optional): Maximum number of leaves to be added to each tree.
            Only relevant when ``grow_policy=lossguide`` """
        return getattr(self, '_max_leaves', None)

    @property
    def reg_lambda(self):
        """ (float, optional): L2 regularization term on weights. Increasing this value will make the model more
            conservative.  Default = 1. """
        return getattr(self, '_reg_lambda', None)

    def serialize(self):
        """
        Converts a :class:`GbdtSpec` object to a dictionary
        """
        return {
            'number_of_trees': self.number_of_trees,
            'max_depth': self.max_depth,
            'min_nodes': self.min_nodes,
            'random_seed': self.random_seed,
            'learn_rate': self.learn_rate,
            'sample_rate': self.sample_rate,
            'col_sample_rate': self.col_sample_rate,
            'col_sample_rate_per_tree': self.col_sample_rate_per_tree,
            'min_split_improvement': self.min_split_improvement,
            'tree_method': self.tree_method,
            'grow_policy': self.grow_policy,
            'max_leaves': self.max_leaves,
            'reg_lambda': self.reg_lambda,
            'ext_params': self._ext_params
        }

    def spec_type(self):
        """
        Returns a key used in the group classifier request
        """
        return 'gbdt_spec'
