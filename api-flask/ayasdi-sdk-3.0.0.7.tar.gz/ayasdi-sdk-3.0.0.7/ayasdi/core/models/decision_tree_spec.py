from ayasdi.core.models.model_spec import ModelSpec


class DecisionTreeSpec(ModelSpec):
    """
    A class with fields as the parameters for decision tree algorithm used in group classifier.

    Args:

        max_depth (int, optional): The maximum depth of a tree, default=5
        min_nodes (int, optional): The threshold under which a node is forced to become a leaf, default=10
    """

    @property
    def max_depth(self):
        """The maximum depth of a tree"""
        return getattr(self, '_max_depth', None)

    @property
    def min_nodes(self):
        """The threshold under which a node is forced to become a leaf"""
        return getattr(self, '_min_nodes', None)

    def __init__(self, max_depth=5, min_nodes=10):
        self._max_depth = max_depth
        self._min_nodes = min_nodes

    def serialize(self):
        """This converts a :class:`DecisionTreeSpec` object to a dictionary"""

        decision_tree_spec = {
            'max_depth': self.max_depth,
            'min_nodes': self.min_nodes
        }
        return decision_tree_spec

    def spec_type(self):
        """This returns a key used in the group classifier request"""
        return 'decision_tree_spec'
