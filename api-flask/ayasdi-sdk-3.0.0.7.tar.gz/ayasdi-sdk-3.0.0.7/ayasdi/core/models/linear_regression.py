import json

from ayasdi.core import json_funcs
from ayasdi.core.models import utilities
from ayasdi.core.models.linear_regression_statistics import LinearRegressionStatistics
from ayasdi.core.models.regression_model import RegressionModel
from ayasdi.core.models.validation_statistics import ValidationStatistics


class LinearRegression(RegressionModel, ValidationStatistics):
    """
    Create, retrieve, and predict with a linear regression model.
    Use static function :func:`LinearRegression.create` to train a model, or use
    :func:`LinearRegression.get_model` to retrieve an existing model.
    Given a LinearRegression instance, use :func:`predict_values` to predict.
    """

    def __init__(self, connection):
        """
        Initialize LinearRegression

        Args:
            connection : an instance of class ayasdi.core.api.Api
        """

        self.json = None
        self.async_job = None
        self.__coefficients = None
        self.__readable = None
        self.__ready = False
        self.connection = connection

    @staticmethod
    def get_model(connection, model_id):
        """
        Retrieve model and create an instance

        Args:
            connection : an instance of class ayasdi.core.api.Api
            model_id: Model ID

        Returns:
            An instance of LinearRegression

        :Example:

        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>>
        >>> source = connection.upload_source("./test/db_test2.txt")
        >>> source.sync()
        >>> import uuid
        >>> model = acm.LinearRegression.create(connection, source.id,
        ...                                     name='model_' + str(uuid.uuid4()),
        ...                                     outcome_column_index=source.colname_to_ids['clinical classification'])
        >>> model_id = model.model_id
        >>> model2 = LinearRegression.get_model(connection, model_id)
        """
        utilities._check_connection(connection)
        model = utilities._get_model(connection, model_id, LinearRegression)
        if model.type != 'LinearRegression':
            raise AttributeError('Model is not a linear regression (it is a ' + model.type + ').')
        return model

    def __reload(self):
        if self.model_id is None:
            raise ValueError('model_id cannot be None')
        url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id
        res = json_funcs._get_(self.connection.session, url)
        if res['type'] != 'LinearRegression':
            raise AttributeError('Model is not a linear regression (it is a ' + res['type'] + ').')
        self.__fill_body__(res)

    @staticmethod
    def get_models(connection, scope="team"):
        """
        Retrieve all LinearRegression models

        Args:
            connection : an instance of class ayasdi.core.api.Api
            scope: how widely to search - takes "user" or "team". Default value is "team"

        Returns:
            List of LinearRegression models
        """
        utilities._check_connection(connection)
        url = connection.CORE_REQUEST_STUB + 'models?type=linear_regression&scope=' + scope
        res = json_funcs._get_(connection.session, url)
        all_models = []
        for m in res['models']:
            model = LinearRegression(connection)
            model.__fill_body__(m)
            all_models.append(model)
        return all_models

    @staticmethod
    def _create_model(connection,
                      name,
                      data_spec,
                      model_spec,
                      outcome_column_index,
                      async_=False,
                      description=None,
                      metadata={},
                      ignore_null_outcomes=True):
        return LinearRegression.create(connection=connection,
                                       source_id=data_spec.source_id,
                                       name=name,
                                       outcome_column_index=outcome_column_index,
                                       column_set_id=data_spec.column_set_id,
                                       group_id=data_spec.group_id,
                                       intercept=model_spec.intercept,
                                       max_iterations=model_spec.max_iterations,
                                       regularization=model_spec.regularization,
                                       l=model_spec.lambda_,
                                       random_seed=model_spec.random_seed,
                                       epsilon=model_spec.epsilon,
                                       async_=async_,
                                       description=description,
                                       metadata=metadata,
                                       ignore_null_outcomes=ignore_null_outcomes)

    @staticmethod
    def create(connection,
               source_id,
               name,
               outcome_column_index,
               column_set_id=None,
               group_id=None,
               intercept=True,
               max_iterations=0,
               regularization='NoPenalty',
               l=0.0,
               random_seed=0,
               epsilon=0.0001,
               async_=False,
               description=None,
               metadata={},
               ignore_null_outcomes=True):
        """
        Create and train linear regression

        Args:
            connection : an instance of class ayasdi.core.api.Api
            source_id (str): ID of source on which to create the model
            name (str): Name of model
            outcome_column_index(int): Index of column to use as outcome/label
            column_set_id (str, optional): ID of columnset
                specifying training features
            group_id (str, optional): ID of rowgroup
                specifying training rows
            regularization (string, enum): type of regularization.
                Possible values: 'NoPenalty', 'L1Penalty', and 'L2Penalty' for
                'Least Squares', 'LASSO Regression', and 'Ridge Regression' respectively.
            l (double): lambda is an optional parameter which is used only
                for Ridge and LASSO regularization.
            max_iterations (int, optional): maximum number of algorithm iterations.
                If it is zero then default value from the algorithm
                is used. Currently only used in the ADMM algorithm in
                LASSO Regression, in which the default is 500 iterations.
            intercept (boolean): if True then model tries to fit an
                intercept value, otherwise intercept is assumed to be zero.
            random_seed (long, optional): a number used to initialize a pseudorandom
                number generator for some algorithms.
            epsilon (double, optional): defines a loop exit criteria in certain algorithms.
                While the algorithm attempts to find a minimum, it will
                terminate when it reaches a precision defined by epsilon.
                A smaller epsilon will increase precision (e.g. 0.0001).
            async_ (boolean, optional): whether to run in async mode [default=False]; if
                run in async mode, sync on the async object
            description (string, optional): user provided information about the model
            metadata (dict): Metadata for the column set stored as key-value pairs (optional).
            ignore_null_outcomes (boolean, optional): whether to exclude rows where outcome value is null

        Returns:
            An instance of LinearRegression

        :Example:

        >>> import time
        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>>
        >>> source = connection.upload_source('./test/db_test2.txt')
        >>> train_group = source.create_group(name='train_group_1',
        ...                                   row_indices=list(range(0, 140)))
        >>> columns_for_analysis = ["relative weight",
        ...                         "blood glucose",
        ...                         "insulin level",
        ...                         "insulin response"]
        >>> cs = source.create_column_set(column_list=columns_for_analysis, name='cs_1')
        >>> steady_state_plasma_glucose = source.colname_to_ids['steady state plasma glucose']
        >>> model = acm.LinearRegression.create(connection, source_id=source.id,
        ...                                     name='model_1',
        ...                                     outcome_column_index=steady_state_plasma_glucose,
        ...                                     column_set_id=cs['id'],
        ...                                     group_id=train_group['id'],
        ...                                     async_=True)
        Training is running in asynchronous mode.
        Remember to call ready() to check status.
        >>> while not model.ready():
        ...     time.sleep(1)
        >>> stats = model.generate_validation_statistics(source_id=source.id,
        ...                                              outcome_column_index=steady_state_plasma_glucose,
        ...                                              group_id=train_group['id'],
        ...                                              column_set_id=cs['id'])
        >>> print(stats.residual_sum_of_squares)
        335886.4849446111
        >>> print(stats.r2_score)
        0.7692681465189171
        >>> print(stats.r2_adjusted)
        0.7624316471565146
        >>> print(stats.Durbin_Watson)
        2.157991950228101
        >>> print(stats.total_sum_of_squares)
        1455743.8857142862
        """
        utilities._check_connection(connection)
        rest_args = {
            'model_type': 'linear_regression',
            'model_name': name,
            'model_description': description,
            'linear_regression_params': {
                'source_view': {
                    'source_id': source_id,
                    'column_set_id': column_set_id,
                    'group_id': group_id,
                    'ignore_null_outcomes': ignore_null_outcomes
                },
                'outcome_column_index': outcome_column_index,
                'intercept': intercept,
                'max_iterations': max_iterations,
                'regularization': regularization,
                'lambda': l,
                'random_seed': random_seed,
                'epsilon': epsilon
            },
            'metadata': metadata
        }

        if async_:
            url = connection.CORE_REQUEST_STUB + 'models/async'
            jobid = json_funcs._post_(connection.session,
                                      url, rest_args)
            print('Training is running in asynchronous mode.')
            print('Remember to call ready() to check status.')

            model = LinearRegression(connection)
            model.__set_async_job__(jobid, url)
            return model
        else:
            url = connection.CORE_REQUEST_STUB + 'models'
            res = json_funcs._post_(connection.session,
                                    url, rest_args)
            model = LinearRegression(connection)
            model.__fill_body__(res)
            return model

    def get_training_columns(self):
        """
        Gets the columns that were used for training the model.

        Args:
            None

        Returns:
            List of column names used for training.
        """
        if 'training_schema' in self.model_info:
            return self.model_info['training_schema']['training_column_names']
        else:
            return self.model_info['training_columns']

    def get_coefficients(self):
        """
        Gets the trained model coefficients including intercept and betas.

        Args:
            None

        Returns:
            Dictionary with up to two elements: 'intercept' (if present), 'betas',
            where 'betas' contains another dictionary one-based index
            (corresponding to training column) to value. For example:
            {u'intercept': 1.192083994828211,
            u'betas': {
            u'1': -0.10974146329310251,
            u'3': 0.2270013821719135,
            u'2': -0.04424044671765222,
            u'4': 0.6098941197163753}
            }
        """
        if self.__ready and self.__coefficients is None:
            self.__reload()
        return self.__coefficients

    def get_readable(self):
        """
        Gets the trained model coefficients in human readable format
        sorted by module with column names.

        Args:
            None

        Returns:
            Trained linear model formula. For example:
            1.19208399483 +6.09894e-01 * [petal_width] +2.27001e-01 * [petal_length]
            -1.09741e-01 * [sepal_length] -4.42404e-02 * [sepal_width]
        """
        if self.__ready and self.__readable is None:
            self.__reload()
        return self.__readable

    def __fill_body__(self, res):
        self.__set_base_properties__(res)
        self.json = res
        if 'model' in res:
            self.__coefficients = json.loads(res['model'])
            self.__readable = utilities.__to_readable__(self.__coefficients, self.get_training_columns())
        self.__ready = True

    def get_statistics_type(self):
        return LinearRegressionStatistics
