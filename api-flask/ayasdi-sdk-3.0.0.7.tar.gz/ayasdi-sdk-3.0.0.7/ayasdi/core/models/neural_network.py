import warnings

from ayasdi.core import json_funcs
from ayasdi.core import message_funcs
from ayasdi.core.models import utilities
from ayasdi.core.models.neural_network_spec import NeuralNetworkSpec
from ayasdi.core.models.validation_statistics import ValidationStatistics
from ayasdi.core.models.classification_model import ClassificationModel
from ayasdi.core.models.regression_model import RegressionModel


class NeuralNetwork(ClassificationModel, RegressionModel, ValidationStatistics):
    """
    Create, retrieve, and predict with a NeuralNetwork model.
    Use static function :func:`create` to train a model, or use :func:`get_model` to retrieve an existing model.
    Given a NeuralNetwork instance, use \
    :func:`predict_proba <ayasdi.core.models.classification_model.ClassificationModel.predict_proba>`, \
    :func:`predict_decisions <ayasdi.core.models.classification_model.ClassificationModel.predict_decisions> or \
    :func:`predict_values <ayasdi.core.models.regression_model.RegressionModel.predict_values>` \
    to predict.
    """

    def __init__(self, connection):
        """
        Initialize NeuralNetwork

        Args:
            connection : an instance of :class:`Api <ayasdi.core.api.Api>`
        """
        ClassificationModel.__init__(self)
        RegressionModel.__init__(self)
        self.json = None
        self.__ready = None
        self.async_job = None
        self.connection = connection
        # either classification or regression
        self._kind = None

    @staticmethod
    def get_model(connection, model_id):
        """
        Retrieve model and create an instance

        Args:
            connection : an instance of :class:`Api <ayasdi.core.api.Api>`
            model_id: Model ID

        Returns:
            An instance of :class:`NeuralNetwork`

        :Example:

        >>> source = connection.upload_source("./test/iris_binomial.csv")
        >>> source.sync()
        >>> import uuid
        >>> model = NeuralNetwork.create(connection, source.id,
        ...                              name='model_' + str(uuid.uuid4()),
        ...                              outcome_column_index=source.colname_to_ids['setosa'])
        >>> model_id = model.model_id
        >>> model2 = NeuralNetwork.get_model(connection, model_id)
        >>> connection.delete_source(source.id)
        """
        utilities._check_connection(connection)
        model = utilities._get_model(connection, model_id, NeuralNetwork)
        if model.type != 'NeuralNetwork':
            raise AttributeError('Model is not a NeuralNetwork (it is a ' + model.type + ').')
        return model

    @staticmethod
    def get_models(connection, scope="team"):
        """
        Retrieve all NeuralNetwork models

        Args:
            connection : an instance of :class:`Api <ayasdi.core.api.Api>`
            scope: how widely to search - takes "user" or "team". Default value is "team"

        Returns:
            List of :class:`NeuralNetwork` models
        """
        utilities._check_connection(connection)
        url = connection.CORE_REQUEST_STUB + 'models?type=neural_network&scope=' + scope
        res = json_funcs._get_(connection.session, url)
        all_models = []
        for m in res['models']:
            model = NeuralNetwork(connection)
            model.__fill_body__(m)
            all_models.append(model)
        return all_models

    @staticmethod
    def _create_model(connection,
                      name,
                      data_spec,
                      model_spec,
                      outcome_column_index,
                      async_=False,
                      description=None,
                      metadata={},
                      ignore_null_outcomes=True):
        return NeuralNetwork.create(connection=connection,
                                    source_id=data_spec.source_id,
                                    name=name,
                                    outcome_column_index=outcome_column_index,
                                    column_set_id=data_spec.column_set_id,
                                    group_id=data_spec.group_id,
                                    spec=model_spec,
                                    async_=async_,
                                    description=description,
                                    metadata=metadata,
                                    ignore_null_outcomes=ignore_null_outcomes)

    @staticmethod
    def create(connection,
               source_id,
               name,
               outcome_column_index,
               column_set_id=None,
               group_id=None,
               spec=NeuralNetworkSpec(),
               async_=False,
               description=None,
               metadata={},
               ignore_null_outcomes=True):
        """
        Create and train a neural network model.

        Args:
            connection : an instance of :class:`Api <ayasdi.core.api.Api>`
            source_id (string): ID of source on which to create the model
            name (string): Name of model
            outcome_column_index(int): Index of column to use as outcome/label
            column_set_id (str, optional): ID of a column set specifying training features
            group_id (str, optional): ID of a row group specifying training rows
            spec : a :class:`NeuralNetworkSpec <ayasdi.core.models.neural_network_spec.NeuralNetworkSpec>` instance \
                for passing neural network algorithm params
            async\_ (boolean, optional): whether to run in async mode [default=False]; if
                run in async mode, sync on the async object
            description (string, optional): user provided information about the model
            metadata (dict): Metadata for the column set stored as key-value pairs (optional).
            ignore_null_outcomes (boolean, optional): whether to exclude rows where outcome value is null

        Returns:
            An instance of :class:`NeuralNetwork`
        """
        warnings.warn(message_funcs._show_labs("neural network algorithm"))
        utilities._check_connection(connection)
        rest_args = {
            'model_type': 'neural_network',
            'model_name': name,
            'model_description': description,
            'neural_network_params': {
                'source_view': {
                    'source_id': source_id,
                    'column_set_id': column_set_id,
                    'group_id': group_id,
                    'ignore_null_outcomes': ignore_null_outcomes
                },
                'outcome_column_index': outcome_column_index,
                'neural_network_spec': spec.serialize(),
            },
            'metadata': metadata
        }

        if async_:
            url = connection.CORE_REQUEST_STUB + 'models/async'
            jobid = json_funcs._post_(connection.session,
                                      url, rest_args)
            print('Training is running in asynchronous mode.')
            print('Remember to call ready() to check status.')

            model = NeuralNetwork(connection)
            model.__set_async_job__(jobid, url)
            return model
        else:
            url = connection.CORE_REQUEST_STUB + 'models'
            res = json_funcs._post_(connection.session,
                                    url, rest_args)
            model = NeuralNetwork(connection)
            model.__fill_body__(res)
            return model

    def get_training_columns(self):
        """
        Gets the columns that were used for training the model.

        Returns:
            List of column names used for training.
        """
        return self.model_info['training_schema']['training_column_names']

    def __fill_body__(self, res):
        self.__set_base_properties__(res)
        self.json = res
        self._classes = self._model_info.get('domain', None)
        self._feature_importances = self._model_info.get('feature_importances', None)
        self.__ready = True
        self._kind = self._model_info.get('problemKind')

    @property
    def feature_importances(self):
        """
        Feature importances computed during training.
        A dictionary from feature name to importance value which is in [0, 1] range.

        Example:
            {u'sepal_width': 0.03461609408259392, u'petal_width': 1.0,
            u'sepal_length': 0.17813679575920105, u'petal_length': 0.8722841143608093}
        """
        return getattr(self, '_feature_importances', None)

    def get_statistics_type(self):
        if hasattr(self, '_kind') and self._kind == 'Regression':
            return RegressionModel.get_statistics_type(self)
        else:
            return ClassificationModel.get_statistics_type(self)

    @property
    def training_metrics(self):
        return self.model_info.get('training_metrics')
