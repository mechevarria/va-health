from ayasdi.core.async_jobs import AsyncJob
from ayasdi.core.models.regression_coefficient_statistics import RegressionCoefficientStatistics


class RegressionStatistics(object):
    """
    Regression statistics data
    """

    @property
    def r2_score(self):
        """
        Coefficient of determination
        """
        return getattr(self, '_r2_score', None)

    @property
    def mean_squared_error(self):
        """
        mean absolute error is the average absolute difference between predicted and original values
        """
        return getattr(self, '_mean_squared_error', None)

    @property
    def mean_absolute_error(self):
        """
        mean absolute error is the average absolute difference between predicted and original values
        """
        return getattr(self, '_mean_absolute_error', None)

    @property
    def mean_absolute_percentage_error(self):
        """
        mean absolute percentage error is the average absolute percentage difference between
        predicted and original values
        """
        return getattr(self, '_mean_absolute_percentage_error', None)

    @property
    def weighted_mean_absolute_percentage_error(self):
        """
        weighted mean absolute percentage error is the average absolute percentage difference between
        predicted and original values
        """
        return getattr(self, '_weighted_mean_absolute_percentage_error', None)

    @property
    def values(self):
        """
        List of original and predicted value pairs
        """
        return getattr(self, '_values', None)

    def __init__(self, connection):
        """
        Initialize RegressionStatistics object
        """
        self.connection = connection
        self.json = None
        self.model_type = None
        self.__ready = None
        self.async_job = None

    def __getitem__(self, key):
        return getattr(self, key)

    def __fill_body__(self, res):
        self.json = res
        self.model_type = res['model_type']
        stats = res['regression_statistics']
        for key, value in stats.items():
            setattr(self, '_' + key, value)
        self.__ready = True

        self._coefficients = self.__parse_coefficients__(stats)
        fs = stats.get('f_statistic')
        if fs is not None:
            self._f_value = fs['f']
            self._numerator_degrees_of_freedom = fs['numerator_degrees_of_freedom']
            self._denominator_degrees_of_freedom = fs['denominator_degrees_of_freedom']
        self.f_statistic = fs

    @staticmethod
    def __parse_coefficients__(stats):
        coefficients = []
        sc = stats.get('coefficients')
        if sc is not None:
            for c in sc:
                rcs = RegressionCoefficientStatistics()
                rcs.__fill_body__(c)
                coefficients.append(rcs)
        return coefficients

    def __set_async_job__(self, async_job, url):
        self.__ready = False
        self.async_job = AsyncJob(self.connection, async_job, url)

    def ready(self):
        """
        Check readiness of object
        Used as part of asynchronous call pattern.
        """
        if self.__ready:
            return True
        else:
            async_ready = self.async_job.ready()
            if async_ready:
                self.__fill_body__(self.async_job.result)
                return True
            else:
                return False

    def __repr__(self):
        return "RegressionStatistics: " + str(self.json)
