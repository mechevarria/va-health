from ayasdi.core.models.model_spec import ModelSpec


class LogisticRegressionSpec(ModelSpec):
    """
    This specifies parameters for building logistic regression model. It can be used to build :class:`GroupClassifier` model.

    Args:
        intercept (boolean, optional): If True then model tries to fit an intercept value, otherwise the intercept value
            is assumed to be zero, default=True
        max_iterations (int, optional): the maximum number of algorithm iterations. If it is zero then default value from
            the algorithm is used. default=0
        regularization (string, enum, optional): The type of regularization. Possible values: 'NoPenalty', 'L1Penalty',
            and 'L2Penalty'. default='NoPenalty
        lambda_ (double, optional): An optional parameter which is used only for Ridge and LASSO regularization.
            default=0.0
        random_seed (long, optional): A number used to initialize a pseudorandom number generator for some algorithms.
            default=0.
        epsilon (double, optional): This defines a loop exit criteria in certain algorithms. While the algorithm attempts to
            find a minimum, it will terminate when it reaches a precision defined by epsilon. A smaller epsilon will
            increase precision (e.g. 0.0001). default=0.0001
    """

    @property
    def intercept(self):
        """If True then model tries to fit an intercept value, otherwise the intercept value is assumed to be zero"""
        return getattr(self, '_intercept', None)

    @property
    def max_iterations(self):
        """The maximum number of algorithm iterations. If it is zero then default value from the algorithm is used"""
        return getattr(self, '_max_iterations', None)

    @property
    def regularization(self):
        """The type of regularization. Possible values: 'NoPenalty', 'L1Penalty', and 'L2Penalty'. default='NoPenalty"""
        return getattr(self, '_regularization', None)

    @property
    def lambda_(self):
        """An optional parameter which is used only for Ridge and LASSO regularization"""
        return getattr(self, '_lambda_', None)

    @property
    def random_seed(self):
        """A number used to initialize a pseudorandom number generator for some algorithms"""
        return getattr(self, '_random_seed', None)

    @property
    def epsilon(self):
        """
        This defines a loop exit criteria in certain algorithms. While the algorithm attempts to find a minimum, it will
        terminate when it reaches a precision defined by epsilon.
        A smaller epsilon will increase precision (e.g. 0.0001)
        """
        return getattr(self, '_epsilon', None)

    def __init__(self, intercept=True, max_iterations=0, regularization='NoPenalty', lambda_=0.0, random_seed=0,
                 epsilon=0.0001):
        self._intercept = intercept
        self._max_iterations = max_iterations
        self._regularization = regularization
        self._lambda_ = lambda_
        self._random_seed = random_seed
        self._epsilon = epsilon

    def serialize(self):
        """This converts a :class:`LogisticRegressionSpec` object to a dictionary"""

        logistic_regression_spec = {
            'intercept': self.intercept,
            'max_iterations': self.max_iterations,
            'regularization': self.regularization,
            'lambda': self.lambda_,
            'random_seed': self.random_seed,
            'epsilon': self.epsilon
        }
        return logistic_regression_spec

    def spec_type(self):
        """This returns a key used in the group classifier request"""
        return 'logistic_regression_spec'
