from ayasdi.core.models.model_spec import ModelSpec


class NeuralNetworkSpec(ModelSpec):

    """
    A class with fields as the parameters for neural network algorithm.

    Args:
        hidden_layer_sizes (list of ints): The number of neurons in the hidden layer. If this has two elements, then
            this is the number of neurons in two separate layers. default=[100, 100].
        activation (str): Activation function - Options are: 'tanh', 'tanh_with_dropout', 'rectifier',
            'rectifier_with_dropout', 'maxout', 'maxout_with_dropout', exp_rectifier, exp_rectifier_with_dropout.
             default='rectifier'.
        alpha (float): L2 penalty (regularization term) parameter. default=0.0001.
        batch_size (int): Size of minibatches for stochastic optimizers. default=1.
        adaptive (bool):  Enable adaptive learning rate algorithm (ADADELTA) or not. Please refer to \
            `H2O documentation <https://docs.h2o.ai/h2o/latest-stable/h2o-docs/data-science/deep-learning.html>`_ for \
            details. default=True.
        beta (float): Exponential decay rate for adaptive learning. Only used when adaptive=True. default=0.9.
        epsilon (float): Value for numerical stability. Only used when adaptive=True. default=1.0e-8.
        learning_rate_init (float): The initial learning rate used. It controls the step-size in updating the weights,
            which is active when adaptive is False. default=0.001.
        max_iter (int): Maximum number of iterations. The solver iterates until convergence (determined by tol) or this
            number of iterations. default=200.
        shuffle (bool): Whether to shuffle samples in each iteration. default=False.
        random_seed (int): Determines random number generation for weights and bias initialization. default=None where
        a seed will be generated randomly.
        tol (float): Tolerance for the optimization. Please refer to \
            `H2O documentation <https://docs.h2o.ai/h2o/latest-stable/h2o-docs/data-science/deep-learning.html>`_ for \
            details. default=0.0001.
        momentum (float): Momentum for gradient descent update. Should be between 0 and 1. default=0.9.
        nesterov_momentum (bool): Whether to use Nesterov’s momentum. default=True.
        early_stopping (bool): Whether to use early stopping to terminate training when validation score is not
            improving. default=True.
        validation_fraction (float): The proportion of training data to set aside as validation set for early stopping.
            Must be between 0 and 1. Only used if early_stopping is True. default=0.1.
        n_iter_no_change (int): Maximum number of iterations to not meet tol improvement. Only used if early_stopping is
            True. default=10.
        reproducible (bool): Force reproducibility on small data (will be slow - only uses 1 thread). default=False.
        ext_params (dict): This will be a dictionary that internal users can use to pass parameters directly to the \
            underlying H20 library. These parameters will need to have H20 readable parameter names. Please refer to \
            `H20 documentation <https://docs.h2o.ai/h2o/latest-stable/h2o-docs/data-science/deep-learning.html>`_ for \
            details. Any parameters specified in this dictionary will override the other input parameters provided
            above.

    """

    def __init__(self, hidden_layer_sizes=[100, 100], activation='rectifier', alpha=0.0001, batch_size=1, adaptive=True,
                 beta=0.9, epsilon=1.0e-8, learning_rate_init=0.001, max_iter=200, shuffle=False, random_seed=None,
                 tol=0.0001, momentum=0.9, nesterov_momentum=True, early_stopping=True, validation_fraction=0.1,
                 n_iter_no_change=10, reproducible=False, ext_params=None):
        self._hidden_layer_sizes = hidden_layer_sizes
        self._activation = activation
        self._alpha = alpha
        self._batch_size = batch_size
        self._adaptive = adaptive
        self._beta = beta
        self._epsilon = epsilon
        self._learning_rate_int = learning_rate_init
        self._max_iter = max_iter
        self._shuffle = shuffle
        self._random_seed = random_seed
        self._tol = tol
        self._momentum = momentum
        self._nesterov_momentum = nesterov_momentum
        self._early_stopping = early_stopping
        self._validation_fraction = validation_fraction
        self._n_iter_no_change = n_iter_no_change
        self._reproducible = reproducible
        self._ext_params = ext_params

    @property
    def hidden_layer_sizes(self):
        return getattr(self, '_hidden_layer_sizes', None)

    @property
    def activation(self):
        return getattr(self, '_activation', None)

    @property
    def alpha(self):
        return getattr(self, '_alpha', None)

    @property
    def batch_size(self):
        return getattr(self, '_batch_size', None)

    @property
    def adaptive(self):
        return getattr(self, '_adaptive', None)

    @property
    def beta(self):
        return getattr(self, '_beta', None)

    @property
    def epsilon(self):
        return getattr(self, '_epsilon', None)

    @property
    def learning_rate_init(self):
        return getattr(self, '_learning_rate_init', None)

    @property
    def max_iter(self):
        return getattr(self, '_max_iter', None)

    @property
    def shuffle(self):
        return getattr(self, '_shuffle', None)

    @property
    def random_seed(self):
        return getattr(self, '_random_seed', None)

    @property
    def tol(self):
        return getattr(self, '_tol', None)

    @property
    def momentum(self):
        return getattr(self, '_momentum', None)

    @property
    def nesterov_momentum(self):
        return getattr(self, '_nesterov_momentum', None)

    @property
    def early_stopping(self):
        return getattr(self, '_early_stopping', None)

    @property
    def validation_fraction(self):
        return getattr(self, '_validation_fraction', None)

    @property
    def n_iter_no_change(self):
        return getattr(self, '_n_iter_no_change', None)

    @property
    def reproducible(self):
        return getattr(self, '_reproducible', None)

    @property
    def ext_params(self):
        return getattr(self, '_ext_params', None)

    def serialize(self):
        """
        Converts a :class:`NeuralNetworkSpec` object to a dictionary.
        """
        return {
            'hidden_layer_sizes': self.hidden_layer_sizes,
            'activation': self.activation,
            'alpha': self.alpha,
            'batch_size': self.batch_size,
            'adaptive': self.adaptive,
            'beta': self.beta,
            'epsilon': self.epsilon,
            'learning_rate_init': self.learning_rate_init,
            'max_iter': self.max_iter,
            'shuffle': self.shuffle,
            'random_seed': self.random_seed,
            'tol': self.tol,
            'momentum': self.momentum,
            'nesterov_momentum': self.nesterov_momentum,
            'early_stopping': self.early_stopping,
            'validation_fraction': self.validation_fraction,
            'n_iter_no_change': self.n_iter_no_change,
            'reproducible': self.reproducible,
            'ext_params': self.ext_params
        }

    def spec_type(self):
        """
        Returns a key used in the group classifier request
        """
        return 'neural_network_spec'
