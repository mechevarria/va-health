class Point2D:
    """ A two dimensional point used in :class:`Curve2D <ayasdi.core.models.curve2d.Curve2D>`"""

    def __init__(self, x=0.0, y=0.0):
        """
        Initializes a point
        :param x: x coordinate
        :param y: y coordinate
        """
        self._x = x
        self._y = y

    @property
    def x(self):
        """ x coordinate """
        return self._x

    @property
    def y(self):
        """ y coordinate """
        return self._y

    def __getitem__(self, key):
        return getattr(self, key, None)

    def __repr__(self):
        return "(%.5f,%.5f)" % (self.x, self.y)
