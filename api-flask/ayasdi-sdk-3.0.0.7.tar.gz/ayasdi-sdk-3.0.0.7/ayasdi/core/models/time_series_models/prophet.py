from ayasdi.core.models import utilities
from ayasdi.core.data_point_list import DataPointList
from ayasdi.core.models.time_series_models.prophet_spec import ProphetSpec
from ayasdi.core.models.time_series_models.time_series_model_base import TimeSeriesModelBase
from ayasdi.core import json_funcs

import json


class Prophet:
    """
    Create a Prophet model
    """

    def __init__(self, connection):
        """
        Initialize a :class:`Prophet` object.

        Args:
            connection : An instance of :class:`Api <ayasdi.core.api.Api>`.
        """
        self.connection = connection
        self.json = None

    @staticmethod
    def create(connection,
               source_id,
               name,
               endogenous_column_index,
               exogenous_column_set_id=None,
               date_time_column_index=None,
               partition_key_column_set_id=None,
               group_id=None,
               model_spec=ProphetSpec(),
               async_=False):
        """
        Create and train a model of ProphetParentModel type consisting of a list of prophet models for all primary keys
        in the primary key columns.

        Args:
            connection : An instance of :class:`Api <ayasdi.core.api.Api>`.
            source_id (string): ID of source on which to create the model.
            name (string): The name of a model.
            endogenous_column_index(int): Index of column containing the time series data.
            exogenous_column_set_id (str, optional): ID of column set specifying exogenous columns.
            date_time_column_index (int, optional): Index of column containing dates.
            partition_key_column_set_id (str, optional): ID of column set specifying partition keys.
            group_id (str, optional): ID of rowgroup specifying training rows.
            model_spec: A :class:`ProphetSpec <ayasdi.core.models.time_series_models.prophet_spec.ProphetSpec>` object \
                for passing prophet algorithm parameters.
            async\_ (boolean, optional): Whether to run in async mode [default=False]; if run in async mode, sync on the
                async object.

        Returns:
            An instance of :class:`ProphetParentModel`.
        """
        utilities._check_connection(connection)
        rest_args = {
            'model_type': 'prophet',
            'model_name': name,
            'prophet_params': {
                'source_id': source_id,
                'endogenous_column_index': endogenous_column_index,
                'date_time_column_index': date_time_column_index,
                'exogenous_column_set_id': exogenous_column_set_id,
                'partition_key_column_set_id': partition_key_column_set_id,
                'group_id': group_id,
                'prophet_spec': model_spec.serialize(),
            },
        }

        if async_:
            url = connection.CORE_REQUEST_STUB + 'time_series_models/async'
            jobid = json_funcs._post_(connection.session, url, rest_args)
            print('Prophet training is running in asynchronous mode.')
            print('Remember to call ready() to check status.')

            model = ProphetParentModel(connection)
            model.__set_async_job__(jobid, url)
            return model
        else:
            url = connection.CORE_REQUEST_STUB + 'time_series_models'
            res = json_funcs._post_(connection.session, url, rest_args)
            model = ProphetParentModel(connection)
            model.__fill_body__(res)
            return model

    def forecast(self, n_steps=None, data_spec=None):
        """
        Forecast the time series with the exogenous data provided by data_spec.

        Args:
            n_steps (int): Number of forecasts to make. Not required if data_spec is provided.
            data_spec (:class:`DataSpec <ayasdi.core.data_spec.DataSpec>`) : Object that encapsulates the exogenous
                data.

        Returns:
            A dictionary containing 'lower_values', 'mean_values', 'upper_values' and 'epochs' for the time series
            forecast.

        >>> import uuid
        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models.time_series_models as tsm
        >>>
        >>> source = connection.upload_source("./test/time_series_wpi.csv")
        >>> source.sync()
        >>> model = tsm.Prophet.create(connection, name=str(uuid.uuid4()),
        ...                            source_id=source.id, endogenous_column_index=0, date_time_column_index=1)
        >>> forecast = model.submodels[0].forecast(n_steps=10)
        >>> connection.delete_source(source.id) #ignore-in-doc
        """
        if data_spec is None and self._use_exogenous():
            raise ValueError(
                "Must provide the data_spec for exogenous data since the model is trained with exogenous data")
        if isinstance(data_spec, list):
            data_spec = DataPointList(data_spec)

        request = {
            u'n_steps': n_steps,
            u'data_spec': None if data_spec is None else data_spec.serialize()
        }

        url = self.connection.CORE_REQUEST_STUB + 'time_series_models/' + self.model_id + '/forecast'
        response = json_funcs._post_(self.connection.session, url, request)
        return response

    def forecast_without_exog(self, n_steps=None):
        """
        Forecast the time series without the exogenous data provided. A fake exogenous data is provided on the backend,
        based on the exogenous data used in the model training.

        Args:
            n_steps (int): Number of forecasts to make. The backend will give a number of forecast if it is not provided.

        Returns:
            A dictionary containing 'lower_values', 'mean_values', 'upper_values' and 'epochs' for the time series
            forecast.

        >>> import uuid
        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models.time_series_models as tsm
        >>>
        >>> source = connection.upload_source("./test/time_series_wpi.csv")
        >>> source.sync()
        >>> model = tsm.Prophet.create(connection, name=str(uuid.uuid4()),
        ...                            source_id=source.id, endogenous_column_index=0, date_time_column_index=1)
        >>> forecast = model.submodels[0].forecast_without_exog(n_steps=10)
        >>> connection.delete_source(source.id) #ignore-in-doc
        """
        request = {
            u'n_steps': n_steps,
            u'without_exog': True
        }

        url = self.connection.CORE_REQUEST_STUB + 'time_series_models/' + self.model_id + '/forecast'
        response = json_funcs._post_(self.connection.session, url, request)
        return response

    def _use_exogenous(self):
        return 'exogenous_column_set_id' in self.model_info

    def __fill_body__(self, res):
        self._model_id = res['model_id']
        self._parent_model_id = res['parent_model_id']
        self._partition_key = json.loads(res.get('partition_key'))
        self._model_location = res['model_location']
        self._model_info = json.loads(res['model_info'])
        self._creation_time = utilities.__to_datetime__(res.get('create_timestamp'))
        self._update_time = utilities.__to_datetime__(res.get('update_timestamp'))
        self.json = res

    @property
    def model_id(self):
        """
        A uuid string to uniquely identify the model.
        """
        return self._model_id

    @property
    def parent_model_id(self):
        """
        The parent model ID. See :func:`submodels <ProphetParentModel.submodels>`.
        """
        return self._parent_model_id

    @property
    def model_info(self):
        """
        Contains some basic information of the model such as training_metrics, feature_importance, frequency.
        """
        return self._model_info

    @property
    def training_metrics(self):
        """
        Contains the training errors 'mean_squared_error', 'mean_absolute_error', 'median_absolute_error',
        'mean_absolute_percentage_error' and 'r_squared'.
        """
        return self.model_info['training_metrics']

    @property
    def summary(self):
        """
        A summary of the model characteristics.
        """
        return self.model_info['model_summary']

    @property
    def feature_importance(self):
        """
        Exogenous Feature importances computed during training.
        A dictionary from exogenous variable name to importance value which is in [0, 1] range, or None if no exogenous
        variables are used in the training.

        Example:
            {u'sepal_width': 0.03461609408259392, u'petal_width': 1.0,
            u'sepal_length': 0.17813679575920105, u'petal_length': 0.8722841143608093}
        """
        return self.model_info.get('feature_importance')

    @property
    def frequency(self):
        """
        Time series dates frequency.
        """
        return self.model_info.get('frequency')

    @property
    def partition_key(self):
        """
        Used to partition the time series data into different groups to train different models.
        """
        return self._partition_key

    @property
    def model_location(self):
        """
        HDFS file location for the model.
        """
        return self._model_location


class ProphetParentModel(TimeSeriesModelBase):
    """
    A class to wrap the trained Prophet submodels.
    """
    def __init__(self, connection):
        """
        Initialize a :class:`ProphetParentModel` object.

        Args:
            connection : An instance of :class:`Api <ayasdi.core.api.Api>`.
        """
        self.json = None
        self._submodels = None
        self._ready = None
        self.async_job = None
        self.connection = connection

    @staticmethod
    def get_model(connection, model_id):
        """
        Retrieve a parent model and create an instance.

        Args:
            connection : An instance of :class:`Api <ayasdi.core.api.Api>`
            model_id: The parent model ID.

        Returns:
            An instance of :class:`ProphetParentModel`.

        :Example:

        >>> import uuid
        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models.time_series_models as tsm
        >>>
        >>> source = connection.upload_source("./test/time_series_wpi.csv")
        >>> source.sync()
        >>> model = tsm.Prophet.create(connection, name=str(uuid.uuid4()),
        ...                            source_id=source.id, endogenous_column_index=0, date_time_column_index=1)
        >>> model_id = model.model_id
        >>> model2 = tsm.ProphetParentModel.get_model(connection, model_id)
        >>> connection.delete_source(source.id) #ignore-in-doc
        """
        model = utilities._get_time_series_parent_model(connection, model_id, ProphetParentModel)
        if model.type != 'Prophet':
            raise AttributeError('Model is not Prophet (it is a ' + model.type + ').')
        return model

    def __fill_body__(self, res):
        self.__set_base_properties__(res)
        self.json = res
        self._model_params = res['model_params']
        self._submodels = ProphetParentModel.__fill_submodels__(res['submodels'], self.connection)
        self._ready = True

    @staticmethod
    def __fill_submodels__(results, connection):
        submodels = []
        for result in results:
            submodel = Prophet(connection)
            submodel.__fill_body__(result)
            submodels.append(submodel)
        return submodels

    @property
    def submodels(self):
        """
        The submodels are the models which we can run forecast with. We group the submodels together under a same parent
        model since they share same model specs but are trained with different parts of the data on the same source
        file.

        Returns:
            A list of :class:`Prophet` objects.
        """
        return self._submodels
