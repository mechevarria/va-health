import json

from ayasdi.core.models import utilities
from ayasdi.core.async_jobs import AsyncJob


class TimeSeriesModelBase(object):
    """Base class with common properties.
    """

    @property
    def name(self):
        """
        Name of the model.
        """
        return getattr(self, '_name', None)

    @property
    def type(self):
        """
        Type of the model.
        """
        return getattr(self, '_type', None)

    @property
    def description(self):
        """
        Description of the model.
        """
        return getattr(self, '_description', None)

    @property
    def model_id(self):
        """
        System wide unique identifier of the model.
        """
        return getattr(self, '_model_id', None)

    @property
    def model_info(self):
        """
        Additional information in the form of a dictionary specific to the model type.
        """
        return getattr(self, '_model_info', None)

    @property
    def creation_time(self):
        """
        Creation datetime.
        """
        return getattr(self, '_creation_time', None)

    @property
    def update_time(self):
        """
        Last update datetime.
        """
        return getattr(self, '_update_time', None)

    @staticmethod
    def delete_model(connection, model_id):
        """
        Delete a time series parent model as well as all its submodels.

        Args:
            connection : An instance of :class:`Api <ayasdi.core.api.Api>`.
            model_id (str): Model identifier

        :Example:

        >>> import uuid
        >>> import ayasdi.core.models.time_series_models as tsm
        >>> source = connection.upload_source("./test/time_series_wpi.csv")
        >>> source.sync()
        >>> # create a SarimaxParentModel instance.
        >>> model = tsm.Sarimax.create(connection, name=str(uuid.uuid4()),
        ...                            source_id=source.id, endogenous_column_index=0, date_time_column_index=1)
        >>> connection.delete_source(source.id) #ignore-in-doc
        >>> TimeSeriesModelBase.delete_model(connection, model.model_id)
        """
        utilities._delete_time_series_parent_model(connection, model_id)

    def delete(self):
        """
        Delete a time series parent model as well as all its submodels.

        :Example:

        >>> import uuid
        >>> import ayasdi.core.models.time_series_models as tsm
        >>> source = connection.upload_source("./test/time_series_wpi.csv")
        >>> source.sync()
        >>> # create a SarimaxParentModel instance.
        >>> model = tsm.Sarimax.create(connection, name=str(uuid.uuid4()),
        ...                            source_id=source.id, endogenous_column_index=0, date_time_column_index=1)
        >>> connection.delete_source(source.id) #ignore-in-doc
        >>> model.delete()
        """
        TimeSeriesModelBase.delete_model(self.connection, self.model_id)

    def __set_base_properties__(self, res):
        self._name = res.get('name')
        self._type = res.get('type')
        self._description = res.get('description')
        self._model_id = res.get('model_id')
        self._model_info = json.loads(res['model_info'])

        self.version = res.get('version')
        self.source_id = res.get('source_id')

        self._creation_time = utilities.__to_datetime__(res.get('create_timestamp'))
        self._update_time = utilities.__to_datetime__(res.get('update_timestamp'))

    def ready(self):
        """
        Check readiness of the object.
        Used as part of an asynchronous call pattern.
        """
        if self._ready:
            return True
        else:
            async_ready = self.async_job.ready()
            if async_ready:
                self.__fill_body__(self.async_job.result)
                return True
            else:
                return False

    def __set_async_job__(self, async_job, url):
        self._ready = False
        self.async_job = AsyncJob(self.connection, async_job, url)
