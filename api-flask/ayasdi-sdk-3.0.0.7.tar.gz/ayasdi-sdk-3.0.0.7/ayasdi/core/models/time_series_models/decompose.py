from ayasdi.core import json_funcs
from ayasdi.core.async_jobs import AsyncJob
from ayasdi.core.models import utilities


class TSDecompose:
    """
    Decompose provides time series data into Seasonal, Trend, and Residual components using StatsModel Time Series Decompose.
    """

    def __init__(self, connection):
        """
        Initialize a :class:`TSDecompose` object.

        Args:
            connection : An instance of :class:`Api <ayasdi.core.api.Api>`.
        """
        self.json = None
        self.__ready = None
        self.async_job = None
        self.connection = connection

    @staticmethod
    def create(connection,
               source_id,
               endogenous_column_index,
               date_time_column_index=None,
               group_id=None,
               async_=False):
        """
        Decompose the time series data's all primary keys in the primary columns.

        Args:
            connection : An instance of :class:`Api <ayasdi.core.api.Api>`.
            source_id (string): ID of source on which to create the model.
            endogenous_column_index(int): Index of column containing the time series data.
            date_time_column_index (int, optional): Index of column containing dates.
            group_id (str, optional): ID of rowgroup specifying training rows.
            async\_ (boolean, optional): Whether to run in async mode [default=False]; if run in async mode, sync on the
                async object.

        Returns:
            A dictionary of partition keys containing decomposition data.
        """
        utilities._check_connection(connection)

        rest_args = {
            'src_id': source_id,
            'target_col_idx': endogenous_column_index,
            'datetime_col_idx': date_time_column_index,
            'group_id': group_id
        }
        model = TSDecompose(connection)

        if async_:
            url = connection.CORE_REQUEST_STUB + 'time_series_models/decompose/async'
            jobid = json_funcs._post_(connection.session, url, rest_args)
            print('Time series decompose is running in asynchronous mode.')
            print('Remember to call ready() to check status and then call retrieve_data() if ready.')
            model.__set_async_job__(jobid, url)
            return model
        else:
            url = connection.CORE_REQUEST_STUB + 'time_series_models/decompose'
            res = json_funcs._post_(connection.session, url, rest_args)
            model.json = res
            return model

    def __set_async_job__(self, async_job, url):
        self.__ready = False
        self.async_job = AsyncJob(self.connection, async_job, url)

    def ready(self):

        """
        Check readiness of object.
        Used as part of asynchronous call pattern.
        """
        if self.__ready:
            return True
        else:
            if self.async_job.ready():
                self.__fill_body__(self.async_job.result)
                return True
            else:
                return False

    def __fill_body__(self, res):
        self.json = res
        self.__ready = True
