class ProphetSpec:
    """
    A class with fields as the parameters for Prophet.

    Args:
        growth: String 'linear' or 'logistic' to specify a linear or logistic trend.
        n_changepoints: Number of potential changepoints to include.
        changepoint_range: Proportion of history in which trend changepoints will be estimated. 
            Defaults to 0.8 for the first 80%.
        yearly_seasonality: Fit yearly seasonality. Can be 'auto', True, False.
        weekly_seasonality: Fit weekly seasonality. Can be 'auto', True, False.
        daily_seasonality: Fit daily seasonality. Can be 'auto', True, False.
        seasonality_mode: 'additive' (default) or 'multiplicative'.
        seasonality_prior_scale: Parameter modulating the strength of the seasonality model. Larger values allow 
            the model to fit larger seasonal fluctuations, smaller values dampen the seasonality.
        holidays_prior_scale: Parameter modulating the strength of the holiday components model, 
            unless overridden in the holidays input.
        changepoint_prior_scale: Parameter modulating the flexibility of the automatic changepoint selection. 
            Large values will allow many changepoints, small values will allow few changepoints.
        mcmc_samples: Integer, if greater than 0, will do full Bayesian inference with the specified number of 
            Markov chain Monte Carlo (MCMC) samples. If 0, it will do maximum a posteriori probability (MAP) estimation.
        interval_width: Float, width of the uncertainty intervals provided for the forecast. If mcmc_samples=0, 
            this will be only the uncertainty in the trend using the MAP estimate of the extrapolated generative
            model. If mcmc.samples>0, this will be integrated into all model parameters, 
            which will include uncertainty in seasonality.
        uncertainty_samples: Number of simulated draws used to estimate uncertainty intervals. Setting this value to 
            0 or False will disable uncertainty estimation and speed up the calculation.

    """

    def __init__(self, growth='linear', n_changepoints=25, changepoint_range=0.8, yearly_seasonality='auto', 
                 weekly_seasonality='auto', daily_seasonality='auto', seasonality_mode='additive', 
                 seasonality_prior_scale=10.0, holidays_prior_scale=10.0, changepoint_prior_scale=10.0,
                 mcmc_samples=0, interval_width=0.8, uncertainty_samples=1000):
        
        self._growth = growth
        self._n_changepoints = n_changepoints
        self._changepoint_range = changepoint_range
        self._yearly_seasonality = yearly_seasonality
        self._weekly_seasonality = weekly_seasonality
        self._daily_seasonality = daily_seasonality
        self._seasonality_mode = seasonality_mode
        self._seasonality_prior_scale = seasonality_prior_scale
        self._holidays_prior_scale = holidays_prior_scale
        self._changepoint_prior_scale = changepoint_prior_scale
        self._mcmc_samples = mcmc_samples
        self._interval_width = interval_width
        self._uncertainty_samples = uncertainty_samples
   

    @property
    def growth(self):
        return getattr(self, '_growth', None)

    @property
    def n_changepoints(self):
        return getattr(self, '_n_changepoints', None)

    @property
    def changepoint_range(self):
        return getattr(self, '_changepoint_range', None)

    @property
    def yearly_seasonality(self):
        return getattr(self, '_yearly_seasonality', None)

    @property
    def weekly_seasonality(self):
        return getattr(self, '_weekly_seasonality', None)

    @property
    def daily_seasonality(self):
        return getattr(self, '_daily_seasonality', None)

    @property
    def seasonality_mode(self):
        return getattr(self, '_seasonality_mode', None)

    @property
    def seasonality_prior_scale(self):
        return getattr(self, '_seasonality_prior_scale', None)

    @property
    def holidays_prior_scale(self):
        return getattr(self, '_holidays_prior_scale', None)

    @property
    def changepoint_prior_scale(self):
        return getattr(self, '_changepoint_prior_scale', None)

    @property
    def mcmc_samples(self):
        return getattr(self, '_mcmc_samples', None)

    @property
    def interval_width(self):
        return getattr(self, '_interval_width', None)

    @property
    def uncertainty_samples(self):
        return getattr(self, '_uncertainty_samples', None)

    def serialize(self):
        """
        Converts a :class:`ProphetSpec` object to a dictionary.
        """
        return {
            'growth': self.growth,
            'n_changepoints': self.n_changepoints,
            'changepoint_range': self.changepoint_range,
            'yearly_seasonality': self.yearly_seasonality,
            'weekly_seasonality': self.weekly_seasonality,
            'daily_seasonality': self.daily_seasonality,
            'seasonality_mode': self.seasonality_mode,
            'seasonality_prior_scale': self.seasonality_prior_scale,
            'holidays_prior_scale': self.holidays_prior_scale,
            'changepoint_prior_scale': self.changepoint_prior_scale,
            'mcmc_samples': self.mcmc_samples,
            'interval_width': self.interval_width,
            'uncertainty_samples': self.uncertainty_samples,
        }

    def spec_type(self):
        """
        Returns a key used in the time series model training request.
        """
        return 'prophet_spec'
