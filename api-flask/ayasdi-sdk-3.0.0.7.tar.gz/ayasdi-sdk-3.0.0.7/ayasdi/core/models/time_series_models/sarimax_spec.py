class SarimaxSpec:
    """
    A class with fields as the parameters for Sarimax
    (Seasonal AutoRegressive Integrated Moving Averages with eXogenous regressors) algorithm. See \
    `Sarimax <https://www.statsmodels.org/dev/statespace.html#statespace>`_ for details.

    Args:
        order (tuple): The (p,d,q) order of the model for the number of autoregressive (AR) parameters, differences, and
            moving average (MA) parameters. `d` must be an integer indicating the integration order of the process,
            while `p` and `q` are lists giving specific AR and MA lags to include. Default=([1, 1, 1],1,[1, 1, 1]).
        seasonal_order (tuple): The (P,D,Q,s) order of the seasonal component of the model for the AR parameters,
            differences, MA parameters, and periodicity. `D` must be an integer indicating the integration order of the
            process, while `P` and `Q` are lists giving specific AR and MA lags to include. `s` is an integer giving the
            periodicity (number of periods in a season), often it is 4 for quarterly data or 12 for monthly data. An
            example is `([1, 1], 1, [1, 1, 0, 1], 12)`. Default=None, meaning no seasonal effect.
        trend (tuple): Defines the deterministic trend polynomial. For example, `(1,1,0,1)` denotes \
            :math:`a + bt + ct^3`. Default=(1, 1).
        measurement_error (bool): Whether or not to assume the endogenous values were measured with error. Default=False
        time_varying_regression (bool): Used when `exogenous values` are provided, whether or not coefficients on the
            exogenous regressors are allowed to vary over time. Default=False.
        mle_regression (bool): Whether or not to use estimation of the regression coefficients for the exogenous
            variables as part of maximum likelihood estimation or through the Kalman filter
            (i.e., recursive least squares). If `time_varying_regression` is True, this must be set to False.
            Default=True.
        simple_differencing (bool): Whether or not to use partially conditional maximum likelihood estimation. If True,
            differencing is performed prior to estimation, which discards the first :math:`s D + d` initial rows but
            results in a smaller state-space formulation. If False, the full Sarimax model is put in state-space form so
            that all data points can be used in estimation. Default=False.
        enforce_stationarity (bool): Whether or not to transform the AR parameters to enforce stationarity in the
            autoregressive component of the model. Default=True.
        enforce_invertibility (bool): Whether or not to transform the MA parameters to enforce invertibility in the
            moving average component of the model. Default=True.
        hamilton_representation (bool): Whether or not to use the Hamilton representation of an
            autoregressive moving average (ARMA) process (if True) or the Harvey representation (if False).
            Default=False.
        concentrate_scale (bool): Whether or not to concentrate the scale (variance of the error term) out of the
            likelihood. This reduces the number of parameters estimated by maximum likelihood by one, but standard
            errors will then not be available for the scale parameter. Default=False.
        trend_offset (int): The offset at which to start time trend values. Default=1. Typically this is only set when the
            model is created by extending a previous dataset.
        use_exact_diffuse (bool): Whether or not to use exact diffuse initialization for non-stationary states.
            Default=False meaning approximate diffuse initialization is used.
        freq (str, optional): The frequency of the time series in the form of a Pandas offset string. See
            `Pandas offset <https://pandas.pydata.org/pandas-docs/stable/user_guide/timeseries.html>`_ for details. \
            Default=None
        missing (str): Available options are 'none', 'drop', and 'raise'. If 'none', no nan checking is done. If 'drop',
            any observations with nans are dropped. If 'raise', an error is raised. Default='none'.

    """

    def __init__(self, order=([1, 1, 1], 1, [1, 1, 1]), seasonal_order=None, trend=None, measurement_error=False,
                 time_varying_regression=False, mle_regression=True, simple_differencing=False,
                 enforce_stationarity=True, enforce_invertibility=True, hamilton_representation=False,
                 concentrate_scale=False, trend_offset=1, use_exact_diffuse=False, freq=None, missing='none'):
        if order is None:
            order = ([], 0, [])
        if not isinstance(order, tuple) or len(order) != 3:
            raise ValueError('`order` argument must be a tuple with three elements.')
        if seasonal_order is None:
            seasonal_order = ([], 0, [], 0)
        if not isinstance(seasonal_order, tuple) or len(seasonal_order) != 4:
            raise ValueError('`seasonal_order` argument must be a tuple with four elements.')

        self._order = order
        self._seasonal_order = seasonal_order
        self._trend = trend
        self._measurement_error = measurement_error
        self._time_varying_regression = time_varying_regression
        self._mle_regression = mle_regression
        self._simple_differencing = simple_differencing
        self._enforce_stationarity = enforce_stationarity
        self._enforce_invertibility = enforce_invertibility
        self._hamilton_representation = hamilton_representation
        self._concentrate_scale = concentrate_scale
        self._trend_offset = trend_offset
        self._use_exact_diffuse = use_exact_diffuse
        self._freq = freq
        self._missing = missing

    @property
    def order(self):
        return getattr(self, '_order', None)

    @property
    def seasonal_order(self):
        return getattr(self, '_seasonal_order', None)

    @property
    def trend(self):
        return getattr(self, '_trend', None)

    @property
    def time_varying_regression(self):
        return getattr(self, '_time_varying_regression', None)

    @property
    def mle_regression(self):
        return getattr(self, '_mle_regression', None)

    @property
    def simple_differencing(self):
        return getattr(self, '_simple_differencing', None)

    @property
    def enforce_stationarity(self):
        return getattr(self, '_enforce_stationarity', None)

    @property
    def enforce_invertibility(self):
        return getattr(self, '_enforce_invertibility', None)

    @property
    def hamilton_representation(self):
        return getattr(self, '_hamilton_representation', None)

    @property
    def concentrate_scale(self):
        return getattr(self, '_concentrate_scale', None)

    @property
    def trend_offset(self):
        return getattr(self, '_trend_offset', None)

    @property
    def use_exact_diffuse(self):
        return getattr(self, '_use_exact_diffuse', None)

    @property
    def freq(self):
        return getattr(self, '_freq', None)

    @property
    def missing(self):
        return getattr(self, '_missing', None)

    def serialize(self):
        """
        Converts a :class:`SarimaxSpec` object to a dictionary.
        """
        return {
            'ar_order': self.order[0],
            'diff': self.order[1],
            'ma_order': self.order[2],
            'seasonal_ar_order': self.seasonal_order[0],
            'seasonal_diff': self.seasonal_order[1],
            'seasonal_ma_order': self.seasonal_order[2],
            'seasonal_periods': self.seasonal_order[3],
            'trend': self.trend,
            'measurement_error': self._measurement_error,
            'time_varying_regression': self.time_varying_regression,
            'mle_regression': self.mle_regression,
            'simple_differencing': self.simple_differencing,
            'enforce_stationarity': self.enforce_stationarity,
            'enforce_invertibility': self.enforce_invertibility,
            'hamilton_representation': self.hamilton_representation,
            'concentrate_scale': self.concentrate_scale,
            'trend_offset': self.trend_offset,
            'use_exact_diffuse': self.use_exact_diffuse,
            'freq': self.freq,
            'missing': self.missing
        }

    def spec_type(self):
        """
        Returns a key used in the time series model training request.
        """
        return 'sarimax_spec'
