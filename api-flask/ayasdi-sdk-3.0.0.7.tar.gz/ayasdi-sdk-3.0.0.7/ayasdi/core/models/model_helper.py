from ayasdi.core.source_subset import SourceSubset
from ayasdi.core.models.decision_tree import DecisionTree
from ayasdi.core.models.linear_regression import LinearRegression
from ayasdi.core.models.logistic_regression import LogisticRegression
from ayasdi.core.models.random_forest import RandomForest
from ayasdi.core.models.gbdt import GBDT
from ayasdi.core.models.neural_network import NeuralNetwork
from ayasdi.core.models.group_classifier import GroupClassifier
from ayasdi.core.models.decision_tree_spec import DecisionTreeSpec
from ayasdi.core.models.linear_regression_spec import LinearRegressionSpec
from ayasdi.core.models.logistic_regression_spec import LogisticRegressionSpec
from ayasdi.core.models.random_forest_spec import RandomForestSpec
from ayasdi.core.models.gbdt_spec import GbdtSpec
from ayasdi.core.models.neural_network_spec import NeuralNetworkSpec
from ayasdi.core.models.problem_spec import ProblemSpec
from ayasdi.core.models.model_outcome_spec import ModelOutcomeSpec
from ayasdi.core.models.group_classifier_spec import GroupClassifierSpec
from ayasdi.core import async_jobs
from ayasdi.core import json_funcs


class ModelHelper:
    """
    A helper class which provides a single access point to train predictive models, as well as holding some static
    methods such as :func:`cross_validation`.

    This class can be used to train predictive models for:
        - outcome based classification;
        - outcome based regression;
        - group membership classification.

    See the usage in :func:`create_model`.

    Args:
        connection: A :class:`Api <ayasdi.core.api.Api>` instance.
        name (str): Name of the model being trained.
        data_spec: A :class:`SourceSubset <ayasdi.core.source_subset.SourceSubset>` instance.
        problem_spec: An instance derived from :class:`ProblemSpec <ayasdi.core.models.problem_spec.ProblemSpec>`,
            depending on the type of the model being trained. It can be one of the following derived classes:
                - :class:`ModelOutcomeSpec <ayasdi.core.models.model_outcome_spec.ModelOutcomeSpec>` for predictions \
                    based on an outcome column.
                - :class:`GroupClassifierSpec <ayasdi.core.models.group_classifier_spec.GroupClassifierSpec>` for \
                    predictions based on a set of classification groups.
        model_spec: An instance derived from :class:`ModelSpec <ayasdi.core.models.model_spec.ModelSpec>` to specify
            parameters used in the predictive model algorithms. It can be one of the following derived classes:
                - :class:`RandomForestSpec <ayasdi.core.models.random_forest_spec.RandomForestSpec>` for random forest \
                    algorithm;
                - :class:`DecisionTreeSpec <ayasdi.core.models.decision_tree_spec.DecisionTreeSpec>` for decision tree \
                    algorithm;
                - :class:`LinearRegressionSpec <ayasdi.core.models.linear_regression_spec.LinearRegressionSpec>` for \
                    linear regression algorithm;
                - :class:`LogisticRegressionSpec <ayasdi.core.models.logistic_regression_spec.LogisticRegressionSpec>` \
                    for logistic regression algorithm;
                - :class:`GbdtSpec <ayasdi.core.models.gbdt_spec.GbdtSpec>` for gradient boosted decision tree \
                    algorithm.
                - :class:`NeuralNetworkSpec <ayasdi.core.models.neural_network_spec.NeuralNetworkSpec>` for a neural \
                    network algorithm.
        description (str): A user-provided description of the model (optional).
        metadata (dict): Metadata for the column set stored as key-value pairs (optional).
    """
    def __init__(self,
                 connection,
                 name,
                 data_spec,
                 problem_spec,
                 model_spec,
                 description=None,
                 metadata={}):
        self.connection = connection
        self.name = name
        self.data_spec = data_spec
        self.problem_spec = problem_spec
        self.model_spec = model_spec
        self.description = description
        self.metadata = metadata
        self._validate()

    def _validate(self):
        if not isinstance(self.data_spec, SourceSubset):
            raise TypeError("Incorrect type of data spec. Please use SourceSubset.")
        if not isinstance(self.problem_spec, ProblemSpec):
            raise TypeError("The problem_spec parameter must be of general type ProblemSpec.")

    def create_model(self, async_=False):
        """
        Train the predictive model

        :param async_:
            (bool) when True, specifies that the query should run in asynchronous mode. If False or not
            specified, the query is run in synchronous mode. Default, False.
        :return:
            an instance of the class corresponding to the trained predictive model. It can be one of the following:
                - :class:`RandomForest <ayasdi.core.models.random_forest.RandomForest>` for a random forest model;
                - :class:`DecisionTree <ayasdi.core.models.decision_tree.DecisionTree>` for a decision tree model;
                - :class:`LinearRegression <ayasdi.core.models.linear_regression.LinearRegression>` for a linear \
                    regression model;
                - :class:`LogisticRegression <ayasdi.core.models.logistic_regression.LogisticRegression>` for a \
                    logistic regression model;
                - :class:`GBDT <ayasdi.core.models.gbdt.GBDT>` for a gradient boosted decision tree models;
                - :class:`NeuralNetwork <ayasdi.core.models.neural_network.NeuralNetwork>` for a neural network model;
                - :class:`GroupClassifier <ayasdi.core.models.group_classifier.GroupClassifier>` for group \
                    classification models.

        Example:

        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>> import uuid
        >>> import time
        >>> source = connection.upload_source("./test/db_test2.txt")
        >>> # Create a random forest model.
        >>> model = acm.ModelHelper(connection=connection,
        ...                         name=str(uuid.uuid4()),
        ...                         data_spec=ac.SourceSubset(source_id=source.id),
        ...                         problem_spec=acm.ModelOutcomeSpec(outcome_column_index=6),
        ...                         model_spec=acm.RandomForestSpec()).create_model(async_=True)
        Training is running in asynchronous mode.
        Remember to call ready() to check status.
        >>> while not model.ready():
        ...     time.sleep(1)
        >>> assert model.name is not None
        >>> model.delete()  #ignore-in-doc
        >>> group1 = source.create_group(name=str(uuid.uuid4()), row_indices=list(range(100)))
        >>> group2 = source.create_group(name=str(uuid.uuid4()), row_indices=list(range(100, 140)))
        >>> group_ids = [group1['id'], group2['id']]
        >>> # Create a group classifier model.
        >>> model = acm.ModelHelper(connection=connection,
        ...                         name=str(uuid.uuid4()),
        ...                         data_spec=ac.SourceSubset(source_id=source.id),
        ...                         problem_spec=acm.GroupClassifierSpec(classification_group_ids=group_ids,
        ...                                                              strategy='multi_class'),
        ...                         model_spec=acm.DecisionTreeSpec()).create_model(async_=False)
        >>> assert model.name is not None
        >>> model.delete()  #ignore-in-doc
        >>> connection.delete_source(id=source.id)  #ignore-in-doc
        """
        model_type_mapping = {
            DecisionTreeSpec: DecisionTree,
            LinearRegressionSpec: LinearRegression,
            LogisticRegressionSpec: LogisticRegression,
            RandomForestSpec: RandomForest,
            GbdtSpec: GBDT,
            NeuralNetworkSpec: NeuralNetwork
        }
        if isinstance(self.problem_spec, ModelOutcomeSpec):
            model_type = model_type_mapping[type(self.model_spec)]
            return model_type._create_model(connection=self.connection,
                                            name=self.name,
                                            data_spec=self.data_spec,
                                            model_spec=self.model_spec,
                                            outcome_column_index=self.problem_spec.outcome_column_index,
                                            ignore_null_outcomes=self.problem_spec.ignore_null_outcomes,
                                            async_=async_,
                                            description=self.description,
                                            metadata=self.metadata)
        elif isinstance(self.problem_spec, GroupClassifierSpec):
            return GroupClassifier.create(connection=self.connection,
                                          source_id=self.data_spec.source_id,
                                          name=self.name,
                                          classification_group_ids=self.problem_spec.classification_group_ids,
                                          column_set_id=self.data_spec.column_set_id,
                                          group_id=self.data_spec.group_id,
                                          model_spec=self.model_spec,
                                          strategy=self.problem_spec.strategy,
                                          async_=async_,
                                          metadata=self.metadata)
        else:
            raise TypeError("The problem_spec parameter must be an instance of either "
                            "ModelOutcomeSpec or GroupClassifierSpec.")

    @staticmethod
    def cross_validation(connection, model_id, n_splits=10, sampling='random_sampling', random_seed=0, async_=False):
        """
        K-fold cross validation.

        Args:
            connection (:class:`Api <ayasdi.core.api.Api>`): an Ayasdi Platform connection
            n_splits (int): Number of groups to split the data into. Default=10.
            sampling (str): Indicates how to sample the data to create training/test data. Currently only
                'random_sampling' is supported which is also the default option.
            random_seed (int): A random seed used in the sampling method. default=0.
            async\_ (boolean, optional): whether to run in async mode [default=False]; if
                run in async mode, sync on the async object

        Returns:
            A list of validation statistics.

        Example:

        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>> import uuid
        >>> source = connection.upload_source("./test/db_test2.txt")
        >>> model = acm.RandomForest.create(connection=connection, name=str(uuid.uuid4()), source_id=source.id,
        ...                                 outcome_column_index=6)
        >>> cross_validation = acm.ModelHelper.cross_validation(connection=connection,
        ...                                                     model_id=model.model_id, n_splits=2)
        >>> assert len(cross_validation) == 1 and 'statistics_list' in cross_validation
        >>> assert len(cross_validation['statistics_list']) == 2
        >>> model.delete()  #ignore-in-doc
        >>> connection.delete_source(id=source.id)  #ignore-in-doc
        """
        if model_id is None:
            raise ValueError('model_id not set. Verify that the model has been instantiated and is ready.')
        rest_args = {'n_splits': n_splits, 'sampling': sampling, 'random_seed': random_seed}

        if async_ is True:
            url = connection.CORE_REQUEST_STUB + 'models/' + model_id + '/cross_validation/async'
            jobid = json_funcs._post_(connection.session, url, rest_args)
            print('cross validation is running in asynchronous mode.')
            print('Remember to call ready() to check status and call get_result() once it is ready.')
            return async_jobs.AsyncJob(connection, jobid, url)
        else:
            url = connection.CORE_REQUEST_STUB + 'models/' + model_id + '/cross_validation'
            res = json_funcs._post_(connection.session, url, rest_args)
            return res
