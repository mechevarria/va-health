from ayasdi.core.models.model_spec import ModelSpec


class RandomForestSpec(ModelSpec):
    """
    A random forest spec is a class having fields as the parameters for random forest algorithm and is used in group classifier.

    Args:
        number_of_trees (int, optional): number of trees to train, default=500
        max_depth (int, optional): maximum depth of a tree, default=20
        min_nodes (int, optional): minimum number of data rows for a leaf, default=5
        random_seed (int, optional): a number used to initialize a pseudo random number generator, default=0
        epsilon (double, optional): defines a loop exit criteria. While the algorithm attempts to find a minimum, it
            will terminate when it reaches a precision defined by epsilon. A smaller epsilon will increase precision
            (e.g. 0.0001). default=0.0001
    """  # noqa

    @property
    def number_of_trees(self):
        """number of trees to train"""
        return getattr(self, '_number_of_trees', None)

    @property
    def max_depth(self):
        """
        Maximum depth of trees in the RandomForest model. Depth is calculated as the count of nodes from the root to the farthest leaf.
        """
        return getattr(self, '_max_depth', None)

    @property
    def min_nodes(self):
        """
        Minimum number of data rows for a leaf
        """
        return getattr(self, '_min_nodes', None)

    @property
    def random_seed(self):
        """
        Number used to initialize a pseudo random number generator
        """
        return getattr(self, '_random_seed', None)

    @property
    def epsilon(self):
        """
        Defines a loop exit criteria. While the algorithm attempts to find a minimum,
        it will terminate when it reaches a precision defined by epsilon.
        A smaller epsilon will increase precision (e.g. 0.0001)
        """
        return getattr(self, '_epsilon', None)

    @property
    def params(self):
        """
        A dictionary of parameters for the random forest algorithm.
        """
        return getattr(self, '_params', None)

    def __init__(self, number_of_trees=500, max_depth=20, min_nodes=5, random_seed=0, epsilon=0.0001, params=None):
        self._number_of_trees = number_of_trees
        self._max_depth = max_depth
        self._min_nodes = min_nodes
        self._random_seed = random_seed
        self._epsilon = epsilon
        self._params = params or {}

    def serialize(self):
        """
        Converts a :class:`RandomForestSpec` object to a dictionary
        """

        random_forest_spec = {
            'number_of_trees': self.number_of_trees,
            'max_depth': self.max_depth,
            'min_nodes': self.min_nodes,
            'random_seed': self.random_seed,
            'epsilon': self.epsilon,
            'params': self.params
        }
        return random_forest_spec

    def spec_type(self):
        """
        Returns a key used in the group classifier request
        """
        return 'random_forest_spec'
