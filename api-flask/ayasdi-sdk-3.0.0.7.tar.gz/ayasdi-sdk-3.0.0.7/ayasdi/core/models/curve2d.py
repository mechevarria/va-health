class Curve2D(object):
    """ A two dimensional curve used primarily for ROC curves"""

    def __init__(self, points=[]):
        """
        Initialize a curve
        :param points: a sequence of :class:`Point2D <ayasdi.core.models.point2d.Point2D>` objects
        """
        self._points = points

    @property
    def points(self):
        """
        A list of :class:`Point2D <ayasdi.core.models.point2d.Point2D>` points
        """
        return self._points

    def __getitem__(self, key):
        return getattr(self, key, None)

    def __repr__(self):
        return "Two dimensional curve of " + str(len(self.points)) + " points"
