#!/usr/bin/env python
"""

Use the :class:`GroupClassifier` class to create classifiers based on one of the following algorithms: random forest,
logistic regression, or decision tree. Instantiate a :class:`ModelSpec` object to pass as an argument to the
:func:`GroupClassifier.create` method.

Note: to import a class of models, use an import statement as shown below
for the RandomForest example:

.. code:: python

    import ayasdi.core as ac
    import ayasdi.core.models as acm

.. note::
   Here is a listing of available functions in this module.

   .. autosummary::
      create_group_classifier
      apply_group_classifier
      import_pmml_model
      get_pmml_model_by_id
      get_pmml_models
      delete_pmml_model
      MLModel
      MLModel.sync
      MLModel.predict
      LegacyGroupClassifier
      LegacyGroupClassifier.import_model
      LegacyGroupClassifier.ready
      LegacyGroupClassifier.export

"""
from __future__ import absolute_import, unicode_literals, division, print_function

import logging
import os
from xml.etree import ElementTree as ET

from requests import HTTPError
from requests_toolbelt import MultipartEncoder

import ayasdi.core.api
from ayasdi.core import json_funcs
from ayasdi.core.async_jobs import AsyncJob
from ayasdi.core.file_funcs import _get_download_

import warnings

LOGGER = logging.getLogger(__name__)


def _check_connection(connection):
    if not isinstance(connection, ayasdi.core.api.Api):
        raise TypeError("TypeError: first parameter must be an Api object. "
                        "This is a change since Ayasdi SDK version 7.10.")


def create_group_classifier(network, name, description=None, async_=False, column_set_id=None, group_id=None,
                            node_groups=None, create_new=True, classifier_type='random_forest_2', sampling_size=100000,
                            random_seed=0):
    """Creating a group classifier.

    Args:
        network : network object.
        name : the name for the given model.
        description: optional description for the given classifier.
        async_ : specifies whether or not to run in asynchronous mode. When set to True, query runs in
            asynchronous mode and syncs on the async object. When not set to True or omitted,
            query runs in synchronous mode.
        column_set_id (str): specifies the id of column_set dictionary to be used. When not supplied, defaults to the id
            of the column set used in network creation.
        group_id: group identifier specifying a subset of rows to use in creating the classifier
        node_groups : A list of node group dictionaries (passed back by
            :func:`ayasdi.core.networks.Network.get_node_groups` or by creating a slice from this list).
            Defaults to all node_groups in the network.
        create_new : specifies whether a new model should be created, even if one already exists with the same name.
            If omitted or not set to False, a new model is created.
        classifier_type : (Optional) Choose a classifier from::
            ``random_forest`` - chosen by default, use with
            ``Group Classifier``
        sampling_size : number of rows to process. If not supplied, defaults to 100000.
        random_seed : (Optional) Used for shuffling and sampling. Defaults to 0.

    Returns:
        A :class:`LegacyGroupClassifier` object

    :Example:

    >>> import ayasdi.core as ac
    >>> import ayasdi.core.models as acm
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt")
    >>> src.sync()
    >>> columns_for_analysis = ["relative weight", "blood glucose",
    ...                         "insulin level", "insulin response"]
    >>> column_set = src.create_column_set(column_list=columns_for_analysis,
    ...                                    name="test_column_set1")
    >>> network = src.create_network("test_network123",{
    ...        'metric': {'id': 'Norm Correlation'},
    ...        'column_set_id': column_set['id'],
    ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
    ...                    'equalize': True, 'gain': 3.0},
    ...                   {'resolution': 30, 'id': 'MDS coord 2',
    ...                   'equalize': True, 'gain': 3.0}]
    ...        }
    ... )
    >>> node_groups = network.autogroup()
    >>> #Make two groups
    >>> g1 = network.create_node_group(name="Grp1", nodes=node_groups[0])
    >>> g2 = network.create_node_group(name="Grp2", nodes=node_groups[0])
    >>> src.sync()
    >>> network.sync()
    >>> #Getting all the models for given user
    >>> all_models = _get_group_classifiers_(connection)
    >>> all_models  # doctest: +SKIP
    []
    >>> # Create a new group classifier. If the async_=True arg is used,
    >>> # a job object is created. Models can be later retrieved using
    >>> # _get_group_classifier_ using its
    >>> # name as shown below, hence a name argument is essential.
    >>>
    >>> # Clean up #ignore-in-doc
    >>> all = [x for x in all_models
    ...        if x.name == 'sdkapi_test_model3'] #ignore-in-doc
    >>> for classifier in all: #ignore-in-doc
    ...     _delete_group_classifier_(connection, id=classifier.id) #ignore-in-doc
    >>> classifier = acm.create_group_classifier(network, name="sdkapi_test_model3")
    >>> classifier = _get_group_classifier_(connection, name="sdkapi_test_model3")
    >>> classifier = classifier[0] if type(classifier) == list else classifier
    >>> predictions = \
        acm.apply_group_classifier(connection, classifier,
    ...                        [[0.81, 80, 356, 124],
    ...                        [0.95, 97, 289, 117]])
    ...                         # doctest: +NORMALIZE_WHITESPACE
    >>> # Get the prediction probability for pt 1 for group2
    >>> len(predictions) #Points in predictions
    2
    >>> # Predictions for pt.1
    >>> pt_1_predictions = predictions[0]['node_group_ids']
    >>> pt_1_predictions = dict([(pred[1], pred[2])
    ...                         for pred in pt_1_predictions])
    >>> # Predictions for pt.2
    >>> pt_2_predictions = predictions[1]['node_group_ids']
    >>> pt_2_predictions = dict([(pred[1], pred[2])
    ...                         for pred in pt_2_predictions])
    >>> # Compare two predictions
    >>> pt_1_predictions['Grp1'] > pt_2_predictions['Grp2']
    True
    >>> _delete_group_classifier_(connection, name="sdkapi_test_model3")
    True
    >>> src.delete_network(name="test_network123")
    True
    >>> connection.delete_source(name="db_test2.txt") # ignore-in-doc

    .. see also::
       :func:`apply_group_classifier`, :class:`LegacyGroupClassifier`

    """
    return __create_topological_group_model__(network=network, name=name, description=description, async_=async_,
                                              column_set_id=column_set_id, group_id=group_id, node_groups=node_groups,
                                              create_new=create_new, classifier_type=classifier_type,
                                              sampling_size=sampling_size, random_seed=random_seed)


def __create_topological_group_model__(network, name, description=None, async_=False, column_set_id=None, group_id=None,
                                       node_groups=None, create_new=True, classifier_type='random_forest_2',
                                       sampling_size=100000, random_seed=0):
    """Creating a Topological Group model.

    Args:
        network: A network object.
        column_set_id: (Optional, str) The id of a column_set dictionary. Defaults to the id of the column set used in
            network creation.
        create_new: Create a new model.
        classifier_type: (Optional) Choose a classifier from::
            1. ``random_forest`` - chosen by default
            2. ``decision_tree``
            3. ``logistic_regression``
            4. ``linear_regression``
            5. ``support_vector_machine``
            6. ``quadratic_classifier``
        node_groups: A list of node group dictionaries (passed back by some
            functions). Defaults to all node_groups in the network.

    Returns:

        Group classifier object
    """

    warnings.warn("Deprecated: use GroupClassifier.create instead "
                  "to create a GroupClassifier model ")

    connection = network.connection
    if create_new is False:
        available_group_classifiers = _get_group_classifiers_(connection)
        for classifier in available_group_classifiers:
            if classifier.name == name:
                return _get_group_classifier_(connection, name=classifier.name)
    # Build up model params
    if node_groups is None:
        node_groups = network.get_node_groups()
    if not node_groups:
        msg = {"msg": "No node group has been created in the network."}
        print(msg)
        return msg
    if group_id is None:
        group_id = 0
    node_group_ids = [i['id'] for i in node_groups]
    if column_set_id is None:
        column_set_id = network.column_set_id
    model_build_params = {'name': name,
                          'network_id': network.id,
                          'source_id': network.source.id,
                          'column_set_id': column_set_id,
                          'group_id': group_id,
                          'classifier_type': classifier_type,
                          'node_group_ids': node_group_ids,
                          'sampling_size': sampling_size,
                          'random_seed': random_seed,
                          }
    if description is not None:
        model_build_params['description'] = description

    if async_:
        url = connection.CORE_REQUEST_STUB + 'topological_group_models/async'
        jobid = json_funcs._post_(connection.session,
                                  url,
                                  model_build_params)
        print('Training is running in asynchronous mode.')
        print('Remember to call ready() to check status.')

        model = LegacyGroupClassifier(connection)
        model.__set_async_job__(jobid, url)
        return model
    else:
        url = connection.CORE_REQUEST_STUB + 'topological_group_models'
        res = json_funcs._post_(connection.session,
                                url,
                                model_build_params)
        model = LegacyGroupClassifier(connection)
        model.__fill_body__(res)
        return model


def apply_group_classifier(connection, classifier, rows):
    """Applying a Group Classifier (created by the create processes on this page).

    Args:
        connection : an instance of class ayasdi.core.api.Api
        classifier: A Group Classifier object.
        rows: The rows that need to be classified upon.

    Returns: list of dictionaries

        apply_group_classifier
            returns list of dictionaries with 2 elements each:

            'values' - original data rows,

            'node_group_ids' - a list of triples one per group (row group id, group name, group score)

            [{'values': [u'0.81', u'80', u'356', u'124'],
                'node_group_ids': [(u'10004', u'Grp1', 0.2954055508822203),
                (u'10006', u'Grp2', 0.2954055508822203)]
            }, {'values': [u'0.95', u'97', u'289', u'117'],
                'node_group_ids': [(u'10004', u'Grp1', 0.006423809170722938),
                (u'10006', u'Grp2', 0.006423809170722938)]
            }]


    :Example:

    See usage in :func:`ayasdi.core.models.create_group_classifier`

    .. seealso::
       :func:`create_group_classifier`, :class:`LegacyGroupClassifier`
    """
    _check_connection(connection)
    warnings.warn("Deprecated: use GroupClassifier.predict instead. "
                  "Use GroupClassifier.create to create a GroupClassifier model.")

    post_dict = {'rows': [{'strings': [str(v) for v in row]} for row in rows], 'values': []}
    classifier_curl = "%s%s/%s/predict" % (connection.CORE_REQUEST_STUB,
                                           classifier.model_type,
                                           classifier.id)
    prediction_json = json_funcs._post_(connection.session,
                                        classifier_curl,
                                        post_dict)
    output_vals = prediction_json['rows']
    # The output should have an outcomes keyword,
    # but this is kept as node_group_ids
    # for legacy reasons (Previous modeling endpoints had this).
    # Replace as needed.
    output_list = []
    if classifier.model_type == "topological_group_models":
        for val in output_vals:
            temp_dict = {}
            temp_dict['values'] = val['strings']
            temp_dict['node_group_ids'] = []
            for outcome in val['outcomes']:
                temp_dict['node_group_ids'].append((outcome['group_id'],
                                                    outcome['group_name'],
                                                    outcome['probability']))
            output_list.append(temp_dict)
    return output_list


def import_pmml_model(connection, pmml_model_string, name,
                      description='Description not provided'):
    """Importing a PMML model, specified by XML string.

    Args:
        connection : an instance of class ayasdi.core.api.Api
        pmml_model_string: A string containing a PMML model in XML format.
        name (str): Name for the imported model.
        description: Optional description for the imported model.

    Returns:
        A :class:`ayasdi.core.models.MLModel` object

    :Example:

    >>> import ayasdi.core as ac
    >>> import ayasdi.core.models as acm
    >>>
    >>> linear_model_pmml_file = "./test/IrisLinearReg.xml"
    >>> mlmodel_lr = \
        connection.import_pmml_model(linear_model_pmml_file,
    ...                              name=
    ...                              "pmml_Iris_linear_reg_1",
    ...                              description=
    ...                              "Iris_linear_regression_model")
    >>> iris_src = connection.upload_source("./test/Iris.csv")
    >>> active_columns = ["sepal_length", "sepal_width", "petal_length",
    ...                   "petal_width", "class"]
    >>> column_set = iris_src.create_column_set(column_list=active_columns,
    ...                                         name="test_columns_for_pmml")
    >>> row_group = iris_src.create_group(name="test_row_group_for_pmml",
    ...                                   row_indices=list(range(5)))
    >>> prediction = mlmodel_lr.predict(iris_src.id, column_set['id'],
    ...                                 row_group_id=row_group['id'])
    >>> output = ['%0.2f' % float(i['pred_result']) for i in prediction]
    >>> output == ['5.00', '4.76', '4.77', '4.89', '5.05']
    True
    >>> _ = iris_src.delete_group(id=row_group['id']) # ignore-in-doc
    >>> _ = iris_src.delete_column_set(name="test_columns_for_pmml") # ignore-in-doc
    >>> acm.delete_pmml_model(connection, name="pmml_Iris_linear_reg_1")
    True
    >>> connection.delete_source(id=iris_src.id) # ignore-in-doc
    """
    _check_connection(connection)
    ET.fromstring(pmml_model_string)
    model_build_params = {'name': name,
                          'classifier_type': 'pmml_model',
                          'pmml': pmml_model_string}
    model_build_params['description'] = description
    top_group_json = json_funcs._post_(connection.session,
                                       connection.CORE_REQUEST_STUB + 'pmml',
                                       model_build_params)
    return MLModel(connection, top_group_json, 'pmml')


def get_pmml_model_by_id(connection, model_id):
    _check_connection(connection)
    curl = connection.CORE_REQUEST_STUB
    if model_id:
        uri = curl + 'pmml/' + model_id
        try:
            pmml_model = json_funcs._get_(connection.session, uri)
            if pmml_model:
                return MLModel(connection, pmml_model, 'pmml')
        except HTTPError as e:
            if e.response.status_code == 404:
                error_message = "Model with given id %s does not exist" % model_id
                LOGGER.exception(error_message)
                raise e
            else:
                raise
    else:
        raise ValueError("Provide a valid model id")


def get_pmml_models(connection):
    """ Gets a list of all PMML Models

    Args:
        connection : an instance of class ayasdi.core.api.Api

    Returns:
        A list of :class:`ayasdi.core.models.MLModel` object
    """

    _check_connection(connection)
    curl = connection.CORE_REQUEST_STUB
    uri = curl + 'pmml'
    pmml_models = json_funcs._get_(connection.session, uri)
    return [MLModel(connection, m, 'pmml') for m in pmml_models]


def _delete_pmml_model_by_id(connection, id):
    """ This is a helper method to delete PMML model by ID

    Args:
        connection (str) : an instance of class ayasdi.core.api.Api (see `api <../ayasdi.core.api.html>`_).
        id: id of the pmml model. Optional with name.
    Returns:
        True if successful

    """
    _check_connection(connection)
    curl = connection.CORE_REQUEST_STUB
    uri = curl + 'pmml/{}'.format(id)
    json_funcs._delete_(connection.session, uri)
    return True


def delete_pmml_model(connection, name=None, id=None):
    """ Gets a list of all PMML Models

    Args:
        connection : an instance of class ayasdi.core.api.Api
        name (str): name of the pmml model. Optional with id.
        id (num): id of the pmml model. Optional with name.
    Returns:
        True if successful
    """

    _check_connection(connection)
    if id:
        return _delete_pmml_model_by_id(connection, id)
    elif name:
        models = get_pmml_models(connection)
        for model in models:
            if model.name == name:
                return _delete_pmml_model_by_id(connection, model.id)
    else:
        raise ValueError('Please enter a name or an id')


class MLModel(object):
    def __init__(self, connection, model_info, model_type):
        """
        An instance of the Picklable Model class is created using
        :func:`ayasdi.core.api.get_models`

        Args:
            connection : an instance of class ayasdi.core.api.Api
            model_info: The Json object returned by the REST Endpoint.
            model_type: The type of this model
                (Currently: ``pmml`` or ``topological_model``)

        :Example:

        """
        self.json = model_info
        self.connection = connection
        for key, value in model_info.items():
            setattr(self, key, value)
        self.model_type = model_type
        self.curl = self.connection.CORE_REQUEST_STUB + model_type + '/%s' % self.id

    def sync(self):
        """
        Synchronizes the model with current state at the backend.
        """

        ret_model = json_funcs._get_(self.connection.session,
                                     self.curl)
        for key, value in ret_model.items():
            setattr(self, key, value)
        self.json = ret_model

    def __repr__(self):
        return "<MLModel %s> id: %s" % (self.name, self.id)

    def predict(self, source_id, column_set_id=None, column_set=None,
                column_indices=None, column_names=None, row_group_id=None,
                predicted_column_name=None):
        """
        Applying an ML Model to create a prediction.
        At most one of 'column_set', 'column_set_id', 'column_indices',
        or 'column_names' is allowed.

        Args:
            source_id: A source_id for the dataset.
            row_group_id: row_group_id specifying a subset of rows
            predicted_column_name: if predicted results are
                going to be appended to the source this name would be used,
                if no row_group_id nor predicted_column_name are specified
                then the default 'predicted_value' is used
            column_set_id: identifier of column set to use for prediction.
            column_set: column set to use for prediction.
            column_indices: a set of column indices to use for prediction.
            column_names: a set of column names to use for prediction.

        :Example:

         As seen in :func:`import_pmml_model`
        """
        if len([i for i in [column_set_id, column_set, column_indices,
                            column_names] if i is not None]) > 1:
            raise ValueError("At most one of 'column_set', 'column_set_id', "
                             "'column_indices', or 'column_names' is allowed.")

        # Construct post dict and post
        post_dict = {'source_id': source_id}
        if column_indices is not None:
            post_dict['column_indices'] = column_indices
        elif column_names is not None:
            post_dict['column_names'] = column_names
        elif isinstance(column_set_id, int):
            post_dict['column_set_id'] = column_set_id
        elif column_set is not None:
            post_dict['column_set_id'] = column_set['id']
        elif column_set_id is not None:
            post_dict['column_set_id'] = column_set_id

        if row_group_id and predicted_column_name:
            raise ValueError("Need to use either row_group_id or"
                             "predicted_column_name parameter.")
        if row_group_id is not None:
            post_dict['row_group_id'] = row_group_id
        elif predicted_column_name is not None:
            post_dict['predicted_column_name'] = predicted_column_name
        else:
            # supply default name
            post_dict['predicted_column_name'] = 'predicted_value'
        predict_curl = "%s%s/%s/predict" % \
                       (self.connection.CORE_REQUEST_STUB, self.model_type, self.id)
        prediction_json = json_funcs._post_(self.connection.session,
                                            predict_curl,
                                            post_dict)
        output_vals = prediction_json['predictions']
        output_list = []
        if self.model_type == "pmml":
            for val in output_vals:
                temp_dict = {}
                if 'pred_result' in val:
                    temp_dict['pred_result'] = float(val['pred_result'])
                if 'pred_class_name' in val:
                    temp_dict['pred_class_name'] = val['pred_class_name']
                output_list.append(val)

        return output_list


class LegacyGroupClassifier(object):
    """
    An instance of the Picklable Model class is created
    using :func:`ayasdi.core.models.create_group_classifier`.
    To learn more about the Group Classifier visit
    https://ayasdicommunity.force.com/s/article/ka00P0000009IAnQAM/Feature-Overview-Group-Classifier
    """

    def __init__(self, connection):
        """
        Initialize LegacyGroupClassifier
        """

        self.json = None
        self.__ready = None
        self.async_job = None
        self.model_type = 'topological_group_models'
        self.connection = connection

    @staticmethod
    def import_model(connection, filename):
        """
        Load model from binary file to backend.
        The saved model can be transferred from one Ayasdi platform instance to another.
        See also :func:`LegacyGroupClassifier.export`

        Args:
            connection : an instance of class ayasdi.core.api.Api (see `api <../ayasdi.core.api.html>`_).
            filename: full filename to load model from.

        Returns:
            New instance of LegacyGroupClassifier class which can be used for predictions.


        """
        _check_connection(connection)
        base_filename = os.path.basename(filename)
        m = MultipartEncoder([('file', (base_filename, open(filename, 'rb'), 'application/zip'))])
        import_url = "%s%s/import" % (connection.CORE_REQUEST_STUB,
                                      'topological_group_models')
        res = json_funcs._post_(connection.session,
                                import_url,
                                m,
                                content_type=m.content_type)
        model = LegacyGroupClassifier(connection)
        model.__fill_body__(res)
        return model

    def __fill_body__(self, res):
        self.json = res
        for key, value in res.items():
            setattr(self, key, value)
        self.__ready = True

    def __set_async_job__(self, async_job, url):
        self.__ready = False
        self.async_job = AsyncJob(self.connection, async_job, url)

    def ready(self):
        """
        Check readiness of object
        Used as part of asynchronous call pattern.
        """
        if self.__ready:
            return True
        else:
            async_ready = self.async_job.ready()
            if async_ready:
                self.__fill_body__(self.async_job.result)
                return True
            else:
                return False

    def __repr__(self):
        return "<GroupClassifier '%s' id: %s" % (self.name, self.id)

    def export(self, filename):
        """
        Save the model to binary file.

        .. note::
            Saved model can be transferred from one Ayasdi platform instance to another.

        Args:
            filename: full filename to save the model to.

        Returns:
            True if successful

        .. seealso::
           :func:`LegacyGroupClassifier.import_model`
        """
        export_url = "{}{}/{}/export".format(self.connection.CORE_REQUEST_STUB,
                                             self.model_type,
                                             self.id)
        return _get_download_(self.connection.session,
                              export_url,
                              filename)


def delete_model(connection, model_id):
    """
    Deletes the specified model.
    Only models with UUIDs can be deleted this way.

    Args:
        connection (str) : an instance of class ayasdi.core.api.Api (see `api <../ayasdi.core.api.html>`_).
        model_id (str): ID of model to delete
    """
    _check_connection(connection)
    url = connection.CORE_REQUEST_STUB + 'models/' + model_id
    res = json_funcs._delete_(connection.session, url)
    return res


def _get_group_classifiers_(connection):
    """
    Get previously created group classifiers.
    """
    models_list = json_funcs._get_(connection.session,
                                   connection.CORE_REQUEST_STUB + 'topological_group_models')
    res = []
    for i in models_list:
        gc = LegacyGroupClassifier(connection)
        gc.__fill_body__(i)
        res.append(gc)
    return res


def _get_group_classifier_(connection, id=None, name=None):
    """
    Get group_classifier by id or name.
    """
    # Refresh the sources
    available_models = _get_group_classifiers_(connection)
    model_curl = connection.CORE_REQUEST_STUB + 'topological_group_models/'
    # Find the relevant source
    multiple_models = []
    for model in available_models:
        if id is not None and model.id == id:
            model_val = json_funcs._get_(connection.session, model_curl + model.id)
            model_obj = LegacyGroupClassifier(connection)
            model_obj.__fill_body__(model_val)
            return model_obj
        elif name is not None and model.name == name:
            model_val = json_funcs._get_(connection.session, model_curl + model.id)
            model_obj = LegacyGroupClassifier(connection)
            model_obj.__fill_body__(model_val)
            multiple_models.append(model_obj)
    # Return only one model if possible.
    if not multiple_models:
        raise IndexError("Can't find model '%s'" % name)
    elif len(multiple_models) == 1:
        return multiple_models[0]
    else:
        print("Multiple models with the same name found!")
        return multiple_models


def _delete_group_classifier_(connection, id=None, name=None):
    """
    Delete group classifier by id or name.
    """
    models = _get_group_classifiers_(connection)
    selected_model = None
    for ind, model in enumerate(models):
        if name is not None and model.name == name:
            selected_model = model.id
        elif id is not None and model.id == id:
            selected_model = model.id
        if selected_model:
            url = connection.CORE_REQUEST_STUB + 'topological_group_models/' + selected_model
            json_funcs._delete_(connection.session, url)
            return True

    msg = {"msg": "Model with given parameters does not exist"}
    print(msg)
    return
