from ayasdi.core import json_funcs
from ayasdi.core.models.model_base import ModelBase
from ayasdi.core.models import utilities
from ayasdi.core.data_point_list import DataPointList
from ayasdi.core.models.multiclass_statistics import MulticlassStatistics
from ayasdi.core.models.regression_statistics import RegressionStatistics


class EnsembleModel(ModelBase):
    """
    Args:
       connection : an instance of :class:`Api <ayasdi.core.api.Api>`.
    """

    def __init__(self, connection):
        ModelBase.__init__(self)
        self.json = None
        self.__ready = None
        self.async_job = None
        self.connection = connection

    @staticmethod
    def create(connection,
               name,
               source_id,
               group_classifier_model_spec,
               local_model_spec,
               async_=False,
               description=None,
               metadata={}):
        """
        This call fist creates a group classifier model with the source_id and group_classifier_spec and creates some
        new training groups from this group classifier model and then creates new models on these new training groups
        and source_id, as long as local_model_spec.

        Args:
            connection : an instance of :class:`Api <ayasdi.core.api.Api>`
            name (string): Name of a new model
            source_id (str): identifier of a source on which to create the model
            group_classifier_model_spec: A dictionary containing the fields 'classification_group_ids', 'column_set_id',
                'strategy', and 'model_spec', for creating a group classifier model.
                See :class:`GroupClassifier <ayasdi.core.models.group_classifier.GroupClassifier>` for these fields \
                usage.
            local_model_spec: A dictionary containing the fields 'outcome_column_index', 'column_set_id', and \
                'model_spec' for creating a new model. See \
                :class:`DecisionTree <ayasdi.core.models.decision_tree.DecisionTree>`, \
                :class:`GBDT <ayasdi.core.models.gbdt.GBDT>`, \
                :class:`NeuralNetwork <ayasdi.core.models.neural_network.NeuralNetwork>`, \
                :class:`RandomForest <ayasdi.core.models.random_forest.RandomForest>` or
                :class:`LogisticRegression <ayasdi.core.models.logistic_regression.LogisticRegression>` for these \
                fields usage.
            async\_ (bool) : when True, specifies that the query should run in asynchronous mode. If False or not
                specified, the query is run in synchronous mode.
            description (string, optional): user provided information about the model
            metadata (dict): Metadata for the column set stored as key-value pairs (optional)

        Model spec example:
            group_classifier_model_spec = {'classification_group_ids': ['10000', '10001'],
                                           'column_set_id': '-3936055302277233737',
                                           'model_spec': DecisionTreeSpec(),
                                           'strategy': 'multi_class'}
            local_model_spec = {'outcome_column_index': 6, 'column_set_id': '-3194216939005034366',
                                'model_spec': RandomForestSpec()}

        Returns:
            An instance of :class:`EnsembleModel` wrapping a list of models.

            Example:
                {'model_id': '580b08c3-a404-42c9-900a-11b6ebef1d5e',
                 'model_info': {'models': {'group_classifier_model': '29b5ee92-e2cb-4e24-8fef-bb296a173495',
                                           'local_models': ['956b07d2-a8b5-4577-bcf8-94817a63f09e',
                                                            'ff2bd338-dbb4-4316-a4f6-94143e6e7f13']
                                          }
                               },
                 'name': 'ensemble',
                 'type': 'EnsembleModel'
                }
        >>> import ayasdi.core.models as acm
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> src.sync()
        >>> import uuid
        >>> g1 = src.create_group(name=str(uuid.uuid4()), row_indices=list(range(20, 120)))
        >>> g2 = src.create_group(name=str(uuid.uuid4()), row_indices=list(range(30, 140)))
        >>> col_set = src.create_column_set(name=str(uuid.uuid4()), column_list=list(range(4)))
        >>> col_set_1 = src.create_column_set(name=str(uuid.uuid4()), column_list=list(range(6)))
        >>> gc_model_spec = {'classification_group_ids': [g1['id'], g2['id']], 'column_set_id': col_set['id'],
        ...                  'model_spec': acm.RandomForestSpec(), 'strategy': 'one_vs_rest'}
        >>> local_model_spec = {'column_set_id': col_set_1['id'], 'model_spec': acm.DecisionTreeSpec(),
        ...                     'outcome_column_index': 6}
        >>> ensemble_model = acm.EnsembleModel.create(connection, name=str(uuid.uuid4()), source_id=src.id,
        ...                                           group_classifier_model_spec=gc_model_spec,
        ...                                           local_model_spec=local_model_spec)
        >>> connection.delete_source(id=src.id) #ignore-in-doc
        """
        utilities._check_connection(connection)
        rest_args = {
            'model_type': 'ensemble_model',
            'model_name': name,
            'model_description': description,
            'ensemble_model_params': {
                'group_classifier_params': {
                    'source_view': {
                        'source_id': source_id,
                        'column_set_id': group_classifier_model_spec.get('column_set_id')
                    },
                    'classification_group_ids': group_classifier_model_spec['classification_group_ids'],
                    'strategy': group_classifier_model_spec.get('strategy', 'one_vs_rest')
                },
                'column_set_id': local_model_spec.get('column_set_id'),
                'outcome_column_index': local_model_spec['outcome_column_index']
            },
            'metadata': metadata
        }
        gc_model_algorithm_spec = group_classifier_model_spec['model_spec']
        rest_args['ensemble_model_params']['group_classifier_params'][gc_model_algorithm_spec.spec_type()] = \
            gc_model_algorithm_spec.serialize()
        local_model_algorithm_spec = local_model_spec['model_spec']
        rest_args['ensemble_model_params'][local_model_algorithm_spec.spec_type()] = \
            local_model_algorithm_spec.serialize()

        if async_:
            url = connection.CORE_REQUEST_STUB + 'models/async'
            jobid = json_funcs._post_(connection.session,
                                      url, rest_args)
            print('Training is running in asynchronous mode.')
            print('Remember to call ready() to check status.')

            model = EnsembleModel(connection)
            model.__set_async_job__(jobid, url)
            return model
        else:
            url = connection.CORE_REQUEST_STUB + 'models'
            res = json_funcs._post_(connection.session,
                                    url, rest_args)
            model = EnsembleModel(connection)
            model.__fill_body__(res)
            return model

    def predict_proba(self, data_spec, group_classifier_data_spec=None):
        """
        Predicts for each data point likelihoods of each class (call :func:`get_classes()`) in the ensemble model.

        Args:
            data_spec: A :class:`DataSpec <ayasdi.core.data_spec.DataSpec>` object or a list of data points
                specified independent of any particular source object. This parameter if for predict of the local models
                created during the ensemble model training. If not provided, it will be same as
                group_classifier_data_spec.
            group_classifier_data_spec: A :class:`DataSpec <ayasdi.core.data_spec.DataSpec>` object or a list of data
                points specified independent of any particular source object. This parameter if for predict of the group
                classifier model created during the ensemble model training. If not provided, it will be same as
                data_spec.

        Returns:
            a list of predictions for each data point.

        Example:
              If the local models have four classes (call :func:`get_classes()`), the output looks like:
             [[0.1, 0.3, 0.5, 0.1],
              [0.2, 0.3, 0.4, 0.1],
              ...
             ]


        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>> import uuid
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> src.sync()
        >>> col_set = src.create_column_set(column_list=list(range(4)), name=str(uuid.uuid4()))
        >>> col_set_1 = src.create_column_set(column_list=list(range(5)), name=str(uuid.uuid4()))
        >>> group1 = src.create_group(name='group1_' + str(uuid.uuid4()), row_indices=list(range(20, 120)))
        >>> group2 = src.create_group(name='group2_' + str(uuid.uuid4()), row_indices=list(range(30, 140)))
        >>> gc_model_spec = {'classification_group_ids': [group1['id'], group2['id']],
        ...                  'column_set_id': col_set['id'],
        ...                  'model_spec': acm.RandomForestSpec(), 'strategy': 'one_vs_rest'}
        >>> local_model_spec = {'column_set_id': col_set_1['id'], 'model_spec': acm.DecisionTreeSpec(),
        ...                     'outcome_column_index': 6}
        >>> model = acm.EnsembleModel.create(connection=connection, name=str(uuid.uuid4()),
        ...                                  source_id=src.id,
        ...                                  group_classifier_model_spec=gc_model_spec,
        ...                                  local_model_spec=local_model_spec)
        >>> proba = model.predict_proba(data_spec=ac.SourceSubset(source_id=src.id,
        ...                                                       group_id=group2['id'],
        ...                                                       column_set_id=col_set_1['id']),
        ...                             group_classifier_data_spec =ac.SourceSubset(source_id=src.id,
        ...                                                                         group_id=group2['id'],
        ...                                                                         column_set_id=col_set['id']))
        >>> connection.delete_source(id=src.id)  #ignore-in-doc
        """
        if self.model_id is None:
            raise ValueError('model_id not set. Verify that the model has been instantiated and is ready.')
        if group_classifier_data_spec is None:
            group_classifier_data_spec = data_spec

        if isinstance(group_classifier_data_spec, list):
            group_classifier_data_spec = DataPointList(group_classifier_data_spec)
        if isinstance(data_spec, list):
            data_spec = DataPointList(data_spec)

        request = {
            u'data_spec': data_spec.serialize(),
            u'group_classifier_data_spec': group_classifier_data_spec.serialize()
        }

        url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/predict_proba'
        response = json_funcs._post_(self.connection.session, url, request)
        return response[u'probabilities']

    def predict_values(self, data_spec, group_classifier_data_spec=None):
        """
        Predict regression values for each data point

        Args:
            See :func:`predict_proba` for details.

        Returns:
                a list of values for each data point, in order.

        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>> import uuid
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> src.sync()
        >>> col_set = src.create_column_set(column_list=list(range(4)), name=str(uuid.uuid4()))
        >>> col_set_1 = src.create_column_set(column_list=list(range(5)), name=str(uuid.uuid4()))
        >>> group1 = src.create_group(name='group1_' + str(uuid.uuid4()), row_indices=list(range(20, 120)))
        >>> group2 = src.create_group(name='group2_' + str(uuid.uuid4()), row_indices=list(range(30, 140)))
        >>> gc_model_spec = {'classification_group_ids': [group1['id'], group2['id']],
        ...                  'column_set_id': col_set['id'],
        ...                  'model_spec': acm.RandomForestSpec(), 'strategy': 'one_vs_rest'}
        >>> local_model_spec = {'column_set_id': col_set_1['id'], 'model_spec': acm.LinearRegressionSpec(),
        ...                     'outcome_column_index': 5}
        >>> model = acm.EnsembleModel.create(connection=connection, name=str(uuid.uuid4()),
        ...                                  source_id=src.id,
        ...                                  group_classifier_model_spec=gc_model_spec,
        ...                                  local_model_spec=local_model_spec)
        >>> values = model.predict_values(data_spec=ac.SourceSubset(source_id=src.id,
        ...                                                         group_id=group2['id'],
        ...                                                         column_set_id=col_set_1['id']),
        ...                               group_classifier_data_spec=ac.SourceSubset(source_id=src.id,
        ...                                                                          group_id=group2['id'],
        ...                                                                          column_set_id=col_set['id']))
        >>> connection.delete_source(id=src.id)  #ignore-in-doc
        """
        if self.model_id is None:
            raise ValueError('model_id not set. Verify that the model has been instantiated and is ready.')
        if group_classifier_data_spec is None:
            group_classifier_data_spec = data_spec

        if isinstance(group_classifier_data_spec, list):
            group_classifier_data_spec = DataPointList(group_classifier_data_spec)
        if isinstance(data_spec, list):
            data_spec = DataPointList(data_spec)

        request = {
            u'data_spec': data_spec.serialize(),
            u'group_classifier_data_spec': group_classifier_data_spec.serialize()
        }

        url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/predict_values'
        response = json_funcs._post_(self.connection.session, url, request)
        return response[u'values']

    def ensemble_predict_proba(self, data_spec, group_classifier_data_spec=None):
        """
        Predicts for each data point likelihoods of each class of the group classifier model and local models created in
        the ensemble model training.

        Args:
            See :func:`predict_proba` for details.

        Returns:
            Returns a dictionary containing two lists. For example of two local models:
            { 'group_classifier_predict_probabilities': [[0.9, 0.3], [0.8, 0.4], ...]
              'local_models_predict_probabilities': [[[0.2, 0.3, 0.4, 0.1], [0.6, 0.4, 0, 0]],
                                                     [[0.1, 0.3, 0.5, 0.1], [0.3, 0.7, 0, 0]],
                                                     ...
                                                    ]
            }

        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>> import uuid
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> src.sync()
        >>> col_set = src.create_column_set(column_list=list(range(4)), name=str(uuid.uuid4()))
        >>> col_set_1 = src.create_column_set(column_list=list(range(5)), name=str(uuid.uuid4()))
        >>> group1 = src.create_group(name='group1_' + str(uuid.uuid4()), row_indices=list(range(20, 120)))
        >>> group2 = src.create_group(name='group2_' + str(uuid.uuid4()), row_indices=list(range(30, 140)))
        >>> gc_model_spec = {'classification_group_ids': [group1['id'], group2['id']],
        ...                  'column_set_id': col_set['id'],
        ...                  'model_spec': acm.RandomForestSpec(), 'strategy': 'one_vs_rest'}
        >>> local_model_spec = {'column_set_id': col_set_1['id'], 'model_spec': acm.DecisionTreeSpec(),
        ...                     'outcome_column_index': 6}
        >>> model = acm.EnsembleModel.create(connection=connection, name=str(uuid.uuid4()),
        ...                                  source_id=src.id,
        ...                                  group_classifier_model_spec=gc_model_spec,
        ...                                  local_model_spec=local_model_spec)
        >>> prob = model.ensemble_predict_proba(group_classifier_data_spec=ac.SourceSubset(source_id=src.id,
        ...                                                                                group_id=group2['id'],
        ...                                                                                column_set_id=col_set['id']),
        ...                                     data_spec=ac.SourceSubset(source_id=src.id,
        ...                                                               group_id=group2['id'],
        ...                                                               column_set_id=col_set_1['id']))
        >>> connection.delete_source(id=src.id)  #ignore-in-doc
        """
        if self.model_id is None:
            raise ValueError('model_id not set. Verify that the model has been instantiated and is ready.')
        if group_classifier_data_spec is None:
            group_classifier_data_spec = data_spec

        if isinstance(group_classifier_data_spec, list):
            group_classifier_data_spec = DataPointList(group_classifier_data_spec)
        if isinstance(data_spec, list):
            data_spec = DataPointList(data_spec)

        request = {
            u'data_spec': data_spec.serialize(),
            u'group_classifier_data_spec': group_classifier_data_spec.serialize()
        }

        url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/ensemble_predict_proba'
        response = json_funcs._post_(self.connection.session, url, request)
        return response

    def ensemble_predict_values(self, data_spec, group_classifier_data_spec=None):
        """
        Predict regression values for each data point

        Args:
            See :func:`predict_proba` for details.

        Returns:
            Returns a dictionary containing two lists. For example of two local models:
            { 'group_classifier_predict_probabilities': [[0.9, 0.3], [0.8, 0.4], ...]
              'local_models_predict_probabilities': [[10.2, 11.3], [7.6, 9.4], ...]
            }

        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>> import uuid
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> src.sync()
        >>> col_set = src.create_column_set(column_list=list(range(4)), name=str(uuid.uuid4()))
        >>> col_set_1 = src.create_column_set(column_list=list(range(5)), name=str(uuid.uuid4()))
        >>> group1 = src.create_group(name='group1_' + str(uuid.uuid4()), row_indices=list(range(20, 120)))
        >>> group2 = src.create_group(name='group2_' + str(uuid.uuid4()), row_indices=list(range(30, 140)))
        >>> gc_model_spec = {'classification_group_ids': [group1['id'], group2['id']],
        ...                  'column_set_id': col_set['id'],
        ...                  'model_spec': acm.RandomForestSpec(), 'strategy': 'one_vs_rest'}
        >>> local_model_spec = {'column_set_id': col_set_1['id'], 'model_spec': acm.LinearRegressionSpec(),
        ...                     'outcome_column_index': 5}
        >>> model = acm.EnsembleModel.create(connection=connection, name=str(uuid.uuid4()),
        ...                                  source_id=src.id,
        ...                                  group_classifier_model_spec=gc_model_spec,
        ...                                  local_model_spec=local_model_spec)
        >>> val = model.ensemble_predict_values(group_classifier_data_spec=ac.SourceSubset(source_id=src.id,
        ...                                                                                group_id=group2['id'],
        ...                                                                                column_set_id=col_set['id']),
        ...                                     data_spec=ac.SourceSubset(source_id=src.id,
        ...                                                               group_id=group2['id'],
        ...                                                               column_set_id=col_set_1['id']))
        >>> connection.delete_source(id=src.id)  #ignore-in-doc
        """
        if self.model_id is None:
            raise ValueError('model_id not set. Verify that the model has been instantiated and is ready.')
        if group_classifier_data_spec is None:
            group_classifier_data_spec = data_spec

        if isinstance(group_classifier_data_spec, list):
            group_classifier_data_spec = DataPointList(group_classifier_data_spec)
        if isinstance(data_spec, list):
            data_spec = DataPointList(data_spec)

        request = {
            u'data_spec': data_spec.serialize(),
            u'group_classifier_data_spec': group_classifier_data_spec.serialize()
        }

        url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/ensemble_predict_values'
        response = json_funcs._post_(self.connection.session, url, request)
        return response

    def generate_validation_statistics(self,
                                       source_id,
                                       outcome_column_index,
                                       column_set_id=None,
                                       group_classifier_column_set_id=None,
                                       group_id=None,
                                       decision_threshold=None,
                                       async_=False):
        """
        Calculate prediction statistics on the provided data set with known outcome.

        Args:
            source_id (string): identifier of source on which to validate the model
            outcome_column_index (int): Index of column to use as ground truth outcome/label
            column_set_id (str, optional): ID of column set specifying testing features
            group_classifier_column_set_id(str, optional): ID of column set specifying testing features for created
                group classifier model.
            group_id (str, optional): ID of group specifying testing rows
            decision_threshold (float, optional): defines a discrimination boundary
                used to perform binary classification. This value can
                range from 0 to 1.
                Higher decision thresholds will exclude more elements
                from being classified (increasing type II error), whereas
                lower decision thresholds will cause fewer exclusions
                (increasing type I error). This parameter should depend
                on the user's tolerance for each type of error.
            async\_ (boolean, optional): if set to True, the statistics are calculated asynchronously.

        Returns:
            A :class:`ayasdi.core.models.multiclass_statistics.MulticlassStatistics` object for a multi class model,
            or a :class`ayasdi.core.models.regression_statistics.RegressionStatistics` object for a regress model
        """
        if self.model_id is None:
            raise ValueError('model_id not set. Verify that the model has been instantiated and is ready.')

        if group_classifier_column_set_id is None:
            group_classifier_column_set_id = column_set_id
        rest_args = {
            'source_view': {
                'source_id': source_id,
                'column_set_id': column_set_id,
                'group_id': group_id,
            },
            'group_classifier_source_view': {
                'source_id': source_id,
                'column_set_id': group_classifier_column_set_id,
                'group_id': group_id
            },
            'outcome_column_index': outcome_column_index,
            'decision_threshold': decision_threshold
        }

        if async_:
            url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/model_statistics/async'
            jobid = json_funcs._post_(self.connection.session, url, rest_args)
            print('Generating statistics is running in asynchronous mode.')
            print('Remember to call ready() to check status.')
            stats = self.get_statistics_type()(self.connection)
            stats.__set_async_job__(jobid, url)
        else:
            url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/model_statistics'
            res = json_funcs._post_(self.connection.session, url, rest_args)
            stats = self.get_statistics_type()(self.connection)
            stats.__fill_body__(res)

        return stats

    def get_statistics_type(self):
        if hasattr(self, '_kind') and self._kind == 'Regression':
            return RegressionStatistics
        else:
            return MulticlassStatistics

    def get_group_classifier_classes(self):
        return self.model_info['groupClassifierClasses']

    def get_local_model_classes(self):
        return self.model_info.get('localModelClasses')

    def get_classes(self):  # The union of classes of all local models.
        return self.model_info.get('classes')

    def __fill_body__(self, res):
        self.__set_base_properties__(res)
        self.json = res
        self._kind = self.model_info.get('problemKind')
        self.__ready = True
