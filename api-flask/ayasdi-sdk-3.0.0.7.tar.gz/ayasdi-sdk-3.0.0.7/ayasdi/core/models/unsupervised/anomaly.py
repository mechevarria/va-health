#!/usr/bin/env python

from __future__ import absolute_import, unicode_literals, division, print_function
from abc import ABC, abstractmethod

from ayasdi.core import json_funcs
from ayasdi.core.async_jobs import AsyncJob
from ayasdi.core.models.random_forest_spec import RandomForestSpec
from ayasdi.core.source_subset import SourceSubset

import copy


class Anomaly:
    """
    Class to create, retrieve, and delete anomaly detection model.

    :Example:

    >>> import ayasdi.core as ac
    >>> import time
    >>> src = connection.upload_source("./test/db_test2.txt")
    >>> group = src.create_group(name='group', row_indices=list(range(120)))
    >>> columns = ["relative weight", "blood glucose",
    ...            "insulin level", "insulin response"]
    >>> col_set = src.create_column_set(columns, "test_column_set")
    >>> spec = AnomalyRandomSampleSpec(
    ...        threshold=0.5,
    ...        sample_size=100,
    ...        sample_number=3,
    ...        group_classifier_spec=RandomForestSpec(),
    ...        metric={'id': 'Norm Correlation'},
    ...        lenses= [{'resolution': 30, 'id': 'MDS coord 1',
    ...                  'equalize': True, 'gain': 30},
    ...                 {'resolution': 30, 'id': 'MDS coord 2',
    ...                  'equalize': True, 'gain': 30}])
    >>> anomaly = Anomaly.create(connection, src.id, 'model', spec,
    ...                          column_set_id=col_set['id'], group_id=group['id'])
    >>> anomaly1 = Anomaly.get(connection, anomaly.model_id)
    >>> anomaly1.model_id == anomaly.model_id
    True
    >>> data_spec = SourceSubset(source_id=src.id, column_set_id=col_set['id'])
    >>> predict = anomaly.predict(data_spec)
    >>> len(predict['anomalies']) > 0
    True
    >>> Anomaly.delete(connection, anomaly.model_id)
    >>> spec = AnomalyFeatureWeightSpec(
    ...     column_set_id=col_set['id'], threshold=0.5,
    ...     num_features=4)
    >>> anomaly_fw = Anomaly.create(connection, src.id, 'model', spec,
    ...                             column_set_id=col_set['id'],
    ...                             group_id=group['id'], async_=True)
    Training is running in asynchronous mode.
    Remember to call ready() to check status.
    >>> while not anomaly_fw.ready():
    ...     time.sleep(5)
    >>> data_spec = SourceSubset(source_id=src.id, column_set_id=col_set['id'])
    >>> job = anomaly_fw.predict(data_spec, async_=True)
    Prediction is running in asynchronous mode.
    Remember to call ready() to check status.
    >>> while not job.ready():
    ...     time.sleep(5)
    >>> len(job.result['anomalies']) > 0
    True
    >>> Anomaly.delete(connection, anomaly_fw.model_id)
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    @classmethod
    def get(cls, connection, model_id):
        """
        Retrieve an anomaly detection model.

        Args:
            model_id (str): id of anomaly detection model to be retrieved.

        Returns:
            An anomaly detection model object :class:`ayasdi.core.models.unsupervised.anomaly.AnomalyFeatureWeight`
            or :class:`ayasdi.core.models.unsupervised.anomaly.AnomalyRandomSample`.
        """
        if model_id is None:
            raise ValueError('model_id cannot be None')
        url = connection.CORE_REQUEST_STUB + 'anomalies/' + str(model_id)
        anomaly = json_funcs._get_(connection.session, url)
        return cls._create_anomaly(connection, anomaly)

    @classmethod
    def create_model(cls, connection, data_spec, name, anomaly_spec, async_=False):
        """
        Create an anomaly detection model.

        Args:
            connection: an instance of :class:`ayasdi.core.api.Api`.
            data_spec: a :class:`ayasdi.core.source_subset.SourceSubset` object.
            name (str): Name of the model
            anomaly_spec: an instance of :class:`ayasdi.core.models.unsupervised.anomaly.AnomalyFeatureWeightSpec`
                          or :class:`ayasdi.core.models.unsupervised.anomaly.AnomalyRandomSampleSpec`.
            async_ (bool): when True, create an anomaly detection model asynchronously.
                          Default is False. (optional)

        Returns:
            The anomaly model object :class:`ayasdi.core.models.unsupervised.anomaly.AnomalyFeatureWeight`
            or :class:`ayasdi.core.models.unsupervised.anomaly.AnomalyRandomSample`

        :Example:
            See example in :class:`ayasdi.core.models.unsupervised.anomaly.Anomaly`
        """
        if not isinstance(data_spec, SourceSubset):
            raise ValueError('Need a SourceSubset object')

        if data_spec.source_id is None:
            raise ValueError('source_id in data_spec cannot be None')

        source_id = data_spec.source_id
        column_set_id = data_spec.column_set_id
        group_id = data_spec.group_id

        return cls.create(connection, source_id, name, anomaly_spec,
                          column_set_id=column_set_id, group_id=group_id,
                          async_=async_)

    @classmethod
    def create(cls, connection, source_id, name, anomaly_spec, column_set_id=None,
               group_id=None, async_=False):
        """
        Create an anomaly detection model.

        Args:
            connection: an instance of :class:`ayasdi.core.api.Api`.
            source_id (str): identifier of a source on which to create the model
            name (str): name of the model
            anomaly_spec: an instance of :class:`ayasdi.core.models.unsupervised.anomaly.AnomalyFeatureWeightSpec`
                          or :class:`ayasdi.core.models.unsupervised.anomaly.AnomalyRandomSampleSpec`.
            column_set_id (str): identifier of a column set specifying training features. (optional)
            group_id (str): identifier of a group specifying training rows. (optional)
            name (string): Name of a new model
            async_ (bool): when True, create an anomaly detection model asynchronously.
                          Default is False. (optional)

        Returns:
            The anomaly model object :class:`ayasdi.core.models.unsupervised.anomaly.AnomalyFeatureWeight`
            or :class:`ayasdi.core.models.unsupervised.anomaly.AnomalyRandomSample`

        :Example:
            See example in :class:`ayasdi.core.models.unsupervised.anomaly.Anomaly`
        """
        if not isinstance(anomaly_spec, AnomalyBaseSpec):
            raise ValueError('need a subclass of AnomalyBaseSpec to create a anomaly model')

        params = anomaly_spec.get_params()
        params['source_id'] = int(source_id)
        params['column_set_id'] = int(column_set_id) if column_set_id is not None else None
        params['group_id'] = int(group_id) if group_id is not None else None
        params['name'] = name

        url = connection.CORE_REQUEST_STUB + 'anomalies'
        if async_ is False:
            anomalies = json_funcs._post_(connection.session, url, params)
            return cls._create_anomaly(connection, anomalies)
        else:
            async_url = url + '/async'
            job_id = json_funcs._post_(connection.session, async_url, params)
            print('Training is running in asynchronous mode.')
            print('Remember to call ready() to check status.')
            job = AsyncJob(connection, job_id, async_url)
            return cls._create_anomaly(connection, params, job)

    @classmethod
    def _create_anomaly(cls, connection, anomaly, job=None):
        if job is None:
            model_id = anomaly['id']
        else:
            model_id = None

        if anomaly['detect_method'] == 'feature_weight':
            spec = AnomalyFeatureWeightSpec(**anomaly)
            return AnomalyFeatureWeight(connection, model_id,
                                        anomaly['source_id'], anomaly['column_set_id'],
                                        anomaly['group_id'], anomaly['name'],
                                        spec, job=job, direct=False)
        elif anomaly['detect_method'] == 'random_sample':
            spec = AnomalyRandomSampleSpec(**anomaly)
            return AnomalyRandomSample(connection, model_id,
                                       anomaly['source_id'], anomaly['column_set_id'],
                                       anomaly['group_id'], anomaly['name'],
                                       spec, job=job, direct=False)
        else:
            raise ValueError('{} is not a supported anomaly detection method'.format(
                anomaly['detect_method']))

    @classmethod
    def delete(cls, connection, model_id):
        """
        Delete an anomaly detection model by id.

        Args:
            connection: an instance of :class:`ayasdi.core.api.Api`.
            model_id (str): id of anomaly detection model to be deleted.

        Returns:
            None.

        :Example:
            See example in :class:`ayasdi.core.models.unsupervised.anomaly.Anomaly`
        """
        if model_id is None:
            raise ValueError('model_id cannot be None')
        url = connection.CORE_REQUEST_STUB + 'anomalies/' + str(model_id)
        json_funcs._delete_(connection.session, url)


class AnomalyBase(ABC):
    """
    Base class for anomaly detection model.
    It cannot be instantiated. Use one of its subclasses instead.
    """

    @abstractmethod
    def __init__(self, connection, model_id=None, job=None):
        self.connection = connection
        self.model_id = model_id
        self.async_job = job
        self.__ready = self.async_job is None

    def predict(self, data_spec, async_=False):
        """
        Predict anomalies in a source by using the anomaly detection model.


        Args:
            data_spec: a :class:`ayasdi.core.source_subset.SourceSubset` object.
            async_ (bool): when True, create an anomaly detection model asynchronously.
                Default is False. (optional)

        Returns:
            If ``async_`` is True, return an array of predicted anomalies. Each anomaly is a dictionary
            containing at least three fields, "row_index", "score", and "rank". Depending on the
            anomaly detection model type, it may contains other fields relevant only to the model.
            If ``async_`` is False, return an :class:`ayasdi.core.async_jobs.AsyncJob` object. The
            object's "result" field is the array of predicted anomalies. See a sample of predicted
            anomalies in the subclasses.

        :Example:
            See example in :class:`ayasdi.core.models.unsupervised.anomaly.Anomaly`
        """
        if not isinstance(data_spec, SourceSubset):
            raise ValueError('Need a SourceSubset object')

        if data_spec.source_id is None:
            raise ValueError('source_id in data_spec cannot be None')

        predict_source_id = data_spec.source_id
        predict_column_set_id = data_spec.column_set_id
        predict_group_id = data_spec.group_id

        params = {'model_id': self.model_id,
                  'source_id': predict_source_id,
                  'column_set_id': predict_column_set_id,
                  'group_id': predict_group_id}

        url = self.connection.CORE_REQUEST_STUB + 'anomalies/' + str(self.model_id) + '/prediction'
        if async_ is False:
            anomalies = json_funcs._post_(self.connection.session, url, params)
            return anomalies
        else:
            url = url + '/async'
            job_id = json_funcs._post_(self.connection.session, url, params)
            job_url = self.connection.CORE_REQUEST_STUB + 'anomalies/prediction/async'
            print('Prediction is running in asynchronous mode.')
            print('Remember to call ready() to check status.')
            return AsyncJob(self.connection, job_id, job_url)

    def ready(self):
        """
        Check if this anomaly detection model is ready to be used for prediction.
        if it returns True, the anomaly detection model is created and can be used for prediction.
        If it returns False, the anomaly detection model is created asynchronously and it is not ready
        to be used for prediction.
        """
        if not self.__ready:
            self.__ready = self.async_job.ready()
            if self.__ready:
                self.__fill_body__(self.async_job.result)
                self.async_job = None
        return self.__ready

    @abstractmethod
    def __fill_body__(self, anomaly):
        self.model_id = anomaly['id']
        self.source_id = str(anomaly['source_id'])
        self.column_set_id = str(anomaly['column_set_id'])
        self.group_id = str(anomaly['group_id'])
        self.name = str(anomaly['name'])

    def delete(self):
        """
        Delete an anomaly detection model by id.

        Returns:
            None.

        :Example:
            See example in :class:`ayasdi.core.models.unsupervised.anomaly.Anomaly`
        """
        url = self.connection.CORE_REQUEST_STUB + 'anomalies/' + self.model_id
        json_funcs._delete_(self.connection.session, url)


class AnomalyFeatureWeight(AnomalyBase):
    """
    Class for feature weight anomaly detection model.
    The anomalies predicted by this model has the form:

    .. code-block:: python

        [{'row_index': 49, 'score': 1.0, 'rank': 1,
         'features': [{'name': 'insulin response', 'column_index': 4,
                       'centrality_score': 0.7702002163397759, 'value': 292.0,
                       'population_mean': 186.1172413793103, 'z_score': 0.8755333021675149},
                      ..., ]},
          ..., ]

    """

    def __init__(self, connection, model_id, source_id, column_set_id, group_id, name,
                 anomaly_feature_weight_spec, job=None, direct=True):
        if direct:
            raise ValueError('cannot instantiate class directly. Use Anomaly.create method instead')
        else:
            if not isinstance(anomaly_feature_weight_spec, AnomalyFeatureWeightSpec):
                raise ValueError('an AnomalyFeatureWeightSpec object is needed')
            else:
                super().__init__(connection, model_id, job)
                self.anomaly_spec = anomaly_feature_weight_spec
                self.source_id = source_id
                self.column_set_id = column_set_id
                self.group_id = group_id
                self.name = name

    def __fill_body__(self, anomaly):
        super().__fill_body__(anomaly)
        self.anomaly_spec = AnomalyFeatureWeightSpec(**anomaly)


class AnomalyRandomSample(AnomalyBase):
    """
    Class for random sample anomaly detection model.

    The anomalies predicted by this model has the form:

    .. code-block:: python

        [{'row_index': 127, 'score': 0.9654928580224514, 'rank': 1, 'consensus': 1.0}, ..., ]
    """

    def __init__(self, connection, model_id, source_id, column_set_id, group_id, name,
                 anomaly_random_sample_spec, job=None, direct=True):
        if direct:
            raise ValueError('cannot instantiate class directly. Use Anomaly.create method instead')
        else:
            if not isinstance(anomaly_random_sample_spec, AnomalyRandomSampleSpec):
                raise ValueError('an AnomalyRandomSampleSpec object is needed')
            else:
                super().__init__(connection, model_id, job)
                self.anomaly_spec = anomaly_random_sample_spec
                self.source_id = source_id
                self.column_set_id = column_set_id
                self.group_id = group_id
                self.name = name

    def __fill_body__(self, anomaly):
        super().__fill_body__(anomaly)
        self.anomaly_spec = AnomalyRandomSampleSpec(**anomaly)


class AnomalyBaseSpec(ABC):
    """
    Base class for providing parameters to create an anomaly
    detection model.
    """
    @abstractmethod
    def __init__(self, detect_method):
        self.detect_method = detect_method

    def get_params(self):
        """
        Get paramters to create an anomaly detection model
        """
        params = copy.deepcopy(self.__dict__)
        return params


class AnomalyFeatureWeightSpec(AnomalyBaseSpec):
    """
    Class to provide parameter to create a feature weight anomaly
    detection model.

    Args:
       threshold: The minimum score for a row to be considered an anomaly (It is in [0, 1] and default is 0.5)
       num_features: Number of top features to be displayed per anomalous row (Default is 5)
       algorithm: Currently supported algorithms: CentralityScoring (Default is CentralityScoring)
       log_transform: Apply log transform on the lens value before converting to risk score (Defaults to False)
    """
    def __init__(self, threshold=0.5,
                 num_features=5, algorithm='CentralityScoring',
                 log_transform=False, **kwarg):
        if threshold < 0 or threshold > 1:
            raise ValueError('threshold should be in [0, 1]')
        super().__init__('feature_weight')
        self.threshold = threshold
        self.num_features = num_features
        self.algorithm = algorithm
        self.log_transform = log_transform


class AnomalyRandomSampleSpec(AnomalyBaseSpec):
    """
    Class to provide parameter to create a random sample anomaly
    detection model.

    Args:
        metric (param): a metric to create a network
        lenses (param): A list of lenses to create a network
        threshold (float): The minimum score for a row to be considered an anomaly. (It is in [0, 1])
        sample_size (int): size of rows in one sample (Default is 10000)
        sample_number (int): number of samples used for anomaly detection and must be an odd number (Default is 5)
        algorithm (str): algorithm for autogrouping (Default is connected_components)
        group_classifier_spec: a :class:`ModelSpec` object to specify parameters used in group classifier
            algorithms. It can be one of these subclasses:
                - :class:`ayasdi.core.models.random_forest_spec.RandomForestSpec` for random forest algorithm,
                - :class:`ayasdi.core.models.decision_tree_spec.DecisionTreeSpec` for decision tree algorithm,
                - :class:`ayasdi.core.models.logistic_regression_spec.LogisticRegressionSpec` for logistic
                  regression algorithm.
                - :class:`ayasdi.core.models.gbdt_spec.GbdtSpec` for gradient boosted decision tree algorithm.
            default= RandomForestSpec().
        min_row_count (int): minimum number of rows in a non singleton group (Default is 2)
    """
    def __init__(self, metric, lenses, threshold,
                 sample_size=10000, sample_number=5, group_id=None,
                 algorithm='connected_components',
                 group_classifier_spec=RandomForestSpec(), min_row_count=2, **kwarg):
        if threshold < 0 or threshold > 1:
            raise ValueError('threshold should be in [0, 1]')
        super().__init__('random_sample')
        self.metric = metric
        self.lenses = lenses
        self.threshold = threshold
        self.sample_size = sample_size
        self.sample_number = sample_number
        self.algorithm = algorithm
        self.group_classifier_spec = group_classifier_spec
        self.min_row_count = min_row_count

    def get_params(self):
        """
        Get paramters to create a random sample anomaly detection model
        """
        params = copy.deepcopy(self.__dict__)
        del params['group_classifier_spec']
        params[self.group_classifier_spec.spec_type()] = self.group_classifier_spec.serialize()
        return params
