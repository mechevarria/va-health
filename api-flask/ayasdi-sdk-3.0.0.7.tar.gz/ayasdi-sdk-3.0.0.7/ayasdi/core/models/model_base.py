import json
import logging

from ayasdi.core import json_funcs
from ayasdi.core.models import utilities
from ayasdi.core.async_jobs import AsyncJob
from requests import HTTPError
from requests_toolbelt import MultipartEncoder
from logging import NullHandler

LOGGER = logging.getLogger(__name__)
LOGGER.addHandler(NullHandler())


class ModelBase(object):
    """
    Base class with common properties
    """

    @property
    def name(self):
        """
        The name of the model
        """
        return getattr(self, '_name', None)

    @property
    def type(self):
        """
        The type of the model
        """
        return getattr(self, '_type', None)

    @property
    def description(self):
        """
        The description of the model
        """
        return getattr(self, '_description', None)

    @property
    def model_id(self):
        """
       A system wide unique identifier of the model
        """
        return getattr(self, '_model_id', None)

    @property
    def model_info(self):
        """
        Any kind of additional information in the form of a dictionary specific to the model type
        """
        return getattr(self, '_model_info', None)

    @property
    def creation_time(self):
        """
        The date and time of the creation 
        """
        return getattr(self, '_creation_time', None)

    @property
    def update_time(self):
        """
        The date and time details of the last update 
        """
        return getattr(self, '_update_time', None)

    @staticmethod
    def create_model(connection,
                     name,
                     data_spec,
                     model_spec,
                     outcome_column_index,
                     async_=False,
                     description=None):
        raise Exception("The spec percentages does not correspond to a model implementing this call. Use a different"
                        "model or a different way to create this one." % type(model_spec))

    @staticmethod
    def delete_model(connection, model_id):
        """
        Delete model

        Args:
            connection : an instance of :class:`ayasdi.core.api.Api`
            model_id (str): Model identifier

        :Example:

        >>> import uuid
        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>> from ayasdi.core.models.model_base import ModelBase
        >>>
        >>> source = connection.upload_source("./test/iris_binomial.csv")
        >>> source.sync()
        >>> model = acm.DecisionTree.create(connection, source.id,
        ...                                 name='model_' + str(uuid.uuid4()),
        ...                                 outcome_column_index=source.colname_to_ids['setosa'])
        >>> model_id = model.model_id
        >>> # delete source to unlink it
        >>> connection.delete_source(id=source.id, remove_model=False)
        >>> # delete model
        >>> ModelBase.delete_model(connection, model_id)
        """
        utilities._delete_model(connection, model_id)

    def delete(self):
        """
        Delete model

        :Example:

        >>> import uuid
        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>>
        >>> source = connection.upload_source("./test/iris_binomial.csv")
        >>> source.sync()
        >>> model = acm.DecisionTree.create(connection, source.id,
        ...                                 name='model_' + str(uuid.uuid4()),
        ...                                 outcome_column_index=source.colname_to_ids['setosa'])
        >>> model_id = model.model_id
        >>> # delete source to unlink it
        >>> connection.delete_source(id=source.id, remove_model=False)
        >>> # delete model
        >>> model.delete()
        """
        utilities._delete_model(self.connection, self._model_id)

    def __set_base_properties__(self, res):
        self._name = res.get('name')
        self._type = res.get('type')
        self._description = res.get('description')
        self._model_id = res.get('model_id')
        self._model_info = json.loads(res['model_info'])

        self.version = res.get('version')
        self.source_id = res.get('source_id')

        self._creation_time = utilities.__to_datetime__(res['creation_time'])
        self._update_time = utilities.__to_datetime__(res['update_time'])
        self.metadata = res.get('metadata')

    def export_model(self, filename, fs_option='local'):
        """
        Export model

        Args:
            filename (str): export filename
            fs_option (str): filesystem location option. 'local' for client local. 'hfs' for Hadoop filesystem.

        :Example:

        >>> import os
        >>> import uuid
        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>>
        >>> source = connection.upload_source("./test/iris_binomial.csv")
        >>> source.sync()
        >>> model = acm.DecisionTree.create(connection, source.id,
        ...                                 name='model_' + str(uuid.uuid4()),
        ...                                 outcome_column_index=source.colname_to_ids['setosa'])
        >>> model.export_model('/tmp/exportModel0001.jar', fs_option='local')
        >>> connection.delete_source(id=source.id, remove_model=False)
        >>> os.remove('/tmp/exportModel0001.jar')
        """
        rest_args = {
            'filename': filename,
            'fs_option': fs_option
        }
        async_ = False
        if async_:
            url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/export/async'
            json_funcs._get_(self.connection.session,
                             url, params=rest_args)
            print('Export is running in asynchronous mode.')
            print('Remember to call ready() to check status.')
        else:
            url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/export'
            res = json_funcs._get_octet_(self.connection.session,
                                         url, params=rest_args)
            try:
                if (fs_option == 'local'):
                    if not(len(filename) > 4 and filename[-4:] == '.jar'):
                        filename = filename + '.jar'
                    f = open(filename, 'wb')
                    for chunk in res.iter_content(chunk_size=1024):
                        f.write(chunk)
            except Exception as e:
                LOGGER.exception(e)
                error_message = 'Unable to open or write to local file: {}'.format(e)
                raise ValueError(error_message)

    @staticmethod
    def import_model(connection, filename, fs_option='local'):
        """
        Import model from a file

        Args:
            connection : an instance of class ayasdi.core.api.Api
            filename (str): export filename
            fs_option (str): filesystem location option. 'local' for client local. 'hfs' for Hadoop filesystem.

        Returns:
            list of model ids.

        :Example:

        >>> import os
        >>> import uuid
        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>> from ayasdi.core.models.model_base import ModelBase
        >>>
        >>> source = connection.upload_source("./test/decision_tree_test.csv")
        >>> source.sync()
        >>> model = acm.DecisionTree.create(connection, source.id,
        ...                                 name='model_' + str(uuid.uuid4()), outcome_column_index=12)
        >>> outputJarFilename = '/tmp/exportModel0001.jar'
        >>> model.export_model(outputJarFilename, fs_option='local')
        >>> connection.delete_source(id=source.id)
        >>>
        >>> ids = ModelBase.import_model(connection, outputJarFilename, fs_option='local')
        >>> gc_import = acm.DecisionTree.get_model(connection, ids[0])
        >>> source_new = connection.upload_source('./test/new_dt_test.csv')
        >>> source_new.sync()
        >>>
        >>> predictions = gc_import.predict_proba(data_spec=ac.SourceSubset(source_new.id))
        >>> gc_import.delete()
        >>> os.remove(outputJarFilename)
        """
        utilities._check_connection(connection)
        rest_args = {
            'filename': filename
        }
        async_ = False
        if async_:
            url = connection.CORE_REQUEST_STUB + 'models/import/async'
            json_funcs._post_(connection.session,
                              url, data=None, params=rest_args)
            print('Import is running in asynchronous mode.')
            print('Remember to call ready() to check status.')
        else:
            if (fs_option == 'local'):
                m = MultipartEncoder([('name', filename),
                                     ('file', (filename, open(filename, 'rb'), 'application/octet-stream'))])
                url = connection.CORE_REQUEST_STUB + 'models/import_with_data'
                res = json_funcs._post_(connection.session, url, m,
                                        content_type=m.content_type, params=rest_args)
            else:
                url = connection.CORE_REQUEST_STUB + 'models/import'
                res = json_funcs._post_(connection.session, url, data=None, params=rest_args)
            return res

    def ready(self):
        """
        Check the readiness of the object.
        Used as part of an asynchronous call pattern.
        """
        if self.__ready:
            return True
        else:
            async_ready = self.async_job.ready()
            if async_ready:
                self.__fill_body__(self.async_job.result)
                return True
            else:
                return False

    def __set_async_job__(self, async_job, url):
        self.__ready = False
        self.async_job = AsyncJob(self.connection, async_job, url)

