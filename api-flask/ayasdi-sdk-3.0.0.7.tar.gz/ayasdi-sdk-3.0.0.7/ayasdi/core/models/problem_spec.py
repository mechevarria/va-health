class ProblemSpec():
    """
    Base class with fields as the parameters for the problem being solved: outcome-based classifcation/regression,
    or group membership classification.
    """
