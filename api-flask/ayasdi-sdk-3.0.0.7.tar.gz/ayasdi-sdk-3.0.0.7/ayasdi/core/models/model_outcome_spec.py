from ayasdi.core.models.problem_spec import ProblemSpec


class ModelOutcomeSpec(ProblemSpec):
    """
    A class with fields as the parameters for outcome-based classification/regression problems

    Args:
        outcome_column_index (int): outcome column index
        ignore_null_outcomes (bool): ignore rows with null outcome data or not.
    """

    @property
    def outcome_column_index(self):
        """Outcome column index"""
        return getattr(self, '_outcome_column_index', None)

    @property
    def ignore_null_outcomes(self):
        """Ignore rows of null outcome data or not."""
        return getattr(self, '_ignore_null_outcomes', True)

    def __init__(self, outcome_column_index, ignore_null_outcomes=True):
        self._outcome_column_index = outcome_column_index
        self._ignore_null_outcomes = ignore_null_outcomes
