from ayasdi.core import json_funcs
from ayasdi.core.data_point_list import DataPointList
from ayasdi.core.models.model_base import ModelBase
from ayasdi.core.models.regression_statistics import RegressionStatistics


class RegressionModel(ModelBase):
    """Base Regression Model"""
    def __init__(self):
        ModelBase.__init__(self)

    def predict_values(self, data_spec):
        """
        Predict regression values for each data point

        Args:
            data_spec (:class:`ayasdi.core.DataSpec`): an object of subclass :class:`DataSpec` which defines
                data on which to perform predictions on.

                Sample using :class:`ayasdi.core.DataPointList`:
                    predictions = model.predict_values([[5.1,3.5,1.4,0.2], [6.4,2.9,4.3,1.3]])

                Sample using :class:`ayasdi.core.SourceSubset`:
                    subset = SourceSubset(test_source.id, group1[u"id"], column_set1[u"id"])
                    predictions = model.predict_values(subset)

        Returns:
                A list of values for each point, in order.

                Samples:
                    [0.9983636344249522, 0.0, 0.0016363655750477948]

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> source = connection.upload_source(u'./test/db_test2.txt')
        >>> source.sync()
        >>> columns_for_analysis = [
        ...     u'relative weight',
        ...     u'blood glucose',
        ...     u'insulin level',
        ...     u'insulin response',
        ... ]
        >>>
        >>> column_set = source.create_column_set(
        ...     column_list=columns_for_analysis,
        ...     name=u'column_set_123')
        >>> from ayasdi.core.models.gbdt import GBDT
        >>> model = GBDT.create(
        ...     connection,
        ...     source_id=source.id,
        ...     name=u'model_1',
        ...     column_set_id=column_set[u'id'],
        ...     outcome_column_index=source.colname_to_ids[u'steady state plasma glucose'])
        >>> group1 = source.create_group(name=u'group_1', row_indices=list(range(0, 50)))
        >>> values = model.predict_values(ac.SourceSubset(
        ...     source_id=source.id,
        ...     column_set_id=column_set[u'id'],
        ...     group_id=group1[u'id']))
        >>> connection.delete_source(source.id)
        """
        if self.model_id is None:
            raise ValueError('model_id not set. Verify that the model has been instantiated and is ready.')

        if isinstance(data_spec, list):
            data_spec = DataPointList(data_spec)

        request = {
            u'data_spec': data_spec.serialize()
        }

        url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/predict_values'
        response = json_funcs._post_(self.connection.session, url, request)
        return response[u'values']

    def get_statistics_type(self):
        return RegressionStatistics
