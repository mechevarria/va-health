from datetime import datetime

import ayasdi.core
from ayasdi.core import json_funcs
from dateutil import parser as dt_parser


def _check_connection(connection):
    if not isinstance(connection, ayasdi.core.api.Api):
        raise TypeError("TypeError: first parameter must be an Api object. "
                        "This is a change since Ayasdi SDK version 7.10.")


def __to_readable__(coefficients, column_names):
    """
    Converts regression coefficients to human readable formula.
    :param coefficients: dictionary with regression coefficients - column identifier to coefficient value
    :param column_names: list of column names
    :return:
        Human readable regression formula in the following form like in the example:
        + 1.19208e+00 + 6.09894e-01 * [petal_width] + 2.27001e-01 * [petal_length]
         - 1.09741e-01 * [sepal_length] - 4.42404e-02 * [sepal_width]
    """

    def __format_float__(val):
        return ('- ' if val < 0 else '+ ') + ('{0:.5e}'.format(abs(val)))

    # ['sepal_length', 'sepal_width', 'petal_length', 'petal_width']
    # {0:'sepal_length', 1:'sepal_width', 2:'petal_length', 3:'petal_width'}
    indexed_names = {k: v for k, v in enumerate(column_names)}

    # {'0':-1.09741e-01, '1':-4.42404e-02, '2':+2.27001e-01, '3':+6.09894e-01}
    # [('sepal_length':-1.09741e-01), ('sepal_width':-4.42404e-02), ('petal_length':+2.27001e-01),
    #  ('petal_width':+6.09894e-01)]
    vals = [(indexed_names[int(idx)], coef) for idx, coef in coefficients['betas'].items()]

    # [('petal_width':+6.09894e-01), ('petal_length':+2.27001e-01), ('sepal_length':-1.09741e-01),
    #  ('sepal_width':-4.42404e-02)]
    vals = sorted(vals, key=lambda tup: -abs(tup[1]))

    result = ''
    if abs(coefficients['intercept']) > 0:
        result = result + __format_float__(coefficients['intercept'])

    for name, coef in vals:
        result = result + ' ' + __format_float__(coef) + ' * [' + name + ']'
    return result


def _get_model(connection, model_id, cls):
    """
    Retrieve model and create an instance

    Args:
        connection : an instance of class ayasdi.core.api.Api
        model_id: Model identifier

    Returns:
        An instance of a model.

    :Example:

    >>> import uuid
    >>> import ayasdi.core as ac
    >>> import ayasdi.core.models as acm
    >>>
    >>> source = connection.upload_source("./test/iris_binomial.csv")
    >>> source.sync()
    >>> model = acm.DecisionTree.create(connection, source.id,
    ...                                 name='model_' + str(uuid.uuid4()),
    ...                                 outcome_column_index=source.colname_to_ids['setosa'])
    >>> model_id = model.model_id
    >>> model2 = _get_model(connection, model_id, acm.DecisionTree)
    """
    _check_connection(connection)
    if model_id is None:
        raise ValueError('model_id cannot be None')
    url = connection.CORE_REQUEST_STUB + 'models/' + model_id
    res = json_funcs._get_(connection.session, url)
    model = cls(connection)
    model.__fill_body__(res)
    return model


def _get_time_series_parent_model(connection, model_id, cls):
    """
    Retrieve a time series parent model and create an instance

    Args:
        connection : an instance of :class:`Api <ayasdi.core.api.Api>`
        model_id: the parent model identifier
        cls: parent model class.

    Returns:
        An instance of a time series parent model of class cls.

    :Example:

    >>> import uuid
    >>> import ayasdi.core as ac
    >>> import ayasdi.core.models.time_series_models as tsm
    >>>
    >>> source = connection.upload_source("./test/time_series_wpi.csv")
    >>> source.sync()
    >>> model = tsm.Sarimax.create(connection, name=str(uuid.uuid4()),
    ...                            source_id=source.id, endogenous_column_index=0, date_time_column_index=1)
    >>> model_id = model.model_id
    >>> model2 = _get_time_series_parent_model(connection, model_id, tsm.SarimaxParentModel)
    >>> connection.delete_source(source.id) #ignore-in-doc
    """
    _check_connection(connection)
    if model_id is None:
        raise ValueError('model_id cannot be None')
    url = connection.CORE_REQUEST_STUB + 'time_series_models/parent_model/' + model_id
    res = json_funcs._get_(connection.session, url)
    model = cls(connection)
    model.__fill_body__(res)
    return model


def _delete_model(connection, model_id):
    _check_connection(connection)
    if model_id is None:
        raise ValueError('model_id cannot be None')
    url = connection.CORE_REQUEST_STUB + 'models/' + model_id
    json_funcs._delete_(connection.session, url)


def _delete_time_series_parent_model(connection, model_id):
    _check_connection(connection)
    if model_id is None:
        raise ValueError('model_id cannot be None')
    url = connection.CORE_REQUEST_STUB + 'time_series_models/parent_model/' + model_id
    json_funcs._delete_(connection.session, url)


def __to_datetime__(ts):
    """
    Converts timestamp (number of milliseconds since January 1, 1970 00:00:00 GMT) or string (like
    'Feb 18, 2018 2:42:04 AM'() to Python datetime.
    :param ts: timestamp (number of milliseconds since January 1, 1970 00:00:00 GMT)
        or unicode string like 'Feb 18, 2018 2:42:04 AM'
    :return: datetime
    """
    try:
        return datetime.fromtimestamp(ts / 1000.0)
    except TypeError:
        return dt_parser.parse(ts)
