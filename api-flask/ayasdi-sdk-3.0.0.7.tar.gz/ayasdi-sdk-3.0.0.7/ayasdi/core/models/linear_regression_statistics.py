from ayasdi.core.models.regression_statistics import RegressionStatistics


class LinearRegressionStatistics(RegressionStatistics):
    """
    Regression statistics data
    """

    @property
    def r2_adjusted(self):
        """
        Adjusted coefficient of determination
        """
        return getattr(self, '_r2_adjusted', None)

    @property
    def residual_sum_of_squares(self):
        """
        The residual sum of squares (RSS), also known as the sum of squared residuals (SSR) or the sum of squared
        errors of prediction (SSE), is the sum of the squares of residuals (deviations predicted from actual
        empirical values of data). It is a measure of the discrepancy between the data and an estimation model.
        A small RSS indicates a tight fit of the model to the data.
        """
        return getattr(self, '_residual_sum_of_squares', None)

    @property
    def total_sum_of_squares(self):
        """
        The total sum of squares (TSS or SST) is a quantity that appears as part of a standard way of presenting
        results of such analyses. It is defined as being the sum, over all observations, of the squared differences
        of each observation from the overall mean.
        """
        return getattr(self, '_total_sum_of_squares', None)

    @property
    def Durbin_Watson(self):
        """
        Durbin-Watson statistic is a test statistic used to detect the presence of autocorrelation at lag 1 in the
        residuals (prediction errors) from a regression analysis.
        """
        return getattr(self, '_Durbin_Watson', None)

    @property
    def residual_standard_error(self):
        """
        Positive square root of the mean squared error
        """
        return getattr(self, '_residual_standard_error', None)

    @property
    def coefficients(self):
        """
        A list of :class:`ayasdi.core.models.regression_coefficient_statistics.RegressionCoefficientStatistics`
        objects representing statistics associated with individual regression coefficients (including intercept).
        """
        return getattr(self, '_coefficients', [])

    @property
    def f_value(self):
        """
        f value
        \fF = regression_mean_square / mean_squared_error\f
        \fmean_squared_error = residual_sum_of_squares / denominator_degrees_of_freedom\f
        \fregression_mean_square = regression_sum_of_squares / (number_of_parameters - 1)\f
        """
        return getattr(self, '_f_value', None)

    @property
    def numerator_degrees_of_freedom(self):
        """
        numerator degrees of freedom
        \fnumerator_degrees_of_freedom = number_of_parameters - 1\f
        """
        return getattr(self, '_numerator_degrees_of_freedom', None)

    @property
    def denominator_degrees_of_freedom(self):
        """
        denominator degrees of freedom
        \fdenominator_degrees_of_freedom = number_of_samples - number_of_parameters\f
        """
        return getattr(self, '_denominator_degrees_of_freedom', None)

    def __init__(self, connection):
        """
        Initialize LinearRegressionStatistics object
        """
        super(LinearRegressionStatistics, self).__init__(connection)

    def __repr__(self):
        return "LinearRegressionStatistics: " + str(self.json)
