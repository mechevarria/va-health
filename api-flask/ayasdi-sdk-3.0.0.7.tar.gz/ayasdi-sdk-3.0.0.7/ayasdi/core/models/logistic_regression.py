import json

from ayasdi.core import json_funcs
from ayasdi.core.models import utilities
from ayasdi.core.models.classification_model import ClassificationModel
from ayasdi.core.models.validation_statistics import ValidationStatistics


class LogisticRegression(ClassificationModel, ValidationStatistics):
    """
    A user can create, retrieve, and predict with a logistic regression model.
    Use static function :func:`LogisticRegression.create` to train a model, or use
    :func:`LogisticRegression.get_model` to retrieve an existing model.
    Given a LogisticRegression instance, use :func:`predict_proba` to predict.
    """

    def __init__(self, connection):
        """
        Initialize LogisticRegression

        Args:
            connection (str) : an instance of class ayasdi.core.api.Api
        """
        ClassificationModel.__init__(self)
        self.json = None
        self.__ready = None
        self.async_job = None
        self.__coefficients = None
        self.__readable = None
        self.connection = connection

    @staticmethod
    def get_model(connection, model_id):
        """
        Use this to retrieve a model and create an instance

        Args:
            connection (str) : An instance of class ayasdi.core.api.Api
            model_id: Model ID

        Returns:
            An instance of LogisticRegression

        :Example:

        >>> import uuid
        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>>
        >>> source = connection.upload_source("./test/iris_binomial.csv")
        >>> columns_for_analysis = ["sepal_length",
        ...                         "sepal_width",
        ...                         "petal_length",
        ...                         "petal_width"]
        >>> cs = source.create_column_set(column_list=columns_for_analysis,
        ...                               name='cs_' + str(uuid.uuid4()))
        >>> source.sync()
        >>> model = acm.LogisticRegression.create(connection, source.id,
        ...                                       name='model_' + str(uuid.uuid4()),
        ...                                       column_set_id=cs['id'],
        ...                                       outcome_column_index=source.colname_to_ids['setosa'])
        >>> model_id = model.model_id
        >>> model2 = acm.LogisticRegression.get_model(connection, model_id)
        """
        utilities._check_connection(connection)
        model = utilities._get_model(connection, model_id, LogisticRegression)
        if model.type != 'LogisticRegression':
            raise AttributeError('Model is not a logistic regression (it is a ' + model.type + ').')
        return model

    def __reload(self):
        if self.model_id is None:
            raise ValueError('model_id cannot be None')
        url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id
        res = json_funcs._get_(self.connection.session, url)
        if res['type'] != 'LogisticRegression':
            raise AttributeError('Model is not a logistic regression (it is a ' + res['type'] + ').')
        self.__fill_body__(res)

    @staticmethod
    def get_models(connection, scope="team"):
        """
        Retrieve all LogisticRegression models

        Args:
            connection (str) : An instance of class ayasdi.core.api.Api
            scope: This shows how widely to search - takes "user" or "team". Default value is "team"

        Returns:
            List of LogisticRegression models
        """
        utilities._check_connection(connection)
        url = connection.CORE_REQUEST_STUB + 'models?type=logistic_regression&scope=' + scope
        res = json_funcs._get_(connection.session, url)
        all_models = []
        for m in res['models']:
            model = LogisticRegression(connection)
            model.__fill_body__(m)
            all_models.append(model)
        return all_models

    @staticmethod
    def _create_model(connection,
                      name,
                      data_spec,
                      model_spec,
                      outcome_column_index,
                      async_=False,
                      description=None,
                      metadata={},
                      ignore_null_outcomes=True):
        return LogisticRegression.create(connection=connection,
                                         source_id=data_spec.source_id,
                                         name=name,
                                         outcome_column_index=outcome_column_index,
                                         column_set_id=data_spec.column_set_id,
                                         group_id=data_spec.group_id,
                                         intercept=model_spec.intercept,
                                         max_iterations=model_spec.max_iterations,
                                         regularization=model_spec.regularization,
                                         lambda_=model_spec.lambda_,
                                         random_seed=model_spec.random_seed,
                                         epsilon=model_spec.epsilon,
                                         async_=async_,
                                         description=description,
                                         metadata=metadata,
                                         ignore_null_outcomes=ignore_null_outcomes)

    @staticmethod
    def create(connection,
               source_id,
               name,
               outcome_column_index,
               column_set_id=None,
               group_id=None,
               intercept=True,
               max_iterations=0,
               regularization='NoPenalty',
               lambda_=0.0,
               random_seed=0,
               epsilon=0.0001,
               async_=False,
               description=None,
               metadata={},
               ignore_null_outcomes=True):
        """
        This is used to create and train logistic regression

        Args:
            connection (str) : An instance of :class:`ayasdi.core.api.Api` (a connection to the Ayasdi platform)
            source_id (str) : The ID of the source against which to create the model
            name (str) : The name for the model to be created
            outcome_column_index (int) : The index of column to use as outcome/label
            column_set_id (str) : The ID of column set specifying training features (optional)
            group_id (str) : The ID of group specifying training rows (optional)
            max_iterations (int) : The maximum number of algorithm iterations. If not provided or specified as 0,
                the platform uses the algorithm's default value. Default=0 (optional)
            regularization (str, enum) : This specifies the type of regularization to be applied. Legal values: 'NoPenalty'
                (default), 'L1Penalty1', or 'L2Penalty'.
            lambda_ (double) : This parameter is used in calculation of L1 or L2 regularization. Default=0.0 (optional)
            intercept (bool) : If set to True, the model tries to fit an intercept value; if set to False, the
                platforms assumes an intercept value of 0. Default=True
            random_seed (long) : A number used to initialize a pseudorandom number generator for some algorithms.
                (optional)
            epsilon (double) : This defines a loop exit criteria in certain algorithms. If defined, while the algorithm
                attempts to find a minimum, when it reaches a precision defined by epsilon, it terminates. The
                smaller the epsilon, the greater the precision (e.g. 0.0001). (optional)
            async\_ (bool) : If set to True, specifies that the method will run in asynchronous mode. When set to
                False or not present, method runs in synchronous mode. Default=False (optional)
            description (str): The user-provided description of the model (optional)
            metadata (dict): The metadata for the column set stored as key-value pairs (optional).
            ignore_null_outcomes (boolean, optional): Whether to exclude rows where outcome value is null

        Returns:
            An instance of LogisticRegression
        """
        utilities._check_connection(connection)
        rest_args = {
            'model_type': 'logistic_regression',
            'model_name': name,
            'model_description': description,
            'logistic_regression_params': {
                'source_view': {
                    'source_id': source_id,
                    'column_set_id': column_set_id,
                    'group_id': group_id,
                    'ignore_null_outcomes': ignore_null_outcomes
                },
                'outcome_column_index': outcome_column_index,
                'intercept': intercept,
                'max_iterations': max_iterations,
                'regularization': regularization,
                'lambda': lambda_,
                'random_seed': random_seed,
                'epsilon': epsilon
            },
            'metadata': metadata
        }

        if async_:
            url = connection.CORE_REQUEST_STUB + 'models/async'
            jobid = json_funcs._post_(connection.session,
                                      url, rest_args)
            print('Training is running in asynchronous mode.')
            print('Remember to call ready() to check status.')

            model = LogisticRegression(connection)
            model.__set_async_job__(jobid, url)
            return model
        else:
            url = connection.CORE_REQUEST_STUB + 'models'
            res = json_funcs._post_(connection.session,
                                    url, rest_args)
            model = LogisticRegression(connection)
            model.__fill_body__(res)
            return model

    def get_training_columns(self):
        """
       This fetches the columns that were used for training the model.

        Args:
            None

        Returns:
            A list of column names used for training.

        """
        if 'training_schema' in self.model_info:
            return self.model_info['training_schema']['training_column_names']
        else:
            return self.model_info['training_columns']

    def get_coefficients(self):
        """
        Use this to fetch the trained model coefficients including intercept and betas.

        Args:
            None

        Returns:
            Dictionary with up to two elements: 'intercept' (if present), 'betas',
            where 'betas' contains another dictionary one-based index
            (corresponding to training column) to value. For example:
            {u'intercept': 1.192083994828211,
            u'betas': {
            u'1': -0.10974146329310251,
            u'3': 0.2270013821719135,
            u'2': -0.04424044671765222,
            u'4': 0.6098941197163753}
            }
        """
        if self.__ready and self.__coefficients is None:
            self.__reload()
        return self.__coefficients

    def get_readable(self):
        """
        This fetches the trained model coefficients in human readable format
        sorted by module with column names.

        Args:
            None

        Returns:
            Trained linear model formula. For example:
            1.19208399483 +6.09894e-01 * [petal_width] +2.27001e-01 * [petal_length]
            -1.09741e-01 * [sepal_length] -4.42404e-02 * [sepal_width]
        """
        if self.__ready and self.__readable is None:
            self.__reload()
        return self.__readable

    def __fill_body__(self, res):
        self.__set_base_properties__(res)
        self.json = res
        if 'model' in res and res['model'] is not None:
            self.__coefficients = json.loads(res['model'])
            self.__readable = utilities.__to_readable__(self.__coefficients, self.get_training_columns())
        if 'domain' in self._model_info:
            self._classes = self._model_info['domain']
        self.__ready = True
