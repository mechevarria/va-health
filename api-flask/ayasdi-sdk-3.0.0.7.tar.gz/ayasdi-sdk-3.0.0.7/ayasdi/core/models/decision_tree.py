import json

from ayasdi.core import json_funcs
from ayasdi.core.data_point_list import DataPointList
from ayasdi.core.models import utilities
from ayasdi.core.models.classification_model import ClassificationModel
from ayasdi.core.models.validation_statistics import ValidationStatistics


class DecisionTree(ClassificationModel, ValidationStatistics):
    """
    Create, retrieve, and predict using decision trees.

    .. Note::
        Use the static function :func:`DecisionTree.create` to train a model, or use
        :func:`DecisionTree.get_model` to retrieve an existing model.
        Given a DecisionTree instance, use :func:`predict_proba` to predict.
    """

    @property
    def dot(self):
        """
        This string representation of the decision tree in DOT format
        can be used to visualize the decision tree using GraphViz.

        .. seealso::
           The dot representation can be visualized using GraphViz.
           Learn more about GraphViz here: https://www.graphviz.org/

           .. code-block:: python

                Import graphviz as gv
                dt = models.DecisionTree.create(connection, **params_dict)
                dt.ready()
                g = gv.Source(dt.dot)
                g.render("see")

        """
        return getattr(self, '_dot', None)

    @property
    def rules(self):
        """
        The rules extracted from all paths to the leaves in the current :class:`DecisionTree`

        The following format is used for rules.

        .. code-block:: python

            {'outcome_value1' : [
             [[rule1_condition1], [rule1_condition2], ...],
             [[rule2_condition1], [rule2_condition2], ...]
             ],
             ...
             }

        Returns:
           A rules dictionary

        **Samples:**

        .. code-block:: python

           {'1': [[['blood glucose', '>=', 117.0, 33, 33]]],
            '2': [[['blood glucose', '<', 117.0, 112],
                ['insulin level', '<', 420.5, 76],
                ['steady state plasma glucose', '>=', 264.5, 2, 1]],
               [['blood glucose', '<', 117.0, 112],
                ['insulin level', '>=', 420.5, 36],
                ['insulin response', '<', 118.5, 2, 1]],
               [['blood glucose', '<', 117.0, 112],
                ['insulin level', '>=', 420.5, 36],
                ['insulin response', '>=', 118.5, 34, 34]]],
            '3': [[['blood glucose', '<', 117.0, 112],
                ['insulin level', '<', 420.5, 76],
                ['steady state plasma glucose', '<', 264.5, 74, 74]]]
           }

        """
        url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/rules'
        res = json_funcs._get_(self.connection.session, url)
        return res.get('rules')

    @staticmethod
    def get_model(connection, model_id):
        """Retrieve model and create an instance

        Args:
            connection (:class:`Api <ayasdi.core.api.Api>`): an Ayasdi Platform connection
            model_id (str) : Model ID

        Returns:
            A :class:`DecisionTree` object

        :Example:

        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>>
        >>> source = connection.upload_source("./test/iris_binomial.csv")
        >>> source.sync()
        >>> import uuid
        >>> model = acm.DecisionTree.create(connection, source.id,
        ...                                 name='model_' + str(uuid.uuid4()),
        ...                                 outcome_column_index=source.colname_to_ids['setosa'])
        >>> model_id = model.model_id
        >>> model2 = acm.DecisionTree.get_model(connection, model_id)
        """
        utilities._check_connection(connection)
        if model_id is None:
            raise ValueError('model_id cannot be None')
        model = utilities._get_model(connection, model_id, DecisionTree)
        if model.type != 'DecisionTree':
            raise ValueError('Model is not a decision tree (it is a ' + model.type + ').')
        return model

    @staticmethod
    def get_models(connection, scope="team"):
        """
       This retrieves all DecisionTree models

        Args:
            connection (:class:`Api <ayasdi.core.api.Api>`): an Ayasdi Platform connection
            scope (str): Search within "user" or "team" accessible models. Default="team"

        Returns:
            A list of :class:`DecisionTree` objects
        """
        utilities._check_connection(connection)
        url = connection.CORE_REQUEST_STUB + 'models?type=decision_tree&scope=' + scope
        res = json_funcs._get_(connection.session, url)
        all_models = []
        for m in res['models']:
            model = DecisionTree(connection)
            model.__fill_body__(m)
            all_models.append(model)
        return all_models

    @staticmethod
    def _create_model(connection,
                      name,
                      data_spec,
                      model_spec,
                      outcome_column_index,
                      async_=False,
                      description=None,
                      metadata={},
                      ignore_null_outcomes=True):
        return DecisionTree.create(connection=connection,
                                   source_id=data_spec.source_id,
                                   name=name,
                                   outcome_column_index=outcome_column_index,
                                   column_set_id=data_spec.column_set_id,
                                   group_id=data_spec.group_id,
                                   max_tree_depth=model_spec.max_depth,
                                   min_samples_leaf=model_spec.min_nodes,
                                   async_=async_,
                                   description=description,
                                   metadata=metadata,
                                   ignore_null_outcomes=ignore_null_outcomes)

    @staticmethod
    def create(connection,
               source_id,
               name,
               outcome_column_index=None,
               outcome_column_name=None,
               column_set_id=None,
               group_id=None,
               max_tree_depth=5,
               min_samples_leaf=10,
               async_=False,
               description=None,
               metadata={},
               ignore_null_outcomes=True):
        """
        Use this to create or train a :class:`DecisionTree`

        Args:
            connection (:class:`Api <ayasdi.core.api.Api>`): an Ayasdi Platform connection
            source_id (string): Id of :class:`Source <ayasdi.core.source.Source>`
            name (str): User defined name of the model
            outcome_column_index (int): Index of column to use as outcome/label
                (if not specified, ``outcome_column_name`` required)
            outcome_column_name (str): Name of column to use as outcome/label
                (if not specified, ``outcome_column_index`` required)
            column_set_id (str): ID of column_set that specifies training columns (optional). Default=All Columns.
            group_id (str): ID of group to constrain training rows (optional). Default=All Rows.
            max_tree_depth (int): Maximum depth of tree (optional). Default=5
            min_samples_leaf (int): Threshold under which a node will be forced to a leaf (optional).
                Default=10
            async\_ (bool): when True, runs feature selection asynchronously and returns an
                :class:`ayasdi.core.async_jobs.AsyncJob` object. The object's "result" field is set to a dictionary
                that describes the result set.
            description (str): User defined description of the model (optional).
            metadata (dict): Metadata for the column set stored as key-value pairs (optional).
            ignore_null_outcomes (boolean, optional): whether to exclude rows where outcome value is null

        Returns:
            A :class:`DecisionTree` object

        :Example:

        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>>
        >>> source = connection.upload_source(filename=
        ...                                   './test/decision_tree_test.csv')
        >>> dtree = acm.DecisionTree.create(connection, source.id, 'hello',
        ...                                 outcome_column_name='safe_loans')
        """
        utilities._check_connection(connection)
        train_args = dict()
        train_args['model_type'] = 'decision_tree'
        train_args['model_name'] = str(name)
        train_args['model_description'] = str(description)
        train_args['metadata'] = metadata

        dt_args = dict()
        dt_args['source_id'] = str(source_id)
        if outcome_column_index is None and outcome_column_name is None:
            raise ValueError('Specify outcome column')
        elif outcome_column_index is not None and \
                outcome_column_name is not None:
            raise ValueError('Specify either outcome column index or name'
                             'but not both')
        elif outcome_column_index is not None:
            dt_args['label_column_index'] = int(outcome_column_index)
        else:
            dt_args['label_column_name'] = str(outcome_column_name)

        if group_id:
            dt_args['group_id'] = str(group_id)
        if column_set_id:
            dt_args['train_columnset_id'] = str(column_set_id)
        if max_tree_depth:
            dt_args['max_tree_depth'] = int(max_tree_depth)
        if min_samples_leaf:
            dt_args['min_samples_leaf'] = int(min_samples_leaf)

        dt_args['ignore_null_outcomes'] = ignore_null_outcomes
        rest_args = train_args
        rest_args['decision_tree_params'] = dt_args

        if async_:
            url = connection.CORE_REQUEST_STUB + 'models/async'
            jobid = json_funcs._post_(connection.session,
                                      url, rest_args)
            print('Training is running in asynchronous mode.')
            print('Remember to call ready() to check status.')

            model = DecisionTree(connection)
            model.__set_async_job__(jobid, url)
            return model
        else:
            url = connection.CORE_REQUEST_STUB + 'models'
            res = json_funcs._post_(connection.session,
                                    url, rest_args)
            model = DecisionTree(connection)
            model.__fill_body__(res)
            return model

    def get_training_columns(self):
        """
       This will fetch columns that were used during training the :class:`DecisionTree`.

        Args:
            None

        Returns:
            List of column names.

        """
        return self.training_parameters['training_columns']

    def __fill_body__(self, res):
        self.__set_base_properties__(res)
        model_info = json.loads(res['model_info'])
        self.training_error = model_info['training_error']
        self._dot = model_info['dot']
        self.training_parameters = dict()
        self.training_parameters['max_depth'] = \
            model_info['max_tree_depth']
        self.training_parameters['min_samples_leaf'] = \
            model_info['min_samples_leaf']
        if 'training_schema' in model_info:
            self.training_parameters['training_columns'] = \
                model_info['training_schema']['training_column_names']
        else:
            self.training_parameters['training_columns'] = \
                model_info['training_columns']
        if 'label_column' in model_info:  # Backwards compat.
            self.training_parameters['outcome_column'] = \
                model_info['label_column']
        if 'group_id' in model_info:
            self.training_parameters['group_id'] = \
                model_info['group_id']
        if 'domain' in model_info:
            self._classes = model_info['domain']
        self.__ready = True

    def __init__(self, connection):
        """
        Args:
            connection (:class:`Api <ayasdi.core.api.Api>`): an Ayasdi Platform connection
        """
        ClassificationModel.__init__(self)
        self.connection = connection
        self._model_id = None
        self.__ready = False
        self.training_error = None
        self.training_parameters = None
        self.async_job = None

    def predict_decisions_with_rules(self, data_spec):
        """
        This predicts the decision class and returns the decision path for each data point.

        Args:
            data_spec (:class:`DataSpec <ayasdi.core.data_spec.DataSpec>`) : The object that encapsulates
                a list of data points specified independent of any
                particular source object.

        Returns:
            A list of predicted decison class associated with the decision path for each point.

        **Samples**:

        .. code-block:: python

           [
            ['1', [['blood glucose', '>=', 117.0, 33, 33]]],
            ['2', [['blood glucose', '<', 117.0, 112], ['insulin level', '<', 420.5, 76],
                   ['steady state plasma glucose', '>=', 264.5, 2, 1]]],
            ...,
            ['3', [['blood glucose', '<', 117.0, 112], ['insulin level', '<', 420.5, 76],
                   ['steady state plasma glucose', '<', 264.5, 74, 74]]]
           ]

        :Example:

        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>>
        >>> source = connection.upload_source("./test/db_test2.txt")
        >>> source.sync()
        >>> import uuid
        >>> group = source.create_group(name=str(uuid.uuid4()), row_indices=list(range(0, 50)))
        >>> model = acm.DecisionTree.create(connection, source.id, name='model_1', outcome_column_index=6)
        >>> column_set = source.create_column_set(name=str(uuid.uuid4()), column_list=list(range(6)))
        >>> decisions_with_rules = model.predict_decisions_with_rules(
        ...     ac.SourceSubset(source_id=source.id, column_set_id=column_set['id'], group_id=group['id']))
        >>> connection.delete_source(name=source.name)
        """
        if self.model_id is None:
            raise ValueError('model_id not set. Verify that the model has been instantiated and is ready.')

        if isinstance(data_spec, list):
            data_spec = DataPointList(data_spec)

        request = {
            'data_spec': data_spec.serialize()
        }

        url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/predict_decisions_with_rules'
        response = json_funcs._post_(self.connection.session, url, request)
        return response['decisions_with_rules']

    @property
    def training_metrics(self):
        return {'training_error': self.model_info['training_error']}
