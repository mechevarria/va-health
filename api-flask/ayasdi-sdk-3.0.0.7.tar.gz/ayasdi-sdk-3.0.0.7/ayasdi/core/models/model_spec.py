class ModelSpec(object):
    """
    The base class for parameters used in group classifier algorithms:
        The classes that inherit from this base class:
            - :class:`DecisionTreeSpec <ayasdi.core.models.decision_tree_spec.DecisionTreeSpec>`
            - :class:`LogisticRegressionSpec <ayasdi.core.models.logistic_regression_spec.LogisticRegressionSpec>`
            - :class:`RandomForestSpec <ayasdi.core.models.random_forest_spec.RandomForestSpec>`
            - :class:`GbdtSpec <ayasdi.core.models.gbdt_spec.GbdtSpec>`
            - :class:`NeuralNetworkSpec <ayasdi.core.models.neural_network_spec.NeuralNetworkSpec>`

    """

    def serialize(self):
        """This converts a :class:`ModelSpec` object into a dictionary"""
        return {}

    def spec_type(self):
        """This returns a key used in the group classifier request

        This function is overriden in inherited classes"""
        return 'model_spec'
