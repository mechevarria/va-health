from ayasdi.core.models.problem_spec import ProblemSpec


class GroupClassifierSpec(ProblemSpec):
    """
    A class with fields as the parameters for the group membership classification problem.

    Args:
        classification_group_ids (list): classification_group_ids (used in Group Classifier)
        strategy (string, optional): strategy used for Group Classifier
    """

    @property
    def classification_group_ids(self):
        """
        Classification group IDs
        """
        return getattr(self, '_classification_group_ids', None)

    @property
    def strategy(self):
        """
        Strategy used when the problem is group membership classification.
        It can be "one_vs_rest" (default) or "multi_class"
        """
        return getattr(self, '_strategy', "one_vs_rest")

    def __init__(self, classification_group_ids=None, strategy="one_vs_rest"):
        self._classification_group_ids = classification_group_ids
        self._strategy = strategy
