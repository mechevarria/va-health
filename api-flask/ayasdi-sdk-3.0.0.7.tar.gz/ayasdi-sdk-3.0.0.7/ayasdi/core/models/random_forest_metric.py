from ayasdi.core import json_funcs
from ayasdi.core.async_jobs import AsyncJob
from ayasdi.core.models import utilities
from ayasdi.core.models.model_base import ModelBase


class RandomForestMetric(ModelBase):
    """
    Create, retrieve, and generate features with a random forest metric model.
    Use static function :func:`RandomForestMetric.create` to train a model, or use
    :func:`RandomForestMetric.get_model` to retrieve an existing model.
    Given a RandomForestMetric instance, use :func:`transform_source` to generate features.
    """

    def __init__(self, connection):
        """
        Initialize RandomForestMetric

        Args:
            connection : an instance of class ayasdi.core.api.Api
        """
        self.json = None
        self.__ready = None
        self.async_job = None
        self.connection = connection

    @staticmethod
    def get_model(connection, model_id):
        """
        Retrieve model and create an instance

        Args:
            connection : an instance of class ayasdi.core.api.Api
            model_id: Model ID

        Returns:
            An instance of RandomForestMetric

        :Example:

        >>> import uuid
        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>>
        >>> source = connection.upload_source("./test/db_test2.txt")
        >>> source.sync()
        >>> model = acm.RandomForestMetric.create(connection, source.id,
        ...                                       name='model_' + str(uuid.uuid4()),
        ...                                       outcome_column_index=source.colname_to_ids['clinical classification'])
        >>> model_id = model.model_id
        >>> model2 = acm.RandomForestMetric.get_model(connection, model_id)
        """
        utilities._check_connection(connection)
        model = utilities._get_model(connection, model_id, RandomForestMetric)
        if model.type != 'RandomForestMetric':
            raise AttributeError('Model is not a random forest metric (it is a ' + model.type + ').')
        return model

    @staticmethod
    def get_models(connection, scope="team"):
        """
        Retrieve all RandomForestMetric models

        Args:
            connection : an instance of class ayasdi.core.api.Api
            scope: how widely to search - takes "user" or "team". Default value is "team"

        Returns:
            List of RandomForestMetric models
        """
        utilities._check_connection(connection)
        url = connection.CORE_REQUEST_STUB + 'models?type=random_forest_metric&scope=' + scope
        res = json_funcs._get_(connection.session, url)
        all_models = []
        for m in res['models']:
            model = RandomForestMetric(connection)
            model.__fill_body__(m)
            all_models.append(model)
        return all_models

    @staticmethod
    def create(connection,
               source_id,
               name,
               outcome_column_index,
               column_set_id=None,
               group_id=None,
               number_of_trees=500,
               min_nodes=5,
               random_seed=0,
               async_=False,
               description=None,
               metadata={}):
        """
        Create and train random forest metric

        Args:
            connection : an instance of class ayasdi.core.api.Api
            source_id (string): identifier of a source on which to create the model
            name (string): name of the new model
            outcome_column_index (int): index of the column to use as outcome/label
            column_set_id (string, optional): identifier of a column set specifying training features
            group_id (string, optional): identifier of a group specifying training rows
            number_of_trees (int): number of trees to train
            min_nodes (int): minimum number of data rows for a leaf
            random_seed (int, optional): a number used to initialize a pseudo random number generator
            async\_ (boolean, optional, default=False): whether to run in async mode
            description (string, optional): user provided information about the model
            metadata (dict): Metadata for the column set stored as key-value pairs (optional).

        Returns:
            An instance of RandomForestMetric
        """
        utilities._check_connection(connection)
        rest_args = {
            'model_type': 'random_forest_metric',
            'model_name': name,
            'model_description': description,
            'random_forest_metric_params': {
                'source_view': {
                    'source_id': source_id,
                    'column_set_id': column_set_id,
                    'group_id': group_id,
                },
                'outcome_column_index': outcome_column_index,
                'number_of_trees': number_of_trees,
                'min_nodes': min_nodes,
                'random_seed': random_seed,
            },
            'metadata': metadata
        }

        if async_:
            url = connection.CORE_REQUEST_STUB + 'models/async'
            jobid = json_funcs._post_(connection.session,
                                      url, rest_args)
            print('Training is running in asynchronous mode.')
            print('Remember to call ready() to check status.')

            model = RandomForestMetric(connection)
            model.__set_async_job__(jobid, url)
            return model
        else:
            url = connection.CORE_REQUEST_STUB + 'models'
            res = json_funcs._post_(connection.session,
                                    url, rest_args)
            model = RandomForestMetric(connection)
            model.__fill_body__(res)
            return model

    def get_training_columns(self):
        """
        Gets the columns that were used for training the model.

        Args:
            None

        Returns:
            List of column names used for training.

        """
        if 'training_schema' in self.model_info:
            return self.model_info['training_schema']['training_column_names']
        else:
            return self.model_info['training_columns']

    def __fill_body__(self, res):
        self.__set_base_properties__(res)
        self.json = res
        self.__ready = True

    def __set_async_job__(self, async_job, url):
        self.__ready = False
        self.async_job = AsyncJob(self.connection, async_job, url)

    def ready(self):
        """
        Check readiness of object
        Used as part of asynchronous call pattern.
        """
        if self.__ready:
            return True
        else:
            async_ready = self.async_job.ready()
            if async_ready:
                self.__fill_body__(self.async_job.result)
                return True
            else:
                return False

    def transform_source(self,
                         source_id,
                         column_set_id=None,
                         group_id=None,
                         new_source_name=None,
                         new_column_prefix=None):
        """
        Calculates a metric based on this Random Forest Metric model and appends as new columns to existing source
        or creates as a new source.

        Args:
            source_id (string): identifier of a source on which to build the metric
            column_set_id (string, optional): identifier of a column set specifying testing features
            group_id (string, optional): identifier of a group specifying testing rows
            new_source_name (string, optional): name of the new source if provided,
                otherwise new features will be added to the original source as new columns
            new_column_prefix (string, optional): prefix of the new columns

        Returns:
            Identifier of a new source if created, or old source if appended columns
        """

        if self.model_id is None:
            raise ValueError('model_id not set. Verify that the model has been instantiated and is ready.')

        args = {
            'source_view': {
                'source_id': source_id,
                'column_set_id': column_set_id,
                'group_id': group_id,
            },
            'new_source_name': new_source_name,
            'new_column_prefix': new_column_prefix,
        }

        url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/metric_transformation'
        res = json_funcs._post_(self.connection.session, url, args)
        return res['source_identifier']
