from ayasdi.core.async_jobs import AsyncJob
from ayasdi.core.models.curve2d import Curve2D
from ayasdi.core.models.point2d import Point2D


class ClassificationStatistics(object):
    """
    Classification statistics data for a binomial model
    """

    @property
    def true_positive(self):
        """ Number of correctly predicted true-values (hit) """
        return getattr(self, '_true_positive', None)

    @property
    def true_negative(self):
        """ Number of correctly predicted false-values (correct rejection) """
        return getattr(self, '_true_negative', None)

    @property
    def false_positive(self):
        """ Number of incorrectly predicted true-values (false alarm, Type II error) """
        return getattr(self, '_false_positive', None)

    @property
    def false_negative(self):
        """ Number of incorrectly predicted false-values (miss, Type I error) """
        return getattr(self, '_false_negative', None)

    @property
    def condition_positive(self):
        """ Number of real positive cases in the data """
        return getattr(self, '_condition_positive', None)

    @property
    def condition_negative(self):
        """ Number of real negative cases in the data """
        return getattr(self, '_condition_negative', None)

    @property
    def decision_threshold(self):
        return getattr(self, '_decision_threshold', None)

    @property
    def precision(self):
        """
        Fraction of correct predictions among points predicted true (positive predictive value)
        \fprecision = TP / (TP + FP)\f
        """
        return getattr(self, '_precision', None)

    @property
    def recall(self):
        """
        Fraction of correct predictions among true-values
        \frecall = TP / (TP + FN)\f
        """
        return getattr(self, '_recall', None)

    @property
    def fall_out(self):
        """
        Fraction of incorrectly predicted false-values among all false-values
        (false positive rate, non-relevant results from a query)
        \ffall_out = FP / (FP + TN)\f
        """
        return getattr(self, '_fall_out', None)

    @property
    def accuracy(self):
        """
        Fraction of correct predictions among all data points.
        \faccuracy = (TP + TN) / (TP + TN + FP + FN)\f
        """
        return getattr(self, '_accuracy', None)

    @property
    def specificity(self):
        """
        Fraction of negatives that are correctly identified as such (true negative rate)
        \fspecificity = TN / (TN + FP)\f
        """
        return getattr(self, '_specificity', None)

    @property
    def f1_score(self):
        """
        Harmonic mean of precision and sensitivity
        \fF1 = 2TP / (2TP + FP + FN)\f
        """
        return getattr(self, '_f1_score', None)

    @property
    def area_under_receiver_operating_characteristic_curve(self):
        """ AUC is area under receiver operating characteristic curve """
        return getattr(self, '_area_under_receiver_operating_characteristic_curve', None)

    @property
    def receiver_operating_characteristic_curve(self):
        """
        ROC is receiver operating characteristic curve.
        A monotonic curve as a series of (x, y) points.
        A :class:`ayasdi.core.models.curve2d.Curve2D` instance.
        """
        return getattr(self, '_receiver_operating_characteristic_curve', None)

    def __init__(self, connection=None):
        """
        Initialize :class:`ClassificationStatistics` object
        """
        self.connection = connection
        self.json = None
        self.model_type = None
        self.__ready = False
        self.async_job = None

    def __getitem__(self, key):
        return getattr(self, key, None)

    def __fill_body__(self, res):
        self.json = res
        self.model_type = res['model_type']
        stats = res['classification_statistics']
        for key, value in stats.items():
            setattr(self, '_' + key, value)
        self.__ready = True
        if 'fallOut' in stats:
            self._fall_out = stats.get('fallOut')
        if 'f1Score' in stats:
            self._f1_score = stats.get('f1Score')

        curve = stats.get('receiver_operating_characteristic_curve')
        if curve is not None:
            self._receiver_operating_characteristic_curve = self.__build_curve__(curve)

        self.fallOut = self.fall_out
        self.f1Score = self.f1_score

    def __set_model_type__(self, model_type):
        self.model_type = model_type

    def __set_async_job__(self, async_job, url):
        self.__ready = False
        self.async_job = AsyncJob(self.connection, async_job, url)

    def ready(self):
        """
        Check readiness of a :class:`ClassificationStatistics` object
        Used as part of asynchronous call pattern.
        """
        if self.__ready:
            return True
        else:
            async_ready = self.async_job.ready()
            if async_ready:
                self.__fill_body__(self.async_job.result)
                return True
            else:
                return False

    def __repr__(self):
        return "ClassificationStatistics: " + str(self.json)

    @staticmethod
    def __build_curve__(json):
        points = []
        json_points = json['points']
        for p in json_points:
            points.append(Point2D(float(p['x']), float(p['y'])))
        return Curve2D(points)
