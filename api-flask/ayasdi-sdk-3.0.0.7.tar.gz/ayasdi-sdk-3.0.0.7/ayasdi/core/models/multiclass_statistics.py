from ayasdi.core.async_jobs import AsyncJob
from ayasdi.core.models.classification_statistics import ClassificationStatistics


class MulticlassStatistics(object):
    """
    Classification statistics data for a multi class model

    Example: SDK Output
        MulticlassStatistics: {
            u'model_type': u'DecisionTree',

            u'confusion_matrix': {u'error_rate': [0.0, 0.04, 0.02564102564102564], u'matrix': [[0, 0, 0], [0, 24, 1],
            [0, 2, 76]], u'recall': [1.0, 0.96, 0.9743589743589743], u'total_predictions': [0, 26, 77], u'precision': [0.0,
            0.9230769230769231, 0.987012987012987], u'classes': [u'1', u'2', u'3'], u'total_observations': [0, 25, 78],
            u'error': [0, 1, 2]},

            u'multiclass_statistics': [
                {u'decision_threshold': 0.5, u'false_positive': 0, u'condition_positive': 0,
                 u'receiver_operating_characteristic_curve': {u'points': [{u'y': 0.0, u'x': 0.0}, {u'y': 1.0, u'x': 1.0}]},
                 u'condition_negative': 100, u'specificity': 1.0, u'precision': 0.0,
                 u'area_under_receiver_operating_characteristic_curve': 0.5, u'true_negative': 100, u'fallOut': 0.0,
                 u'recall': 0.0, u'true_positive': 0, u'accuracy': 1.0, u'f1Score': 0.0, u'false_negative': 0},

                {u'decision_threshold': 0.5, u'false_positive': 2, u'condition_positive': 24,
                 u'receiver_operating_characteristic_curve': {u'points': [{u'y': 0.9583333333333334, u'x': 0.0}, {u'y': 1.0,
                 u'x': 0.02631578947368421}, {u'y': 1.0, u'x': 1.0}]}, u'condition_negative': 76, u'specificity':
                 0.9736842105263158, u'precision': 0.9230769230769231, u'area_under_receiver_operating_characteristic_curve':
                 0.9994517543859649, u'true_negative': 74, u'fallOut': 0.02631578947368421, u'recall': 1.0, u'true_positive':
                 24, u'accuracy': 0.98, u'f1Score': 0.96, u'false_negative': 0},

                {u'decision_threshold': 0.5, u'false_positive': 1, u'condition_positive': 76,
                 u'receiver_operating_characteristic_curve': {u'points': [{u'y': 0.0, u'x': 0.0}, {u'y': 1.0, u'x':
                 0.041666666666666664}, {u'y': 1.0, u'x': 1.0}]}, u'condition_negative': 24, u'specificity': 0.9583333333333334,
                 u'precision': 0.987012987012987, u'area_under_receiver_operating_characteristic_curve': 0.9791666666666667,
                 u'true_negative': 23, u'fallOut': 0.041666666666666664, u'recall': 1.0, u'true_positive': 76, u'accuracy':
                 0.99, u'f1Score': 0.9934640522875817, u'false_negative': 0}
            ]
        }
    """

    def __init__(self, connection):
        """
        Initialize a :class:`MulticlassStatistics` object

        Attributes:
            self.multiclass_statistics: A list of :class:`ayasdi.core.models.ClassificationStatistics` objects for each
                class, presented in an order that corresponds to the order of elements in the
                :class:`ayasdi.core.models.ClassificationModel.classes` property.
        """
        self.connection = connection
        self.json = None
        self.model_type = None
        self.confusion_matrix = None
        self.multiclass_statistics = None
        self.__ready = False
        self.async_job = None

    def __getitem__(self, key):
        return getattr(self, key, None)

    def __fill_body__(self, res):
        self.json = res
        self.model_type = res['model_type']
        if 'confusion_matrix' in res:
            self.confusion_matrix = res['confusion_matrix']
        self.__ready = True
        multiclass_statistics = []
        for stats in res['multiclass_statistics']:
            classification_statistics = ClassificationStatistics()
            classification_statistics.__fill_body__({'model_type': self.model_type,
                                                     'classification_statistics': stats})
            multiclass_statistics.append(classification_statistics)
        self.multiclass_statistics = multiclass_statistics

    def __set_async_job__(self, async_job, url):
        self.__ready = False
        self.async_job = AsyncJob(self.connection, async_job, url)

    def ready(self):
        """
        Check readiness of a :class:`MulticlassStatistics` object
        Used as part of asynchronous call pattern.
        """
        if self.__ready:
            return True
        else:
            async_ready = self.async_job.ready()
            if async_ready:
                self.__fill_body__(self.async_job.result)
                return True
            else:
                return False

    def print_matrix_stats(self):
        """
        :return the confusion matrix and stats numbers such as classes, total observations, error, error rate, recall,
        total predictions, precision, in which any list order is consistent with the classes order.

        A confusion matrix and stats numbers example:
            {'error_rate': [0.0, 0.08333333333333333, 0.039473684210526314],
             'matrix': [[0, 0, 0], [0, 22, 2], [0, 3, 73]], 'recall': [1.0, 0.9166666666666666, 0.9605263157894737],
             'total_predictions': [0, 25, 75], 'precision': [0.0, 0.88, 0.9733333333333334],
             'classes': ['1', '2', '3'], 'total_observations': [0, 24, 76], 'error': [0, 2, 3]
            }
        """
        return self.confusion_matrix

    def __repr__(self):
        return "MulticlassStatistics: " + str(self.json)
