import uuid

from ayasdi.core import json_funcs
from ayasdi.core.models import utilities
from ayasdi.core.models.classification_model import ClassificationModel
from ayasdi.core.models.decision_tree import DecisionTree
from ayasdi.core.models.decision_tree_spec import DecisionTreeSpec
from ayasdi.core.models.gbdt import GBDT
from ayasdi.core.models.neural_network import NeuralNetwork
from ayasdi.core.models.logistic_regression import LogisticRegression
from ayasdi.core.models.multiclass_statistics import MulticlassStatistics
from ayasdi.core.models.random_forest import RandomForest
from ayasdi.core.models.random_forest_spec import RandomForestSpec


class GroupClassifier(ClassificationModel):
    """
    Create, retrieve, and predict group membership.
    Use static function :func:`GroupClassifier.create` to train a model, or use
    :func:`GroupClassifier.get_model` to retrieve an existing model.
    Given a :class:`GroupClassifier` instance, use \
    :func:`predict_proba <ayasdi.core.models.classification_model.ClassificationModel.predict_proba>` to predict.

    Args:
        connection : an instance of :class:`Api <ayasdi.core.api.Api>`
    """

    def __init__(self, connection):
        ClassificationModel.__init__(self)
        self.json = None
        self.__ready = None
        self.async_job = None
        self.connection = connection

    @staticmethod
    def get_model(connection, model_id):
        """
        Retrieve model and create an instance

        Args:
            connection : an instance of :class:`Api <ayasdi.core.api.Api>`
            model_id: Model ID

        Returns:
            An instance of :class:`GroupClassifier`

        :Example:

        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>>
        >>> source = connection.upload_source("./test/iris_binomial.csv")
        >>> source.sync()
        >>> import uuid
        >>> group1 = source.create_group(name='group_' + str(uuid.uuid4()), row_indices=list(range(0, 50)))
        >>> model = acm.GroupClassifier.create(connection, source.id,
        ...                                    name='model_' + str(uuid.uuid4()),
        ...                                    classification_group_ids=[group1['id']])
        >>> model_id = model.model_id
        >>> model2 = acm.GroupClassifier.get_model(connection, model_id)
        """
        utilities._check_connection(connection)
        model = utilities._get_model(connection, model_id, GroupClassifier)
        if model.type != 'GroupClassifier':
            raise AttributeError('Model is not a group classifier (it is a ' + model.type + ').')
        return model

    def get_submodels(self):
        """
        Retrieve sub models of the group classifier.

        Returns:
            A dictionary of a group name to an instance of a binary classification model such as
            :class:`RandomForest <ayasdi.core.models.random_forest.RandomForest>`, \
            :class:`GBDT <ayasdi.core.models.gbdt.GBDT>`, \
            :class:`NeuralNetwork <ayasdi.core.models.neural_network.NeuralNetwork>`, \
            :class:`DecisionTree <ayasdi.core.models.decision_tree.DecisionTree>`, or \
            :class:`LogisticRegression <ayasdi.core.models.logistic_regression.LogisticRegression>`::
             {
                u'group_1': RandomForest(),
                u'group_2': RandomForest()
             }

        :Example:

        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>>
        >>> source = connection.upload_source("./test/iris_binomial.csv")
        >>> source.sync()
        >>> import uuid
        >>> uuid_ = uuid.uuid4()
        >>> group1 = source.create_group(name='group_' + str(uuid_), row_indices=list(range(0, 50)))
        >>> gc_model = acm.GroupClassifier.create(connection, source.id,
        ...                                       name='model_' + str(uuid_),
        ...                                       classification_group_ids=[group1['id']])
        >>> submodels = gc_model.get_submodels()
        >>> items = submodels.items()
        """
        # >>> # Then we can also call submodel.predict_proba() or submodel.predict_decisions() next.
        # >>> # See examples on: ClassificationModel.predict_proba() or ClassificationModel.predict_decisions().

        model_type_mapping = {
            'DecisionTree': DecisionTree,
            'LogisticRegression': LogisticRegression,
            'RandomForest': RandomForest,
            'GBDT': GBDT,
            'NeuralNetwork': NeuralNetwork
        }

        submodelTypeName = self.model_info.get('submodelType')
        if submodelTypeName not in model_type_mapping:
            raise ValueError('This model is not of one of these types: {}. It is a {}'
                             .format(model_type_mapping.keys(), submodelTypeName))
        submodel_type = model_type_mapping[submodelTypeName]

        submodels = {}
        group_to_submodels = self.model_info.get('group_to_submodels')
        if group_to_submodels is not None:
            for group_name, submodel_id in group_to_submodels.items():
                model = utilities._get_model(self.connection, submodel_id, submodel_type)
                submodels[group_name] = model
        return submodels

    @staticmethod
    def get_models(connection, scope="team"):
        """
        Retrieve all :class:`GroupClassifier` models

        Args:
            connection : an instance of class ayasdi.core.api.Api
            scope: how widely to search - takes "user" or "team". Default value is "team"

        Returns:
            List of :class:`GroupClassifier` models
        """
        utilities._check_connection(connection)
        url = connection.CORE_REQUEST_STUB + 'models?type=group_classifier&scope=' + scope
        res = json_funcs._get_(connection.session, url)
        all_models = []
        for m in res['models']:
            model = GroupClassifier(connection)
            model.__fill_body__(m)
            all_models.append(model)
        return all_models

    @staticmethod
    def create(connection,
               source_id,
               name,
               classification_group_ids,
               column_set_id=None,
               group_id=None,
               model_spec=RandomForestSpec(),
               strategy='one_vs_rest',
               async_=False,
               metadata={}):
        """
        Create and train a model to predict groups

        Args:
            connection : an instance of :class:`Api <ayasdi.core.api.Api>`
            source_id (str): identifier of a source on which to create the model
            name (string): Name of a new model
            classification_group_ids (List of strings): A list of group identifiers to predict
            column_set_id (str, optional): identifier of a column set specifying training features
            group_id (str, optional): identifier of a group specifying training rows
            model_spec: a :class:`ModelSpec <ayasdi.core.models.model_spec.ModelSpec>` object to specify parameters \
                used in group classifier algorithms. It can be one of these subclasses:
                    - :class:`RandomForestSpec <ayasdi.core.models.random_forest_spec.RandomForestSpec>` for random \
                        forest algorithm,
                    - :class:`DecisionTreeSpec <ayasdi.core.models.decision_tree_spec.DecisionTreeSpec>` for decision \
                        tree algorithm,
                    - :class:`LogisticRegressionSpec \
                        <ayasdi.core.models.logistic_regression_spec.LogisticRegressionSpec>` for logistic regression \
                        algorithm.
                    - :class:`GbdtSpec <ayasdi.core.models.gbdt_spec.GbdtSpec>` for gradient boosted decision tree \
                        algorithm.
                    - :class:`NeuralNetworkSpec <ayasdi.core.models.neural_network_spec.NeuralNetworkSpec>` for neural \
                        network algorithm.
                default= RandomForestSpec().
            strategy (str): 'one_vs_rest' or 'multi_class'. default='one_vs_rest'. one_vs_rest means that we want to
                predict if a point belongs to a group or not. multi_class means that we want to predict which group a
                point belongs to. If strategy='multi_class', then model_spec has to be an instance of
                :class:`DecisionTreeSpec <ayasdi.core.models.decision_tree_spec.DecisionTreeSpec>` currently. Other \
                :class:`ModelSpec <ayasdi.core.models.model_spec.ModelSpec>` instances will be supported in future \
                releases for multi_class strategy.
            async\_ (bool) : when True, specifies that the query should run in asynchronous mode. If False or not
                specified, the query is run in synchronous mode.
            metadata (dict): Metadata for the column set stored as key-value pairs (optional).

        Returns:
            An instance of :class:`GroupClassifier`

        """
        utilities._check_connection(connection)
        if strategy == 'multi_class' and not isinstance(model_spec, DecisionTreeSpec):
            raise ValueError("Only DecisionTreeSpec instance can be passed for %s strategy. A %s instance was wrongly "
                             "passed. Other ModelSpec instances will be supported in future releases for multi_class "
                             "strategy" % (strategy, type(model_spec)))
        if strategy == 'multi_class' and group_id is not None:
            raise ValueError("The parameter 'group_id' is not used if 'strategy' is set to multi_class. Instead the "
                             "default group will contain the union of all provided classification_group_ids")
        rest_args = {
            'model_type': 'group_classifier',
            'model_name': name,
            'group_classifier_params': {
                'source_view': {
                    'source_id': source_id,
                    'column_set_id': column_set_id,
                    'group_id': group_id
                },
                'classification_group_ids': classification_group_ids,
                'strategy': strategy
            },
            'metadata': metadata
        }
        rest_args['group_classifier_params'][model_spec.spec_type()] = model_spec.serialize()

        if async_:
            url = connection.CORE_REQUEST_STUB + 'models/async'
            jobid = json_funcs._post_(connection.session,
                                      url, rest_args)
            print('Training is running in asynchronous mode.')
            print('Remember to call ready() to check status.')

            model = GroupClassifier(connection)
            model.__set_async_job__(jobid, url)
            return model
        else:
            url = connection.CORE_REQUEST_STUB + 'models'
            res = json_funcs._post_(connection.session,
                                    url, rest_args)
            model = GroupClassifier(connection)
            model.__fill_body__(res)
            return model

    def get_training_columns(self):
        """
        Gets the columns that were used for training the model.

        Args:
            None

        Returns:
            List of column names used for training.

        """
        if 'training_schema' in self.model_info:
            return self.model_info['training_schema']['training_column_names']
        else:
            return self.model_info['training_columns']

    def __fill_body__(self, res):
        self.__set_base_properties__(res)
        self.json = res
        if 'domain' in self._model_info:
            self._classes = self._model_info['domain']
        self.__ready = True

    def get_statistics(self, group_id, decision_threshold=None, async_=False):
        """
        Calculate prediction statistics on the provided data set.

        Args:
            group_id (str): ID of group specifying testing rows
            decision_threshold (float, optional): defines a discrimination boundary
                used to perform binary classification. This value can
                range from 0 to 1.
                Higher decision thresholds will exclude more elements
                from being classified (increasing type II error), whereas
                lower decision thresholds will cause fewer exclusions
                (increasing type I error). This parameter should depend
                on the user's tolerance for each type of error.
            async\_ (boolean, optional): if set to True, the statistics are calculated asynchronously.

        Returns:
            A :class:`MulticlassStatistics <ayasdi.core.models.multiclass_statistics.MulticlassStatistics>` object.
        """
        if self.model_id is None:
            raise ValueError('model_id not set. Verify that the model has been instantiated and is ready.')
        if group_id is None:
            raise ValueError("The parameter 'group_id' has to be provided for group classifier validation statistics")
        src = self.connection.get_source(id=self.source_id)
        classification_group_ids = []
        for group_name in self.classes:
            group = src.get_group(name=group_name)
            classification_group_ids.append(group['id'])
        training_columns = self.model_info['training_schema']['training_column_names']
        column_set = src.create_column_set(name='gc_stats_' + str(uuid.uuid4()), column_list=training_columns)
        return self.__generate_validation_statistics(self.source_id,
                                                     classification_group_ids,
                                                     column_set['id'],
                                                     group_id,
                                                     decision_threshold,
                                                     async_)

    def __generate_validation_statistics(self,
                                         source_id,
                                         classification_group_ids,
                                         column_set_id=None,
                                         group_id=None,
                                         decision_threshold=None,
                                         async_=False):

        rest_args = {
            'source_view': {
                'source_id': source_id,
                'column_set_id': column_set_id,
                'group_id': group_id,
            },
            'classification_group_ids': classification_group_ids,
            'decision_threshold': decision_threshold
        }
        if async_:
            url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/model_statistics/async'
            jobid = json_funcs._post_(self.connection.session, url, rest_args)
            print('Generating statistics is running in asynchronous mode.')
            print('Remember to call ready() to check status.')
            stats = MulticlassStatistics(self.connection)
            stats.__set_async_job__(jobid, url)
            return stats
        else:
            url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/model_statistics'
            res = json_funcs._post_(self.connection.session, url, rest_args)
            stats = MulticlassStatistics(self.connection)
            stats.__fill_body__(res)
            return stats
