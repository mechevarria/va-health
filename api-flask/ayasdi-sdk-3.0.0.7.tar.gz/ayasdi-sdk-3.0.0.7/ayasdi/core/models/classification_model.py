from ayasdi.core import json_funcs
from ayasdi.core.data_point_list import DataPointList
from ayasdi.core.models.classification_statistics import ClassificationStatistics
from ayasdi.core.models.model_base import ModelBase
from ayasdi.core.models.multiclass_statistics import MulticlassStatistics


class ClassificationModel(ModelBase):
    """Base Classification Model"""
    def __init__(self):
        ModelBase.__init__(self)
        self._classes = None

    @property
    def classes(self):
        """
        List of all possible outcome values
        """
        return self._classes

    @property
    def model_type(self):
        return self._type

    def predict_proba(self, data_spec):
        """
        Predicts the likelihood of each class for each data point.

        .. Note::
            Returns a list of lists, where each point prediction
            is a list of likelihoods for each class from the outcome column domain.
            The order of likelihoods corresponds
            to the order of elements in the :func:`classes` property.


            For e.g. If the outcome column has three classes 'A', 'B', and 'C', and the output
            of this function for the first point
            is ``[0.5, 0.3, 0.2]``, then this indicates that this point is predicted to have a label
            'A' if :func:`classes` looks like ``['A', 'B', 'C']``

        Args:
            data_spec (:class:`DataSpec <ayasdi.core.data_spec.DataSpec>`) : object that encapsulates
                a list of data points specified independent of any
                particular source object.

        Returns:
            a list of predictions for each point.

        **Samples**:

        .. code-block:: python

            [[0.9983636344249522, 0.0, 0.0016363655750477948], [0.0, 0.9865688473787969, 0.013431152621203132]]

        :Example:

        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>>
        >>> source = connection.upload_source("./test/iris_binomial.csv")
        >>> source.sync()
        >>> group1 = source.create_group(name='group_1', row_indices=list(range(0, 50)))
        >>> model = acm.GroupClassifier.create(
        ...     connection, source.id, name='model_1', classification_group_ids=[group1[u'id']])
        >>> probabilities = model.predict_proba(ac.SourceSubset(source.id, group1[u"id"]))
        """
        if self.model_id is None:
            raise ValueError('model_id not set. Verify that the model has been instantiated and is ready.')

        if isinstance(data_spec, list):
            data_spec = DataPointList(data_spec)

        request = {
            u'data_spec': data_spec.serialize()
        }

        url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/predict_proba'
        response = json_funcs._post_(self.connection.session, url, request)
        return response[u'probabilities']

    def predict_decisions(self, data_spec, decision_threshold=0.5, class_weights=None):
        """
        Predict the outcome value for each data point.

        Args:
            data_spec (:class:`DataSpec <ayasdi.core.data_spec.DataSpec>`) : The object that encapsulates
                a list of data points specified independent of any
                particular source object.

            decision_threshold (double) : Defines a discrimination boundary used to perform binary classification.
                Specify a decision threshold depending on your tolerance for either type I or type II error.
                Higher decision thresholds exclude more elements from being classified (increasing type II error);
                lower decision thresholds cause fewer exclusions (increasing type I error).
                Legal values range from 0 to 1. Default=0.5

            class_weights ([double]): Defines weights of each class, specified as a list of weights. Used as criteria
                for classification decisions. Default=[all ones]

        Returns:
            A list of predicted class names for each point, in order.

        **Samples**:

        .. code-block:: python

                [u'1', u'0', u'0', u'1', u'1', u'1', u'1', u'1', u'1', u'1']
        """
        if self.model_id is None:
            raise ValueError('model_id not set. Verify that the model has been instantiated and is ready.')

        if isinstance(data_spec, list):
            data_spec = DataPointList(data_spec)

        request = {
            u'data_spec': data_spec.serialize(),
            u'decision_threshold': decision_threshold,
            u'class_weights': class_weights,
        }

        url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/predict_decisions'
        response = json_funcs._post_(self.connection.session, url, request)
        return response[u'decisions']

    def predict_proba_anomaly(self, data_spec, threshold):
        """
        Predicts the likelihood of each class for each data point with maximum probability smaller than
        the given threshold.

        .. Note::
            Returns two lists. One list of integer stores the row indices of points, and the other
            is a list of lists, where each point prediction is a list of likelihoods for each class.

        Args:
            data_spec (:class:`DataSpec <ayasdi.core.data_spec.DataSpec>`) : The object that encapsulates
                a list of data points specified independent of any
                particular source object.
            threshold (float) : The threshold which the maximum predicted probability should not exceed.

        Returns:
            A dictionary contains a list of row indices and a list of predictions for each point.

        **Samples**:

        .. code-block:: python

            {'row_indices': [0, 1],
             'probabilities': [[0.9983636344249522, 0.0, 0.0016363655750477948],
                               [0.0, 0.9865688473787969, 0.013431152621203132]]}

        :Example:

        >>> import ayasdi.core as ac
        >>> import ayasdi.core.models as acm
        >>>
        >>> source = connection.upload_source("./test/iris_binomial.csv")
        >>> source.sync()
        >>> group1 = source.create_group(name='group_1', row_indices=list(range(0, 50)))
        >>> model = acm.GroupClassifier.create(
        ...     connection, source.id, name='model_1', classification_group_ids=[group1[u'id']])
        >>> probabilities = model.predict_proba_anomaly(ac.SourceSubset(source.id, group1[u"id"]), threshold=0.5)
        """
        if self.model_id is None:
            raise ValueError('model_id not set. Verify that the model has been instantiated and is ready.')

        if threshold is None:
            raise ValueError('please give a threshold.')

        if isinstance(data_spec, list):
            data_spec = DataPointList(data_spec)

        request = {
            u'data_spec': data_spec.serialize(),
            u'threshold': threshold
        }

        url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/predict_proba_anomaly'
        response = json_funcs._post_(self.connection.session, url, request)
        return response

    def is_binomial(self):
        """
        Returns true if this is a binomial classifier.
        """
        if self.model_type == 'DecisionTree':  # decision tree model is always multinomial.
            return False
        return self.classes is not None and len(self.classes) == 2

    def get_statistics_type(self):
        if self.is_binomial():
            return ClassificationStatistics
        else:
            return MulticlassStatistics
