class RegressionCoefficientStatistics(object):
    """
    Statistics data associated with a coefficient (including intercept)
    """

    @property
    def index(self):
        """ zero based index of the column """
        return getattr(self, '_index', None)

    @property
    def name(self):
        """ name of the column or '(intercept)' """
        return getattr(self, '_name', None)

    @property
    def estimate(self):
        """ estimated value """
        return getattr(self, '_estimate', None)

    @property
    def standard_error(self):
        """ standard error """
        return getattr(self, '_standard_error', None)

    @property
    def t_value(self):
        """ t-value """
        return getattr(self, '_t_value', None)

    @property
    def p_value(self):
        """ p-value """
        return getattr(self, '_p_value', None)

    def __getitem__(self, key):
        return getattr(self, key)

    def __fill_body__(self, json):
        self.json = json
        for key, value in json.items():
            setattr(self, '_' + key, value)

    def __repr__(self):
        return "RegressionCoefficientStatistics: " + str(self.json)
