from ayasdi.core import json_funcs


class ValidationStatistics(object):
    """Base Validation Statistics"""
    def get_statistics_type(self):
        raise NotImplementedError('Please implement this method in the subclass')

    def generate_validation_statistics(self,
                                       source_id,
                                       outcome_column_index,
                                       column_set_id=None,
                                       group_id=None,
                                       decision_threshold=None,
                                       async_=False,
                                       with_values=False
                                       ):
        """
        Calculate prediction statistics on the provided data set with known outcome.

        Args:
            source_id (string): Identifier of the source on which to validate the model
            outcome_column_index (int): Index of the column to use as ground truth outcome/label
            column_set_id (str, optional): ID of the column set specifying testing features
            group_id (str, optional): ID of the group specifying testing rows
            decision_threshold (float, optional): Defines a discrimination boundary
                used to perform binary classification. This value can
                range from 0 to 1.
                Higher decision thresholds will exclude more elements
                from being classified (increasing type II error), whereas
                lower decision thresholds will cause fewer exclusions
                (increasing type I error). This parameter should depend
                on the user's tolerance for each type of error.
            async\_ (boolean, optional): If set to True, the statistics are calculated asynchronously.
            with_values (boolean, optional): If set to True, the original and predicted values will be
                returned with validation statistics for regression models, default = False.

        Returns:
            A :class:`ayasdi.core.models.multiclass_statistics.MulticlassStatistics` object for a multi class model,
            a :class:`ayasdi.core.models.classification_statistics.ClassificationStatistics` object,
            or a :class`ayasdi.core.models.regression_statistics.RegressionStatistics` object for a regression model
            Always returns a :class:`ayasdi.core.models.multiclass_statistics.MulticlassStatistics` object for decision
            tree model.
        """
        if self.model_id is None:
            raise ValueError('model_id not set. Verify that the model has been instantiated and is ready.')

        rest_args = {
            'source_view': {
                'source_id': source_id,
                'column_set_id': column_set_id,
                'group_id': group_id,
            },
            'outcome_column_index': outcome_column_index,
            'decision_threshold': decision_threshold,
            'with_values': with_values
        }

        if async_:
            url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/model_statistics/async'
            jobid = json_funcs._post_(self.connection.session, url, rest_args)
            print('Generating statistics is running in asynchronous mode.')
            print('Remember to call ready() to check status.')
            stats = self.get_statistics_type()(self.connection)
            stats.__set_async_job__(jobid, url)
        else:
            url = self.connection.CORE_REQUEST_STUB + 'models/' + self.model_id + '/model_statistics'
            res = json_funcs._post_(self.connection.session, url, rest_args)
            stats = self.get_statistics_type()(self.connection)
            stats.__fill_body__(res)

        return stats
