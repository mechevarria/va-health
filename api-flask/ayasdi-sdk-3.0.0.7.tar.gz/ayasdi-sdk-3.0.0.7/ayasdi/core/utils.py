from __future__ import absolute_import, unicode_literals, division, print_function


def ordered_dedup(seq):
    '''
    function to deduplicate a list while keeping elements in order

    Args:
        list

    Returns:
        list

    >>> from ayasdi.core import utils
    >>> utils.ordered_dedup([1,3,2,4,2,2,2,7])
    [1, 3, 2, 4, 7]

    '''
    seen = set()
    seen_add = seen.add
    return [x for x in seq if not (x in seen or seen_add(x))]


if __name__ == "__main__":
    import doctest
    doctest.testmod()


def grammar_join(items, connector=u'and'):
    words = sorted([u'"' + str(item) + u'"' for item in items])
    length = len(words)
    if length == 0:
        return u''
    if length == 1:
        return words[0]
    if length == 2:
        return words[0] + u' ' + connector + u' ' + words[1]
    return u', '.join(words[:-1]) + u', ' + connector + u' ' + words[-1]
