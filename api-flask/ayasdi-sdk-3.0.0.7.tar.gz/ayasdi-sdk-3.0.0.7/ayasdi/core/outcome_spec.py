#!/usr/bin/env python
class OutcomeSpec(object):
    """Defines parameters for an outcome class.
    Used in:
     - Outcome Auto analysis : :class:`ayasdi.core.source.Source.outcome_auto_analysis`.
     - Feature Selection : :class:`ayasdi.core.source.Source.select_features`.

To construct a new OutcomeSpec, supply a list of classes_of_interest and EITHER an ``outcome_column_index`` OR
an ``outcome_column_name``. All other parameters are optional and represent advanced controls on
the scoring algorithm for Outcome Auto analysis.

Args:
    classes_of_interest ([str]): list of classes to be included in an OutcomeSpec, specified as a list of strings.
    outcome_column_index (int): integer index of the outcome column to be created. Used if the ``outcome_column_name``
        is not found.
    outcome_column_name (str): specifies the name of the outcome column to be created. (optional)
    small_group_size (int): minimum count of rows in a group below which we would consider groups to be outlier groups.
        In regular OAA, rows in these groups are penalized. In rare OAA, rows in these groups enter the outlier pool.
        Must be positive. Default set to log(<row_count>). (optional)
    cutoff_strength (double): This parameter controls the acceptable proportion of outliers in our network. This is
        used for scaling the small group penalty so that it approaches the maximum impurity penalty when the fraction
        of rows in small groups approaches cutoff_strength. Must be in [0,1]. Default: 0.125. (optional)
    node_count_penalty (double): penalty factor for networks with high ratios between node_count and either row_count
        or the max number of displayable nodes. When the larger of those two ratios is close to one, the penalty term
        is equal to the worst possible homogeneity times this parameter. Must be positive. Default 0.25. (optional)
    edge_count_penalty (double): penalty term for networks with high ratios between edge_count and either the max
        possible edge_count in a complete graph with the current node_count or the max number of displayable edges.
        When the larger of those two ratios is close to one, the penalty term is equal to the worst possible
        homogeneity times this parameter. Must be positive. Default 0.25. (optional)

**Return Type:**

A specification similar to the following example:

.. raw:: html

        <div class="highlight"><pre>
            import ayasdi.core as ac

            column_set = src.create_column_set(name=<span class="s2">'test_column_set1'</span>,
                                               column_list=<span class="s2">['c1', 'c2', 'c3', 'c4']</span>)
            <span class="c1"># Pass OutcomeSpec.outcome_column_name</span>
            src.outcome_auto_analysis(name=<span class="s2">'test_outcome'</span>,
                                      column_set=column_set,
                                      outcome_spec=OutcomeSpec(
                                                               classes_of_interest=<span class="s2">['1.0']</span>,
                                                               outcome_column_name=<span class="s2">'Label'</span>))
        </pre></div>

    """
    def __init__(self,
                 classes_of_interest=list(),
                 outcome_column_index=None,
                 outcome_column_name=None,
                 small_group_size=None,
                 cutoff_strength=None,
                 node_count_penalty=None,
                 edge_count_penalty=None):
        self.classes_of_interest = classes_of_interest
        self.outcome_column_index = outcome_column_index
        self._outcome_column_name = outcome_column_name
        self.small_group_size = small_group_size
        self.cutoff_strength = cutoff_strength
        self.node_count_penalty = node_count_penalty
        self.edge_count_penalty = edge_count_penalty

    def __getitem__(self, key):
        if key in self.__dict__:
            return self.__dict__[key]
        if not key.startswith('_'):
            return self.__getitem__('_{}'.format(key))

    def __setitem__(self, key, value):
        uk = '_{}'.format(key)
        if uk in self.__dict__:
            key = uk
        self.__dict__[key] = value

    def serialize(self):
        """
        converts an :class:`ayasdi.core.outcome_spec.OutcomeSpec` object into a
        dictionary
        """
        return {
            k: self.__dict__[k]
            for k in self.__dict__.keys()
            if not k.startswith('_')
        }
