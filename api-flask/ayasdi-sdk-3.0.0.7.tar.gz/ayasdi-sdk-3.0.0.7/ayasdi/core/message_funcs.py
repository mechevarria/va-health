from __future__ import absolute_import, unicode_literals, division, print_function


def _show_labs(subject="This"):
    message = "{} is an Ayasdi LABS Feature and is subject " \
              "to modification or deprecation in a future release. " \
              "Visit our LABS page at " \
              "https://platform.ayasdi.com/sdkdocs/labs.html " \
              "to learn more and give us your feedback.".format(subject)
    return message
