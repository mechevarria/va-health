#!/usr/bin/env python

"""AsyncJob class for Ayasdi API.
"""
from __future__ import absolute_import, unicode_literals, division, print_function
import ssl
import json
import logging
import time
import websocket
import threading

from ayasdi.core import json_funcs

LOGGER = logging.getLogger(__name__)


class AsyncJob(object):
    """ An instance of the asynchronous job class.

    .. Note::
       This class is not instantiated directly, but returned as a result of a number of
       functions where ``async\_`` is set to true. Example functions that do this are:
          - :func:`api.upload_source <ayasdi.core.api.Api.upload_source>`
          - :func:`source.select_features <ayasdi.core.source.Source.select_features>`
          - :func:`source.create_network_async <ayasdi.core.source.Source.create_network_async>`
          - :func:`source.compare_groups <ayasdi.core.source.Source.compare_groups>`
          - :func:`source.get_stats <ayasdi.core.source.Source.get_stats>`


    The following variables are available for each job object:
     - id - The id of the job object
     - status - either ``running`` or ``complete``
     - result - The JSON returned by the REST Endpoint
     - exception - The exception returned by the REST Endpoint
     - running_since - The timestamp indicating when the job
        is received by the backend

    Args:
        job_info (dict): Job info requested by the API class

    Returns:
        The AsyncJob object.
    """
    def __init__(self,
                 connection,
                 job_info=None,
                 endpoint=None,
                 id=None,
                 start_time=None,
                 end_time=None,
                 running_since=None,
                 completed_at=None,
                 execution_time=None,
                 exception=None,
                 result=None,
                 status="running",
                 result_converter=None
                 ):
        self.id = id or job_info.get('jobId')
        if self.id is None:
            raise ValueError("Must provide 'job_info' or 'id' in parameter")
        self.trace_id = None
        if job_info:
            self.trace_id = job_info.get('traceId', None)
        self.start_time = start_time or time.time()
        self.end_time = end_time
        self.running_since = running_since or time.strftime("%a %d %b %Y %H:%M:%S GMT",
                                                            time.localtime(self.start_time))
        self.completed_at = completed_at
        self.execution_time = execution_time
        self.exception = exception
        self.result = result
        self.status = status
        self.result_converter = result_converter
        self.connection = connection
        self.endpoint = endpoint
        self.curl = self.endpoint + "/" + self.id
        self.ws_endpoint = 'notifications/'
        self.ws_app = None
        self.ws_last_msg_timestamp = 0
        self.WS_MAX_CONNECT_RETRY = 3
        self.ws_connect_retry = 0
        self.ws_error = False
        # user defined callbacks to receive websocket messages
        self.ws_on_message_callback = None
        self.ws_on_error_callback = None

    def serialize(self):
        """
        Converts an AsyncJob into a dictionary to be saved
        or exported to another thread or process.

        Returns:
            An AsyncJob dictionary.

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> source = connection.upload_source("./test/db_test2.txt")
        >>> extraglobs['src'] = source #ignore-in-doc
        >>> for comp in source.get_comparisons(): #ignore-in-docs
        ...     _ = source.delete_comparison(name=comp['name']) #ignore-in-docs
        >>> len(source.get_comparisons())
        0
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = \
            source.create_column_set(column_list=columns_for_analysis,
        ...                       name="test_column_set")
        >>> group1 = source.create_group(name="test_group1",
        ...                              row_indices=list(range(10)))
        >>> group2 = source.create_group(name="test_group2",
        ...                              row_indices=list(range(5, 15)))
        >>> # Async version below
        >>> compare_job = source.compare_groups("test_group1", "test_group2",
        ...                                     comparison_type='continuous_only',
        ...                                     async_=True)
        >>> serialized_job = compare_job.serialize()
        >>> new_comparison_job = AsyncJob(connection, **serialized_job)
        >>> new_comparison_job.sync()
        >>> source.sync()
        >>> comparisons = source.get_comparisons()
        >>> comparisons[0]['name']
        'test_group1 vs. test_group2 on All columns'
        >>> new_comp = source.rename_comparison(id=comparisons[0]['id'],
        ...                                     new_name="new_comparison_name")
        >>> new_comp['name']
        'new_comparison_name'
        >>> comparisons = source.get_comparisons()
        >>> comparisons[0]['name']
        'new_comparison_name'
        >>> source.delete_comparison(name="new_comparison_name")
        True
        >>> source.delete_column_set(id=column_set['id'])
        True

        """
        data = {'id': self.id,
                'start_time': self.start_time,
                'end_time': self.end_time,
                'running_since': self.running_since,
                'completed_at': self.completed_at,
                'execution_time': self.execution_time,
                'exception': self.exception,
                'result': self.result,
                'status': self.status,
                'endpoint': self.endpoint,
                }
        return data

    def __repr__(self):
        """String representation of the job.
        """
        if self.status == "running":
            return "Job id '%s' running since %s" % \
                (self.id, self.running_since)
        else:
            return "Job id '%s' completed in %s seconds at %s" % \
                (self.id, self.execution_time, self.completed_at)

    def ready(self):
        """ Query status of job

        Returns:
            If job complete, returns True, else False
        """
        if self.status == 'complete':
            return True
        else:
            ret_job = json_funcs._get_(self.connection.session, self.curl)
            if ret_job:
                self.status = 'complete'
                self.exception = ret_job.get('exception')
                self.result = ret_job.get('result')
                self.end_time = time.time()
                self.execution_time = self.end_time - self.start_time
                self.completed_at = \
                    time.strftime("%a %d %b %Y %H:%M:%S GMT",
                                  time.localtime(self.end_time))
                return True
            else:
                return False

    def sync(self):
        """Synchronizes the job class, waits for the
           job completion, and sets the results to 'json' field.
        """
        while not self.ready():
            time.sleep(1)

        if self.ws_app:
            self.ws_app.close()

    def get_result(self):
        """Returns the result of the current :class:`AsyncJob <ayasdi.core.async_jobs.AsyncJob>`.
        """
        self.sync()
        if self.exception is not None:
            raise self.exception
        if self.result_converter is not None:
            return self.result_converter(self.result)
        else:
            return self.result

    def subscribe(self, on_message, on_error):
        """
        Allows the user to subscribe and receive events for the
        current :class:`AsyncJob <ayasdi.core.async_jobs.AsyncJob>`.

        Args:
            on_message (func): callback function that needs to be called
               whenever a message is received from the server.
               The ``on_message`` function has two arguments:
                  - An AsyncJob object
                  - The event dictionary returned by the Ayasdi platform
            on_error (func): callback function that needs to be called
              whenever there is an error.
              The ``on_error`` function has two arguments:
                  - An AsyncJob object
                  - The error dictionary returned by the Ayasdi platform

        Returns:
            None

        :Example:

        >>> source = connection.upload_source("./test/db_test12.txt", check_duplicate=False)
        >>> group1 = source.create_group(name="test_group1",
        ...                              row_indices=list(range(50)))
        >>> group2 = source.create_group(name="test_group2",
        ...                              row_indices=list(range(25, 75)))
        >>> # callback functions
        >>> import json
        >>> msg_count = 0
        >>> def on_message(job, event_dict):
        ...     global msg_count
        ...     msg_count += 1
        >>> def on_error(job, error_msg):
        ...     print (error_msg)
        >>> # Async version below
        >>> compare_job = source.compare_groups("test_group1", "test_group2",
        ...                                     comparison_type='continuous_only',
        ...                                     async_=True)
        >>> compare_job.subscribe(on_message, on_error)
        >>> compare_job.sync()
        >>> msg_count > 0
        True
        >>> connection.delete_source(id=source.id)
        """
        if not self.trace_id:
            return

        thread_name = 'notification thread: %s' % self.id
        t = threading.Thread(name=thread_name,
                             target=self.__setup_websocket_channel,
                             args=(on_message, on_error))
        t.daemon = True
        t.start()

    def __setup_websocket_channel(self, on_message, on_error):
        ws_url = '%s%s' % (self.connection.CORE_LOGIN_STUB, self.ws_endpoint)
        # replace https: with wss:
        ws_url = ws_url.replace('https', 'wss')
        cookie_str = ';'.join(['%s=%s' % (key, val) for key, val in self.connection.get_cookie_dict().items()])
        try:
            self.ws_app = websocket.WebSocketApp(ws_url,
                                                 on_open=self.__subscribe,
                                                 on_close=self.__on_close,
                                                 on_message=self.__on_message,
                                                 on_error=self.__on_error,
                                                 cookie=cookie_str)
            self.ws_on_message_callback = on_message
            self.ws_on_error_callback = on_error
            time.sleep(0.01)
            self.ws_app.run_forever(sslopt={"cert_reqs": ssl.CERT_NONE})
        except websocket.WebSocketException as e:
            LOGGER.warning("error establishing websocket connection", e)
        finally:
            self.ws_app.close()

    def __on_message(self, ws_app, msg):
        if self.ws_on_message_callback:
            msg_dict = json.loads(msg)
            self.ws_error = True if 'error' in msg_dict else False
            self.ws_last_msg_timestamp = int(time.time())
            self.ws_on_message_callback(self, msg_dict)

    def __on_error(self, ws_app, error):
        self.ws_error = True
        if self.ws_on_error_callback:
            self.ws_on_error_callback(self, error)

    def __on_close(self, ws_app):
        # try to re-subscribe if job is still running
        if not self.ready():
            ws_app.close()
            self.ws_connect_retry += 1
            time.sleep(2)
            self.subscribe(self.ws_on_message_callback, self.ws_on_error_callback)

    def __subscribe(self, ws_app):
        try:
            subscribe_msg = '{"action":"%s", "traceId":"%s", "timestamp":%s}' \
                            % ('subscribe', self.trace_id, self.ws_last_msg_timestamp)
            ws_app.send('%s' % (subscribe_msg))
        except websocket.WebSocketConnectionClosedException as e:
            LOGGER.warning("error subscribing", e)

    def __unsubscribe(self, ws_app):
        try:
            unsubscribe_msg = '{"action":"%s", "traceId":"%s"}' % ('unsubscribe', self.trace_id)
            ws_app.send('%s' % (unsubscribe_msg))
        except websocket.WebSocketConnectionClosedException:
            pass
