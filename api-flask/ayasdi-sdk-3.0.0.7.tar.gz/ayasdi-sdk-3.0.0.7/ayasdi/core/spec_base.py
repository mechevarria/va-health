#!/usr/bin/env python


# Todo 10349: check if needed.
class SpecBase(object):

    def __getitem__(self, key):
        if key in self.__dict__:
            return self.__dict__[key]
        if not key.startswith('_'):
            return self.__getitem__('_' + key)

    def __setitem__(self, key, value):
        uk = '_' + key
        if uk in self.__dict__:
            key = uk
        self.__dict__[key] = value

    def serialize(self):
        return {
            k: self.__dict__[k]
            for k in self.__dict__.keys()
            if not k.startswith('_')
        }
