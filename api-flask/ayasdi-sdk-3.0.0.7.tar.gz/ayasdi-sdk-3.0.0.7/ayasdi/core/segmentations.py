#!/usr/bin/env python

"""
Segmentation class for the Ayasdi API.
"""
import ayasdi.core.api
from ayasdi.core import json_funcs


def _check_connection(connection):
    if not isinstance(connection, ayasdi.core.api.Api):
        raise TypeError("TypeError: first parameter must be an Api object. "
                        "This is a change since Ayasdi SDK version 7.10.")


class Segmentation(object):

    def __init__(self, connection):
        """
        Create a Segmentation object.
        """
        self.connection = connection
        self.name = None
        self.group_ids = None

    def __fill_body__(self, res):
        self.group_ids = res['group_ids']

    def __repr__(self):
        """
        :return: A string containing a printable representation of Segmentation object.
        """

        return "<Segmentation '%s'> \ngroup_ids: %s" % (self.name, self.group_ids)

    @staticmethod
    def _create(connection, name, source_subset, outcome_column_index=None, network_id=None, autogroup_parameters=None):
        """
        Run a segmentation scenario with an existing network.

        :param connection: The Api connection
        :param name: The name of this segmentation. It overwrites autogroup_parameters['create_groups_with_name']
        :param source_subset: a SourceSubset object
        :param network_id (string or int): The network identifier
        :param autogroup_parameters: A dictionary of parameters for Network.autogroup_create()
        :return: A list of group ids

        :Example:
        >>> import ayasdi.core as ac
        >>>
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> columns = ["relative weight", "blood glucose",
        ...            "insulin level", "insulin response"]
        >>> col_set = src.create_column_set(columns, "test_column_set")
        >>> network = src.create_network("test_network21",{
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': col_set['id'],
        ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 30, 'id': 'MDS coord 2',
        ...                   'equalize': True, 'gain': 3.0}]
        ...        }
        ... )
        >>> source_subset = ac.SourceSubset(source_id=src.id, column_set_id=col_set['id'])
        >>> autogroup_parameters = {'autogroup_algorithm_id': 'connected_components',
        ...                         'create_groups_with_name': None,
        ...                         'min_node_count': 5,
        ...                         'cutoff_strength': None,
        ...                         'coloring_values': None,
        ...                         'output_column_id': None,
        ...                         'num_initial_trials': None,
        ...                         'initial_cutoff': None,
        ...                         'num_rd_trials': None,
        ...                         'rd_cutoff': None
        ...                         }
        >>> segmentation = ac.Segmentation._create(connection=connection,
        ...                                     name='segmentation',
        ...                                     source_subset=source_subset,
        ...                                     network_id=network.id,
        ...                                     autogroup_parameters=autogroup_parameters)
        >>> group_ids = segmentation._get_group_ids()
        >>> _ = src.delete_network(id=network.id) #ignore-in-docs
        """

        _check_connection(connection)

        # Overwrite name specified in autogroup_parameters by name specified in Segmentation._create_()
        autogroup_parameters['create_groups_with_name'] = name

        segmentation_request = {'name': name,
                                'source_subset': source_subset.serialize()['source_subset'],
                                'network_id': network_id,
                                'autogroup_parameters': autogroup_parameters
                                }

        url = connection.CORE_REQUEST_STUB + 'segmentations'
        res = json_funcs._post_(connection.session, url, segmentation_request)

        segmentation = Segmentation(connection)
        segmentation.__fill_body__(res)
        segmentation.name = name

        return segmentation

    def _get_group_ids(self):
        """
        :return: Identifiers of created segments (groups)
        """
        return self.group_ids
