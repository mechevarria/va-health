import six


def validate_conditions(conditions, valid_column_keys):
    for condition in conditions:
        if not any(col_key in condition for col_key in valid_column_keys):
            raise KeyError(
                "one of the following is required as a key in the conditions dict: " +
                ', '.join(valid_column_keys))


def process_conditions(col_key, conditions, ret_dict):
    col_predicates_map = {}
    for condition in conditions:
        if col_key in condition:
            col_value = condition[col_key]
            predicate = _create_predicate(condition)
            predicates_list = col_predicates_map.get(col_value, [])
            predicates_list.append(predicate)
            col_predicates_map[col_value] = predicates_list

    for col_value, predicates in six.iteritems(col_predicates_map):
        condition_dict = {col_key: col_value,
                          'predicates': col_predicates_map[col_value]}
        ret_dict['filters'].append(condition_dict)

    return ret_dict


def _create_predicate(condition):
    predicate = {}
    in_set = condition.get('in_set', None)
    in_range = condition.get('in_range', None)
    if in_set:
        predicate['in_set'] = in_set
    elif in_range:
        predicate['in_range'] = in_range
    else:
        raise ValueError("Either in_set or in_range are required")
    if 'not' in condition:
        predicate['not'] = condition['not']
    if 'contains' in condition:
        predicate['contains'] = condition['contains']
    return predicate
