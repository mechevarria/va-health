from __future__ import absolute_import, unicode_literals, division, print_function
import logging
from functools import wraps
LOGGER = logging.getLogger(__name__)


def __dependency_checker__(*decargs):
    """A decorator with arguments.
    Check http://stackoverflow.com/a/5929165 for an eg.
    """
    def real_decorator(func):
        @wraps(func)
        def wrapped_function(*args, **kwargs):
            for arg in decargs:
                try:
                    __import__(arg)
                except ImportError as e:
                    LOGGER.exception(e)
                    raise ImportError(
                        '''Method "%s" cannot be used.
                        Requires an unavailable package "%s".''' %
                        (func.__name__, arg))
            return func(*args, **kwargs)
        return wrapped_function
    return real_decorator
