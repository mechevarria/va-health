#!/usr/bin/env python
"""
Comparison utilities
====================

Utilities that are meant to work with comparisons.

Each of these functions take a comparison dictionary as input.
Dependencies for running these functions include

 - pandas

Import this utility prior to usage::

   >>> import ayasdi.core.utilities.comparisons \
        as comparison_utils # doctest: +SKIP

"""
from __future__ import absolute_import, unicode_literals, division, print_function
from ayasdi.core.utilities.lib import __dependency_checker__


@__dependency_checker__('pandas')
def as_dataframe(comparison):
    '''Returns the comparison as a pandas dataframe.

    Args:
        comparison: A dictionary returned from :func:`source.compare_groups`.

    Returns: A tuple of pandas dataframes (numeric and categorical)

    :Example:

    >>> source = connection.get_source(name='db_test2.txt')
    >>> group1 = source.create_group(name="test_group1",
    ...                                    row_indices=range(10))
    >>> comparison = source.compare_groups("test_group1",
    ...         "Rest", name="testVsRest")
    >>> num_comp, cat_comp = as_dataframe(comparison)
    >>> type(num_comp)
    <class 'pandas.core.frame.DataFrame'>
    >>> sorted(list(num_comp.columns)) # doctest: +NORMALIZE_WHITESPACE
    ['bh_p_value', 'bh_t_test_p_value', 'column_index', u'diff_means', u'group0_percent_null',
    u'group1_percent_null', 'group_1_quartile_0', 'group_1_quartile_1',
    'group_1_quartile_2', 'group_1_quartile_3', 'group_1_quartile_4',
    'group_2_quartile_0', 'group_2_quartile_1', 'group_2_quartile_2',
    'group_2_quartile_3', 'group_2_quartile_4', 'ks_score', u'ks_sign', 'name',
    'p_value', u't_test_p_value']
    >>> sorted(list(cat_comp.columns)) # doctest: +NORMALIZE_WHITESPACE
    ['column_index', 'hypergeometric_p_value_1_vs_2',
    'hypergeometric_p_value_2_vs_1', 'name', 'percent_in_group_1',
    'percent_in_group_1_and_2', 'percent_in_group_2']
    >>> connection.delete_source(name="db_test2.txt") #ignore-in-doc
    >>> extraglobs['comparison'] = comparison #ignore-in-doc
    '''
    import pandas as pd
    # Get continuous table
    raw_cns_table = comparison['continuous_explainers']
    if not raw_cns_table:
        cns_df = pd.DataFrame([])
    else:
        v0_cns_cols = ['column_index', 'name', 'ks_score',
                       'p_value', 'quartiles']
        new_cns_cols = set(raw_cns_table[0].keys()).difference(v0_cns_cols)
        all_cols = v0_cns_cols + sorted(list(new_cns_cols))
        cns_df = pd.DataFrame(raw_cns_table, columns=all_cols)
        for group in range(2):
            for quartile in range(5):
                new_col = 'group_%s_quartile_%s' % (group + 1, quartile)
                cns_df[new_col] = \
                    cns_df['quartiles'].apply(lambda x: x[group][quartile])
        del cns_df['quartiles']
    # Get categorical data
    raw_cat_table = comparison['categorical_explainers']
    if not raw_cat_table:
        cat_df = pd.DataFrame([])
    else:
        v0_cat_cols = ['column_index', 'name',
                       'hypergeometric_p_values', 'percent_in_group']
        new_cat_cols = set(raw_cat_table[0].keys()).difference(v0_cat_cols)
        all_cols = v0_cat_cols + sorted(list(new_cat_cols))
        cat_df = pd.DataFrame(raw_cat_table, columns=all_cols)
        cat_df['hypergeometric_p_value_1_vs_2'] = \
            cat_df['hypergeometric_p_values'].apply(lambda x: x[0])
        cat_df['hypergeometric_p_value_2_vs_1'] = \
            cat_df['hypergeometric_p_values'].apply(lambda x: x[1])
        cat_df['percent_in_group_1'] = \
            cat_df['percent_in_group'].apply(lambda x: x[0])
        cat_df['percent_in_group_1_and_2'] = \
            cat_df['percent_in_group'].apply(lambda x: x[1])
        cat_df['percent_in_group_2'] = \
            cat_df['percent_in_group'].apply(lambda x: x[2])
        del cat_df['hypergeometric_p_values']
        del cat_df['percent_in_group']
    return cns_df, cat_df


def get_top_features(comparison, **kwargs):
    '''Returns the top features in a comparison filtered by specific features.

    Args:

        comparison (dict): A dictionary returned from :func:`source.compare_groups`.
        type (str) : Whether to work on `numeric` or
            `categorical`, default is numeric.
        num_features (int): (Optional) Number of features
            to return, defaults to 10.
        stat (str) : (Optional) Statistics to sort by, default to
            `ks_score` for numeric and `percent_in_group_1` for
            categorical. Operators +-%*/ can be used as predicates.

    Returns:

        feature_list (list) : A list of features.

    :Example:

    >>> comparison = extraglobs['comparison'] #ignore-in-doc
    >>> set(get_top_features(comparison)) # doctest: +NORMALIZE_WHITESPACE
    set([u'blood glucose', u'steady state plasma glucose',
         u'relative weight', u'db_annotation1', u'Median',
         u'insulin level', u'insulin response', u'ID',
         u'clinical classification'])
    '''
    num_comp, cat_comp = as_dataframe(comparison)
    num_features = kwargs.get('num_features', 10)
    comparison_type = kwargs.get('type', 'numeric')
    if comparison_type == "numeric":
        stat = kwargs.get('stat', 'ks_score')
        features = num_comp.sort_values(by=stat,
                                        ascending=False).name[:num_features]
    else:
        stat = kwargs.get('stat', 'percent_in_group_1')
        features = cat_comp.sort_values(by=stat,
                                        ascending=False).name[:num_features]
    return list(features)


if __name__ == "__main__":
    import doctest
    doctest.testmod()
