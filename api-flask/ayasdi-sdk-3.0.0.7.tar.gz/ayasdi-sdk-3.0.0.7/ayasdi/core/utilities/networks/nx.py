#!/usr/bin/env python
"""
Networkx utilities
====================
:author: Raviteja Chirala, Ajith Warrier

Utilities that are meant to work with networks, e.g.
convert to a networkx graph.
Each of these functions take a network object as an input.

Dependencies for running these functions include `networkx`.

Import this utility prior to usage::

   >>> import ayasdi.core.utilities.networks as network_utils # doctest: +SKIP

"""
from __future__ import absolute_import, unicode_literals, division, print_function
import networkx
from ayasdi.core.utilities.lib import __dependency_checker__


@__dependency_checker__('networkx')
def as_networkx_graph(network, encoding='utf-8'):
    """Convert a network object to a networkx graph

    Args:
      network (:class:`ayasdi.core.networks.Network`) : A network object.

    Returns:

      A networkx object.

    :Examples:

    >>> source = connection.upload_source('./test/db_test2.txt')
    >>> from ayasdi.core.utilities.networks \
        import as_networkx_graph # doctest: +SKIP
    >>> columns_for_analysis = ["relative weight", "blood glucose",
    ...     "insulin level", "insulin response"]
    >>> column_set = source.create_column_set(column_list=columns_for_analysis,
    ...     name="test_column_set1")
    >>> network = source.create_network("test_network1",{
    ...     'metric': {'id': 'Norm Correlation'},
    ...     'column_set_id': column_set['id'],
    ...     'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
    ...                 'equalize': True, 'gain': 3.0},
    ...                {'resolution': 30, 'id': 'MDS coord 2',
    ...                  'equalize': True, 'gain': 3.0}]
    ...     }
    ... )
    >>> nx_graph = as_networkx_graph(network)
    >>> type(nx_graph)
    <class 'networkx.classes.graph.Graph'>
    >>> extraglobs['network'] = network #ignore-in-doc
    >>> extraglobs['source'] = source #ignore-in-doc

    """
    all_nodes = network.get_nodes()
    node_ids = [node['id'] for node in all_nodes]
    networkx_graph = networkx.Graph()
    for node in node_ids:
        networkx_graph.add_node(int(node))
    for link in network.links:
        networkx_graph.add_edge(link['from'], link['to'])
    return networkx_graph


@__dependency_checker__('networkx')
def get_connected_components(network):
    '''Returns a list of connected components in the network.

    Args:
      network (:class:`ayasdi.core.networks.Network`) : A network object.

    Returns:
      A list of connected components.

    :Examples:

    >>> network = extraglobs['network'] #ignore-in-doc
    >>> from ayasdi.core.utilities.networks \
        import get_connected_components # doctest: +SKIP
    >>> connected_components = get_connected_components(network)
    >>> len(list(connected_components))
    8
    >>> source = extraglobs['source'] #ignore-in-doc
    >>> _ = source.delete_network(name='test_network1') #ignore-in-doc
    '''
    nx_graph = as_networkx_graph(network)
    return networkx.connected_components(nx_graph)


@__dependency_checker__('networkx')
def to_graphMl(network, filename):
    """Returns a graphMl representation of the network.

    Args:
      network (:class:`ayasdi.core.networks.Network`) : A network object.
      filename (str) : The output file.

    Returns:
      None

    """
    nx_graph = as_networkx_graph(network)
    with open(filename, 'wb') as f:
        networkx.write_graphml(nx_graph, f)
