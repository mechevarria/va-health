from ayasdi.core import json_funcs


class PredictionService(object):
    def __init__(self, connection, model_url, return_type="predict_proba"):
        self.connection = connection
        if model_url is None or len(model_url) == 0 or model_url[0] != '/':
            raise ValueError("Invalid model_url")
        self.model_url = model_url  # service url indicated in the link above
        self.return_type = return_type

    def predict(self, row_vector):
        # The function calls a post on the service url website and retrieves the result
        # If the return type is "predict_proba", then the result is similar to what is returned by the model endpoint
        # else if it is 'predict_decisions", the the result is similar to that one.
        if row_vector is None:
            raise ValueError("Invalid row vector")

        if self.return_type != 'predict_proba' and self.return_type != 'predict_decisions':
            raise ValueError("Invalid return type")

        if self.model_url is None or len(self.model_url) == 0 or self.model_url[0] != '/':
            raise ValueError("Invalid model_url")

        requestData = {
            'points': [row_vector],
            'return_type': self.return_type
        }
        n_url = self.model_url[1:len(self.model_url)] if self.model_url[0] == '/' else self.model_url
        url = self.connection.CORE_KONG_REQUEST_STUB + n_url + '/process'
        prediction = json_funcs._post_(self.connection.session, url, data=requestData, params=None)
        return prediction
