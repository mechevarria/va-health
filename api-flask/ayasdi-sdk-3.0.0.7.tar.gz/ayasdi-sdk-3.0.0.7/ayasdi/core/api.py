#!/usr/bin/env python
"""
==========
Details
==========

Core module that acts as an authenticated entry point to the rest of the SDK functionality.

.. highlight:: python
   :linenothreshold: 2

.. Note::
   Connection to the Ayasdi platform is established using the following code block.

    .. code-block:: python

        from ayasdi.core.api import Api
        connection = Api(username, password)

.. rubric:: Functions

.. autosummary::
   Api
   Api.upload_source
   Api.create_resumable_upload
   Api.check_platform_version
   Api.get_sources
   Api.get_source
   Api.delete_source
   Api.get_user
   Api.get_models
   Api.get_model
   Api.import_pmml_model
   Api.get_jobs
   Api.get_transformations
   Api.set_timeout
   Api.get_last_traceid
   Api.get_cookie_dict
   Api.get_cookie_domains
   Api.register_model
   Api.unregister_model
   Api.get_model_status
   Api.terminate_job


================
Module Contents
================

"""

from __future__ import absolute_import, unicode_literals, division, print_function

import json
import logging
import os
import re
import warnings
from logging import NullHandler
from zipfile import ZipFile

import requests
from ayasdi._version import __version__  # noqa: F401
from ayasdi.core import async_jobs
from ayasdi.core import creds
from ayasdi.core import jobs
from ayasdi.core import json_funcs
from ayasdi.core import message_funcs
from ayasdi.core import models
from ayasdi.core import resumable_upload
from ayasdi.core import source
from ayasdi.core import user
from requests.exceptions import RequestException
from requests.exceptions import SSLError
from requests_toolbelt import MultipartEncoder

from ayasdi import session as ayasdi_session

LOGGER = logging.getLogger(__name__)
LOGGER.addHandler(NullHandler())


# prevents warnings.warn from spitting out garbage on the second line.
def warning_on_one_line(message, category, filename, lineno, file=None, line=None):
    return '%s:%s: %s: %s\n' % (filename, lineno, category.__name__, message)


warnings.formatwarning = warning_on_one_line


def get_default_api_server_url():
    url = "https://platform.ayasdi.com/workbench"
    env_var = 'AYASDI_APISERVER'
    if env_var in os.environ:
        env_url = os.environ[env_var].strip()
        if not env_url == '':
            url = env_url
    return url


def normalize_api_server_url(url):
    url = url.strip()
    if not url.endswith('/'):
        url += "/"
    return url


class Api(object):
    """Instantiate a new connection.

    .. Note::
       To import a class of models, use an import statement as shown below for the RandomForest example:

       .. code-block:: python

          from ayasdi.core.models import RandomForest

    Args:
        username (str) : Your Ayasdi Core username.
        password (str) :  Your Ayasdi Core password.
        save_password (bool) : If set to True, saves the user-entered username and password in
            the local machine's keyring. (optional)
        cookie_dict (dict) : Cookie dictionary used for single sign-on login. Can also be passed as a JSON string in
            the 'AYASDI_COOKIE' environment variable. (optional)
        cookie_domain (string) : Cookie domain string used for single sign-on login. Can also be passed as the
            environment variable 'AYASDI_COOKIE_DOMAIN'. (optional)
        url (string): URL to the Ayasdi platform. For example: "https://platform.ayasdi.com/workbench"
        ignore_version (bool): If set to True, the Ayasdi platform skips the version match check. **SDK version
            mismatches with the platform are not supported.** Set =True at your own risk.
        session (requests.Session): An existing ``requests.Session`` object that should be used
            for connection. (optional)

    Returns:
        The :class:`Api` connection object

    :Example:

    >>> import ayasdi.core as ac
    >>>
    >>> connection = ac.Api(username, password, url=url)
    >>> # Connection properties
    >>> username = connection.username
    >>> password = connection.password
    >>> # Check connection status
    >>> connection.is_connected
    True
    """

    def __init__(self, username=None, password=None, save_password=False,
                 cookie_dict=None, cookie_domain="", url="",
                 ignore_version=False, session=None, verify=True, trace_id=None):
        """Instantiate a new ayasdi.core.Api connection.
        """
        self.password = None
        self.is_connected = False
        if url == "":
            url = get_default_api_server_url()
        self.CORE_LOGIN_STUB = normalize_api_server_url(url)
        ix = self.CORE_LOGIN_STUB.find('workbench/', len(self.CORE_LOGIN_STUB) - 10)
        self.CORE_KONG_REQUEST_STUB = self.CORE_LOGIN_STUB[0:ix] if ix != -1 else ''
        self.CORE_REQUEST_STUB = "%sv0/" % self.CORE_LOGIN_STUB
        if session is not None:
            self.session = session
        else:
            self.session = ayasdi_session.Session()
            self.session.verify = verify
        if trace_id is not None:
            self.session.trace_id = trace_id

        if cookie_dict is None:
            ayasdi_cookie_json = os.environ.get('AYASDI_COOKIE')
            if ayasdi_cookie_json is not None:
                cookie_dict = json.loads(ayasdi_cookie_json)

        cookie_domain = cookie_domain or os.environ.get('AYASDI_COOKIE_DOMAIN', '')

        if not cookie_dict:
            # If username is given, check creds for
            # this user's password on this server.
            # Else check creds for both username and password.
            # If both are given, save the password to be used with cli.
            if not username:
                username, password = creds.get_creds(
                    self.CORE_LOGIN_STUB)
            elif not password:
                username, password = creds.get_creds(
                    self.CORE_LOGIN_STUB,
                    username=username)
            else:
                self.password = password
            self.username = username

            try:
                resp = self.session.post(
                    self.CORE_LOGIN_STUB + 'login',
                    data={"username": username,
                          "passphrase": password},
                    headers={'accept': 'application/json',
                             'content-type': 'application/x-www-form-urlencoded'})
            except SSLError as e:
                error_message = "SSLError: %s" % e
                LOGGER.exception(error_message)
                warnings.warn(error_message)
                self.session.verify = False
                resp = self.session.post(
                    self.CORE_LOGIN_STUB + 'login',
                    data={"username": username,
                          "passphrase": password},
                    headers={'accept': 'application/json',
                             'content-type': 'application/x-www-form-urlencoded'})
            # Did login work?
            try:
                resp.raise_for_status()
                self.is_connected = True
                if save_password:
                    creds.save_creds(self.CORE_LOGIN_STUB,
                                     username, password)
            except RequestException:
                json_funcs._log_error(resp)
                raise
        else:
            for name, value in cookie_dict.items():
                self.session.cookies.set(name, value,
                                         domain=cookie_domain)
            try:
                resp = self.session.get(
                    self.CORE_LOGIN_STUB + 'validateCookie',
                    headers={'accept': 'application/json'},
                )
            except SSLError as e:
                error_message = "SSLError: %s" % e
                LOGGER.exception(error_message)
                warnings.warn(error_message)
                self.session.verify = False
                resp = self.session.get(
                    self.CORE_LOGIN_STUB + 'validateCookie',
                    headers={'accept': 'application/json'},
                )

            if resp.status_code not in [200, 204]:
                self.session.cookies.clear()
                resp.raise_for_status()
            else:
                self.is_connected = True

        if not ignore_version:
            self.check_platform_version()

    def upload_source(self, filename, check_duplicate=True,
                      allow_duplicate=False,
                      upload_spec=None,
                      metadata=None,
                      async_=False):
        """Uploads a new file or return a previously uploaded :class:`Source <ayasdi.core.source.Source>` object.

        Args:
            filename (str) : absolute path to the file to be uploaded
            check_duplicate(bool): Only for internal use. Please use ``allow_duplicate`` instead.
            allow_duplicate (bool): if True, and if a source with the same name already exists appends a number.
                  (For example, if  "my_source.txt" already exists it becomes "my_source.txt 1".)
                  If False, if a source file with the same name already exists in your instance,
                  returns the existing source. Default=False
            upload_spec (dict): specification for overriding the column type and data type detect lines.
                See example below.
                  The following optional keys are accepted:
                    - ``column_type_overrides`` for overriding column types. Legal types can
                        be "string, "double, "long" and "datetime".
                    - ``column_type_detect_lines`` for overriding data type detect lines.
                    - ``ignore_null_rows (str)`` for ignoring rows with null values in all columns. Default is false.
            metadata (dict): optional user defined metadata. Allows only simple key,value pairs in the dictionary.
                Default is None. For example, can add metadata={'key':'value'}.

            async\_ (bool): if True, uploads the source asynchronously. Default=False

        Returns:
            A :class:`Source <ayasdi.core.source.Source>` object.

        . . . . . . . . . . . . . . . . . . . . . . . .
        . . . . . . . . . . . . . . . . . . . . . . . .
        . . . . . . . . . . . . . . . . . . . . . . . .
        . . . . . . . . . . . . . . . . . . . . . . . .
        . . . . . . . . . . . . . . . . . . . . . . . .
        . . . . . . . . . . . . . . . . . . . . . . . .
        . . . . . . . . . . . . . . . . . . . . . . . .

        :Example:

        >>> # Remove a data source if it exists
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> extraglobs['src'] = src #ignore-in-doc
        >>> src.name
        'db_test2.txt'
        >>> src = connection.get_source(name="db_test2.txt")
        >>> # Asynchronous Call
        >>> src3 = \
            connection.upload_source("./test/db_test2.txt", async_=True)
        >>> src3 = connection.get_source(id=src3.id)
        >>> connection.delete_source(id=src3.id) #ignore-in-doc
        >>> # override system default column types
        >>> src4 = connection.upload_source("./test/db_test2.txt",
        ...                                 upload_spec=
        ...                                     {"column_type_overrides":[
        ...                                         {"name": "blood glucose", "type": "double"},
        ...                                         {"name": "relative weight", "type": "string"}]})
        >>> src4 = connection.get_source(id=src4.id)
        >>> connection.delete_source(id=src4.id) #ignore-in-doc
        >>> # override detect lines
        >>> src5 = \
            connection.upload_source("./test/db_test2.txt",
        ...                           upload_spec=
        ...                           {'column_type_detect_lines': 5000})
        >>> src5 = connection.get_source(id=src5.id)
        >>> connection.delete_source(id=src5.id) #ignore-in-doc

        """

        if async_:
            source_obj = self._upload_source_internal(filename=filename, check_duplicate=check_duplicate,
                                                      allow_duplicate=allow_duplicate,
                                                      upload_spec=upload_spec,
                                                      metadata=metadata,
                                                      async_=async_)
            return source_obj

        try:
            source_obj = self._upload_source_internal(filename=filename, check_duplicate=check_duplicate,
                                                      allow_duplicate=allow_duplicate,
                                                      upload_spec=upload_spec,
                                                      metadata=metadata,
                                                      async_=False)
        except requests.exceptions.HTTPError as errh:
            if errh.response.status_code == 400 and 'Data type mismatch. Mismatch data type for column' \
                    in errh.response.json()['message']:
                if upload_spec is None:
                    upload_spec = {}
                # retry with 20,000
                upload_spec['column_type_detect_lines'] = 20000
                source_obj = self._upload_source_internal(filename=filename, check_duplicate=check_duplicate,
                                                          allow_duplicate=allow_duplicate,
                                                          upload_spec=upload_spec,
                                                          metadata=metadata,
                                                          async_=False)
            else:
                raise
        return source_obj

    def _upload_source_internal(self, filename, check_duplicate=True,
                                allow_duplicate=False,
                                upload_spec=None,
                                metadata=None,
                                async_=False):
        filename = os.path.abspath(filename)
        base_filename = os.path.basename(filename)
        on_duplicate = 'create_new'

        # Check whether a file with this name has been previously uploaded.
        if check_duplicate or allow_duplicate:
            target_filename = base_filename
            if base_filename[-4:] == '.zip':
                if not os.path.isfile(filename):
                    raise IOError("File '%s' doesn't exist." % filename)
                zfile = ZipFile(filename)
                zfilenames = zfile.namelist()
                if len(zfilenames) == 0:
                    raise IOError("Zipfile '%s' does not contain "
                                  "any files." % filename)
                # Currently on the server side we are only
                # saving the first file in a zipfile.
                target_filename = zfilenames[0]

            file_uploaded, source_objects = self._check_file_uploaded(target_filename)
            if file_uploaded:
                if not allow_duplicate:
                    if len(source_objects) > 1:
                        message = ("Multiple source objects with the same name found.To retrieve a " +
                                   "list of all source objects with this name, run the get_sources() " +
                                   "function and specify the name as a function argument.")
                        LOGGER.warning(message)
                        print(message)
                    src = source_objects[0]
                    src.sync()
                    return src
                else:
                    on_duplicate = 'create_with_new_name'

        if upload_spec is None:
            m = MultipartEncoder([('name', base_filename),
                                  ('on_duplicate', on_duplicate),
                                  ('allow_duplicate', str(allow_duplicate)),
                                  ('metadata', str(metadata)),
                                  ('file', (base_filename, open(filename, 'rb'), 'text/plain'))])
        else:
            m = MultipartEncoder([('name', base_filename),
                                  ('on_duplicate', on_duplicate),
                                  ('allow_duplicate', str(allow_duplicate)),
                                  ('metadata', str(metadata)),
                                  ('uploadSpec', json.dumps(upload_spec)),
                                  ('file', (base_filename, open(filename, 'rb'), 'text/plain'))])

        if async_:
            endpoint = self.CORE_REQUEST_STUB + 'sources/async'
            async_task = json_funcs._post_(self.session,
                                           endpoint, m,
                                           content_type=m.content_type)

            upload_source_job = async_jobs.AsyncJob(self, async_task, endpoint)
            upload_source_job.sync()
            src_dict = upload_source_job.result
        else:
            endpoint = self.CORE_REQUEST_STUB + 'sources'
            src_dict = json_funcs._post_(self.session,
                                         endpoint, m,
                                         content_type=m.content_type)

        source_obj = source.Source(self, src_dict)
        source_obj.sync()
        return source_obj

    def create_resumable_upload(self, filename, check_duplicate=True, allow_duplicate=False,
                                upload_spec=None, metadata=None, async_=False):

        """Create a :class:`Source <ayasdi.core.source.Source>` from a file like object.
        Args:
            filename (str) : Name of the uploaded source
            check_duplicate(bool): Only for internal use. Please use ``allow_duplicate`` instead.
            allow_duplicate (bool): if True, and if a source with the same name already exists appends a number.
                  (For example, if  "my_source.txt" already exists it becomes "my_source.txt 1".)
                  If False, if a source file with the same name already exists in your instance,
                  returns the existing source. Default=False
            upload_spec (dict): specification for overriding the column type and data type detect lines.
                  See example below.
                  The following keys are accepted:
                    - ``column_type_overrides`` for overriding column types. Legal types can be
                    "string, "double, "long" and "datetime".
                    - ``column_type_detect_lines`` for overriding data type detect lines.
            metadata (dict): optional user defined metadata. Allows only simple key,value pairs in the dictionary.
                Default is None.
                For example, you can add metadata={'key':'value'}.

        Returns:
            A :class:`Source <ayasdi.core.source.Source>` object.

        :Example:

        >>> # Uploading a file with Upload Configuration
        >>> # Method 1: use context manager
        >>> with open("./test/db_test2.txt") as fin:
        ...     data = fin.read()
        >>> with connection.create_resumable_upload("db_test12 resume.txt") as up:
        ...     up.upload(data[0:int(len(data)/2)])
        ...     up.upload(data[int(len(data)/2):])
        >>> src = connection.get_source(id=up.source_object.id)
        >>> connection.delete_source(id=src.id) #ignore-in-doc
        >>> # Method 2: use ResumableUpload class
        >>> with open("./test/db_test2.txt.zip", 'rb') as fin:
        ...     data = fin.read()
        >>> r = connection.create_resumable_upload("db_test2.txt")
        >>> r.start()
        >>> r.upload(data[0:int(len(data)/2)])
        >>> r.upload(data[int(len(data)/2):])
        >>> source_object = r.finish()
        >>> src = connection.get_source(id=source_object.id)
        >>> connection.delete_source(id=src.id) #ignore-in-doc
        >>> # Asynchronous Call
        >>> with open("./test/db_test2.txt") as fin:
        ...     data = fin.read()
        >>> with connection.create_resumable_upload("db_test12 resume.txt",
        ...                                       async_=True) as up:
        ...     up.upload(data[0:int(len(data)/2)])
        ...     up.upload(data[int(len(data)/2):])
        >>> src = connection.get_source(id=up.source_object.id)
        >>> connection.delete_source(id=src.id) #ignore-in-doc
        >>> # Uploading a file with Upload Spec
        >>> with open("./test/db_test2.txt") as fin:
        ...     data = fin.read()
        >>> with connection.create_resumable_upload("db_test12 resume.txt",
        ...                          upload_spec=
        ...                           {'column_type_overrides':
        ...                            [{'name':'blood glucose',
        ...                              'type':'Double'},
        ...                             {'name':'relative weight',
        ...                              'type':'String'}]}) as up:
        ...     up.start()
        ...     up.upload(data[0:int(len(data)/2)])
        ...     up.upload(data[int(len(data)/2):])
        ...     up.source_object = up.finish()
        >>> src = connection.get_source(id=up.source_object.id)
        >>> connection.delete_source(id=src.id) #ignore-in-doc
        """

        return resumable_upload.ResumableUpload(self, filename, upload_spec=upload_spec,
                                                check_duplicate=check_duplicate,
                                                allow_duplicate=allow_duplicate,
                                                metadata=metadata,
                                                async_=async_)

    def check_platform_version(self):
        """Gets the version information from the Ayasdi platform
        and checks it against the SDK version

        Returns:
            Ayasdi platform version as a dictionary object

        :Example:

        >>> version = connection.check_platform_version()
        >>> 'Implementation-Version' in version
        True
        >>> 'Build-Number' in version
        True
        >>> print(version) # doctest: +SKIP
        {'Build-Number': '589',
         'Build-Time': '20170314021946',
         'Built-By': 'jenkins',
         'Built-JDK': '1.8.0_92',
         'Implementation-Title': 'ayasdi-platform-all-6.6.0-SNAPSHOT.jar',
         'Implementation-Version': '6.6.0-SNAPSHOT',
         'Manifest-Version': '1.0',
         'Revision': 'ca1b55a',
         'Source-Compatibility': '1.8',
         'Target-Compatibility': '1.8'}
        """
        platform_build = json_funcs._get_(self.session,
                                          self.CORE_REQUEST_STUB +
                                          'platform_build')
        version_re = re.compile(r'(\d+)\.(\d+)\.(\d+)(.*)')
        platform_version = platform_build.get('Implementation-Version', '')
        sdk_match = version_re.match(__version__)
        platform_match = \
            version_re.match(platform_version)

        if not sdk_match:
            raise ValueError("Couldn't parse SDK version")
        if not platform_match:
            raise ValueError("Couldn't parse Platform version")
        if sdk_match and platform_match and \
                sdk_match.group(1) == platform_match.group(1):
            sdk_minor = int(sdk_match.group(2))
            platform_minor = int(platform_match.group(2))
            if abs(sdk_minor - platform_minor) > 2:
                raise OSError(
                    "Your SDK version {} is more than two "
                    "minor releases from the platform version {}."
                    " Please upgrade."
                    .format(__version__, platform_version))
            elif sdk_minor != platform_minor:
                warnings.warn("Your SDK version {} doesn't match "
                              "the platform version {}."
                              " Please upgrade."
                              .format(__version__, platform_version))

        else:
            raise OSError(
                "Your SDK version {} is a different "
                "major release than the platform version {}. "
                "Please upgrade."
                .format(__version__, platform_version))

        return platform_build

    def validate_transformation_config(self, config_json_string):
        """Checks for the validity of a transformation config.

        Args:
            config_json_string (str) : The config JSON as a string

        Returns:
            A dict with an is_valid flag and error/warning messages (if any)
        """

        resp = self.session.post(
            self.CORE_REQUEST_STUB + 'transformations/check',
            data=config_json_string,
            headers={'Content-Type': 'application/json'})
        if resp.status_code == 200:
            return {'is_valid': True, 'message': resp.text}
        elif resp.status_code == 400:
            return {'is_valid': False, 'message': resp.text}
        else:
            resp.raise_for_status()

    def _check_file_uploaded(self, filename):
        all_sources = self.get_sources()
        sources_dict = {}
        matching_sources = []
        for each_source in all_sources:
            if each_source.name == filename:
                matching_sources.append(each_source)
            sources_dict[each_source.name] = each_source
        if filename in sources_dict.keys():
            return (True, matching_sources)
        else:
            return (False, None)

    def get_sources(self, name=None):
        """Get existing :class:`Source <ayasdi.core.source.Source>` objects from the Ayasdi Platform.

        Args:
            name (str): Search only for sources with this name (Exact name required).

        Returns:
            List of :class:`Source <ayasdi.core.source.Source>` objects

        :Example:

        >>> sources = connection.get_sources()
        >>> type(sources[0]) # doctest: +SKIP
        <class 'source.Source'>
        >>> #Getting source names
        >>> source_names = [s.name for s in sources]

        """
        sources_list = json_funcs._get_(self.session,
                                        self.CORE_REQUEST_STUB +
                                        'sources')
        if name:
            return [source.Source(self, i) for i in sources_list if i['name'] == name]
        return [source.Source(self, i) for i in sources_list]

    def get_source(self, id=None, name=None):
        """
        Get source by id or name.

        Args:
            id: The identifier of the requested source (optional with name).
            name: The name of the requested source (optional with id).

        Returns:
            :class:`Source <ayasdi.core.source.Source>` object[s] -  if multiples exist,
            then a list of sources.

        :Example:

        >>> #Example in upload_source function

        """
        # Refresh the sources
        # Find the relevant source
        multiple_sources = []
        if id is not None:
            src = source.Source(self, source_info={'id': id})
            src.sync()
            return src
        elif name is not None:
            sources = self.get_sources()
            for src in sources:
                if src.name == name:
                    src.sync()
                    multiple_sources.append(src)
        # Return only one source if possible.
        if not multiple_sources:
            raise IndexError("Can't find source '%s'" % name)
        elif len(multiple_sources) == 1:
            return multiple_sources[0]
        else:
            message = ("Multiple sources with the same name found. To retrieve a list of all sources " +
                       "with this name, use the get_sources() function and specify the name as a " +
                       "function argument. Warning: This will throw an error in future releases.")
            LOGGER.warning(message)
            print(message)
            return multiple_sources

    def delete_source(self, id=None, name=None, remove_model=True):
        """
        Deletes an existing source by name or id. If multiple sources exist with the same name,
        all of them are removed.

        Args:
            id (str) : id of the requested source (optional with name)
            name (str) : name of the requested source (optional with id)
            remove_model (boolean) : True if to remove models (optional)

        Returns:
            None

        :Example:

        See usage in :func:`source.get_networks <ayasdi.core.source.Source.get_networks>`

        """
        def delete_by_id(id_val, remove_model):
            """
            Deletes a single source by id.
            """
            remove_val = 'true' if remove_model else 'false'
            delete_info = {
                'remove_model': remove_val
            }
            json_funcs._delete_(self.session,
                                (self.CORE_REQUEST_STUB +
                                 'sources/%s' % id_val), delete_info)

        if id is not None:
            delete_by_id(id, remove_model)
        else:
            selected_source = self.get_source(id, name)
            # If muliple sources are found, delete them all
            if isinstance(selected_source, list):
                for src in selected_source:
                    delete_by_id(src.id, remove_model)
            else:
                delete_by_id(selected_source.id, remove_model)
        return None

    def get_user(self):
        """
        Get the current authenticated user and a number of characteristics of the user.
        The returned object contains the following variables:
           - applications - A list of applications that exist in the Ayasdi platform
           - rights - A list of applications that the user has access rights to.
           - email - Email address of the user. Typically synonymous with username
           - id - User id
           - isAuthenticated - Is the user currently authenticated.
           - primaryTeam - Details about the primary team that the user belongs to.
           - teams - All the teams that the user belongs to.

        Args:
          None

        Returns:
          User: An object of :class:`ayasdi.core.user.User`.

        :Example:

        >>> user = connection.get_user() # doctest: +SKIP
        >>> username = connection.session.cookies.get('username') # doctest: +SKIP
        >>> user_dict = user.json() # doctest: +SKIP
        >>> user_dict['email'] == int(username) # doctest: +SKIP
        True
        >>> first_team = user.teams[0] # doctest: +SKIP
        >>> user.set_active_team(id=first_team['id']) # doctest: +SKIP
        True
        >>> user.set_active_team(name=first_team['name']) # doctest: +SKIP
        True

        """
        user_json = json_funcs._get_(self.session,
                                     self.CORE_REQUEST_STUB +
                                     'users/self')
        return user.User(self, user_json)

    def get_models(self):
        """
        Get a list of accessible :class:`MLModel <ayasdi.core.models.legacy.MLModel>` objects.
        These objects are created by using :func:`import_pmml_model` or
        the `create` methods in :class:`MLModel <ayasdi.core.models.legacy.MLModel>` instances.

        Returns:
            A list of :class:`MLModel <ayasdi.core.models.legacy.MLModel>` objects.

        :Example:

        >>> connection.get_models() # doctest: +SKIP
        []

        """
        models_list = json_funcs._get_(self.session,
                                       self.CORE_REQUEST_STUB +
                                       'models')
        pmml_models_list = [models.MLModel(self, i, 'pmml') for i in
                            models_list['pmml_models']]
        topo_models_list = [models.MLModel(self, i, 'topological_group_models')
                            for i in models_list['topological_group_models']]
        return {'pmml_models': pmml_models_list,
                'topo_models': topo_models_list}

    def get_model(self, model_type=None, name=None):
        """
        Get :class:`MLModels <ayasdi.core.models.legacy.MLModel>` by name.

        Args:
            name: The name of the requested model.
            model_type: The type of the model ('pmml_model'
                        or 'topo_model')

        Returns:
            A list of :class:`MLModel <ayasdi.core.models.legacy.MLModel>` objects

        :Example:

        See :mod:`ayasdi.core.models` for details.

        """
        # Refresh the sources
        available_models = self.get_models()
        # model_curl = self.CORE_REQUEST_STUB + 'models'
        # Find the relevant source
        multiple_models = []
        if model_type is not None and name is not None:
            if model_type in ['pmml_model', 'topo_model']:
                for model in available_models[model_type + 's']:
                    if model.name == name:
                        model_obj = model
                        model_obj.sync()
                        multiple_models.append(model_obj)
        # Return only one model if possible.
        if not multiple_models:
            raise IndexError("Can't find model '%s'" % name)
        elif len(multiple_models) == 1:
            return multiple_models[0]
        else:
            print("Multiple models with the same name found!")
            return multiple_models

    def import_pmml_model(self, model_file, name, description=""):
        """
        Imports a pmml model file.

        Args:

            model_file (str): A pmml model xml file (Required).
            name (str): A name for the uploaded pmml model (Required).
            description (str): A description for this pmml model (Optional).

        Returns:

            An :class:`MLModel <ayasdi.core.models.legacy.MLModel>` object

        """
        model_str = open(model_file).read()
        return models.import_pmml_model(self, model_str, name=name,
                                        description=description)

    def get_jobs(self, all=False):
        """Get running asynchronous jobs.
           These jobs are generated by any function where async_ is set to True.

        Args:
            all (bool) : (Optional) If set to True, then all jobs you've started are
                returned. Shows only uncompleted jobs by default.

        Returns:
            A list of running jobs (:class:`ayasdi.core.jobs.Job` objects)

        >>> jobs = connection.get_jobs()
        >>> jobs # doctest: +SKIP
        []

        """
        jobs_list = json_funcs._get_(self.session,
                                     self.CORE_REQUEST_STUB +
                                     'jobs')
        if all:
            return [jobs.Job(self, i) for i in jobs_list]
        else:
            return [jobs.Job(self, i) for i in jobs_list
                    if i['status'].strip().lower() == "in_progress"]

    def get_transformations(self):
        """
        Returns a dictionary containing all the transformations available within the Ayasdi Platform.
        Additionally, the descriptions of these transormation functions are provided.

        The following format is used:
        ``{u"<transformer_function_name>" : u"<transformer_description>"}``

        .. Note:: Sample output

            .. code-block:: python

                {'datetime': 'Date[YYYYMMDD], Year Month[YYYYMM], Year[YYYY],
                              Month[MM], Day Of Month[DD], Day of Week[D], Weekend[W],
                              Second of Day[SSSS], Timezone[TT:TT], DT_Error[Text]',
                 'lag': u"f = value of variable in the previous row or \
                         'lagCount' rows before",
                 'lagdif': u"f = (value of the current variable - value of \
                           variable in the previous row or 'lagCount' rows before)",
                 'log': 'f = {x > 0: log(x) | x < 0: -log(-x) | x = 0: 0}',
                 'prepend': 'Add a prefix to a value',
                 'sqr': 'f = x ^ 2',
                 'transpose': 'Transpose columns and rows'}

        Returns:
            A Dict with function name and description of transformers

        """

        resp = json_funcs._get_(self.session,
                                self.CORE_REQUEST_STUB +
                                'transformations')
        return resp

    def set_timeout(self, get_timeout=None, post_timeout=None,
                    put_timeout=None, delete_timeout=None):
        """
        Sets timeouts for Ayasdi Platform API calls via the session to override the defaults.
        Used irregularly and only when the default timeout values
        are found to be insufficient.

        Args:

            get_timeout (int or float) : Sets the timeout value for all `get` calls.
            post_timeout (int or float) : Sets the timeout value for all `post` calls.
            put_timeout (int or float) : Sets the timeout value for all `put` calls.
            delete_timeout (int or float) : Sets the timeout value for all `delete` calls.

        Returns:

            None

        :Example:

        >>> connection.set_timeout(get_timeout=200, post_timeout=500)
        >>> print(connection.session.GET_TIMEOUT)
        200
        >>> print(connection.session.POST_TIMEOUT)
        500
        """
        if get_timeout:
            self.session.GET_TIMEOUT = get_timeout
        if post_timeout:
            self.session.POST_TIMEOUT = post_timeout
        if put_timeout:
            self.session.PUT_TIMEOUT = put_timeout
        if delete_timeout:
            self.session.DELETE_TIMEOUT = delete_timeout

    def get_last_traceid(self):
        """
        Returns the x-traceid header from the last request to the platform.

        :Example:

        >>> #Execute  an API call
        >>> j = connection.get_jobs()
        >>> #Verify trace id has been set
        >>> isinstance(connection.get_last_traceid(), str)
        True

        """
        return self.session.last_traceid

    def get_cookie_dict(self):
        """
        Returns a dict of cookie name-value pairs in the current session. Typically,
            this dictionary contains two keys - username, and AyasdiCookie

        Returns:
            A `dict` object containing all the cookie name-value pairs
        """
        return self.session.cookies.get_dict()

    def get_cookie_domains(self):
        """
        List all the cookie domains in the session (['.ayasdi.com'])

        Returns:
            A `list` of all cookie-domains as strings.
        """

        return self.session.cookies.list_domains()

    def register_model(self, model):
        """
        Register model for on-demand prediction service. Only user with 'org_admin' and 'user' roles can perform this
        operation.

        Args:
          model: decision tree model

        Returns:
          server_uri: server uri

        :Example:
        >>> from ayasdi.core.prediction_service import PredictionService
        >>> source = connection.upload_source("./test/decision_tree_test.csv")
        >>> source.sync()

        >>> # decision tree
        >>> dt = models.DecisionTree.create(connection, source.id, name='model_1', outcome_column_index=12)
        >>> #service_url = connection.register_model(dt)
        >>> #ps = PredictionService(connection, service_url, return_type='predict_decisions')
        >>> #rowV = [1, 0.81, 80, 450, 80, 55]
        >>> #prediction = ps.predict(rowV)
        >>> #connection.unregister_model(dt)
        """
        if model is None:
            raise ValueError("Invalid model")
        url = self.CORE_REQUEST_STUB + 'models/' + model.model_id + '/register_model'
        res = json_funcs._post_(self.session, url, data=None, params=None)
        if res is None or res['url'] is None:
            raise ValueError("Unable to register model")
        service_url = res['url']
        return service_url

    def unregister_model(self, model):
        """
        Un-register model for on-demand prediction service. Only user with 'org_admin' and 'user' roles can perform this
        operation.

        Args:
          model: decision tree model

        Returns:
          None

        :Example:
        >>> from ayasdi.core.prediction_service import PredictionService
        >>> source = connection.upload_source("./test/decision_tree_test.csv")
        >>> source.sync()

        >>> # decision tree
        >>> dt = models.DecisionTree.create(connection, source.id, name='model_1', outcome_column_index=12)
        >>> #service_url = connection.register_model(dt)
        >>> #ps = PredictionService(connection, service_url, return_type='predict_decisions')
        >>> #rowV = [1, 0.81, 80, 450, 80, 55]
        >>> #prediction = ps.predict(rowV)
        >>> #connection.unregister_model(dt)
        """
        if model is None:
            raise ValueError("Invalid model")
        url = self.CORE_REQUEST_STUB + 'models/' + model.model_id + '/unregister_model'
        json_funcs._post_(self.session, url, data=None, params=None)
        return None

    def get_model_status(self):
        """
        Get model status for current user's org. Specifically the active prediction service count
            'prediction_service_count'.

        Args:
          None

        Returns:
          json containing 'prediction_service_count'

        :Example:
        >>> res = connection.get_model_status()
        """
        url = self.CORE_REQUEST_STUB + 'models/status'
        res = json_funcs._get_(self.session, url)
        return res

    def terminate_job(self, trace_id):
        """
        Kill jobs started by the user

        Args:
          trace_id: The trace ID of the jobs

        Returns:
          None

        :Example:
        >>> import ayasdi.core as ac
        >>> import time
        >>>
        >>> source = connection.upload_source("./test/db_test12.txt", check_duplicate=False)
        >>> group1 = source.create_group(name="test_group1",
        ...                              row_indices=list(range(50)))
        >>> group2 = source.create_group(name="test_group2",
        ...                              row_indices=list(range(25, 75)))
        >>> # callback functions
        >>> import json
        >>> msg_count = 0
        >>> def on_message(job, event_dict):
        ...     global msg_count
        ...     msg_count += 1
        >>> def on_error(job, error_msg):
        ...     print (error_msg)
        >>> # Async version below
        >>> compare_job = source.compare_groups("test_group1", "test_group2",
        ...                                     comparison_type='continuous_only',
        ...                                     async_=True)
        >>> time.sleep(2)
        >>> connection.terminate_job(compare_job.trace_id)
        """
        warnings.warn(message_funcs._show_labs())
        url = self.CORE_REQUEST_STUB + "worker/" + str(trace_id)
        json_funcs._delete_(self.session, url)
