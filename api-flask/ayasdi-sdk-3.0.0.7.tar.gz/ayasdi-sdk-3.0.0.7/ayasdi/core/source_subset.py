#!/usr/bin/env python
"""

Class :class:`SourceSubset` defines a subset of data.

.. code:: python

    import ayasdi.core as ac

.. autosummary::

  SourceSubset
  SourceSubset.column_set_id
  SourceSubset.group_id
  SourceSubset.serialize()
  SourceSubset.source_id
"""
from ayasdi.core.data_spec import DataSpec


class SourceSubset(DataSpec):
    def __init__(self, source_id=None, column_set_id=None, group_id=None):
        self._source_id = source_id
        self._column_set_id = column_set_id
        self._group_id = group_id

    @property
    def source_id(self):
        """
        Identifier of a source.
        """
        return self._source_id

    @source_id.setter
    def source_id(self, val):
        self._source_id = val

    @property
    def column_set_id(self):
        """
        Identifier of a column set. A column set represents a collection of columns in the source.
        """
        return self._column_set_id

    @column_set_id.setter
    def column_set_id(self, val):
        self._column_set_id = val

    @property
    def group_id(self):
        """
        Identifier of a group within the source. A group represents a collection of rows in the source.
        """
        return self._group_id

    @group_id.setter
    def group_id(self, val):
        self._group_id = val

    def serialize(self):
        """
        Converts the instance to a dictionary
        """
        dictionary = {
            'source_id': self.source_id,
            'column_set_id': self.column_set_id,
            'group_id': self.group_id,
        }
        return {'source_subset': dictionary}
