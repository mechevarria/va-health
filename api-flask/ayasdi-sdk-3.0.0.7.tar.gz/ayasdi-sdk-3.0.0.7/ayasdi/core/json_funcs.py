from __future__ import absolute_import, unicode_literals, division, print_function
import json
import logging

from requests.exceptions import RequestException

LOGGER = logging.getLogger(__name__)

# list of HTTP response codes that will be used to also print the JSON of the request
# Audited from platform/worker/source/main/java/com/ayasdi/api/ApiErrors.java
# Show error message of response 400 (Bad Request), 401 (Unauthorized), 403 (Forbidden),
# 404 (Not Found), 409 (Conflict), 500 (Internal Server Error)
JSON_ERROR_CODES = [400, 401, 403, 404, 409, 500, 502, 503]


def _log_error(resp):
    '''Internal function to centralize error reporting and logic.
    '''
    error_message = "Error Response: {}".format(resp)

    if resp.status_code in JSON_ERROR_CODES:
        error_message += " JSON: {}".format(resp.text)

    LOGGER.exception(error_message)
    print(error_message)


def _post_(session, url, data, content_type=None, params=None):
    '''Function to post to given url.
    '''
    if not content_type:
        data = json.dumps(data)
        content_type = 'application/json'
    headers = {'content-type': content_type,
               'accept': 'application/json'}
    if session.trace_id is not None:
        headers['x-traceid'] = session.trace_id
    resp = session.post(url, data=data,
                        headers=headers,
                        params=params)
    try:
        resp.raise_for_status()
    except RequestException:
        _log_error(resp)
        raise
    if 'application/json' in resp.headers.get('content-type', {}):
        return resp.json()
    LOGGER.debug("Response is not JSON: {}".format(resp.text))
    return resp.text


def _iter_post_(session, url, data, content_type=None, params=None):
    '''Function to post to given url.
       Returns a generator
    '''
    if not content_type:
        data = json.dumps(data)
        content_type = 'application/json'
    headers = {'content-type': content_type,
               'accept': 'application/json'}
    if session.trace_id is not None:
        headers['x-traceid'] = session.trace_id
    resp = session.post(url, data=data,
                        headers=headers,
                        params=params,
                        stream=True)
    try:
        resp.raise_for_status()
    except RequestException:
        _log_error(resp)
        raise
    if resp.encoding is None:
        resp.encoding = 'utf-8'
    if 'application/json' in resp.headers.get('content-type', {}):
        for item in resp.iter_lines(decode_unicode=True):
            if item:
                json_item = json.loads(item)
                yield json_item
    else:
        LOGGER.debug("Response is not JSON: {}".format(resp.text))


def _put_(session, url, data, content_type=None, params=None):
    '''Function to post to given url.
    '''
    if not content_type:
        data = json.dumps(data)
        content_type = 'application/json'
    headers = {'content-type': content_type,
               'accept': 'application/json'}
    if session.trace_id is not None:
        headers['x-traceid'] = session.trace_id
    resp = session.put(url,
                       data=data,
                       headers=headers,
                       params=params)
    try:
        resp.raise_for_status()
    except RequestException:
        _log_error(resp)
        raise
    if 'application/json' in resp.headers.get('content-type', {}):
        return resp.json()
    return resp.text


def _get_(session, url, params=None):
    '''Function to get from given url.
    '''
    headers = {'accept': 'application/json'}
    if session.trace_id is not None:
        headers['x-traceid'] = session.trace_id
    resp = session.get(url,
                       headers=headers,
                       params=params)
    try:
        resp.raise_for_status()
    except RequestException:
        _log_error(resp)
        raise
    # Hack since outcome_auto_analysis returns this
    # when the process completes.
    # TODO:Remove the next couple of lines when that
    # is fixed.
    if resp.status_code in [303, 204]:
        return json.loads("{}")
    if 'application/json' in resp.headers.get('content-type', {}):
        return resp.json()
    LOGGER.debug("Response is not JSON: {}".format(resp.text))
    return resp.text


def _get_octet_(session, url, params=None):
    '''Function to get octet-stream from given url.
    '''
    headers = {'accept': 'application/octet-stream'}
    if session.trace_id is not None:
        headers['x-traceid'] = session.trace_id
    resp = session.get(url,
                       headers=headers,
                       params=params)
    try:
        resp.raise_for_status()
    except RequestException:
        _log_error(resp)
        raise
    # Hack since outcome_auto_analysis returns this
    # when the process completes.
    # TODO:Remove the next couple of lines when that
    # is fixed.
    if resp.status_code in [303, 204]:
        return json.loads("{}")
    if 'application/json' in resp.headers.get('content-type', {}):
        return resp.json()
    return resp


def _iter_get_(session, url, params=None):
    '''
    Function to get from given url.
    Returns a generator
    '''
    headers = {'accept': 'application/json'}
    if session.trace_id is not None:
        headers['x-traceid'] = session.trace_id
    resp = session.get(url,
                       headers=headers,
                       params=params)
    try:
        resp.raise_for_status()
    except Exception:
        _log_error(resp)
        raise

    if resp.encoding is None:
        resp.encoding = 'utf-8'
    if 'application/json' in resp.headers.get('content-type', {}):
        for item in resp.iter_lines(decode_unicode=True):
            if item:
                json_item = json.loads(item)
                yield json_item
    else:
        LOGGER.debug("Response is not JSON: {}".format(resp.text))


def _delete_(session, url, params=None, content_type=None, data=None):
    '''Function to delete at the given url endpoint.
    '''
    if data and not content_type:
        data = json.dumps(data)
        content_type = 'application/json'
    headers = {'content-type': content_type,
               'accept': 'application/json'}
    if session.trace_id is not None:
        headers['x-traceid'] = session.trace_id
    resp = session.delete(url,
                          data=data,
                          headers=headers,
                          params=params)
    try:
        resp.raise_for_status()
    except RequestException:
        _log_error(resp)
        raise
    return True
