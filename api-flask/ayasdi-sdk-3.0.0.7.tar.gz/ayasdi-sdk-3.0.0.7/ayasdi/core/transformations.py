#!/usr/bin/env python

"""
    Transformations are generally applied by the creation of TransformationStep objects. Each specific
    TransformationStep inherits from a base TransformationStep class.

    Depending on the type of transformation, TransformationStep objects can either be **physical** (values
    stored on disk) or **virtual** (calculated only when needed; the actual values are not stored on disk).

    For a general discussion of Ayasdi Transformation Services and TransformationSteps, see :doc:`transformationsdoc`.

    One or more transformations can be configured and stored as a
    :class:`ayasdi.core.transformations.TransformationConfiguration` object.

    **Available functions in the Transformations Module include:**

        .. autosummary::

           AppendLensValuesTransformationStep
           BinarizeTransformationStep
           BucketizerTransformationStep
           CategoryCountTransformationStep
           CentroidDistanceTransformationStep
           CountVectorTFIDFTransformationStep
           CsvVectorParseTransformationStep
           DateTimeTransformationStep
           DTLagTransformationStep
           ExpressionTransformationStep
           FrequencyRankEncodingTransformationStep
           GroupByTransformationStep
           JoinTransformationStep
           LagDifferenceTransformationStep
           LagTransformationStep
           LogarithmTransformationStep
           LinearFitTransformationStep
           MinMaxScalingTransformationStep
           MismatchTransformationStep
           MultiColumnTransformationStep
           NullImputationTransformationStep
           OneHotEncodeTransformationStep
           OperatorTransformationStep
           OrderByTransformationStep
           PCATransformationStep
           PivotTransformationStep
           PointwiseDistanceTransformationStep
           PrependTransformationStep
           RevertSequenceTransformationStep
           SequenceGroupByTransformationStep
           SequenceSplitEncodeTransformationStep
           SliceTransformationStep
           SquareTransformationStep
           StandardScalingTransformationStep
           StringSplitTransformationStep
           SymmetricLogarithmTransformationStep
           TextFeatureExtractionTransformationStep
           TimeSeriesAggregationTransformationStep
           TransformationConfiguration
           TransformationConfiguration.apply
           TransformationConfiguration.validate
           TransposeTransformationStep
           UnionTransformationStep
"""

from __future__ import absolute_import, unicode_literals, division, print_function
from ayasdi.core import json_funcs
import ayasdi.core.source
import json
import warnings


class TransformationConfiguration(object):
    """
    Creates a new TransformationConfiguration.

    Args:
        connection (api) : Ayasdi Core API object
        description (str) : describes the configuration
        steps (one or more step arguments) : list of TransformationStep objects

    Returns:
        TransformationConfiguration object

    The following example creates a TransformationConfiguration object with two chained transformation steps.

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create two transformation steps
    >>> lag_transform_step = ac.LagTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose',
    ...     new_column_name='blood glucose lag',
    ...     lag_count=2)
    >>> sqr_transform_step = ac.SquareTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose lag',
    ...     new_column_name='blood glucose lag squared',
    ...     virtual=True)
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     lag_transform_step,
    ...     sqr_transform_step
    ...     )
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'blood glucose lag'
    >>> new_source.column_names[8]
    'blood glucose lag squared'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    """

    def __init__(self, connection, description, *steps):
        """
        Do not call this method directly. Instead, call TransformationConfiguration.create(connection,
        description, steps).
        """

        self.connection = connection
        self.description = description
        self.train_source_id = None
        self.steps = steps  # list of steps

    @classmethod
    def create(cls,
               connection,
               description,
               *steps):
        """
        Creates a new TransformationConfiguration.

        Args:
            connection (api) : Ayasdi Core API object
            description (str) : ddescribes this configuration
            steps (one or more step arguments) :

        Returns:
            TransformationConfiguration object

        """
        instance = cls(connection, description, *steps)
        instance.validate()
        return instance

    def validate(self):
        """
        Validate a TransformationConfiguration on the server.

        Args:
            None

        Returns:
            If validation fails, raises an HTTPError; otherwise, returns True.
        """
        data = self._serialize()
        url = "{}{}/{}".format(self.connection.CORE_REQUEST_STUB,
                               "transformations",
                               "validate")
        json_funcs._post_(self.connection.session,
                          url,
                          data=data)
        # Return True if the above doesn't raise an HTTP exception
        return True

    def apply(self, source_id, new_source_name):
        """
        Apply the transformation steps on the specified source.

        Args:
            source_id (str) : The identifier for a Source object
            new_source_name (str) : The name for the new source to be created. If set to None or blank (''), attempts
                to apply these transforms onto the existing source without creating a new source. Virtual
                transformations and some physical transformations which only append columns can be applied to an
                existing source and do not require a new_source_name.

        Returns:
            If successful, a New Source object; if new_source_name was None, returns the
            existing source. If there is an issue with creating a new object (such as a
            conflicting new_source_name), raises an HTTPError.

        """

        data = {"source_id": source_id,
                "new_source_name": new_source_name,
                "description": self.description,
                "steps": self._serialize_steps()}
        url = "{}{}/{}".format(self.connection.CORE_REQUEST_STUB,
                               "transformations",
                               "apply_transform")
        result = json_funcs._post_(self.connection.session,
                                   url,
                                   data=data)
        new_source = ayasdi.core.source.Source(self.connection, result)
        return new_source

    def _serialize(self):
        data = {"description": self.description,
                "steps": self._serialize_steps()}
        if self.train_source_id is not None:
            data['train_source_id'] = self.train_source_id
        return data

    def _serialize_steps(self):
        step_data = [s._serialize() for s in self.steps]
        return step_data

    def _deserialize(self, config):
        description = config.get('description')
        train_source_id = config.get('train_source_id')
        transform_step = TransformationStep("")

        steps_tuple = ()
        for step_config in config['steps']:
            step = transform_step.deserialize(step_config)
            steps_tuple += (step,)

        transformConfig = TransformationConfiguration.create(self.connection, description, *steps_tuple)
        transformConfig.train_source_id = train_source_id
        return transformConfig


class TransformationStep(object):
    """
    Abstract base class for a transformation step.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform. (optional with column_index)
        column_index (int): specifies the index of the column to transform. (optional with column_name)
        virtual (bool): defines whether the column is **physical** (values stored on disk) or **virtual** (calculated
            only when needed; the actual values are not stored on disk).

    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 function=None,
                 virtual=False):
        self.function = function
        if virtual is True:
            self.function = "{}_v".format(self.function)
        self.description = description
        self.column_name = column_name
        self.column_index = column_index
        self.new_column_name = new_column_name

    def _serialize(self):
        columns = []
        entry = {}
        if self.column_name is not None:
            entry['name'] = self.column_name
        if self.column_index is not None:
            entry['index'] = self.column_index
        columns.append(entry)

        data = {'function': self.function,
                'description': self.description,
                'columns': columns,
                'new_column_name': self.new_column_name,
                }
        return data

    def deserialize(self, step_json):
        description = step_json.get('description')

        # column index, then name
        column_name = None
        column_index = None
        if 'columns' in step_json:
            columns = step_json['columns']
            if len(columns) > 0 and 'name' in columns[0]:
                column_name = columns[0]['name']
            if len(columns) > 0 and 'index' in columns[0]:
                column_index = columns[0]['index']

        new_column_name = step_json.get('new_column_name')

        virtual = False
        if step_json['function'].endswith("_v"):
            virtual = True

        if step_json['function'] == 'sqr' or step_json['function'] == 'sqr_v':
            column_names = step_json.get('column_names')
            column_indices = step_json.get('column_indices')

            sqr_transform_step = SquareTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                column_names=column_names,
                column_indices=column_indices,
                virtual=virtual)
            return sqr_transform_step

        elif step_json['function'] == 'log' or step_json['function'] == 'log_v':
            base = step_json.get('base', 2)
            column_names = step_json.get('column_names')
            column_indices = step_json.get('column_indices')

            log_transform_step = LogarithmTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                base=base,
                column_names=column_names,
                column_indices=column_indices,
                virtual=virtual)
            return log_transform_step

        elif step_json['function'] == 'symmetric_log_v':
            base = step_json.get('base', 2)
            column_names = step_json.get('column_names')
            column_indices = step_json.get('column_indices')

            log_transform_step = SymmetricLogarithmTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                base=base,
                column_names=column_names,
                column_indices=column_indices)
            return log_transform_step

        elif step_json['function'] == 'lag':
            lag_count = step_json.get('lag_count')

            lag_transform_step = LagTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                lag_count=lag_count)
            return lag_transform_step

        elif step_json['function'] == 'lagdif':
            lag_count = step_json.get('lag_count')

            lagdif_transform_step = LagDifferenceTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                lag_count=lag_count)
            return lagdif_transform_step

        elif step_json['function'] == 'datetime' or step_json['function'] == 'datetime_v':
            format = step_json.get('format')

            datetime_transform_step = DateTimeTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                format=format,
                virtual=virtual)
            return datetime_transform_step

        elif step_json['function'] == 'prepend' or step_json['function'] == 'prepend_v':
            prefix = step_json.get('prefix')
            column_names = step_json.get('column_names')
            column_indices = step_json.get('column_indices')

            prepend_transform_step = PrependTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                prefix=prefix,
                column_names=column_names,
                column_indices=column_indices,
                virtual=virtual)
            return prepend_transform_step

        elif step_json['function'] == 'transpose' or step_json['function'] == 'transpose_v':
            column_set_id = step_json.get('column_set_id')
            group_id = step_json.get('group_id')
            use_headers = step_json.get('use_headers')

            transpose_transform_step = TransposeTransformationStep(
                description=description,
                column_set_id=column_set_id,
                group_id=group_id,
                use_headers=use_headers)

            return transpose_transform_step

        elif (step_json['function'] == 'text_log_likelihood' or
              step_json['function'] == 'text_log_likelihood_v' or
              step_json['function'] == 'text_feature_extraction' or
              step_json['function'] == 'text_feature_extraction_v'):

            args_dict = {}
            algorithm = step_json.get('algorithm')
            if step_json['function'].startswith('text_log_'):
                algorithm = 'log_likelihood'

            if 'max_columns' in step_json:
                max_columns = step_json['max_columns']
                args_dict['max_columns'] = max_columns

            if 'max_ngram_length' in step_json:
                max_ngram_length = step_json['max_ngram_length']
                args_dict['max_ngram_length'] = max_ngram_length

            if 'use_stemmer' in step_json:
                use_stemmer = True
                if step_json['use_stemmer'] == 'false':
                    use_stemmer = False
                args_dict['use_stemmer'] = use_stemmer

            if 'use_tfidf' in step_json:
                use_tfidf = True
                if step_json['use_tfidf'] == 'false':
                    use_tfidf = False
                args_dict['use_tfidf'] = use_tfidf

            if 'allowed_ngram_length_list' in step_json:
                allowed_ngram_length_list = step_json['allowed_ngram_length_list']
                args_dict['allowed_ngram_length_list'] = allowed_ngram_length_list

            if 'use_stop_words' in step_json:
                use_stop_words = False
                if step_json['use_stop_words'] == 'true':
                    use_stop_words = True
                args_dict['use_stop_words'] = use_stop_words

            if 'max_skips' in step_json:
                max_skips = step_json['max_skips']
                args_dict['max_skips'] = max_skips

            if 'stopword_knee_ratio' in step_json:
                stop_word_knee_ratio = step_json['stopword_knee_ratio']
                args_dict['stop_word_knee_ratio'] = stop_word_knee_ratio

            if 'stopword_min_cutoff' in step_json:
                stop_word_min_cutoff = step_json['stopword_min_cutoff']
                args_dict['stop_word_min_cutoff'] = stop_word_min_cutoff

            if 'stop_word_list' in step_json:
                stop_word_list = step_json['stop_word_list']
                args_dict['stop_word_list'] = stop_word_list

            if 'start_word_list' in step_json:
                start_word_list = step_json['start_word_list']
                args_dict['start_word_list'] = start_word_list

            exported_config_data = step_json.get('exported_config_data')
            exported_column_info = step_json.get('exported_column_info')

            if exported_config_data is not None:
                args_dict['exported_config_data'] = exported_config_data

            if exported_column_info is not None:
                args_dict['exported_column_info'] = exported_column_info

            args_dict['virtual'] = virtual

            text_feature_extraction_transform_step = TextFeatureExtractionTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                algorithm=algorithm,
                **args_dict)

            return text_feature_extraction_transform_step

        elif step_json['function'] == 'groupby':
            group_by_columns = []
            if 'group_by_column_name_list' in step_json:
                group_by_columns = step_json['group_by_column_name_list']

            aggregate_functions = []
            if 'column_aggregation_function_list' in step_json:
                aggregate_functions = step_json['column_aggregation_function_list']

            groupby_transform_step = GroupByTransformationStep(
                description=description,
                group_by_columns=group_by_columns,
                aggregate_functions=aggregate_functions)
            return groupby_transform_step

        elif step_json['function'] == 'onehotencode':
            max_columns = step_json.get('max_columns')

            add_others_column = True
            if 'add_others_column' in step_json and step_json['add_others_column'] == 'false':
                add_others_column = False

            add_nulls_column = False
            if 'add_nulls_column' in step_json and step_json['add_nulls_column'] == 'true':
                add_nulls_column = True

            exported_config_data = step_json.get('exported_config_data')
            exported_column_info = step_json.get('exported_column_info')

            onehotencode_transform_step = OneHotEncodeTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                max_columns=max_columns,
                exported_config_data=exported_config_data,
                exported_column_info=exported_column_info,
                add_others_column=add_others_column,
                add_nulls_column=add_nulls_column)
            return onehotencode_transform_step

        elif step_json['function'] == 'null imputation':
            stat_function_replacement = None
            user_defined_replacement = None
            if 'replacement_params' in step_json:
                replace_param = step_json['replacement_params']
                if 'stat_function_replacement' in replace_param:
                    stat_function_replacement = replace_param['stat_function_replacement']

                if 'user_defined_replacement' in replace_param:
                    user_defined_replacement = replace_param['user_defined_replacement']

            exported_config_data = step_json.get('exported_config_data')
            exported_column_info = step_json.get('exported_column_info')

            column_names = step_json.get('column_names')
            column_indices = step_json.get('column_indices')

            nullimpute_transform_step = NullImputationTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                exported_config_data=exported_config_data,
                exported_column_info=exported_column_info,
                stat_function_replacement=stat_function_replacement,
                user_defined_replacement=user_defined_replacement,
                column_names=column_names,
                column_indices=column_indices,
            )
            return nullimpute_transform_step

        elif step_json['function'] == 'standard_scaling_v':
            with_std = False
            if step_json['with_std']:
                with_std = True

            with_mean = False
            if step_json['with_mean']:
                with_mean = True

            exported_config_data = step_json.get('exported_config_data')
            exported_column_info = step_json.get('exported_column_info')

            column_names = step_json.get('column_names')
            column_indices = step_json.get('column_indices')

            scaling_transform_step = StandardScalingTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                exported_config_data=exported_config_data,
                exported_column_info=exported_column_info,
                with_std=with_std,
                with_mean=with_mean,
                column_names=column_names,
                column_indices=column_indices,
                virtual=virtual)
            return scaling_transform_step

        elif step_json['function'] == 'union':
            secondary_sources = step_json.get('secondary_sources')

            union_transform_step = UnionTransformationStep(
                description=description,
                secondary_sources=secondary_sources,
                primary_column_map=None)
            return union_transform_step

        elif step_json['function'] == 'pivot':
            primary_columns = step_json.get('primary_columns')
            pivot_column = step_json.get('pivot_column')
            value_column = step_json.get('value_column')
            aggregation_function = step_json.get('aggregation_function')
            fill_value = step_json.get('fill_value')
            pivot_transform_step = PivotTransformationStep(
                description=description,
                primary_columns=primary_columns,
                pivot_column=pivot_column,
                value_column=value_column,
                aggregation_function=aggregation_function,
                fill_value=fill_value)
            return pivot_transform_step

        elif step_json['function'] == 'operator' or step_json['function'] == 'operator_v':
            functions = step_json.get('functions', [])

            operator_transform_step = OperatorTransformationStep(
                description=description,
                functions=functions,
                virtual=virtual)
            return operator_transform_step

        elif step_json['function'] == 'join':
            primary_source_key = None
            if 'primary_source_key' in step_json:
                primary_source_key = step_json['primary_source_key']

            secondary_sources = []
            if 'secondary_sources' in step_json:
                secondary_sources = step_json['secondary_sources']

            join_type = None
            if 'join_type' in step_json:
                join_type = step_json['join_type']

            join_transform_step = JoinTransformationStep(
                description=description,
                primary_source_key=primary_source_key,
                secondary_sources=secondary_sources,
                join_type=join_type)
            return join_transform_step

        elif step_json['function'] == 'binarize' or step_json['function'] == 'binarize_v':
            threshold = step_json.get('threshold', 0)
            column_names = step_json.get('column_names')
            column_indices = step_json.get('column_indices')

            binarize_transform_step = BinarizeTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                threshold=threshold,
                column_names=column_names,
                column_indices=column_indices,
                virtual=virtual)
            return binarize_transform_step

        elif step_json['function'] == 'pca':
            input_column_names = step_json.get('input_columns')
            pca_column_prefix = step_json.get('pca_column_prefix')
            n_components = step_json.get('n_components')

            exported_config_data = step_json.get('exported_config_data')
            exported_column_info = step_json.get('exported_column_info')
            pca_transformation_step = PCATransformationStep(
                description=description,
                input_column_names=input_column_names,
                pca_column_prefix=pca_column_prefix,
                n_components=n_components,
                exported_config_data=exported_config_data,
                exported_column_info=exported_column_info)
            return pca_transformation_step

        elif step_json['function'] == 'time_series_aggregation':
            time_step = step_json['time_step']
            time_stamp_column = step_json['time_stamp_column']
            match_column = step_json['match_column']

            exclude_current_value = step_json['exclude_current_value']

            aggregate_functions = []
            if 'column_aggregation_function_list' in step_json:
                aggregate_functions = step_json['column_aggregation_function_list']

            if 'filter_set' in step_json:
                filter_set = step_json['filter_set']

            if (aggregate_functions is not None and
                    len(aggregate_functions) == 1 and
                    len(aggregate_functions[0]['functions']) == 1 and
                    aggregate_functions[0]['functions']['name'] == 'category_count'):
                # count category transformation
                function = aggregate_functions[0]
                category_count_step = CategoryCountTransformationStep(
                    description=description,
                    time_step=time_step,
                    time_stamp_column=time_stamp_column,
                    category_column=function['column'],
                    prefix=function['functions'][0]['new_column_name'],
                    filter_set=filter_set)
                return category_count_step
            else:
                # other time series aggregation transformation
                ts_aggregation_transform_step = TimeSeriesAggregationTransformationStep(
                    description=description,
                    time_step=time_step,
                    time_stamp_column=time_stamp_column,
                    match_column=match_column,
                    aggregate_functions=aggregate_functions,
                    filter_set=filter_set,
                    exclude_current_value=exclude_current_value)
                return ts_aggregation_transform_step

        elif step_json['function'] == 'sequence_group_by':
            new_column_name = step_json['new_column_name']
            primary_columns = step_json['primary_columns']
            order_by_column = step_json['order_by_column']
            sequence_columns = step_json['sequence_columns']
            normalize_column = step_json['normalize_column']
            normalize_value = step_json['normalize_value']
            resolution_strategy = step_json['resolution_strategy']

            sequence_groupby_step = SequenceGroupByTransformationStep(
                description=description,
                new_column_name=new_column_name,
                primary_columns=primary_columns,
                order_by_column=order_by_column,
                sequence_columns=sequence_columns,
                normalize_column=normalize_column,
                normalize_value=normalize_value,
                resolution_strategy=resolution_strategy)
            return sequence_groupby_step

        elif step_json['function'] == 'mismatch':
            new_column_name = step_json['new_column_name']
            primary_column_name = step_json['primary_column_name']
            secondary_column_name = step_json['secondary_column_name']

            mismatch_step = MismatchTransformationStep(
                description=description,
                primary_column_name=primary_column_name,
                secondary_column_name=secondary_column_name,
                new_column_name=new_column_name)
            return mismatch_step

        elif step_json['function'] == 'minmax_scaling_v':
            feature_range = (0, 1)
            if step_json['feature_range']:
                feature_range = step_json['feature_range']
            column_names = step_json.get('column_names')
            column_indices = step_json.get('column_indices')

            scaling_transform_step = MinMaxScalingTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                feature_range=feature_range,
                column_names=column_names,
                column_indices=column_indices,
                virtual=True)
            return scaling_transform_step

        elif step_json['function'] == 'bucketizer_v' or step_json['function'] == 'bucketizer':
            splits = None
            if step_json['splits']:
                splits = step_json['splits']

            bucketizer_transform_step = BucketizerTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                splits=splits,
                virtual=virtual)
            return bucketizer_transform_step

        elif step_json['function'] == 'frequency_ranking':
            strategy = 'DENSE'
            if step_json['strategy']:
                strategy = step_json['strategy']
            max_labels = 50
            if step_json['max_labels']:
                max_labels = step_json['max_labels']
            ignore_nulls = True
            if step_json['ignore_nulls'] is None:
                ignore_nulls = False

            exported_config_data = step_json.get('exported_config_data')
            exported_column_info = step_json.get('exported_column_info')

            freqrank_transform_step = FrequencyRankEncodingTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                strategy=strategy,
                max_labels=max_labels,
                ignore_nulls=ignore_nulls,
                exported_config_data=exported_config_data,
                exported_column_info=exported_column_info)
            return freqrank_transform_step

        elif step_json['function'] == 'multicolumn_v':
            function_name = step_json['function_name']
            column_names = None
            if step_json['column_names']:
                column_names = step_json['column_names']
            column_indices = None
            if step_json['column_indices']:
                column_indices = step_json['column_indices']

            multicolumn_transform_step = MultiColumnTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                function_name=function_name,
                column_names=column_names,
                column_indices=column_indices)
            return multicolumn_transform_step

        elif step_json['function'] == 'centroid_distance' or step_json['function'] == 'centroid_distance_v':
            network_id = step_json.get('network_id')
            groupset_id = step_json.get('groupset_id')
            prefix = step_json.get('prefix')
            exported_config_data = step_json.get('exported_config_data')
            exported_column_info = step_json.get('exported_column_info')

            centroid_transform_step = CentroidDistanceTransformationStep(
                description=description,
                network_id=network_id,
                groupset_id=groupset_id,
                prefix=prefix,
                exported_config_data=exported_config_data,
                exported_column_info=exported_column_info)
            return centroid_transform_step

        elif step_json['function'] == 'count_vector_tfidf' or step_json['function'] == 'count_vector_tfidf_v':
            norm = step_json.get('norm')
            column_set_id = step_json.get('column_set_id')
            prefix = step_json.get('prefix')
            smooth_idf = step_json.get('smooth_idf')
            sublinear_tf = step_json.get('sublinear_tf')
            idf_list = step_json.get('idf_list')
            exported_config_data = step_json.get('exported_config_data')
            exported_column_info = step_json.get('exported_column_info')

            count_tfidf_transform_step = CountVectorTFIDFTransformationStep(
                description=description,
                norm=norm,
                column_set_id=column_set_id,
                prefix=prefix,
                smooth_idf=smooth_idf,
                sublinear_tf=sublinear_tf,
                idf_list=idf_list,
                exported_config_data=exported_config_data,
                exported_column_info=exported_column_info)
            return count_tfidf_transform_step

        elif step_json['function'] == 'pointwise_distance':
            group_id = step_json.get('group_id')
            column_set_id = step_json.get('column_set_id')
            prefix = step_json.get('prefix')
            metric = step_json.get('metric')
            exported_config_data = step_json.get('exported_config_data')
            exported_column_info = step_json.get('exported_column_info')

            pointwise_transform_step = PointwiseDistanceTransformationStep(
                description=description,
                group_id=group_id,
                column_set_id=column_set_id,
                prefix=prefix,
                metric=metric,
                exported_config_data=exported_config_data,
                exported_column_info=exported_column_info)
            return pointwise_transform_step

        elif step_json['function'] == 'lens_values':
            new_column_names = step_json.get('new_column_names')
            column_set_id = step_json.get('column_set_id')
            lens_params = step_json.get('lens_params')
            exported_config_data = step_json.get('exported_config_data')
            exported_column_info = step_json.get('exported_column_info')

            appendlens_transform_step = AppendLensValuesTransformationStep(
                description=description,
                new_column_names=new_column_names,
                column_set_id=column_set_id,
                lens_params=lens_params,
                exported_config_data=exported_config_data,
                exported_column_info=exported_column_info)
            return appendlens_transform_step

        elif step_json['function'] == 'string_split':
            prefix = step_json.get('prefix')
            pattern = step_json.get('pattern')
            separator = step_json.get('separator')
            substring = step_json.get('substring')
            exported_config_data = step_json.get('exported_config_data')
            exported_column_info = step_json.get('exported_column_info')

            ss_transform_step = StringSplitTransformationStep(
                description=description,
                column_name=column_name,
                pattern=pattern,
                separator=separator,
                substring=substring,
                prefix=prefix,
                exported_config_data=exported_config_data,
                exported_column_info=exported_column_info)
            return ss_transform_step

        elif step_json['function'] == 'math_expression' or step_json['function'] == 'math_expression_v':
            expression = None
            if step_json['expression']:
                expression = step_json['expression']

            math_transform_step = ExpressionTransformationStep(
                description=description,
                column_name=column_name,
                column_index=column_index,
                new_column_name=new_column_name,
                expression=expression)
            return math_transform_step

        elif step_json['function'] == 'slice':
            column_set_id = step_json['column_set_id']
            column_names = step_json['column_names']
            column_indices = step_json['column_indices']
            delete = step_json['delete']

            slice_transform_step = SliceTransformationStep(
                description=description,
                column_set_id=column_set_id,
                column_names=column_names,
                column_indices=column_indices,
                delete=delete)
            return slice_transform_step

        elif step_json['function'] == 'linearfit_v':
            column_names = None
            if step_json['column_names']:
                column_names = step_json['column_names']
            column_indices = None
            if step_json['column_indices']:
                column_indices = step_json['column_indices']

            linearfit_transform_step = LinearFitTransformationStep(
                description=description,
                column_names=column_names,
                column_indices=column_indices)
            return linearfit_transform_step

        return None


class SquareTransformationStep(TransformationStep):
    """
    Squares a value on a single column, identified either by name or index. For further information, see
    :doc:`transformations/square`.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform (optional with column_index)
        column_index (int): specifies the index of the column to transform (optional with column_name)
        column_names (list): specify a list of column names to transform, much faster than adding a new step for each
           column. Only available when virtual == True. (use instead of column_name, column_index or column_indices)
        column_indices (list): specify a list of column indices to transform. Only available when virtual = True.
           (Use instead of column_name, column_index, or column_names)
        new_column_name (str): specifies the name of the transformed column. If using column_names or
           column_indices parameter, this becomes the new column name prefix.
        virtual (bool): if True, specifies that the transformation is virtual. If False or omitted, the transformation
            is physical.

    Returns:
        A SquareTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a square transformation step
    >>> sqr_transform_step = ac.SquareTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose',
    ...     new_column_name='blood glucose squared',
    ...     virtual=True)
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     sqr_transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'blood glucose squared'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc

    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 column_names=None,
                 column_indices=None,
                 virtual=False):
        if not virtual and (column_names is not None or column_indices is not None):
            raise ValueError('column_names and column_indices can only be used when virtual is True')
        self.column_names = column_names
        self.column_indices = column_indices
        super(SquareTransformationStep, self).__init__(
            function='sqr',
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name,
            virtual=virtual)

    def _serialize(self):
        data = super(SquareTransformationStep, self)._serialize()
        data['column_names'] = self.column_names
        data['column_indices'] = self.column_indices
        return data


class LogarithmTransformationStep(TransformationStep):
    """
    Creates a new LogarithmTransformationStep.

    This performs a logarithm function on column value. For further information, For further information, see
    :doc:`transformations/log`.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform (optional with column_index)
        column_index (int): Index of the column to transform (optional with column_name)
        base (int): base for the logarithm function
        column_names (list): specify a list of column names to transform, much faster than adding a new step for each
           column. Only available when virtual == True. (use instead of column_name, column_index or column_indices)
        column_indices (list): specify a list of column indices to transform. Only available when virtual = True.
           (Use instead of column_name, column_index, or column_names)
        new_column_name (str): specifies the name of the transformed column. If using column_names or
           column_indices parameter, this becomes the new column name prefix.
        virtual (bool): if True, specifies that the transformation is virtual. If False or omitted, the transformation
            is physical.

    Returns:
        A LogarithmTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.LogarithmTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose',
    ...     new_column_name='blood glucose log',
    ...     base=2,
    ...     virtual=True)
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'blood glucose log'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc

    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 base=None,
                 column_names=None,
                 column_indices=None,
                 virtual=False):
        super(LogarithmTransformationStep, self).__init__(
            function='log',
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name,
            virtual=virtual)
        self.base = base
        self.column_names = column_names
        self.column_indices = column_indices

    def _serialize(self):
        data = super(LogarithmTransformationStep, self)._serialize()
        data['base'] = self.base
        data['column_names'] = self.column_names
        data['column_indices'] = self.column_indices
        return data


class SymmetricLogarithmTransformationStep(TransformationStep):
    """
    Creates a new SymmetricLogarithmTransformationStep.

    Performs a symmetric logarithm function on column value. For further information, see
    :doc:`transformations/symmetriclog`.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform. (optional with column_index)
        column_index (int): specifiesthe index of the column to transform. (optional with column_name)
        column_names (list): specify a list of column names to transform, much faster than adding a new step for each
           column. (use instead of column_name, column_index or column_indices)
        column_indices (list): specify a list of column indices to transform. (Use instead of column_name, column_index,
           or column_names)
        new_column_name (str): specifies the name of the transformed (logarithm) column. If using column_names or
           column_indices parameter, this becomes the new column name prefix.
        base (int): base for the logarithm function

    Returns:
        A SymmetricLogarithmTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.SymmetricLogarithmTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose',
    ...     new_column_name='blood glucose symmetric log',
    ...     base=2)
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'blood glucose symmetric log'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc

    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 base=None,
                 column_names=None,
                 column_indices=None,
                 virtual=True):
        super(SymmetricLogarithmTransformationStep, self).__init__(
            function='symmetric_log',
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name,
            virtual=virtual)
        self.base = base
        self.column_names = column_names
        self.column_indices = column_indices

    def _serialize(self):
        data = super(SymmetricLogarithmTransformationStep, self)._serialize()
        data['base'] = self.base
        data['column_names'] = self.column_names
        data['column_indices'] = self.column_indices

        return data


class LagTransformationStep(TransformationStep):
    """
    Creates a new LagTransformationStep.

    Creates a new column where the values are equal to a previous row's value on an existing column. For further
    information, see :doc:`transformations/lag_lagdiff`.

    Args:
        description (str): describes the transformation.
        column_name (str): specifies the name of the column to transform. (optional with column_index)
        column_index (int): specifies the index of the column to transform. (optional with column_name)
        lag_count (int): specifies the amount of lag, if any. When specified, the column value lags by this amount.
            For example, if lagCount is 3, the transformed value is equal to the third previous value.
        new_column_name (str) : the name of the new column to create

    Returns:
        A LagTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.LagTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose',
    ...     new_column_name='blood glucose lag',
    ...     lag_count=2)
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'blood glucose lag'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc

    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 lag_count=None):
        super(LagTransformationStep, self).__init__(
            function='lag',
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name)
        self.lag_count = lag_count

    def _serialize(self):
        data = super(LagTransformationStep, self)._serialize()
        data['lag_count'] = self.lag_count
        return data


class LagDifferenceTransformationStep(TransformationStep):
    """
    Creates a new LagDifferenceTransformationStep.

    Creates a new column with values that are equal to the difference between the current value and a previous value
    on an existing column. For further information, see :doc:`transformations/lag_lagdiff`.


    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform. (optional with column_index)
        column_index (int): specifies the index of the column to transform. (optional with column_name)
        lag_count (int): specifes the amount of lag, if any. When specified, the column value lags by this amount.
            For example, if lagCount is 3, the new value will be equal to the difference between the current value
            and the third previous value.

    Returns:
        A LagDifferenceTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt",
    ...     allow_duplicate=True) #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.LagDifferenceTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose',
    ...     new_column_name='blood glucose lag difference',
    ...     lag_count=2)
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'blood glucose lag difference'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc

    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 lag_count=None):
        super(LagDifferenceTransformationStep, self).__init__(
            function='lagdif',
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name)
        self.lag_count = lag_count

    def _serialize(self):
        data = super(LagDifferenceTransformationStep, self)._serialize()
        data['lag_count'] = self.lag_count
        return data


class DateTimeTransformationStep(TransformationStep):
    """
    Physical or virtual transformation that converts date/time data into a useful format for analysis purposes,
    isolating date, yearmonth, year, month, day of month, day of week, weekend, secondofday, and timezone.
    For further information, see :doc:`transformations/datetime`.

    Args:
        description (str) : describes the transformation
        column_name (str) : specifies the name of the column to transform (optional with column_index)
        column_index (int) : specifies the index of the column to transform (optional with column_name)
        format (str) : datetime format string, such as "yyyy-MM-dd HH:mm:ss.SSS)".' Used if you do not
            want to use ISO 8601 format. (optional)
        new_column_name (str) : specifies the name of the new column to be created

    Returns:
        A DateTimeTransformationStep object

    ``DateTimeTransformationStep`` transforms the Original column value "2016-12-31T23:00:00-08:00" (ISO 8601 format)
    into nine new columns plus one DT error column, as follows:

    ================ =================
    New Column Names New Column Values
    ================ =================
    New_Date         20161231
    New_YearMonth    201612
    New_Year         2016
    New_Month        12
    New_DayOfMonth   31
    New_DayOfWeek    6
    New_Weekend      1
    New_SecondOfDay  82800
    New_Timezone     -08:00
    New_DT_Error     OK
    ================ =================

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/time_series.csv") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.DateTimeTransformationStep(
    ...     description='step description',
    ...     column_name='transaction_timestamp',
    ...     format='yyyy-MM-dd HH:mm:ss')
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='time_series_new')
    >>> new_source.sync()
    >>> new_source.name
    'time_series_new'
    >>> new_source.column_names[6]
    'transaction_timestamp_Date'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> src = connection.delete_source(name="time_series.csv") #ignore-in-doc

    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 format=None,
                 virtual=False):
        super(DateTimeTransformationStep, self).__init__(
            function='datetime',
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name,
            virtual=virtual)
        self.format = format

    def _serialize(self):
        data = super(DateTimeTransformationStep, self)._serialize()
        data['format'] = self.format
        return data


class PrependTransformationStep(TransformationStep):
    """
    Prepends a literal string to the value, transforming the new value into a string datatype. For further information,
    see :doc:`transformations/prepend`.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform. (optional with column_index)
        column_index (int): Index of the column to transform. (optional with column_name)
        prefix (str): string value to be prepended to the input column value.
        column_names (list): specify a list of column names to transform, much faster than adding a new step for each
           column. Only available when virtual == True. (use instead of column_name, column_index or column_indices)
        column_indices (list): specify a list of column indices to transform. Only available when virtual = True.
           (Use instead of column_name, column_index, or column_names)
        new_column_name (str): specifies the name of the transformed column. If using column_names or
           column_indices parameter, this becomes the new column name prefix.
        virtual (bool): if True, the transformation is virtual. If False or omitted, the transformation is physical.

    Returns:
        A PrependTransformationStep object

    ========    ===========
    Original    Transformed
    ========    ===========
    42          value_42
    0.5         value_0.5
    ========    ===========

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.PrependTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose',
    ...     new_column_name='blood glucose prepend',
    ...     prefix='prefix_',
    ...     virtual=True)
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'blood glucose prepend'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc

    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 prefix=None,
                 column_names=None,
                 column_indices=None,
                 virtual=False):
        if not virtual and (column_names is not None or column_indices is not None):
            raise ValueError('column_names and column_indices can only be used when virtual is True')
        super(PrependTransformationStep, self).__init__(
            function='prepend',
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name,
            virtual=virtual)
        self.prefix = prefix
        self.column_names = column_names
        self.column_indices = column_indices

    def _serialize(self):
        data = super(PrependTransformationStep, self)._serialize()
        data['prefix'] = self.prefix
        data['column_names'] = self.column_names
        data['column_indices'] = self.column_indices
        return data


class OneHotEncodeTransformationStep(TransformationStep):
    """
    Creates a new OneHotEncodeTransformationStep.

    Transforms a column of categorical values into separate columns with a 1 if the value matches and a 0 if it
    does not match. For further information, see :doc:`transformations/onehot`.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform. (optional with column_index)
        column_index (int): Index of the column to transform. (optional with column_name)
        new_column_name (str): specifies the name of the new column to create.
        max_columns (int): Maximum number of columns to encode up to 50 (default).
        exported_config_data (str): system-generated config data from training source. **Do not change**
        exported_column_info (str): system-generated column information from training source. **Do not change**
        add_others_column (bool): Create additional column for values not represented in the max_columns columns.
            Default=True
        add_nulls_column (bool): if True, creates an extra column that captures whether the value was a null, an
            empty string, or NaN.
            If nulls is selected, these values are not included in the "other" category.
            If nulls are not selected, nulls show in the "other" column.

    Returns:
        A OneHotEncodeTransformationStep object


    ========    =============    ============    ====================
    Original    Original_Blue    Original_Red    Original_OTHERVALUES
    ========    =============    ============    ====================
    Blue        1                0               0
    Red         0                1               0
    Yellow      0                0               1
    ========    =============    ============    ====================

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.OneHotEncodeTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose')
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[-1]
    'blood glucose_OTHERVALUES'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc

    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 exported_config_data=None,
                 exported_column_info=None,
                 max_columns=50,
                 add_others_column=True,
                 add_nulls_column=False):
        super(OneHotEncodeTransformationStep, self).__init__(
            function='onehotencode',
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name)
        self.exported_config_data = exported_config_data
        self.exported_column_info = exported_column_info
        self.max_columns = max_columns
        self.add_others_column = add_others_column
        self.add_nulls_column = add_nulls_column

    def _serialize(self):
        data = super(OneHotEncodeTransformationStep, self)._serialize()
        if self.exported_config_data is not None:
            data['exported_config_data'] = self.exported_config_data
        if self.exported_column_info is not None:
            data['exported_column_info'] = self.exported_column_info
        data['max_columns'] = self.max_columns
        data['add_others_column'] = self.add_others_column
        data['add_nulls_column'] = self.add_nulls_column
        return data


class GroupByTransformationStep(TransformationStep):
    """
    Groups by and aggregates on specified columns. For further information, see :doc:`transformations/groupby`.

    Available aggregate functions:
        - sum(numeric column): returns the sum of all values in the group.
        - avg(numeric column): returns the average of the values in a group.
        - count(categorical/numeric column): returns the number of items in a group.
        - median(categorical/numeric column): returns the median value of items in a group.
        - max(categorical/numeric column): returns the maximum value of the items in a group.
        - min(categorical/numeric column): returns the minimum value of the items in a group.
        - mode(categorical/numeric column): return the most frequently occuring number in the group.
        - unique_value_count(categorical/numeric column): return the counts of unique values in the group.

    Args:
        description (str): describes the transformation
        group_by_columns (list): lists the names of the columns to group by
        aggregate_functions (list): lists aggregate functions applied on columns
        new_column_name (str): name of the new column to create.

    Returns:
        GroupByTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/diabetes_test_points.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.GroupByTransformationStep(
    ...     description='Group by classification',
    ...     group_by_columns=['clinical classification'],
    ...     aggregate_functions=[
    ...            {
    ...                'column': 'blood glucose',
    ...                'functions': [
    ...                    {
    ...                        'name': 'avg',
    ...                        'new_column_name': 'avg_blood_glucose',
    ...                        'ignore_null': True
    ...                    },
    ...                    {
    ...                        'name': 'median',
    ...                        'new_column_name': 'median_blood_glucose'
    ...                    }
    ...                ]
    ...            },
    ...           {
    ...                'column': 'insulin level',
    ...                'functions': [
    ...                        {
    ...                         'name': 'count',
    ...                         'new_column_name': 'count_insulin_level'
    ...                        }
    ...                ]
    ...            }
    ...     ]
    ... )
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='diabetes2')
    >>> new_source.sync()
    >>> new_source.name
    'diabetes2'
    >>> sorted(new_source.column_names)
    ['avg_blood_glucose', 'clinical classification', 'count_insulin_level', 'median_blood_glucose']
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 group_by_columns,
                 aggregate_functions):
        super(GroupByTransformationStep, self).__init__(
            function='groupby',
            description=description
        )
        self.group_by_columns = group_by_columns
        self.aggregate_functions = aggregate_functions

    def _serialize(self):
        data = super(GroupByTransformationStep, self)._serialize()
        data['group_by_column_name_list'] = self.group_by_columns
        data['column_aggregation_function_list'] = self.aggregate_functions
        return data


class PivotTransformationStep(TransformationStep):
    """
    Pivots and aggregates on specified columns. For further information, see :doc:`transformations/pivot`.

    Available aggregate functions:
        - sum(numeric column): returns the sum of all values in the group.
        - avg(numeric column): returns the average of the values in a group
        - max(categorical/numeric column): returns the maximum value of the items in a group.
        - min(categorical/numeric column): returns the minimum value of the items in a group.

    Args:
        description (str): describes the transformation
        primary_columns (list): list of names of the columns to group the value column
        pivot_column (str): specifies the name of the column to pivot
        value_column (str): specifies the name of the column to use as value
        aggregation_function (str): aggregate function to apply on the value column
        fill_value (str): fill value

    Returns:
        PivotTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/pivot.csv") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.PivotTransformationStep(
    ...     description='PivotTransformation',
    ...     primary_columns=["Customer id"],
    ...     pivot_column="concatenated_group_by_string",
    ...     value_column="Number of transactions",
    ...     aggregation_function="sum",
    ...     fill_value="5"
    ... )
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='pivot')
    >>> new_source.sync()
    >>> new_source.name
    'pivot'
    >>> sorted(new_source.column_names)[3]
    'wired_medium_risk_february_industry'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 primary_columns,
                 pivot_column,
                 value_column,
                 aggregation_function,
                 fill_value):
        super(PivotTransformationStep, self).__init__(
            function='pivot',
            description=description
        )
        self.primary_columns = primary_columns
        self.pivot_column = pivot_column
        self.value_column = value_column
        self.aggregation_function = aggregation_function
        self.fill_value = fill_value

    def _serialize(self):
        data = super(PivotTransformationStep, self)._serialize()
        data['primary_columns'] = self.primary_columns
        data['pivot_column'] = self.pivot_column
        data['value_column'] = self.value_column
        data['aggregation_function'] = self.aggregation_function
        data['fill_value'] = self.fill_value
        return data


class JoinTransformationStep(TransformationStep):
    """
    Physical-only transformation that merges a primary source with any number of secondary sources. For further
    information, see :doc:`transformations/join`.

    Args:
        description (str): describes the transformation
        primary_source_key (str): specifies the column in the primary source that will be used as a key.
        secondary_sources (list): a list of one or more dictionaries, where each dictionary represents a secondary
            source. In each dictionary, `id` represents the source id and `key` represents the join key. 'columns'
            is a list of dict that represent the columns that need to be joined. Within the dictionary include 'id'
            representing column id, an optional 'new_name' for the column and an optional 'fill_value' that should
            replace the nulls in the joined column.
        join_type (str): specifies how the new sources will be joined to the primary. Legal values are LEFT_OUTER,
            INNER, and FULL_OUTER. If not specified, the platform throws an error.

    Returns:
        JoinTransformationStep object

    :Example:

    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/northwind_orders.csv") #ignore-in-doc
    >>> secondary_src1 = connection.upload_source("./test/northwind_employees.csv") #ignore-in-doc
    >>> secondary_src2 = connection.upload_source("./test/northwind_employee_territories.csv") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.JoinTransformationStep(
    ...     description='Join Orders with employee and territory data',
    ...     primary_source_key='employeeID',
    ...     secondary_sources=[{'id' : secondary_src1.id, 'key' : 'employeeID'},
    ...     {'id' : secondary_src2.id, 'key' : 'employeeID'}],
    ...     join_type='LEFT_OUTER'
    ... )
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'Join Orders with employee and territory data',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='orders_with_employees')
    >>> new_source.sync()
    >>> new_source.name
    'orders_with_employees'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 primary_source_key,
                 secondary_sources,
                 join_type):
        super(JoinTransformationStep, self).__init__(
            function='join',
            description=description
        )
        self.primary_source_key = primary_source_key
        self.secondary_sources = secondary_sources
        self.join_type = join_type

    def _serialize(self):
        data = super(JoinTransformationStep, self)._serialize()
        data['primary_source_key'] = self.primary_source_key
        data['secondary_sources'] = self.secondary_sources
        data['join_type'] = self.join_type
        return data


class NullImputationTransformationStep(TransformationStep):
    """
    Virtual-only transformation that enables you to convert null data values into a statistical calculation or value
    you provide.

    Available statistical functions:
       - avg (numeric column): average of the values in the column
       - median (numeric column): median of the values in the column
       - mode (numeric column): mode of the values in the column
       - max (numeric column): max of the values in the column
       - min (numeric): min of the values in the column.

    For further information, see :doc:`transformations/null`.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform (optional with column_index)
        column_names (list): specify a list of column names to transform, much faster than adding a new step for each
           column. (use instead of column_name, column_index or column_indices)
        column_index (int): specifies the index of the column to transform (optional with column_name)
        column_indices (list): specify a list of column indices to transform. (Use instead of column_name, column_index,
           or column_names)
        exported_config_data (str): system-generated config data from the training source. **Do not change**
        exported_column_info (str): system-generated column information from the training source. **Do not change**
        stat_function_replacement (list): list of statistical function replacements. If using column_names or
           column_indices parameter, the new_column_name becomes the new column name prefix.
        user_defined_replacement (list): list of user-defined replacements. If using column_names or
           column_indices parameter, the new_column_name becomes the new column name prefix.

    Returns:
        A NullImputationTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/diabetes_test_points.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.NullImputationTransformationStep(
    ...     description='Replace nulls in insulin level column',
    ...     column_name='insulin level',
    ...     stat_function_replacement=[
    ...     {
    ...            'name' : 'avg',
    ...             'new_column_name' : 'avg_filled_insulin_level'
    ...         },
    ...         {
    ...             'name' : 'median',
    ...             'new_column_name' : 'median_filled_insulin_level'
    ...         }
    ...     ],
    ...     user_defined_replacement=[
    ...         {
    ...             'value' : 0,
    ...             'new_column_name' : 'zero_filled_insulin_level'
    ...         }
    ...     ]
    ... )
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='diabetes2')
    >>> new_source.sync()
    >>> new_source.name
    'diabetes2'
    >>> new_source.column_names[9]
    'zero_filled_insulin_level'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 exported_config_data=None,
                 exported_column_info=None,
                 stat_function_replacement=None,
                 user_defined_replacement=None,
                 column_names=None,
                 column_indices=None):
        super(NullImputationTransformationStep, self).__init__(
            function='null imputation',
            description=description,
            column_name=column_name,
            column_index=column_index
        )
        self.exported_config_data = exported_config_data
        self.exported_column_info = exported_column_info
        self.replacement_params = {'stat_function_replacement': stat_function_replacement,
                                   'user_defined_replacement': user_defined_replacement}
        self.column_names = column_names
        self.column_indices = column_indices

    def _serialize(self):
        data = super(NullImputationTransformationStep, self)._serialize()
        if self.exported_config_data is not None:
            data['exported_config_data'] = self.exported_config_data
        if self.exported_column_info is not None:
            data['exported_column_info'] = self.exported_column_info
        data['replacement_params'] = self.replacement_params
        data['column_names'] = self.column_names
        data['column_indices'] = self.column_indices
        return data


class TransposeTransformationStep(TransformationStep):
    """
    A physical or virtual transformation that transposes a datasource's rows and columns. For further information,
    see :doc:`transformations/transpose`.

    Args:
        description (str): describes the desired transposition
        column_set_id: the id of the column set you want to transpose
        group_id: the id of the group of rows you want to transpose
        use_headers (bool): Default True. If true, will use the column headers as the new
            first column. If False, will not use column headers values.

    Returns:
        A TransposeTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.TransposeTransformationStep(
    ...     description='step description')
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> # The new source has row ids as the column names, so it has an extra row
    >>> new_source.column_count == src.row_count + 1
    True
    >>> new_source.row_count == src.column_count
    True
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc

    """

    def __init__(self,
                 description,
                 column_set_id=None,
                 group_id=None,
                 use_headers=True):
        super(TransposeTransformationStep, self).__init__(
            description,
            column_name=None,
            column_index=None,
            new_column_name=None)
        self.function = 'transpose'
        self.column_set_id = column_set_id
        self.group_id = group_id
        self.use_headers = use_headers

    def _serialize(self):
        data = super(TransposeTransformationStep, self)._serialize()
        data['column_set_id'] = self.column_set_id
        data['group_id'] = self.group_id
        data['use_headers'] = self.use_headers
        return data


class TextFeatureExtractionTransformationStep(TransformationStep):
    """
    Physical or virtual transformation that enables you to extract features from unstructured text that resides within
    a single column in the datasource. Requires an additional parameter, "algorithm", which processes text by
    selecting words based on the log likeliness over an entire corpus of documents or rows, then adds each NGram term
    into the source as a separate column. (NGrams are series of adjaent words, such as "to be supplied".) Each row
    includes its score value.

    For details, see :doc:`transformations/text_feature_extraction`.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform (optional with column_index)
        column_index (int): specifies the index of the column to transform (optional with column_name)
        new_column_name (str): specifies the name of the new column to be created
        algorithm (str): specifies the algorithm to be used to extract features from unstructured text.  Legal value:
            "log_likelihood"
        exported_config_data (str): system-generated config data from the training source. **Do not change.**
        exported_column_info (str): system-generated column information from the training source. **Do not change.**
        max_columns (int): the maximum number of new columns (most important NGrams) that will be added. Default=50
        max_ngram_length (int): the maximum length of the NGram. Legal values are 1, 2, 3, and 4. Default=3
        use_stemmer (bool): if True, the transformation utilizes word stemming. Default=True
        use_tfidf (bool): if True, the transformation utilizes TF/IDF word selection. Default=True
        allowed_ngram_length_list ([num]): list of ngram lengths to be considered.  For example, [1,3,4] means only
            consider ngrams of length 1, 3, or 4; discard all ngrams whose length is 2. To consider all ngram lengths
            up to max_ngram_length, specify None.
        use_stop_words (bool): if True, the transformation uses stopwords and calculates additional stopwords based on
            text frequency and the other parameters specified here. Default=False
        max_skips (int): the maximum number of stopwords that can be skipped and still create an ngram.  For example,
            if maxSkips is 0, then a stopword always causes the next valid word to start a new ngram. Default=0
        stop_word_knee_ratio (float): the larger the ratio, the more words are kept (fewer stop words), the smaller
            the ratio, the fewer words are kept (more stop words). 1.0 seems best when using ngrams, 2.5 seems best if
            you are just using single words. Default=2.5
        stop_word_min_cutoff (int): specifies the number of times (or fewer) a word must appear in the corpus, to make
            it a stop word. Default=3
        stop_word_list ([char]): list of words that must never be included in an ngram. If null or empty, an internal
            set is used. Default=None
        start_word_list ([char]): list of words that must never be used as stopwords. If null or empty, an internal
            set is used. Default=None
        virtual (bool): if True, specifies that the transformation is virtual. If False or omitted, the transformation
            is physical.

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/iris_binomial.csv") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.TextFeatureExtractionTransformationStep(
    ...     description='step description',
    ...     column_name='class',
    ...     virtual=True)
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> sorted(new_source.column_names[6:])
    ['class_Iris-setosa', 'class_Iris-versicolor', 'class_Iris-virginica']
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc

    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 algorithm=None,
                 exported_config_data=None,
                 exported_column_info=None,
                 max_columns=None,
                 max_ngram_length=3,
                 use_stemmer=True,
                 use_tfidf=True,
                 allowed_ngram_length_list=None,
                 use_stop_words=False,
                 max_skips=0,
                 stop_word_knee_ratio=None,
                 stop_word_min_cutoff=None,
                 stop_word_list=None,
                 start_word_list=None,
                 virtual=False):
        super(TextFeatureExtractionTransformationStep, self).__init__(
            function='text_feature_extraction',
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name,
            virtual=virtual)
        self.exported_config_data = exported_config_data
        self.exported_column_info = exported_column_info
        self.algorithm = algorithm
        self.max_columns = max_columns
        self.max_ngram_length = max_ngram_length
        self.use_stemmer = use_stemmer
        self.use_tfidf = use_tfidf
        self.allowed_ngram_length_list = allowed_ngram_length_list
        self.use_stop_words = use_stop_words
        self.max_skips = max_skips
        self.stop_word_knee_ratio = stop_word_knee_ratio
        self.stop_word_min_cutoff = stop_word_min_cutoff
        self.stop_word_list = stop_word_list
        self.start_word_list = start_word_list

    def _serialize(self):
        data = super(TextFeatureExtractionTransformationStep, self)._serialize()
        if self.exported_config_data is not None:
            data['exported_config_data'] = self.exported_config_data
        if self.exported_column_info is not None:
            data['exported_column_info'] = self.exported_column_info
        data['algorithm'] = self.algorithm
        data['max_columns'] = self.max_columns
        data['max_ngram_length'] = self.max_ngram_length
        data['use_stemmer'] = self.use_stemmer
        data['use_tfidf'] = self.use_tfidf
        data['allowed_ngram_length_list'] = self.allowed_ngram_length_list
        data['use_stop_words'] = self.use_stop_words
        data['max_skips'] = self.max_skips
        data['stopword_knee_ratio'] = self.stop_word_knee_ratio
        data['stopword_min_cutoff'] = self.stop_word_min_cutoff
        data['stop_word_list'] = self.stop_word_list
        data['start_word_list'] = self.start_word_list
        return data


class StandardScalingTransformationStep(TransformationStep):
    """
    Virtual-only transformation performed against numeric data, that supports standard scaling of a data column
    (Z-scoring). For further information, see :doc:`transformations/z-scoring`.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform (optional with column_index)
        column_names (list): specify a list of column names to transform, much faster than adding a new step for each
           column. (use instead of column_name, column_index or column_indices)
        column_index (int): specifies the index of the column to transform (optional with column_name)
        column_indices (list): specify a list of column indices to transform. (Use instead of column_name, column_index,
           or column_names)
        new_column_name (str): name for the new transformed (Z-scored) column (optional). If using column_names or
           column_indices parameter, this becomes the new column name prefix.
        with_std (bool): if True, then division by standard deviation is performed
        with_mean (bool): if True, then mean centering (i.e. subtraction of mean) is performed
        exported_config_data (str): system-generated config data from training source. **Do not change**
        exported_column_info (str): system-generated column information from training source. **Do not change**

    Returns:
        A StandardScalingTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> ss_transform_step = ac.StandardScalingTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose',
    ...     new_column_name='blood glucose std scaled')
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     ss_transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'blood glucose std scaled'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc

    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 exported_config_data=None,
                 exported_column_info=None,
                 with_std=True,
                 with_mean=True,
                 column_names=None,
                 column_indices=None,
                 virtual=True):
        super(StandardScalingTransformationStep, self).__init__(
            function='standard_scaling',
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name,
            virtual=virtual)
        self.exported_config_data = exported_config_data
        self.exported_column_info = exported_column_info
        self.with_std = with_std
        self.with_mean = with_mean
        self.column_names = column_names
        self.column_indices = column_indices

    def _serialize(self):
        data = super(StandardScalingTransformationStep, self)._serialize()
        if self.exported_config_data is not None:
            data['exported_config_data'] = self.exported_config_data
        if self.exported_column_info is not None:
            data['exported_column_info'] = self.exported_column_info
        data['with_std'] = 'true' if self.with_std else 'false'
        data['with_mean'] = 'true' if self.with_mean else 'false'
        data['column_names'] = self.column_names
        data['column_indices'] = self.column_indices
        return data


class UnionTransformationStep(TransformationStep):
    """
    Physical-only transformation that merges data from two or more sources that have an overlapping column name and
    column type. Every secondary source is concatenated to the primary source in the order that is provided. If a
    secondary source does not have identical headers, a validation error displays. For further information, see
    :doc:`transformations/union`.

    Args:
        description (str): describes the transformation
        primary_column_map (map): maps the new column names to be created, to the old ones (optional)
        secondary_sources ([dict]): list of dictionaries, each of which represents a secondary source with id and an
            optional map of new column names to the old ones. See the example below.
        allow_type_conversion (bool): allow automatic type conversion when column type mismatch. Default is True.

    Returns:
        A UnionTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> src2 = connection.upload_source("./test/db_test2.txt",
    ...     allow_duplicate=True) #ignore-in-doc
    >>> # Create a transformation step
    >>> ss_transform_step = ac.UnionTransformationStep(
    ...     description='step description',
    ...     primary_column_map={'ID': 'col'},
    ...     secondary_sources=[{'id' : src2.id,
    ...                         'column_map': {'ID': 'col'}}])
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     ss_transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    >>> connection.delete_source(id=src2.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 secondary_sources,
                 primary_column_map=None,
                 add_source_name_column=False,
                 allow_type_conversion=True):
        super(UnionTransformationStep, self).__init__(
            function='union',
            description=description,
            virtual=False)
        self.secondary_sources = secondary_sources
        self.primary_column_map = primary_column_map
        self.add_source_name_column = add_source_name_column
        self.allow_type_conversion = allow_type_conversion

    def _serialize(self):
        data = super(UnionTransformationStep, self)._serialize()
        data['secondary_sources'] = self.secondary_sources
        if self.primary_column_map is not None:
            data['primary_column_map'] = json.dumps(self.primary_column_map)
        else:
            data['primary_column_map'] = None
        data['add_source_name_column'] = self.add_source_name_column
        data['allow_type_conversion'] = self.allow_type_conversion
        return data


class OperatorTransformationStep(TransformationStep):
    """
    Virtual-only transformation that enables you to either perform mathematical operations on a set of numeric
    columns, or concatenate strings or numeric values between multiple string or numeric columns. (Applying the
    mathematical operations to a string column raises an error.) For further information, see
    :doc:`transformations/math_and_string`.

    Args:
        description (str): describes the transformation
        primary_column_name (str): first (primary) column in the operation
        secondary_column_names ([str]): list of secondary column names. Operators are chained together between the
            primary column and the secondary column, and then between each of the secondary columns. For example,
            if the operator chosen is 'add' or '+', then an 'add' or a '+' is inserted between the primary column
            and the first secondary column, and then sequentially between each of the remaining secondary
            columns, before evaluation.
        operator : valid values for numeric columns are `add`, `subtract`, `multiply`, `divide`, `+`, `-`, `x`, `/`.
            Valid value for string columns is `concatenate`. If `concatenate` is specified, you can specify a
            `separator` (described below). This parameter only takes in strings that are valid from an SQL
            perspective; for example, a "." is not acceptable.
        separator (char) : character used to separate concatenated string columns. If a separator is  not provided,
            the columns are separated by the default separator, "_" (underscore).
        new_column_name (str): name of the new column to be created. If not specified, the column is named according
            to the operation at the beginning; for example, (sum_column1_column2).

    Returns:
        A OperatorTransformationStep object


    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a square transformation step
    >>> ss_transform_step = ac.OperatorTransformationStep(
    ...     description='step description',
    ...     functions=[
    ...     {
    ...            'primary_column_name' : 'blood glucose',
    ...            'secondary_column_names' : ['insulin level', 'insulin level'],
    ...            'operator': 'add',
    ...            'new_column_name': 'blood_glucose_insulin_level_add'
    ...         },
    ...     {
    ...            'primary_column_name' : 'blood glucose',
    ...            'secondary_column_names' : ['insulin level', 'insulin response'],
    ...            'operator': 'divide'
    ...         }
    ...     ])
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     ss_transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'blood_glucose_insulin_level_add'
    >>> new_source.column_names[8]
    'divide_blood glucose_insulin level_insulin response'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 functions,
                 virtual=True):
        super(OperatorTransformationStep, self).__init__(
            function='operator',
            description=description,
            virtual=virtual)
        self.operator_functions = functions

    def _serialize(self):
        data = super(OperatorTransformationStep, self)._serialize()
        data['functions'] = self.operator_functions
        return data


class BinarizeTransformationStep(TransformationStep):
    """
    Virtual-only transformation that takes in a single numeric column, identified by either name or index, and creates
    a binary column based on a threshold provided. Values that are equal to or greater than the threshold are set to
    "1", and values below the threshold are set to "0". For further information, see :doc:`transformations/binarize`.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform (optional with column_index)
        column_index (int): specifies the index of the column to transform (optional with column_name)
        threshold (str): the point at (and past) which tranformation occurs. Legal values can be a number, a string,
            or the literal string 'null'. If the value is a number, any operator is allowed. (See ``operator``, below.)
            If the value is a string,  only = or != are allowed. If you supply the literal string 'null' (which directs
            the transformation to check whether or not the value is null), only = or != are allowed. (optional)
        operator (str): one of =, !=, >, >=, <, <= (optional)
        column_names (list): specify a list of column names to transform, much faster than adding a new step for each
           column. Only available when virtual == True. (use instead of column_name, column_index or column_indices)
        column_indices (list): specify a list of column indices to transform. Only available when virtual = True.
           (Use instead of column_name, column_index, or column_names)
        new_column_name (str): specifies the name of the transformed column. If using column_names or
           column_indices parameter, this becomes the new column name prefix.
        virtual (bool): if True or omitted, specifies that the transformation is virtual. If False, the transformation
            is physical.

    Returns:
        A BinarizeTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a square transformation step
    >>> bin_transform_step = ac.BinarizeTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose',
    ...     new_column_name='blood glucose binarized',
    ...     threshold=150)
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     bin_transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'blood glucose binarized'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc

    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 threshold=None,
                 operator=None,
                 column_names=None,
                 column_indices=None,
                 virtual=True):
        super(BinarizeTransformationStep, self).__init__(
            function='binarize',
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name,
            virtual=virtual)
        self.threshold = threshold
        self.operator = operator
        self.column_names = column_names
        self.column_indices = column_indices

    def _serialize(self):
        data = super(BinarizeTransformationStep, self)._serialize()
        data['threshold'] = self.threshold
        data['operator'] = self.operator
        data['column_names'] = self.column_names
        data['column_indices'] = self.column_indices
        return data


class PCATransformationStep(TransformationStep):
    """
        Creates a new source and applies Principal Component Analysis on the input columns and converts them
        into given number of principal components and adds these columns to the new source. This transformation takes
        in a list of input columns, identified by their names. The number of principal components provided should be
        less than the number of input columns.

        Args:
            description (str): describes the transformation
            input_column_names (list): List of input column names.
            pca_column_prefix (str): Prefix string for output columns (principal components).
            n_components (int): Number of principal components to be created.
            exported_config_data (str): system-generated config data from training source. **Do not change**
            exported_column_info (str): system-generated column information from training source. **Do not change**
        Returns:
            A PCATransformationStep object

        :Example:
    >>> import ayasdi.core as ac
    >>>
        >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
        >>> # Create a square transformation step
        >>> pca_transform_step = ac.PCATransformationStep(
        ...     description='step description',
        ...     input_column_names=['insulin response', 'insulin level', 'blood glucose'],
        ...     pca_column_prefix='pca',
        ...     n_components=2)
        >>> # Set up the transformation configuration
        >>> tc = ac.TransformationConfiguration.create(
        ...     connection,
        ...     'description',
        ...     pca_transform_step)
        >>> new_source = tc.apply(source_id=src.id,
        ...                       new_source_name='db_test2_pca')
        >>> new_source.sync()
        >>> new_source.name
        'db_test2_pca'
        >>> len(new_source.column_names)
        9
        >>> new_source.column_names[7]
        'pca1'
        >>> connection.delete_source(id=new_source.id) # ignore-in-doc

        """

    def __init__(self,
                 description,
                 input_column_names=None,
                 pca_column_prefix=None,
                 n_components=None,
                 exported_config_data=None,
                 exported_column_info=None):
        super(PCATransformationStep, self).__init__(
            function='pca',
            description=description,
            virtual=False
        )
        self.input_column_names = input_column_names
        self.pca_column_prefix = pca_column_prefix
        self.n_components = n_components
        self.exported_config_data = exported_config_data
        self.exported_column_info = exported_column_info

    def _serialize(self):
        data = super(PCATransformationStep, self)._serialize()
        data['input_columns'] = self.input_column_names
        data['pca_column_prefix'] = self.pca_column_prefix
        data['n_components'] = self.n_components

        if self.exported_config_data:
            data['exported_config_data'] = self.exported_config_data
        if self.exported_column_info:
            data['exported_column_info'] = self.exported_column_info
        return data


class TimeSeriesAggregationTransformationStep(TransformationStep):
    """
    Performs a time series aggregation transformation on specified columns.

    Available aggregate functions:
        - sum(numeric column): returns the sum of all values in the group.
        - avg(numeric column): returns the average of the values in a group.
        - stddev(numeric column): returns the standard deviation of the values in a group.
        - median(categorical/numeric column): returns the median value of items in a group.
        - max(categorical/numeric column): returns the maximum value of the items in a group.
        - min(categorical/numeric column): returns the minimum value of the items in a group.
        - mode(categorical/numeric column): returns the most frequenctly-occurring value of the items in a group.
        - num_uniques(categorical/numeric column): returns the number of unqiue value of the items in a group.
        - num_nulls(categorical/numeric column): returns the number of unqiue value of the items in a group.

    Args:
        description (str): describes the transformation
        time_step (long): time range in second
        time_stamp_column (str): timestamp column name
        match_column (str): match column name
        aggregate_functions (list): lists aggregate functions applied on columns
        filter_set (filter set): select rows that match this column-based filter set.
          Default is None. See :func:`create_filter_set`
        exclude_current_value (bool): if True, excludes the current row

    Returns:
        TimeSeriesAggregationTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/time_series.csv") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.TimeSeriesAggregationTransformationStep(
    ...     description='Time series aggregations',
    ...     time_step=60*24*60*60,
    ...     time_stamp_column="transaction_timestamp",
    ...     match_column="beneficiary_id",
    ...     aggregate_functions=[
    ...            {
    ...                'column': "transaction_amount_base",
    ...                'functions': [
    ...                    {
    ...                        'name': 'avg',
    ...                        'new_column_name': 'avg_transaction_amount_base',
    ...                        'fill_value': 0.0,
    ...                    },
    ...                    {
    ...                        'name': 'median',
    ...                        'new_column_name': 'median_transaction_amount_base',
    ...                    }
    ...                ]
    ...            }
    ...     ],
    ...     exclude_current_value=True
    ... )
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 time_step,
                 time_stamp_column,
                 match_column,
                 aggregate_functions,
                 exclude_current_value=True,
                 filter_set=None):
        super(TimeSeriesAggregationTransformationStep, self).__init__(
            function='time_series_aggregation',
            description=description,
            virtual=False)
        self.time_step = time_step
        self.time_stamp_column = time_stamp_column
        self.match_column = match_column
        self.aggregate_functions = aggregate_functions
        self.filter_set = filter_set
        self.exclude_current_value = exclude_current_value

    def _serialize(self):
        data = super(TimeSeriesAggregationTransformationStep, self)._serialize()
        data['time_step'] = self.time_step
        data['time_stamp_column'] = self.time_stamp_column
        data['match_column'] = self.match_column
        data['column_aggregation_function_list'] = self.aggregate_functions
        if self.filter_set is not None:
            data['filter_set'] = json.dumps(self.filter_set)
        else:
            data['filter_set'] = None
        data['exclude_current_value'] = self.exclude_current_value
        return data


class SequenceGroupByTransformationStep(TransformationStep):
    """
    Performs a sequence group by transformation.
    This transformation creates a new column containing a json with list of dictionary.
    The keys are the column name and values are corresponding row values.

    Args:
        description (str): describes of the transformation
        new_column_name (str): name for the created column
        primary_columns (list): group by column names
        order_by_column (str): order by column name
        sequence_columns (list): list of column names in the created json dictionary
        normalize_column (str): normalize column name.
        normalize_value (str): value to find the reference row.

    Returns:
        SequenceGroupByTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/sequence_groupby_data.csv") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.SequenceGroupByTransformationStep(
    ...     description='Sequence groupby',
    ...     new_column_name='contents',
    ...     primary_columns=['pid', 'encid'],
    ...     order_by_column='timestamp',
    ...     sequence_columns=['code', 'value']
    ... )
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 new_column_name,
                 primary_columns,
                 order_by_column,
                 sequence_columns=None,
                 normalize_column=None,
                 normalize_value=None):
        super(SequenceGroupByTransformationStep, self).__init__(
            function='sequence_group_by',
            description=description,
            virtual=False)
        self.new_column_name = new_column_name
        self.primary_columns = primary_columns
        self.order_by_column = order_by_column
        self.sequence_columns = sequence_columns
        self.normalize_column = normalize_column
        self.normalize_value = normalize_value
        self.resolution_strategy = "first"

    def _serialize(self):
        data = super(SequenceGroupByTransformationStep, self)._serialize()
        data['new_column_name'] = self.new_column_name
        data['primary_columns'] = self.primary_columns
        data['order_by_column'] = self.order_by_column
        data['sequence_columns'] = self.sequence_columns
        data['normalize_column'] = self.normalize_column
        data['normalize_value'] = self.normalize_value
        data['resolution_strategy'] = self.resolution_strategy
        return data


class MismatchTransformationStep(TransformationStep):
    """
        Compares the values of two columns and checks if the values mismatch

        Args:
            description (str): describes the transformation
            primary_column_name (str): specifies the name of primary column
            secondary_column_name (str): specifies the name of secondary column
            new_column_name (str): the name of the new column to be created. If not specified, the column is named
                ``mismatch_column1_column2``
            allow_type_conversion (bool): allow automatic type conversion when column type mismatch. Default is False.
        Returns:
            A MismatchTransformationStep Object

        :Example:
        >>> import ayasdi.core as ac
        >>>
        >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
        >>> # Create a square transformation step
        >>> mismatch_transform_step = ac.MismatchTransformationStep(
        ...     description='mismatch transformation',
        ...     primary_column_name='relative weight',
        ...     secondary_column_name='blood glucose',
        ...     new_column_name='mismatch_rw_bg')
        >>> # Set up the transformation configuration
        >>> tc = ac.TransformationConfiguration.create(
        ...     connection,
        ...     'description',
        ...     mismatch_transform_step)
        >>> new_source = tc.apply(source_id=src.id,
        ...                       new_source_name='db_test2_mismatch')
        >>> new_source.sync()
        >>> new_source.name
        'db_test2_mismatch'
        >>> len(new_source.column_names)
        8
        >>> new_source.column_names[-1]
        'mismatch_rw_bg'
        >>> connection.delete_source(id=new_source.id) # ignore-in-doc
        """

    def __init__(self,
                 description,
                 primary_column_name,
                 secondary_column_name,
                 new_column_name=None,
                 allow_type_conversion=False):
        super(MismatchTransformationStep, self).__init__(
            function='mismatch',
            description=description,
            virtual=True
        )
        self.primary_column_name = primary_column_name
        self.secondary_column_name = secondary_column_name
        self.new_column_name = new_column_name
        self.allow_type_conversion = allow_type_conversion

    def _serialize(self):
        data = super(MismatchTransformationStep, self)._serialize()
        data['primary_column_name'] = self.primary_column_name
        data['secondary_column_name'] = self.secondary_column_name
        data['new_column_name'] = self.new_column_name
        data['allow_type_conversion'] = self.allow_type_conversion
        return data


class OrderByTransformationStep(TransformationStep):
    """
        Sorts by given columns

        Args:
            description (str): describes the transformation
            order_by_columns (list): List of dictionaries, where each dictionary contains a column name and order
                direction ("asc" or "desc")

        Returns:
            An OrderByTransformationStep Object

        :Example:
        >>> import ayasdi.core as ac
        >>>
        >>> src = connection.upload_source("./test/time_series.csv",
        ...     upload_spec={'column_type_overrides':[
        ...         {'name': 'transaction_timestamp',
        ...          'type': 'datetime'}]})
        >>> # Create a square transformation step
        >>> ss = ac.OrderByTransformationStep(
        ...     description='mismatch transformation',
        ...     order_by_columns=[{'name': 'transaction_id', 'direction': 'asc'},
        ...         {'name': 'transaction_timestamp', 'direction': 'desc'}])
        >>> # Set up the transformation configuration
        >>> tc = ac.TransformationConfiguration.create(
        ...     connection,
        ...     'description',
        ...     ss)
        >>> new_source = tc.apply(source_id=src.id,
        ...                       new_source_name='time_series_orderby')
        >>> new_source.sync()
        >>> new_source.name
        'time_series_orderby'
        >>> connection.delete_source(id=new_source.id) # ignore-in-doc
        """

    def __init__(self,
                 description,
                 order_by_columns):
        super(OrderByTransformationStep, self).__init__(
            function='order_by',
            description=description,
            virtual=False)
        self.order_by_columns = order_by_columns

    def _serialize(self):
        data = super(OrderByTransformationStep, self)._serialize()
        data['order_by_columns'] = self.order_by_columns
        return data


class CategoryCountTransformationStep(TransformationStep):
    """
    Generates categorical context based columns from an existing hierarchy in time series datasets.

    Args:
        description (str): describes the transformation
        time_step (long): time range in second
        time_stamp_column (str): timestamp column name
        category_column (str): column to generate categorical context
        prefix (str): prefix to the new columns
        filter_set (filter set): select rows that match this column-based filter set.
          Default is None. See :func:`create_filter_set`

    Returns:
        CategoryCountTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/time_series.csv",
    ...     allow_duplicate=True) #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.CategoryCountTransformationStep(
    ...     description='Time series aggregations',
    ...     time_step=60*24*60*60,
    ...     time_stamp_column="transaction_timestamp",
    ...     category_column="beneficiary_bank_country")
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 time_step,
                 time_stamp_column,
                 category_column,
                 prefix=None,
                 filter_set=None):
        super(CategoryCountTransformationStep, self).__init__(
            function='time_series_aggregation',
            description=description,
            virtual=False)
        self.time_step = time_step
        self.time_stamp_column = time_stamp_column
        self.aggregate_functions = [{'column': category_column,
                                     'functions': [{'name': 'category_count',
                                                    'new_column_name': prefix}]}]
        self.filter_set = filter_set

    def _serialize(self):
        data = super(CategoryCountTransformationStep, self)._serialize()
        data['time_step'] = self.time_step
        data['time_stamp_column'] = self.time_stamp_column
        data['column_aggregation_function_list'] = self.aggregate_functions
        if self.filter_set is not None:
            data['filter_set'] = json.dumps(self.filter_set)
        else:
            data['filter_set'] = None
        return data


class DTLagTransformationStep(TransformationStep):
    """
    Generates a column of value at a specific point in time in time series datasets. For further information, see
    :doc:`transformations/datetime`.

    Args:
        description (str): describes the transformation
        time_step (long): time to find the specific point
        time_stamp_column (str): timestamp column name
        match_column (str): match column name
        value_column (str): value column name
        buffer_time (long): positive time range to find the specific point. If it is present, the specific point is
            the one closet to the time_step in the time range (time_step - buffer_time, time_step) for future data
            and (abs(time_step) - buffer_time, abs(time_step) for historic data. (optional)
        filter_set (filter set): select rows that match this column-based filter set. See :func:`create_filter_set`
            Default=None

    Returns:
        DTLagTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/time_series.csv",
    ...     allow_duplicate=True) #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.DTLagTransformationStep(
    ...     description='DT Lag',
    ...     new_column_name='dt_lag',
    ...     time_step=60*24*60*60,
    ...     time_stamp_column="transaction_timestamp",
    ...     match_column="beneficiary_id",
    ...     value_column="transaction_amount_base")
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='time_series_lag')
    >>> new_source.sync()
    >>> new_source.name
    'time_series_lag'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 new_column_name,
                 time_step,
                 time_stamp_column,
                 match_column,
                 value_column,
                 fill_value=None,
                 buffer_time=0,
                 filter_set=None):
        super(DTLagTransformationStep, self).__init__(
            function='time_series_aggregation',
            description=description,
            new_column_name=new_column_name,
            virtual=False)
        self.time_step = time_step
        self.time_stamp_column = time_stamp_column
        self.match_column = match_column
        self.aggregate_functions = [{'column': value_column,
                                     'functions': [{'name': 'dt_lag',
                                                    'new_column_name': new_column_name,
                                                    'fill_value': fill_value}]}]
        self.buffer_time = buffer_time
        self.filter_set = filter_set

    def _serialize(self):
        data = super(DTLagTransformationStep, self)._serialize()
        data['time_step'] = self.time_step
        data['time_stamp_column'] = self.time_stamp_column
        data['match_column'] = self.match_column
        data['column_aggregation_function_list'] = self.aggregate_functions
        if self.filter_set is not None:
            data['filter_set'] = json.dumps(self.filter_set)
        else:
            data['filter_set'] = None
        data['buffer_time'] = self.buffer_time
        return data


class MinMaxScalingTransformationStep(TransformationStep):
    """
    Performs MinMax Scaling on a column. For further information, see :doc:`transformations/minmax`.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform. (optional with column_index)
        column_index (int): specifies the Index of the column to transform. (optional with column_name)
        new_column_name (str): the name of the new transformed (Z-scored) column
        feature_range (tuple of lower and upper of range): feature range. Default=(0, 1)
        column_names (list): specify a list of column names to transform, much faster than adding a new step for each
           column. Only available when virtual == True. (use instead of column_name, column_index or column_indices)
        column_indices (list): specify a list of column indices to transform. Only available when virtual = True.
           (Use instead of column_name, column_index, or column_names)
        new_column_name (str): specifies the name of the transformed column. If using column_names or
           column_indices parameter, this becomes the new column name prefix.

    Returns:
        A MinMaxScalingTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> ss_transform_step = ac.MinMaxScalingTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose',
    ...     new_column_name='blood glucose min/max scaled',
    ...     feature_range=(0, 1))
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     ss_transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'blood glucose min/max scaled'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc

    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 feature_range=(0, 1),
                 column_names=None,
                 column_indices=None,
                 virtual=True):
        super(MinMaxScalingTransformationStep, self).__init__(
            function='minmax_scaling',
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name,
            virtual=virtual)
        self.feature_range = feature_range
        self.column_names = column_names
        self.column_indices = column_indices

    def _serialize(self):
        data = super(MinMaxScalingTransformationStep, self)._serialize()
        data['feature_range'] = self.feature_range
        data['column_names'] = self.column_names
        data['column_indices'] = self.column_indices
        return data


class BucketizerTransformationStep(TransformationStep):
    """
    Perform Bucketizer transform on a column.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform. (optional with column_index)
        column_index (int): specifies the index of the column to transform. (optional with column_name)
        new_column_name (str): the name of the new transformed (Z-scored) column
        splits (tuple of increasingly larger split values)

    Returns:
        A BucketizerTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> bt_transform_step = ac.BucketizerTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose',
    ...     new_column_name='blood glucose bucket index',
    ...     splits=(0, 50, 80, 100, 150, 500))
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     bt_transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'blood glucose bucket index'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc

    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 splits=None,
                 virtual=True):
        super(BucketizerTransformationStep, self).__init__(
            function='bucketizer',
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name,
            virtual=virtual)
        self.splits = splits

    def _serialize(self):
        data = super(BucketizerTransformationStep, self)._serialize()
        data['splits'] = self.splits
        return data


class FrequencyRankEncodingTransformationStep(TransformationStep):
    """
    Perform frequency ranking transform on a column. For further information, see :doc:`transformations/freq_rank`.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform (optional with column_index)
        column_index (int): specifies the index of the column to transform (optional with column_name)
        new_column_name (str): the name of the new transformed (Z-scored) column
        strategy (str): tie-breaking strategy. Legal values are "DENSE", "STANDARD_COMPETITION", and "FRACTIONAL".
        max_labels (int): maximum number of generated labels.
        ignore_nulls (boolean): if True, ranking is performed only on non-null values.
        exported_config_data (str): system-generated config data from training source. **Do not change**
        exported_column_info (str): system-generated column information from training source. **Do not change**

    Returns:
        A FrequencyRankEncodingTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ac.FrequencyRankEncodingTransformationStep(
    ...     description='frequency ranking',
    ...     column_name='clinical classification',
    ...     new_column_name='ranked_clinical_classification',
    ...     strategy="DENSE",
    ...     max_labels=50,
    ...     ignore_nulls=True)
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'ranked_clinical_classification'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 strategy="DENSE",
                 max_labels=50,
                 ignore_nulls=True,
                 exported_config_data=None,
                 exported_column_info=None):
        super(FrequencyRankEncodingTransformationStep, self).__init__(
            function='frequency_ranking',
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name,
            virtual=False)
        self.strategy = strategy
        self.max_labels = max_labels
        self.ignore_nulls = ignore_nulls
        self.exported_config_data = exported_config_data
        self.exported_column_info = exported_column_info

    def _serialize(self):
        data = super(FrequencyRankEncodingTransformationStep, self)._serialize()
        data['strategy'] = self.strategy
        data['max_labels'] = self.max_labels
        data['ignore_nulls'] = self.ignore_nulls
        if self.exported_config_data:
            data['exported_config_data'] = self.exported_config_data
        if self.exported_column_info:
            data['exported_column_info'] = self.exported_column_info
        return data


class MultiColumnTransformationStep(TransformationStep):
    """
    Perform a calculation on multiple columns in the same row. For further information, see
    :doc:`transformations/multicol`.

    Args:
        description (str): Description of the transformation
        column_names (list of str): Names of the column to transform. Supports comma-separated list as well as
        \* wildcard. Example: col1, col2, col3, col\*. Optional with column_indices.
        column_indices (list): Indices of the columns to transform.
            Supports comma-separated lists as well as ranges with a -.
            Example: 1-5,33-65. Optional with column_names.
        new_column_name (str): Name of the transformed column. Required.
        function_name (str): The name of the function to apply to the values. Currently supported are: min, max, sum,
            mean, median, geometric_mean, standard_deviation, variance, skew, kurtosis, entropy

    Returns:
        A MultiColumnTransformationStep object

    :Example:
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = MultiColumnTransformationStep(
    ...     description='multicolumn max',
    ...     column_names=['relative weight','blood glucose','clinical classification'],
    ...     new_column_name='max',
    ...     function_name="max")
    >>> # Set up the transformation configuration
    >>> tc = TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'max'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 function_name=None,
                 column_names=None,
                 column_indices=None,
                 virtual=True):
        super(MultiColumnTransformationStep, self).__init__(
            function='multicolumn',  # _v will be added by the framework because virtual=True
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name,
            virtual=True)
        self.function_name = function_name
        self.column_names = column_names
        self.column_indices = column_indices

    def _serialize(self):
        data = super(MultiColumnTransformationStep, self)._serialize()
        data['function_name'] = self.function_name
        data['column_names'] = self.column_names
        data['column_indices'] = self.column_indices
        return data


class MaterializeVirtualTransformationStep(TransformationStep):
    """
    Convert all virtual columns into physical columns. This will also preserve the current column order.

    Args:
        description (str): Description of the transformation.

    Returns:
        A MaterializeVirtualTransformationStep object

    :Example:
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a virtual column
    >>> transform_step1 = SquareTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose',
    ...     new_column_name='sqr',
    ...     virtual=True)
    >>> # convert to physical
    >>> transform_step2 = MaterializeVirtualTransformationStep(
    ...     description='convert to physical')
    >>> # add physical column after
    >>> transform_step3 = SquareTransformationStep(
    ...     description='step description',
    ...     column_name='blood glucose',
    ...     new_column_name='sqr2',
    ...     virtual=False)
    >>> # Set up the transformation configuration
    >>> tc = TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step1, transform_step2, transform_step3)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> # new physical column will be last if materialize worked properly
    >>> new_source.column_names[8]
    'sqr2'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description=None,
                 virtual=False):
        super(MaterializeVirtualTransformationStep, self).__init__(
            function='materialize_virtual',
            description=description,
            column_name='',
            column_index=None,
            new_column_name=None,
            virtual=False)

    def _serialize(self):
        data = super(MaterializeVirtualTransformationStep, self)._serialize()
        return data


class RevertSequenceTransformationStep(TransformationStep):
    """
    Create a new source from a column in the original source containing sequential data as Json
    serialized arrays of dictionaries.
    Each field with the same key in the dictionaries will correspond to a column in the new source
    with the corresponding values.
    The original source must have a column with Sequence datatype, which must be specified as input.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform. (optional with column_index)
        column_index (int): specifies the index of the column to transform. (optional with column_name)

    Returns:
        A RevertSequenceTransformationStep object


    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/revert_sequence.csv") #ignore-in-doc
    >>> # Create a RevertSequenceTransformationStep
    >>> ss_transform_step = ac.RevertSequenceTransformationStep(
    ...     description='step description',
    ...     column_index=6)
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     ss_transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='new_sequence')
    >>> new_source.sync()
    >>> new_source.name
    'new_sequence'
    >>> len(new_source.column_names)
    6
    >>> new_source.row_count
    12
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None
                 ):
        super(RevertSequenceTransformationStep, self).__init__(
            function='revert_sequence',
            description=description,
            column_name=column_name,
            column_index=column_index,
            virtual=False)

    def _serialize(self):
        data = super(RevertSequenceTransformationStep, self)._serialize()
        return data


class SequenceSplitEncodeTransformationStep(TransformationStep):
    """
    Create a new source from a column in the original source containing sequential data as Json
    serialized arrays of dictionaries.
    Common subsequences between sequences in the selected column correspond to a new column, which is
    filled with 1 or 0 depending if the subsequence is found in the corresponding row or not.
    The original source must have a column with Sequence datatype, which must be specified as input.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform. (optional with column_index)
        column_index (int): specifies the index of the column to transform. (optional with column_name)
        exported_config_data (str): system-generated config data from training source. **Do not change**

    Returns:
        A SequenceSplitEncodeTransformationStep object


    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/simple_sequences.txt") #ignore-in-doc
    >>> # First we need to create a RevertSequenceTransformationStep
    >>> ss_transform_step = ac.RevertSequenceTransformationStep(
    ...     description='step description',
    ...     column_name='AyasdiSeq_event_json')
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     ss_transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='revert_sequence')
    >>> # Now, create a SequenceSplitEncodeTransformationStep
    >>> ss_transform_step2 = ac.SequenceSplitEncodeTransformationStep(
    ...     description='step description 2',
    ...     column_name='AyasdiSeq_event_json')
    >>> # Set up the transformation configuration
    >>> tc2 = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description 2',
    ...     ss_transform_step2)
    >>> new_source = tc2.apply(source_id=src.id,
    ...                       new_source_name='new_sequence')
    >>> new_source.sync()
    >>> new_source.name
    'new_sequence'
    >>> len(new_source.column_names)
    2
    >>> new_source.row_count
    20
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 exported_config_data=None
                 ):
        super(SequenceSplitEncodeTransformationStep, self).__init__(
            function='sequence_split_encode',
            description=description,
            column_name=column_name,
            column_index=column_index,
            virtual=False)
        self.exported_config_data = exported_config_data

    def _serialize(self):
        data = super(SequenceSplitEncodeTransformationStep, self)._serialize()
        if self.exported_config_data:
            data['exported_config_data'] = self.exported_config_data
        return data


class CsvVectorParseTransformationStep(TransformationStep):
    """
    Create a new source from a column in the original source containing vectors of comma-separated strings.
    There are two columns, "original_row" and "csv_substring".
    For each element in each CsvVector in the original source, a new row is added to the transformed source with
    the row index in the original source containing the corresponding CsvVector, and the element as a String.
    The original source must have a column with CsvVector datatype, which must be specified as input.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform. (optional with column_index)
        column_index (int): specifies the index of the column to transform. (optional with column_name)

    Returns:
        A CsvVectorParseTransformationStep object

    :Example:
        >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/csv_test.txt") #ignore-in-doc
    >>> # First we need to create a CsvVectorParseTransformationStep
    >>> ss_transform_step = ac.CsvVectorParseTransformationStep(
    ...     description='step description',
    ...     column_name='AyasdiCSV_vectors')
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     ss_transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='csv_vectors')
    >>> new_source.sync()
    >>> new_source.name
    'csv_vectors'
    >>> len(new_source.column_names)
    2
    >>> new_source.row_count
    82
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None
                 ):
        super(CsvVectorParseTransformationStep, self).__init__(
            function='csv_vector_parse',
            description=description,
            column_name=column_name,
            column_index=column_index,
            virtual=False)

    def _serialize(self):
        data = super(CsvVectorParseTransformationStep, self)._serialize()
        return data


class CsvVectorEncodeTransformationStep(TransformationStep):
    """
    Create a new source from a column in the original source containing vectors of comma-separated strings.
    Each column in the transformed source correspond to a unique String, and each row corresponds to a row in
    the original source. Each cell is then filled with 1 or 0 depending on whether the corresponding String is
    conteined or not in the CsvVector of the corresponding row.
    The original source must have a column with CsvVector datatype, which must be specified as input.
    This transformation requires a CsvVectorParseTransformationStep to be previously applied to the same
    source and column.

    Args:
        description (str): describes the transformation
        column_name (str): specifies the name of the column to transform. (optional with column_index)
        column_index (int): specifies the index of the column to transform. (optional with column_name)

    Returns:
        A CsvVectorEncodeTransformationStep object

    :Example:
    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/csv_test.txt") #ignore-in-doc
    >>> # First we need to apply a CsvVectorParseTransformationStep
    >>> tmp_transform_step = ac.CsvVectorParseTransformationStep(
    ...     description='step description',
    ...     column_name='AyasdiCSV_vectors')
    >>> tc_tmp = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     tmp_transform_step)
    >>> tmp_source = tc_tmp.apply(source_id=src.id,
    ...                           new_source_name='csv_vectors_parse')
    >>> # Then we apply the CsvVectorEncodeTransformation
    >>> ss_transform_step = ac.CsvVectorEncodeTransformationStep(
    ...     description='step description 2',
    ...     column_name='AyasdiCSV_vectors')
    >>> # Set up the transformation configuration
    >>> tc = ac.TransformationConfiguration.create(
    ...     connection,
    ...     'description 2',
    ...     ss_transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='csv_vectors_encode')
    >>> new_source.sync()
    >>> new_source.name
    'csv_vectors_encode'
    >>> len(new_source.column_names)
    18
    >>> new_source.row_count
    20
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None
                 ):
        super(CsvVectorEncodeTransformationStep, self).__init__(
            function='csv_vector_encode',
            description=description,
            column_name=column_name,
            column_index=column_index,
            virtual=False)

    def _serialize(self):
        data = super(CsvVectorEncodeTransformationStep, self)._serialize()
        return data


class CentroidDistanceTransformationStep(TransformationStep):
    """
    Calculate distances to the centroids of a series of groups based on a TDA network.

    Args:
        description (str): describes the desired transformation
        groups: (must set groups or groupset_id) a reference to a Group Set
        groupset_id: (optional with groups) a group set id
        network: (deprecated, use network_id, must set network or network_id) a reference to the network, for the
            columns and metric used
        network_id: (optional with network) the id of the network
        prefix (str): (optional) prefix added to the new column names
        exported_config_data (str): system-generated config data from training source. **Do not change**
        exported_column_info (str): system-generated column information from training source. **Do not change**

    Returns:
        A CentroidDistanceTransformationStep object

    :Example:
    >>> source = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> column_set = source.create_column_set(
    ...    column_list=['relative weight','blood glucose','clinical classification'],
    ...    name='column_set_centroid1')
    >>> network = source.create_network("test_network1",{
    ...    'metric': {'id': 'Correlation'},
    ...    'column_set_id': column_set['id'],
    ...    'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
    ...                'equalize': True, 'gain': 3.0}
    ...               ]
    ...    })
    >>> autogroups = network.autogroup_create(name="auto")
    >>> t = CentroidDistanceTransformationStep(
    ...    description='description',
    ...    network=network,
    ...    prefix='CD',
    ...    groups=autogroups)
    >>> tc = TransformationConfiguration.create(connection, 'description',t)
    >>> source = tc.apply(source_id=source.id, new_source_name='')
    >>> source.sync()
    >>> len(source.column_names)
    12
    >>> connection.delete_source(id=source.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 groups=None,
                 network=None,
                 groupset_id=None,
                 network_id=None,
                 prefix=None,
                 exported_config_data=None,
                 exported_column_info=None):
        super(CentroidDistanceTransformationStep, self).__init__(
            description,
            function='centroid_distance',
            column_name=None,
            column_index=None,
            new_column_name=None,
            virtual=False)  # virtual is not currently supported
        if all(v is None for v in {groups, groupset_id}):
            raise ValueError('Expected either groups or groupset_id args')
        if all(v is None for v in {network, network_id}):
            raise ValueError('Expected either network or network_id args')
        if all(v is not None for v in {network, network_id}):
            raise ValueError("Do not pass both network and network_id. Only pass one of them")
        if groupset_id:
            self.groupset_id = groupset_id
        else:
            self.groupset_id = groups.id

        if network is not None:
            warnings.warn("Deprecated: pass network_id instead.")
            network_id = network.id

        self.network_id = network_id
        self.prefix = prefix
        self.exported_config_data = exported_config_data
        self.exported_column_info = exported_column_info

    def _serialize(self):
        data = super(CentroidDistanceTransformationStep, self)._serialize()
        data['groupset_id'] = self.groupset_id
        data['network_id'] = self.network_id
        data['prefix'] = self.prefix
        if self.exported_config_data:
            data['exported_config_data'] = self.exported_config_data
        if self.exported_column_info:
            data['exported_column_info'] = self.exported_column_info
        return data


class CountVectorTFIDFTransformationStep(TransformationStep):
    """
    Calculate TFIDF values based on counts contained in columns. For example, the source
    file will contain columns which represent terms in a corpus. Each row represents a
    single document. The values of these columns are the counts of those terms in the
    given document. The number of new columns generated is the same as the number of
    columns in the column set.

    Args:
        description (str): describes the desired transformation
        column_set: (must use column_set or column_set_id) a reference to a column set,
                   these are the columns which contain the count vectors
        column_set_id: (optional with column_set) a column set id
        norm: (str) optional. Default=None. apply normalization to output values,
            supported values are 'None', 'L1', 'L2'.
            None: no normalization is applied.
            L1: sum of values must equal 1.
            L2: sum of squares of values must equal 1.
        smooth_idf: (bool) optional. Default=False. changes the calculation for idf as follows:
            if False, uses standard idf calculation: log10(N / df(t)+1)
            if True, uses modified idf calculation: log10(N+1 / df(t)+1) + 1
        sublinear_tf: (bool) optional. Default=False. If True, changes TF calculation to
                      use: tf = 1 + log10(tf)
        idf_list: (list) optional. If present, use custom IDF weights. Number of values
            and order must be the same as the natural index order of the columns in column_set.
        prefix (str): optional. The prefix added to the new column names. Default is 'tfidf'.
        exported_config_data (str): system-generated config data from training source. **Do not change**
        exported_column_info (str): system-generated column information from training source. **Do not change**

    Returns:
        A CountVectorTFIDFTransformationStep object

    :Example:
    >>> source = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> column_set = source.create_column_set(name='cset1', column_list=range(2, 6))
    >>> t = CountVectorTFIDFTransformationStep(
    ...        description='description',
    ...        norm=None,
    ...        column_set=column_set)
    >>> tc = TransformationConfiguration.create(connection, 'description',t)
    >>> source = tc.apply(source_id=source.id, new_source_name='')
    >>> source.sync()
    >>> len(source.column_names)
    11
    >>> connection.delete_source(id=source.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 norm=None,
                 column_set=None,
                 column_set_id=None,
                 prefix=None,
                 smooth_idf=None,
                 sublinear_tf=None,
                 idf_list=None,
                 exported_config_data=None,
                 exported_column_info=None):
        super(CountVectorTFIDFTransformationStep, self).__init__(
            description,
            function='count_vector_tfidf',
            column_name=None,
            column_index=None,
            new_column_name=None,
            virtual=True)  # only virtual
        if column_set is None and column_set_id is None:
            raise ValueError('Expected either column_set or column_set_id args')
        if column_set_id:
            self.column_set_id = column_set_id
        else:
            self.column_set_id = column_set['id']

        self.prefix = prefix
        self.norm = norm
        self.smooth_idf = smooth_idf
        self.sublinear_tf = sublinear_tf
        self.idf_list = idf_list
        self.exported_config_data = exported_config_data
        self.exported_column_info = exported_column_info

    def _serialize(self):
        data = super(CountVectorTFIDFTransformationStep, self)._serialize()
        data['column_set_id'] = self.column_set_id
        data['prefix'] = self.prefix
        data['norm'] = self.norm
        data['smooth_idf'] = self.smooth_idf
        data['sublinear_tf'] = self.sublinear_tf
        data['idf_list'] = self.idf_list
        if self.exported_config_data:
            data['exported_config_data'] = self.exported_config_data
        if self.exported_column_info:
            data['exported_column_info'] = self.exported_column_info
        return data


class PointwiseDistanceTransformationStep(TransformationStep):
    """
    Calculate the metric distance between the dataset and each row in a group.

    Args:
        description (str): describes the desired transformation
        group_id: a group id
        column_set_id: a column set id
        metric: the metric specification, it follows the same format as for networks
        prefix (str): optional. The prefix added to the new column names.
        exported_config_data (str): system-generated config data from training source. **Do not change**
        exported_column_info (str): system-generated column information from training source. **Do not change**

    Returns:
        A PointwiseDistanceTransformationStep object

    :Example:
    >>> source = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> column_set = source.create_column_set(
    ...    column_list=['relative weight','blood glucose','clinical classification'],
    ...    name='column_set_centroid1')
    >>> group1 = source.create_group(name="test_group1", row_indices=list(range(2)))
    >>> t = PointwiseDistanceTransformationStep(
    ...     description='description',
    ...     prefix='pointwise',
    ...     group_id=group1['id'],
    ...     column_set_id=column_set['id'],
    ...     metric={'id': 'Correlation'})
    >>> tc = TransformationConfiguration.create(connection, 'description',t)
    >>> source = tc.apply(source_id=source.id, new_source_name='')
    >>> source.sync()
    >>> len(source.column_names)
    9
    >>> connection.delete_source(id=source.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 group_id=None,
                 column_set_id=None,
                 prefix=None,
                 metric=None,
                 exported_config_data=None,
                 exported_column_info=None):
        super(PointwiseDistanceTransformationStep, self).__init__(
            description,
            function='pointwise_distance',
            column_name=None,
            column_index=None,
            new_column_name=None,
            virtual=False)  # no virtual

        self.prefix = prefix
        self.group_id = group_id
        self.column_set_id = column_set_id
        self.metric = metric
        self.exported_config_data = exported_config_data
        self.exported_column_info = exported_column_info

    def _serialize(self):
        data = super(PointwiseDistanceTransformationStep, self)._serialize()
        data['column_set_id'] = self.column_set_id
        data['prefix'] = self.prefix
        data['group_id'] = self.group_id
        data['metric'] = self.metric
        if self.exported_config_data:
            data['exported_config_data'] = self.exported_config_data
        if self.exported_column_info:
            data['exported_column_info'] = self.exported_column_info
        return data


class AppendLensValuesTransformationStep(TransformationStep):
    """
    Append columns representing lens value calculations.

    Args:
        description (str): describes the desired transformation
        new_column_names (list): a list of the new columns names. The number of names must
            match the number of lens_params specified
        column_set_id: a column set id for the columns used in the lens calculations
        lens_params (list): list of metric/lens pairs. The number must match the number of
            new_column_names. The format is as follows: [{'lens_id' : 'Median', 'metric_id' : 'Correlation'}]

    Returns:
        A AppendLensValuesTransformationStep object

    :Example:
    >>> source = connection.upload_source("./test/db_test2.txt", allow_duplicate=True) #ignore-in-doc
    >>> column_set = source.create_column_set(
    ...    column_list=['relative weight','blood glucose','clinical classification'],
    ...    name='column_set_lens1')
    >>> t = AppendLensValuesTransformationStep(
    ...     description='description',
    ...     column_set_id=column_set['id'],
    ...     new_column_names=['new_column1'],
    ...     lens_params=[{'lens_id' : 'Median', 'metric_id' : 'Correlation'}] )
    >>> tc = TransformationConfiguration.create(connection, 'description',t)
    >>> source = tc.apply(source_id=source.id, new_source_name='')
    >>> source.sync()
    >>> len(source.column_names)
    8
    >>> connection.delete_source(id=source.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 new_column_names=None,
                 column_set_id=None,
                 lens_params=None,
                 exported_config_data=None,
                 exported_column_info=None):
        super(AppendLensValuesTransformationStep, self).__init__(
            description,
            function='lens_values',
            column_name=None,
            column_index=None,
            new_column_name=None,
            virtual=False)  # no virtual

        self.new_column_names = new_column_names
        self.lens_params = lens_params
        self.column_set_id = column_set_id
        self.exported_config_data = exported_config_data
        self.exported_column_info = exported_column_info

    def _serialize(self):
        data = super(AppendLensValuesTransformationStep, self)._serialize()
        data['column_set_id'] = self.column_set_id
        data['new_column_names'] = self.new_column_names
        data['lens_params'] = self.lens_params
        if self.exported_config_data:
            data['exported_config_data'] = self.exported_config_data
        if self.exported_column_info:
            data['exported_column_info'] = self.exported_column_info
        return data


class StringSplitTransformationStep(TransformationStep):
    """
    Convert a single string column into multiple columns using string splitting and regexes. Only one type of splitting
    is supported at a time: pattern, separator, or substring.

    Args:
        description (str): describes the desired transformation
        column_name: the name of the source string column.
        pattern: a regular expression with embedded capture groups. Each group will be put into a new column. This
            expects Java regular expression syntax. Example: pattern='(\d+)_(\w+)' will transform the input '1234_abcd'
            into two new columns with values '1234' and 'abcd'.
        separator: the source column will be split on this separator string and each part put into a new column.
        substring: a tuple or list consisting of: start index and span, example: (0,4)
        prefix (str): required. The prefix added to the new column names. new columns will be <prefix>1, <prefix>2, etc.

    Returns:
        A StringSplitTransformationStep object

    :Example:
    >>> source = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> t = StringSplitTransformationStep(
    ...     description = 'description',
    ...     column_name = 'relative weight',
    ...     separator ='.',
    ...     prefix = 'prefix')
    >>> tc = TransformationConfiguration.create(connection, 'description',t)
    >>> source = tc.apply(source_id=source.id, new_source_name='')
    >>> source.sync()
    >>> len(source.column_names)
    9
    >>> connection.delete_source(id=source.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 column_name,
                 pattern=None,
                 separator=None,
                 substring=None,
                 prefix=None,
                 exported_config_data=None,
                 exported_column_info=None):
        super(StringSplitTransformationStep, self).__init__(
            description,
            function='string_split',
            column_name=column_name,
            column_index=None,
            new_column_name=None,
            virtual=False)  # no virtual

        self.prefix = prefix
        self.pattern = pattern
        self.separator = separator
        self.substring = substring
        self.exported_config_data = exported_config_data
        self.exported_column_info = exported_column_info

    def _serialize(self):
        data = super(StringSplitTransformationStep, self)._serialize()
        data['pattern'] = self.pattern
        data['separator'] = self.separator
        data['substring'] = self.substring
        data['prefix'] = self.prefix
        if self.exported_config_data:
            data['exported_config_data'] = self.exported_config_data
        if self.exported_column_info:
            data['exported_column_info'] = self.exported_column_info
        return data


class ExpressionTransformationStep(TransformationStep):
    """
    Enables use of a math expression to transform one or more values in this row. There are two ways to use this:
    One, pass in a column_name or column_index parameter. This will be used as the 'x' variable in the expression.
    This allows expressions such as "1/x", "1-x", "ln(x) * x", and so forth. Many common mathematical functions are
    available to use in the expression. Second, if column_name and column_index are None, then you can use the column
    names as variables in the expression, as long as you surround it with square brackets []. For example,
    "[weight] * [height]". Note that whitespace and special characters in column names is OK, the system will mitigate
    whitespace and special characters automatically. For a list of all supported math functions, see the mXparser
    page: http://mathparser.org/mxparser-math-collection/

    Args:
        description (str): Description of the transformation
        column_name (str): Name of the column to use as 'x' in the expression. Optional with column_index
        column_index (int): Index of the column to use as 'x'. Optional with column_name
        new_column_name (str): Name of the transformed column. Required.
        expression (str): A mathematical expression. If using the column_name or column_index, use the variable 'x'. If
            using multiple source columns, use the column name surrounded with square brackets [],
            like '[relative weight]'.

    Returns:
        A ExpressionTransformationStep object

    :Example:
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = ExpressionTransformationStep(
    ...     description='math expression',
    ...     column_name='relative weight',
    ...     new_column_name='expression1',
    ...     expression="ln(x) * x")
    >>> # Set up the transformation configuration
    >>> tc = TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.name
    'db_test2_new'
    >>> new_source.column_names[7]
    'expression1'
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 column_name=None,
                 column_index=None,
                 new_column_name=None,
                 expression=None,
                 virtual=True):
        super(ExpressionTransformationStep, self).__init__(
            function='math_expression',  # _v will be added by the framework because virtual=True
            description=description,
            column_name=column_name,
            column_index=column_index,
            new_column_name=new_column_name,
            virtual=True)
        self.expression = expression

    def _serialize(self):
        data = super(ExpressionTransformationStep, self)._serialize()
        data['expression'] = self.expression
        return data


class SliceTransformationStep(TransformationStep):
    """
    Keep or remove columns in the source. This transform requires a new_source_name be specified in the
    TransformationConfig. Supports specifying a column set, a column name list, or column index list. Can also use a
    delete flag, which indicates if the column list is to keep or delete.

    Args:
        description (str): Description of the transformation
        column_set_id: the ID of the columns set. Optional with column_names or column_indices.
        column_names (list): list of columns names to include. Optional with column_set_id or column_indices
        column_indices (list): list of column indices to include. Optional with column_set_id or column_names
        delete (bool): (default False) If true, this list of columns will be deleted.
            If false (default) the column list will be kept and all other columns removed. Optional.

    Returns:
        A SliceTransformationStep object

    :Example:
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> column_set = src.create_column_set(column_list=list(range(2)), name='test_column_set')
    >>> # Create a transformation step
    >>> transform_step = SliceTransformationStep(
    ...     description='slice',
    ...     column_set_id=column_set['id'])
    >>> # Set up the transformation configuration
    >>> tc = TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.column_names
    ['ID', 'relative weight']
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 column_set_id=None,
                 column_names=None,
                 column_indices=None,
                 delete=False):
        super(SliceTransformationStep, self).__init__(
            function='slice',
            description=description,
            column_name=None,
            column_index=None,
            new_column_name=None,
            virtual=False)
        self.column_set_id = column_set_id
        self.column_names = column_names
        self.column_indices = column_indices
        self.delete = delete

    def _serialize(self):
        data = super(SliceTransformationStep, self)._serialize()
        data['column_set_id'] = self.column_set_id
        data['column_names'] = self.column_names
        data['column_indices'] = self.column_indices
        data['delete'] = self.delete
        return data


class LinearFitTransformationStep(TransformationStep):
    """
    Determine the linear polynomial and find the slope and y-intercept that fits the given points. The
    xValues is 1, 2, 3, ... and the corresponding yValues is in either column names or column indices.
    The newly created columns are "slope" and "yIntercept".

    Args:
        description (str): Description of the transformation
        column_names (list of str): Names of the column to transform. Supports comma-separated list as well as
        \* wildcard. Example: col1, col2, col3, col\*. Optional with column_indices.
        column_indices (list): Indices of the columns to transform.
            Supports comma-separated lists as well as ranges with a -.
            Example: 1-5,33-65. Optional with column_names.

    Returns:
        A LinearFitTransformationStep object

    :Example:
    >>> src = connection.upload_source("./test/db_test2.txt") #ignore-in-doc
    >>> # Create a transformation step
    >>> transform_step = LinearFitTransformationStep(
    ...     description='linear fit',
    ...     column_names=['relative weight', 'blood glucose'])
    >>> # Set up the transformation configuration
    >>> tc = TransformationConfiguration.create(
    ...     connection,
    ...     'description',
    ...     transform_step)
    >>> new_source = tc.apply(source_id=src.id,
    ...                       new_source_name='db_test2_new')
    >>> new_source.sync()
    >>> new_source.column_names[7:]
    ['slope', 'yIntercept']
    >>> connection.delete_source(id=new_source.id) # ignore-in-doc
    >>> connection.delete_source(id=src.id) # ignore-in-doc
    """

    def __init__(self,
                 description,
                 column_names=None,
                 column_indices=None,
                 virtual=True):
        super(LinearFitTransformationStep, self).__init__(
            function='linearfit',
            description=description,
            virtual=True)
        self.column_names = column_names
        self.column_indices = column_indices

    def _serialize(self):
        data = super(LinearFitTransformationStep, self)._serialize()
        data['column_names'] = self.column_names
        data['column_indices'] = self.column_indices
        return data
