#!/usr/bin/env python
"""

Class :class:`DataPointList` provides data in rows.

.. autosummary::

  DataPointList
  DataPointList.points
  DataPointList.serialize
"""
from ayasdi.core.data_spec import DataSpec


class DataPointList(DataSpec):
    def __init__(self, points=None):
        self._points = points

    @property
    def points(self):
        """
        A list of data points. Each data point is a list of values (integers,
        floating point numbers, strings, or datetimes).
        """
        return self._points

    @points.setter
    def points(self, val):
        self._points = val

    def serialize(self):
        """
        Converts the instance to a dictionary
        """
        dictionary = {
            'points': self.points,
        }
        return {'data_point_list': dictionary}
