#!/usr/bin/env python
"""

:doc:`LABS Feature <labs>` -- The :class:`ayasdi.core.unsupervised_analysis.auto_network_spec.AutoNetworkSpec` class
is used to refine the scope of the networks to be created via AutoAnalysis.

**AutoNetworkSpec Class Functions:**
    .. autosummary::

        AutoNetworkSpec
        AutoNetworkSpec.number_of_networks_returned
        AutoNetworkSpec.analysis_method
        AutoNetworkSpec.gain
        AutoNetworkSpec.resolution
        AutoNetworkSpec.equalize
        AutoNetworkSpec.disjoint
        AutoNetworkSpec.metric_filter
        AutoNetworkSpec.lens_filter

"""
from ayasdi.core.unsupervised_analysis.analysis_method import AnalysisMethod


class AutoNetworkSpec(object):
    def __init__(
            self,
            number_of_networks_returned=6,
            analysis_method=AnalysisMethod.DEFAULT,
            gain=None,
            resolution=None,
            equalize=None,
            disjoint=None,
            metric_filter=None,
            lens_filter=None
    ):
        self.__number_of_networks_returned = number_of_networks_returned
        self.__analysis_method = analysis_method

        self.__number_of_networks_evaluated = None
        self.__network_creation_method = None
        self.__max_number_of_singletons = None
        self.__max_number_of_groups = None
        self.__max_number_of_connected_components = None
        self.__algorithm_for_group_creation = None

        self.__gain = gain
        self.__resolution = resolution
        self.__equalize = equalize
        self.__disjoint = disjoint
        self.__metric_filter = metric_filter
        self.__lens_filter = lens_filter

    @property
    def number_of_networks_returned(self):
        return self.__number_of_networks_returned
    """
        You can provide criteria for the number of networks to be returned, speed & depth of analysis method, metrics to 
        include or avoid, lenses to include or avoid, and typical network parameters such as `gain`, `resolution`, `equalize`, 
        and `disjoint`. The AutoNetworkSpec object is passed via the AutoAnalysis ``auto_network_spec`` parameter.
    """

    @number_of_networks_returned.setter
    def number_of_networks_returned(self, value):
        self.__number_of_networks_returned = value

    @property
    def analysis_method(self):
        return self.__analysis_method
    """
    There are three types of AnalysisMethod Specs: DEFAULT, FAST, and  EXHAUSTIVE. Each of these affect 
    the number of candidate metrics and lenses processed by the code, in order to provide the user with the best scoring ones. 
    FAST, DEFAULT, and EXHAUSTIVE add increasing number of candidates among which users seek optimal network suggestions.      
    """

    @analysis_method.setter
    def analysis_method(self, value):
        self.__analysis_method = value

    @property
    def gain(self):
        return self.__gain

    @gain.setter
    def gain(self, value):
        self.__gain = value

    @property
    def resolution(self):
        return self.__resolution

    @resolution.setter
    def resolution(self, value):
        self.__resolution = value

    @property
    def equalize(self):
        return self.__equalize

    @equalize.setter
    def equalize(self, value):
        self.__equalize = value

    @property
    def disjoint(self):
        return self.__disjoint

    @disjoint.setter
    def disjoint(self, value):
        self.__disjoint = value

    @property
    def metric_filter(self):
        return self.__metric_filter

    @metric_filter.setter
    def metric_filter(self, value):
        self.__metric_filter = value

    @property
    def lens_filter(self):
        return self.__lens_filter

    @lens_filter.setter
    def lens_filter(self, value):
        self.__lens_filter = value

    def serialize(self):
        """
        Converts an :class:`ayasdi.core.unsupervised_analysis.auto_network_spec.AutoNetworkSpec` object into a
        dictionary.
        """
        res = {
            'number_of_networks_returned': self.number_of_networks_returned,
            'analysis_method': self.analysis_method,
            'gain': self.gain,
            'resolution': self.resolution,
            'equalize': self.equalize,
            'disjoint': self.disjoint,
            'metric_filter': self.metric_filter.serialize() if self.metric_filter is not None else None,
            'lens_filter': self.lens_filter.serialize() if self.lens_filter is not None else None,
        }
        return res
