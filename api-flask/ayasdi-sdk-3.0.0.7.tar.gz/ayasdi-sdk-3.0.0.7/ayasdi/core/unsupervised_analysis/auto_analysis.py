#!/usr/bin/env python
"""

:doc:`LABS Feature <labs>` -- The :class:`ayasdi.core.unsupervised_analysis.AutoAnalysis` class performs
unsupervised autoanalysis. Use it to create and compare several networks for hyper-parameter optimization, or
to compare several other networks.

To begin the operation, import SourceSubset, AutoAnalysis, and AutoNetworkSpec as shown below.

To view the list of network objects created, use :class:`ayasdi.core.async_jobs.AsyncJob.get_result`.
The platform returns a list of :class:`ayasdi.core.networks.Network` objects.

**AutoAnalysis Class Functions**
    .. autosummary::

        AutoAnalysis
        AutoAnalysis.unsupervised_score
        AutoAnalysis.unsupervised_scores
        AutoAnalysis.unsupervised_features
        AutoAnalysis.unsupervised_auto_analysis
        AutoAnalysis.unsupervised_auto_analysis_async

"""

from __future__ import absolute_import, unicode_literals, division, print_function

import logging
import warnings

import ayasdi.core.async_jobs as aca
import ayasdi.core.networks as acn
import ayasdi.core.source as acs
from ayasdi.core import json_funcs
from ayasdi.core import message_funcs
from ayasdi.core.score import Score
from ayasdi.core.unsupervised_analysis.auto_network_spec import AutoNetworkSpec

LOGGER = logging.getLogger(__name__)


class AutoAnalysis(object):
    """
    """

    def __init__(self, connection):
        """
        Initializes autoanalysis.

        Args:


        Returns:


        :Example:

        """
        self.connection = connection

    def unsupervised_score(self, network_id):
        """
    Returns the score of a specified network as a floating point number between 0.0 and 5.0.
    The higher the number, the more interesting the graph.

    Args:
        network_id (str or int): The network identifier

    Returns:
        Score object: :class:`ayasdi.core.score.Score`

    :Example:

        >>> import uuid
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> columns = ["relative weight", "blood glucose",
        ...            "insulin level", "insulin response"]
        >>> col_set = src.create_column_set(columns, 'col_set' + str(uuid.uuid4()))
        >>> network = src.create_network('network' + str(uuid.uuid4()),{
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': col_set['id'],
        ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 30, 'id': 'MDS coord 2',
        ...                   'equalize': True, 'gain': 3.0}]
        ...        }
        ... )
        >>> aa = AutoAnalysis(connection)
        >>> score = aa.unsupervised_score(network.id)
        >>> connection.delete_source(src.id) #ignore-in-doc
        """
        warnings.warn(message_funcs._show_labs())

        request = {'network_identifiers': [network_id]}
        response = json_funcs._post_(
            self.connection.session,
            self.connection.CORE_REQUEST_STUB + 'auto_analysis/unsupervised_scores',
            request)
        return Score(**response['scores'][0])

    def unsupervised_scores(self, network_identifiers, rank=True):
        """
    Returns the scores of several networks, each as a floating point number between 0.0 and 5.0.
    The higher the number, the more interesting the graph. Ranking is enabled by default.

    Args:
        network_identifiers ([str] or [int]): list of identifiers for networks to be scored
        rank (bool): when True, ranks the specified networks, sorting from highest to lowest score

    Returns:
        A list of :class:`ayasdi.core.score.Score` including the network identifier and the network score,
        sorted by score when rank=True.
        For example:
            [
                {"score": 2.0372139473756152, "params": "{}", "type": "UNSUPERVISED"}, \n
                {"score": 0.5395769536495209, "params": "{}", "type": "UNSUPERVISED"}
            ]

    :Example:


        >>> from ayasdi.core.unsupervised_analysis import AutoAnalysis
        >>> import uuid
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> columns = ["relative weight", "blood glucose",
        ...            "insulin level", "insulin response"]
        >>> col_set = src.create_column_set(columns, 'col_set' + str(uuid.uuid4()))
        >>> network1 = src.create_network('network' + str(uuid.uuid4()),{
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': col_set['id'],
        ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 30, 'id': 'MDS coord 2',
        ...                   'equalize': True, 'gain': 3.0}]
        ...        }
        ... )
        >>> network2 = src.create_network('network' + str(uuid.uuid4()),{
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': col_set['id'],
        ...        'lenses': [{'resolution': 50, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 4.0},
        ...                   {'resolution': 50, 'id': 'MDS coord 2',
        ...                   'equalize': True, 'gain': 4.0}]
        ...        }
        ... )
        >>> aa = AutoAnalysis(connection)
        >>> scores = aa.unsupervised_scores([network1.id, network2.id])
        >>> print(scores) # doctest:+ELLIPSIS
        [...]
        >>> score1 = scores[0]
        >>> print(score1.score) # doctest:+ELLIPSIS
        2...
        >>> connection.delete_source(src.id) #ignore-in-doc
        """
        warnings.warn(message_funcs._show_labs())

        request = {'network_identifiers': network_identifiers}
        response = json_funcs._post_(
            self.connection.session,
            self.connection.CORE_REQUEST_STUB + 'auto_analysis/unsupervised_scores',
            request)
        scores = [Score(**s) for s in response['scores']]
        if rank:
            scores = sorted(scores, key=lambda x: -x.score)
        return scores

    def unsupervised_features(self, network_identifiers):
        """
    Returns the features of a list of networks.

    Args:
        network_identifiers ([int] or [str]): A list of network identifiers

    **Return Type:**
        A map from network identifiers to network DNN features, similar to the following:

            ``{u'-5993697280436049338': [0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472,``
            ``0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472,``
            ``0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472,``
            ``0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,``
            ``0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.6931472,``
            ``0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472,``
            ``0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472,``
            ``0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472, 0.6931472,``
            ``0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,``
            ``0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0986123, 2.0794415, 3.2580965, 4.5217886, 5.8230457,``
            ``2.0794415, 3.2580965, 4.5217886, 5.8230457, 7.145196, 3.2580965, 4.5217886, 5.8230457,``
            ``7.145196, 8.481773, 4.5217886, 5.8230457, 7.145196, 8.481773, 9.829411, 5.8230457, 7.145196,``
            ``8.481773, 9.829411, 11.1857815, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,``
            ``0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]}``

    :Example:


        >>> from ayasdi.core.unsupervised_analysis.auto_analysis import AutoAnalysis
        >>> import uuid
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> columns = ["relative weight", "blood glucose",
        ...            "insulin level", "insulin response"]
        >>> col_set = src.create_column_set(columns, 'col_set' + str(uuid.uuid4()))
        >>> network1 = src.create_network('network' + str(uuid.uuid4()),{
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': col_set['id'],
        ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 30, 'id': 'MDS coord 2',
        ...                   'equalize': True, 'gain': 3.0}]
        ...        }
        ... )
        >>> aa = AutoAnalysis(connection)
        >>> score = aa.unsupervised_features([network1.id])
        >>> connection.delete_source(src.id) #ignore-in-doc
        """
        warnings.warn(message_funcs._show_labs())

        request = {'network_identifiers': network_identifiers}
        response = json_funcs._post_(
            self.connection.session,
            self.connection.CORE_REQUEST_STUB + 'auto_analysis/unsupervised_features',
            request)
        return response['features']

    def unsupervised_auto_analysis(self, data_spec, auto_network_spec=AutoNetworkSpec()):
        """
    Analyzes the data source and generates a ranked list suggested network objects.

    Args:
        data_spec (sub class of :class:`ayasdi.core.data_spec.DataSpec`): defines the SourceSubset. Required
        auto_network_spec (obj): (AutoNetworkSpec obj): an
            :class:`ayasdi.core.unsupervised_analysis.auto_network_spec.AutoNetworkSpec` object
            that refines the scope of the networks to be created via ``AutoAnalysis``. You can provide criteria for
            the number of networks to be returned, speed and depth of analysis method, metrics to include or
            avoid, lenses to include or avoid, and typical network parameters such as `gain`, `resolution`, `equalize`,
            and `disjoint`. Optional, if absent a default
            :class:`ayasdi.core.unsupervised_analysis.auto_network_spec.AutoNetworkSpec` object.

    Returns:
        A list of suggested network objects.

    :Example:

        >>> from ayasdi.core.unsupervised_analysis.auto_analysis import AutoAnalysis
        >>> from ayasdi.core.unsupervised_analysis.auto_network_spec import AutoNetworkSpec
        >>> from ayasdi.core.unsupervised_analysis.analysis_method import AnalysisMethod
        >>> from ayasdi.core import SourceSubset
        >>> import uuid
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> columns = ["relative weight", "blood glucose",
        ...            "insulin level", "insulin response"]
        >>> col_set = src.create_column_set(columns, 'col_set' + str(uuid.uuid4()))
        >>> aa = AutoAnalysis(connection)
        >>> networks = aa.unsupervised_auto_analysis(
        ...     data_spec=SourceSubset(source_id=src.id, column_set_id=col_set['id']),
        ...     auto_network_spec=AutoNetworkSpec(analysis_method=AnalysisMethod.DEFAULT)
        ...     )
        >>> connection.delete_source(src.id) #ignore-in-doc
        """
        return self.unsupervised_auto_analysis_async(
            data_spec=data_spec,
            auto_network_spec=auto_network_spec)\
            .get_result()

    def unsupervised_auto_analysis_async(self, data_spec, auto_network_spec=AutoNetworkSpec()):
        """
    Performs unsupervised analysis against the data source and generates a ranked list of possible networks.

    Args:
        data_spec (obj) : defines the SourceSubset (see :class:`ayasdi.core.data_spec.DataSpec`). Required
        auto_network_spec (obj): limits network parameters
            (see :class:`ayasdi.core.unsupervised_analysis.auto_network_spec.AutoNetworkSpec`). Optional,
            if absent, a default :class:`ayasdi.core.unsupervised_analysis.auto_network_spec.AutoNetworkSpec` object.

    Returns:
        An instance of :class:`ayasdi.core.async_jobs.AsyncJob` that holds a list of suggested networks of
        interest. To view the list, use :class:`ayasdi.core.async_jobs.AsyncJob.get_result`. The platform
        returns a list of :class:`ayasdi.core.networks.Network` objects.

    :Example:

        >>> from ayasdi.core.unsupervised_analysis import AutoAnalysis, AutoNetworkSpec, AnalysisMethod
        >>> from ayasdi.core import SourceSubset
        >>> import uuid
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> columns = ["relative weight", "blood glucose",
        ...            "insulin level", "insulin response"]
        >>> col_set = src.create_column_set(columns, 'col_set' + str(uuid.uuid4()))
        >>> aa = AutoAnalysis(connection)
        >>> future = aa.unsupervised_auto_analysis_async(
        ...     data_spec=SourceSubset(source_id=src.id, column_set_id=col_set['id']),
        ...     auto_network_spec=AutoNetworkSpec(analysis_method=AnalysisMethod.DEFAULT)
        ...     )
        >>> networks = future.get_result()
        >>> connection.delete_source(src.id) #ignore-in-doc
        """
        warnings.warn(message_funcs._show_labs())

        src = acs.Source(self.connection, source_info={'id': data_spec.source_id})
        src.sync()

        request = {
            'data_spec': data_spec.serialize(),
            'auto_network_spec': auto_network_spec.serialize(),
        }
        url = self.connection.CORE_REQUEST_STUB + 'auto_analysis/unsupervised_auto_analysis/async'
        session = self.connection.session
        jobid = json_funcs._post_(session, url, request)
        return aca.AsyncJob(
            self.connection,
            jobid,
            url,
            result_converter=lambda rep: [acn.Network(src, net) for net in rep[u"networks"]])
