#!/usr/bin/env python
"""

:doc:`LABS Feature <labs>` -- The :class:`ayasdi.core.unsupervised_analysis.name_filter_spec.NameFilterSpec` class
defines the filtering criteria to be employed during unsupervised autoanalysis.

You can specify the metrics to include, metrics to avoid, or a particular metric to use.

The NameFilterSpec is passed via the :class:`ayasdi.core.unsupervised_analysis.auto_analysis.AutoAnalysis`
AutoNetworkSpec ``metric_filter`` parameter.

**NameFilterSpec Class Functions:**
    .. autosummary::

        NameFilterSpec
        NameFilterSpec.not_allowed
        NameFilterSpec.allowed
        NameFilterSpec.fixed


The following example provides all the code needed to load the unsupervised_analysis methods. To
print the networks created at the end of the example, use the ``print networks`` command.


:Example:

     >>> import ayasdi.core as ac
     >>> import ayasdi.core.models as acm
     >>> from ayasdi.core.unsupervised_analysis.auto_analysis import AutoAnalysis
     >>> from ayasdi.core.unsupervised_analysis import AutoNetworkSpec
     >>> from ayasdi.core.unsupervised_analysis import NameFilterSpec
     >>>
     >>> connection = ac.Api()
     >>> source = connection.get_source(id=8798624797604472510)
     >>> source.sync()
     >>> aa = AutoAnalysis(connection)
     >>> columns = ["balance", "net_worth", "transfer", "gender", "marital_status"]
     >>> column_set = source.create_column_set(columns, "test_column_set")
     >>> networks = aa.unsupervised_auto_analysis(
     ...    data_spec = ac.SourceSubset(source_id=source.id, column_set_id=column_set['id']),
     ...        auto_network_spec = AutoNetworkSpec(
     ...            disjoint=True,
     ...            metric_filter= NameFilterSpec(not_allowed=['Norm Correlation']))
     ...        )
        """


class NameFilterSpec(object):
    def __init__(
            self,
            not_allowed=None,
            allowed=None,
            fixed=None
    ):
        self._not_allowed = not_allowed
        self._allowed = allowed
        self._fixed = fixed

    @property
    def not_allowed(self):
        """
        Specifies metrics to be excluded from the filter spec
        """
        return getattr(self, '_not_allowed', None)

    @not_allowed.setter
    def not_allowed(self, val):
        self._not_allowed = val

    @property
    def allowed(self):
        """
        Specifies metrics to be included in the filter spec
        """
        return getattr(self, '_allowed', None)

    @allowed.setter
    def allowed(self, val):
        self._allowed = val

    @property
    def fixed(self):
        """
        Specifies that the flter spec should contain only these metrics
        """
        return getattr(self, '_fixed', None)

    @fixed.setter
    def fixed(self, val):
        self._fixed= val

    def serialize(self):
        """
        Converts an :class:`core.analysis.unsupervised_analysis.name_filter_spec.NameFilterSpec` object into a
        dictionary
        """
        res = {
            'not_allowed': self.not_allowed,
            'allowed': self.allowed,
            'fixed': self.fixed,
        }
        return res
