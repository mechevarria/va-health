#!/usr/bin/env python
"""

:doc:`LABS Feature <labs>` -- The :class:`ayasdi.core.unsupervised_analysis.AnalysisMethod` class specifies whether
the unsupervised analysis should optimize for speed or thoroughness when returning possible networks.

You can specify a FAST analysis, an EXHAUSTIVE analysis, or an output where the platform should return a number of networks
based on server logic (DEFAULT).

**AnalysisMethod Class Functions:**
    .. autosummary::

        AnalysisMethod
        AnalysisMethod.FAST
        AnalysisMethod.EXHAUSTIVE
        AnalysisMethod.DEFAULT

"""


class AnalysisMethod(object):
    FAST = "FAST"
    """
    Executes a simpler algorithm, returning fewer networks
    """

    EXHAUSTIVE = "EXHAUSTIVE"
    """
    Analyzes more options, returning a larger number of networks
    """

    DEFAULT = "DEFAULT"
    """
    Returns a number of networks based on server logic
    """
