#!/usr/bin/env python

"""Jobs class for the Ayasdi API.
   The Job object encapsulates the asynchronous job that is run using
   one of the following options.

"""
from __future__ import absolute_import, unicode_literals, division, print_function
import logging
import time

import requests

from ayasdi.core import json_funcs

LOGGER = logging.getLogger(__name__)


class Job(object):
    """ An instance of the Asynchronous Job class.
    Using the :func:`ayasdi.core.source.Source.create_network` function.
    The following variables are available for each job object:
     - id - The id of this job object
     - status - one of `in_progress`, `complete`, or `error`
     - json - The json returned by the REST Endpoint.
     - running_since - The timestamp indicating when
        the job is received by the backend.
     - running_for - The number of seconds that this job has been running for.

    Args:
        job_info: Job info requested by the API class.

    Returns:
        The Job object.

    :Example:

    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt")
    >>> columns = ["relative weight", "blood glucose",
    ...            "insulin level", "insulin response"]
    >>> col_set = src.create_column_set(columns, "test_column_set")
    >>> network_job = src.create_network("test_async_network",{
    ...        'metric': {'id': 'Norm Correlation'},
    ...        'column_set_id': col_set['id'],
    ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
    ...                    'equalize': True, 'gain': 3.0},
    ...                   {'resolution': 30, 'id': 'MDS coord 2',
    ...                   'equalize': True, 'gain': 3.0}]
    ...        },
    ...        async_=True
    ... )
    >>> # Wait until this job is completed if necessary.
    >>> # Most commonly, you'd do this polling later
    >>> while network_job.status == 'in_progress':
    ...    network_job.sync()
    >>> src.sync()
    >>> network = src.get_network(name="test_async_network")
    >>> src.delete_network(name="test_async_network")
    True
    >>> src.delete_column_set(name='test_column_set')
    True
    >>> extraglobs['network'] = network #ignore-in-doc
    >>> extraglobs['network_job'] = network_job #ignore-in-doc
    """
    def __init__(self, connection, job_info, **kwargs):
        self.elapsed_time = kwargs.get('elapsed_time', 0)
        self.connection = connection

        if kwargs.get('type') == 'new':
            self.curl = kwargs['uri']
            self.json = {}
            self.id = kwargs['id']
            self.status = 'in_progress'
            self.running_since = time.time()
            self.start_time = time.time()
            self.type = 'new'
        # old async endpoint
        else:
            if isinstance(job_info, list) and len(job_info) > 0:
                self.json = job_info[0]
            else:
                self.json = job_info

            for key, value in self.json.items():
                setattr(self, key, value)
            self.add_elapsed_time()
            self.curl = self.connection.CORE_REQUEST_STUB + 'jobs/%s' % self.id
            self.type = 'old'

    def __repr__(self):
        """String representation of the job.

        Tested in __init__
        """
        return "Job id %s (%s): Started: %s" % \
            (self.id, self.status, self.running_since)

    def serialize(self):
        """
        Converts a Job into a dictionary to be saved
        or exported to another thread or process.

        Returns:
            A dictionary containing the job kwargs.

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> columns = ["relative weight", "blood glucose",
        ...            "insulin level", "insulin response"]
        >>> col_set = src.create_column_set(columns, "test_column_set")
        >>> network_job = src.create_network("test_async_network",{
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': col_set['id'],
        ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 30, 'id': 'MDS coord 2',
        ...                   'equalize': True, 'gain': 3.0}]
        ...        },
        ...        async_=True
        ... )
        >>> # Wait until this job is completed if necessary.
        >>> # Most commonly, you'd do this polling later
        >>> serialized_network_job = network_job.serialize()
        >>> copied_network_job = Job(connection, **serialized_network_job)
        >>> while copied_network_job.status == 'in_progress':
        ...    copied_network_job.sync()
        >>> src.sync()
        >>> network = src.get_network(name="test_async_network")
        >>> src.delete_network(name="test_async_network")
        True
        >>> src.delete_column_set(name='test_column_set')
        True
        """

        if self.type == 'new':
            data = {'uri': self.curl,
                    'id': self.id,
                    'status': self.status,
                    'running_since': self.running_since,
                    'start_time': self.start_time,
                    'type': self.type,
                    'job_info': None}
        else:
            data = {'job_info': self.json}
        return data

    def sync(self):
        """Synchronizes the job class. Gets an update on the job and sets the status
        to `complete` if the job is done.

        :Example:
        See the blob above.
        """
        try:
            ret_job = json_funcs._get_(self.connection.session, self.curl)
        except requests.exceptions.HTTPError as e:
            LOGGER.exception(e)
            self.status = 'failed'
            raise Exception("Request failed with Error: {}".format(e.response.text))

        if self.type == 'new':
            # if the job has been populated on the back end
            if ret_job:
                if ret_job['finished']:
                    self.status = 'complete'
                self.json = ret_job['result']
        else:
            for key, value in ret_job.items():
                setattr(self, key, value)
            # If a job is completed, then the status variable is removed.
            if 'status' not in ret_job:
                self.status = 'complete'
            self.json = ret_job

        self.add_elapsed_time()

    def add_elapsed_time(self):
        """Calculates the time from the start. Called whenever the network is synced.

        :Example:

        >>> network_job = extraglobs['network_job'] #ignore-in-doc
        >>> network_job.add_elapsed_time()
        """
        running_ts = self.start_time / 1000
        self.running_since = time.strftime("%a %d %b %Y %H:%M:%S GMT",
                                           time.localtime(running_ts))
        self.running_for = int(time.time() * 1000) - running_ts
