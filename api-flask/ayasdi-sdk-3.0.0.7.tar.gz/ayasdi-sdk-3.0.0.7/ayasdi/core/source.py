#!/usr/bin/env python

from __future__ import absolute_import, unicode_literals, division, print_function

import datetime
import itertools
import json
import logging
import math
import os
import re
import shutil
import sys
import tempfile
import time
import warnings
import webbrowser
from collections import defaultdict
from itertools import islice

import six
from ayasdi.core import async_jobs
from ayasdi.core import file_funcs
from ayasdi.core import groupconfig
from ayasdi.core import jobs
from ayasdi.core import json_funcs
from ayasdi.core import message_funcs
from ayasdi.core import networks
from ayasdi.core import transformations
from ayasdi.core import utils
from ayasdi.core.async_jobs import AsyncJob
from ayasdi.core.top_explainers_filter_spec import TopExplainersFilterSpec
from ayasdi.core.utilities.source import subset
from ayasdi.core.models.random_forest_spec import RandomForestSpec
from ayasdi.core.models.unsupervised.anomaly import Anomaly, AnomalyFeatureWeightSpec, AnomalyRandomSampleSpec
from ayasdi.core.source_subset import SourceSubset
from requests import HTTPError
from requests_toolbelt import MultipartEncoder

LOGGER = logging.getLogger(__name__)


class Source(object):
    """
    Data source class for the Ayasdi API.

    A source is the primary representation of a dataset within Ayasdi. A Source object encapsulates an NxM rectangular
    dataset, where N is the number of rows, and M the number of columns. Sources are accessible to all users who belong
    to the same group, but can only be deleted either by the uploader or the group administrator.

    An instance of the Source class is created by the API connection, using either
    :func:`Api.upload_source <ayasdi.core.api.Api.upload_source>` or
    :func:`Api.get_source <ayasdi.core.api.Api.get_source>`

    Sources have the following attributes:
        - **columns**: provides a dictionary of the columns in the source with column information.
        - **colname_to_ids**: provides a dictionary of column names to the ID of the column. Expects headers to be
          unique. Fails if any headers are duplicated.
        - **id_to_colnames**: reverse mapping of the colname_to_ids dictionary.
        - **name**: source object name.
        - **id**: source ID.
        - **column_count**: Number of columns in the source.
        - **row_count**: Number of rows in the source.




    **AVAILABLE FUNCTIONS**

        Functions applied on the source class are split into the following major groups


    **Synchronize and show the UI**:

       .. autosummary::
          Source.sync
          Source.show


    **Selecting features and working with column sets**:

       .. autosummary::
          Source.select_features
          Source.create_column_set
          Source.get_column_sets
          Source.get_column_set
          Source.update_column_set
          Source.delete_column_set
          Source.delete_column_sets
          Source.share_column_set


    **Working with topological models (networks)**:

       .. autosummary::
          Source.get_valid_metrics
          Source.get_valid_lenses
          Source.get_auto_analysis_suggestions
          Source.create_network
          Source.create_network_async
          Source.outcome_auto_analysis
          Source.get_networks
          Source.get_network
          Source.delete_network
          Source.delete_networks
          Source.outcome_lens_param_optimization
          Source.outcome_affine_selector


    **Working with colorings**:

       .. autosummary::
          Source.create_coloring
          Source.get_colorings
          Source.get_coloring
          Source.delete_coloring
          Source.delete_colorings
          Source.share_coloring


    **Working with comparisons**:

       .. autosummary::
          Source.compare_groups
          Source.compare_multiple_groups
          Source.iter_compare_groups
          Source.get_comparisons
          Source.get_comparison
          Source.iter_get_continuous_comparison
          Source.iter_get_categorical_comparison
          Source.delete_comparison
          Source.delete_comparisons
          Source.rename_comparison
          Source.share_comparison

    **Working with groups (row subsets)**:

       .. autosummary::
          Source.create_group
          Source.get_groups
          Source.get_group
          Source.delete_group
          Source.delete_groups
          Source.rename_group
          Source.export
          Source.retrieve_subset_to_file
          Source.synchronize_retrieve_subset_to_file
          Source.create_group_set
          Source.get_group_sets
          Source.get_group_set
          Source.delete_group_set
          Source.delete_group_sets
          Source.rename_group_set
          Source.get_group_membership
          Source.append_group_membership
          Source.score_groups
          Source.share_group

    **Working with annotations**:

       .. autosummary::
          Source.annotate
          Source.get_annotations
          Source.get_annotation

    **Working with transformations**:

       .. autosummary::
          Source.get_transformation_sequence
          Source.get_transformation_config
          Source.get_transformed_sources

    **Getting descriptive stats**:

       .. autosummary::
          Source.get_group_features
          Source.get_stats
          Source.iter_correlation_stats

    **Working with charts**:

       .. autosummary::
          Source.create_chart
          Source.get_all_charts
          Source.get_chart
          Source.delete_chart
          Source.delete_charts
          Source.share_chart

    **Working with anomalies detection**:

       .. autosummary::
          Source.detect_anomalous_rows
          Source.detect_anomalous_rows_random_sample

    **Miscellaneous functions**:

       .. autosummary::
          Source.optimize_format
          Source.calculate_feature_weights
          Source.compute_feature_weights
          Source.create_filter_set
          Source.get_lens_values
          Source.export_metadata
          Source.import_metadata


    Args:
        source_info: Source information returned by the API

    Returns:
        The Source object :class:`ayasdi.core.source.Source`

    :Example:

    >>> import ayasdi.core as ac
    >>>
    >>> src = connection.upload_source("./test/db_test2.txt")
    >>> extraglobs['src'] = src #ignore-in-doc
    """

    def __init__(self, connection, source_info):
        """
        Creating a source class. Done through api.upload_data or api.get_source.
        """

        self.column_names = None
        self.colname_to_ids = None
        self.id_to_colnames = None
        for key, value in source_info.items():
            setattr(self, key, value)
        self.connection = connection
        self.json = source_info
        # for easy url access
        self.curl = self.connection.CORE_REQUEST_STUB + 'sources/%s' % self.id

        self.MAX_EXPORT_SIZE = 100000
        self.MIN_COLUMN_BATCH_SIZE = 1000

    def __repr__(self):
        """
        Returns a string containing a printable representation of an object.
        """
        return "<Source '%s'>" % self.name

    def __get_full_source__(self, ret_source=None):
        """
        Return the full source object, including networks, node groups, etc.

        :Example:

        as seen in :func:`sync`
        """

        if not ret_source:
            ret_source = json_funcs._get_(self.connection.session, self.curl)
        for key, value in ret_source.items():
            setattr(self, key, value)
        self.json = ret_source
        # mapping between column names and ids
        self.column_names = [col['name'] for col in self.columns]
        self.colname_to_ids = dict([(col['name'], col['index']) for col
                                    in self.columns])
        self.id_to_colnames = dict([(col['index'], col['name']) for col
                                    in self.columns])

    def __error__(self, msg, with_print=True):
        """Prints and returns error message."""
        msg = {'msg': msg}
        if with_print:
            print(msg)
        return msg

    # ## EXPORT HELPER FUNCTIONS ## #
    def _get_row_list(self, row_indices, row_range):
        if row_indices is not None and row_range is not None:
            row_indices = row_indices[row_range[0]: row_range[1]]
        elif row_range is not None:
            row_indices = list(range(row_range[0], row_range[1] + 1))
        elif row_indices is None:
            row_indices = list(range(0, self.row_count))
        return row_indices

    def _get_column_list(self, column_indices, column_range, use_given_order=False):
        if column_range is not None:
            col_indices = list(range(column_range[0], column_range[1] + 1))
        elif column_indices is None:
            col_indices = list(range(self.column_count))
        else:
            if not use_given_order:
                return sorted(list(set(column_indices)))
            else:
                return column_indices
        return col_indices

    def _get_column_batch_size(self, row_indices, row_range):
        """
        Column batch size will be 0 if row count is more than
        MAX_EXPORT_SIZE (this will be interpreted as
        no column batching). Else column batch size will be
        at least MIN_COLUMN_BATCH_SIZE
        """
        if row_indices is not None:
            row_count = len(row_indices)
        elif row_range is not None:
            row_count = row_range[1] - row_range[0]
        else:
            row_count = self.row_count
        if row_count <= 0:
            return self.MIN_COLUMN_BATCH_SIZE
        col_batch_size = int(math.floor(self.MAX_EXPORT_SIZE /
                                        float(row_count)))

        if 0 < col_batch_size < self.MIN_COLUMN_BATCH_SIZE:
            return self.MIN_COLUMN_BATCH_SIZE
        else:
            return col_batch_size

    def _get_column_batches(self, col_indices, row_indices, col_batch_size):
        if col_batch_size > 0:
            # batch rows
            col_batches = [col_indices[i:i + col_batch_size]
                           for i in range(0, len(col_indices), col_batch_size)]

            # row are all of the rows
            row_batches = [row_indices, ]

        # more than 100,000 rows
        else:
            # row batch is one row at a time
            col_batches = [[i] for i in col_indices]

            row_batches = [row_indices[i:i + self.MAX_EXPORT_SIZE]
                           for i in range(0, len(row_indices),
                                          self.MAX_EXPORT_SIZE)]

        return [col_batches, row_batches]

    def _get_range_batches(self, initial_range, max_batch_size):
        """
        This is helper method for _get_range_and_index_batches that fetches
        a generator for ranges.

        Args:
            initial_range (tuple): This specifes the (start, end) range
                to be batched
            max_batch_size (int): This is the maximum length of a range
                in a given batch.
        """
        total_count = int(initial_range[1] - initial_range[0])
        if total_count <= max_batch_size:
            batches = [initial_range]
        else:
            # Use six.moves.range, itertools, zip for memory-efficient iterators
            range_starts = six.moves.range(initial_range[0],
                                           initial_range[1],
                                           max_batch_size)
            range_ends = itertools.chain(six.moves.range(initial_range[0] + max_batch_size,
                                                         initial_range[1],
                                                         max_batch_size), [initial_range[1]])
            batches = six.moves.zip(range_starts, range_ends)
        return batches

    def _get_range_and_index_batches(self, initial_range, indices, max_batch_size):
        """
        This is a helper method for retrieve_subset_to_file.
        It gets batches of ranges or indexes (of rows or columns)
        to be fetched from the platform.
        Ranges are more efficient than indices memory-wise so ranges
        should be used when possible.

        Args:
            initial_range (tuple): This is a tuple of (start, end) that specifies
                the initial range
            indices ([int]): List of indices (of source or column)
            max_batch_size (int): Maximum number of indices, or length of range,
                in a single batch to be fetched form platform.
        """

        def _grouper(n, iterable):
            """
            See https://stackoverflow.com/questions/12185952/python-optimize-grouper-function-to-avoid-none-elements.
            This groups a list into multiple groups of the same size.

            Example:
            grouper(3, 'ABCDEFG', 'x') --> ABC DEF G
            """
            it = iter(iterable)
            return iter(lambda: tuple(islice(it, n)), ())

        range_batches = []
        index_batches = []
        if initial_range is not None:
            range_batches = self._get_range_batches(initial_range, max_batch_size)
        elif indices is not None:
            indices = sorted(set(indices))
            initial_range = (indices[0], indices[-1] + 1)

            # If the indices are contiguous we can represent as a range rather than
            # a full list, saving data sent up to the server. E.g. sending 1mil items
            # in a list vs sending just the range (0 to 999,999).
            if (indices[-1] - indices[0] + 1) == len(indices):
                range_batches = self._get_range_batches(initial_range, max_batch_size)
            else:
                index_batches = _grouper(max_batch_size, indices)
        return range_batches, index_batches

    def _post_retrieve_subset_to_file(self,
                                      file_name,
                                      file_type,
                                      param_dict,
                                      async_):
        """
        This is a helper method for retrieve_subset_to_file that
        makes the HTTP requests with parameterized data and returns
        a 2d array (list of lists) that includes either the async
        job info or the file names
        """
        if file_type == 'csv' and async_ is True:
            endpoint = self.curl + '/retrieve_subset/csv/async'
            result = json_funcs._post_(self.connection.session,
                                       endpoint,
                                       data=param_dict)
            job_info = {'job_id': result['jobId'],
                        'file_name': file_name}
            return job_info
        elif file_type == 'csv':
            endpoint = self.curl + '/retrieve_subset/csv'
            resp = file_funcs._post_download_(self.connection.session,
                                              endpoint,
                                              data=param_dict,
                                              file_name=file_name)
            if resp is True:
                return {'file_name': file_name}

    def _concatenate_csv_files(self, results, file_name):
        """
        This takes the resulting files from retrieve_subset_to_file and
        concatenates them into a single file
        Args:
            results: 2d array of dictionaries of file information
            file_name: name of resulting concatenated file to write to
        """
        output_file = open(file_name, 'w')
        results = list(zip(*results))
        for row in range(len(results)):
            files = []
            for file_info in results[row]:
                f = open(file_info['file_name'], 'r')
                if row != 0:
                    # Skip the header line for rows greater than 1
                    f.readline()
                if sys.version_info[0] < 3:
                    f_gen = (x.decode('utf-8').strip('\n\r') for x in f)  # generator
                else:
                    f_gen = (x.strip('\r\n') for x in f)
                files.append(f_gen)
            if len(files) == 0:
                return False
            for file_gen_zip in zip(*files):
                new_line = file_gen_zip[0]
                for piece in file_gen_zip[1:]:
                    # Remove the "Row ID" from column parts after the first
                    piece = re.sub(pattern="[^,]*,", repl=',', string=piece, count=1)
                    new_line += piece
                new_line += '\n'
                if sys.version_info[0] < 3:
                    output_file.write(new_line.encode('utf-8'))
                else:
                    output_file.write(new_line)
        return True

    def sync(self):
        """
        Force refreshs the current source, i.e. updates the current instance with any actions
        performed by other clients (e.g. workbench), on the same source.
        Adds networks, groups, etc. to the current source if they don't exist.
        Please note that this function updates the current instance with Ayasdi MIP state, not the other way around.
        For instance, if the source.name parameter is changed, then this change is lost, since the change was
        never reflected on the platform.

        Two additional attributes are added for convenience:
         - id_to_colnames = (dict) column_index to the names of the columns
         - colname_to_ids = (dict) column names to their indices


        Returns:
            None

        :Example:

        >>> src = extraglobs['src'] #ignore-in-doc
        >>> src.sync()
        >>> 'networks' in dir(src) # After getting full src, these exist
        True
        >>> 'colorings' in dir(src)
        True
        >>> src.id_to_colnames[1]
        'relative weight'
        >>> src.colname_to_ids['clinical classification']
        6
        >>> extraglobs['src'] = src #ignore-in-doc
        """

        self.__get_full_source__()

    def show(self):
        """Shows the current :class:`source <ayasdi.core.source.Source>` in a browser window."""

        url = "%ssources/%s" % (self.connection.CORE_LOGIN_STUB, self.id)
        result = webbrowser.open_new_tab(url)
        if result is False:
            warnings.warn("Could not open web browser. Please navigate to: {}".format(url))

    def select_features(self, selection_method=None,
                        metric=None, column_set_id=None,
                        group_id=None, row_sampling=None,
                        max_columns=None, adjacency_weight_function=None,
                        async_=False,
                        outcome_spec=None):
        """Perform feature selection on the current :class:`source <ayasdi.core.source.Source>`.

        .. note::

           All combinations of selection methods and metrics work with continuous data columns. For combinations
           of selection methods and metrics that can be used with categorical data or outcome columns,
           see the :doc:`select_features Supplementary Overview </userdoc/select_features_supp_overview>`.

        Args:
            selection_method (str) : Algorithm for feature selection. Currently supported: mRMR (Min-Redundancy
                Max-Relevance), mRMR-mSMS (Min-Redundancy Max-Relevance, Min-Size Max-Score), mRMR-distinct (mRMR as
                well as approximating the feature recommendations), Landmarking, Laplacian. For details, see the
                :doc:`select_features Supplementary Overview </userdoc/select_features_supp_overview>`
            metric (str) : Metric for feature selection.
                Supported for mRMR: MI, Correlation
                Supported for Landmarking: VI, Correlation
                Supported for Laplacian: Euclidean, Cosine
            column_set_id (str) : Column set id to limit the features that need to be considered.. Default=all columns
            group_id (str) : Group id to limit the rows over which features are selected.
                Default=all rows (subject to sampling).
            row_sampling (int): The maximum number of rows to be considered; if the group specifies a higher
                number of rows, this many are sampled at random. Default=all rows
            max_columns (int): The maximum number of columns that will be returned. Default=1000
            adjacency_weight_function (str) : The kernel function for adjacency weights between pairs of data points.
                Supported in the **Laplacian** `selection_method` only. For details, see the
                :doc:`select_features Supplementary Overview </userdoc/select_features_supp_overview>`.
            async_ (bool): when True, runs feature selection asynchronously and returns an
                :class:`ayasdi.core.async_jobs.AsyncJob` object. The object's "result" field is set to a dictionary
                that describes the result set.
            outcome_spec (OutcomeSpec object, :class:`ayasdi.core.outcome_spec.OutcomeSpec`) : to be used to pass
                information on the selected outcome column (required for outcome-based selection) and, optionally,
                to specify a list of "classes of interest" to be sampled at a higher rate.
                For details, see the documentation in the corresponding class.

        Returns:
            When ``async_=False``, returns a dictionary containing entries for ``column_indices``,
            ``nearest_landmarks``, ``recommended_columnset``, ``all_scored_columns``, and/or ``scored_columns``.

            For details, see the :doc:`select_features Supplementary Overview </userdoc/select_features_supp_overview>`.

        :Example:

            >>> import ayasdi.core as ac
            >>>
            >>> src = extraglobs['src'] #ignore-in-doc
            >>> columns_for_analysis = ['relative weight',
            ...                         'blood glucose',
            ...                         'insulin level',
            ...                         'insulin response',
            ...                         'steady state plasma glucose']
            >>> candidate_column_set = \
                    src.create_column_set(column_list=columns_for_analysis, name='candidate_column_set')
            >>> ########
            >>> # First we do Min-Redundancy Max-Relevance (mRMR)
            >>> # outcome-based feature selection.
            >>> # When we don't specify a row group,
            >>> # sampling occurs from all rows.
            >>> # Also, here row_sampling is greater
            >>> # than the number of rows in the dataset,
            >>> # so all rows will be considered.
            >>> # We use the MI (Mutual Information) metric.
            >>> outcome_spec = ac.OutcomeSpec(outcome_column_index=6)
            >>> results = \
                    src.select_features(selection_method='mRMR',
            ...                         metric='MI',
            ...                         outcome_spec=outcome_spec,
            ...                         column_set_id=candidate_column_set['id'],
            ...                         row_sampling=150, max_columns=4)
            >>> sorted(results.keys())
            ['column_indices']
            >>> column_indices = results['column_indices']
            >>> len(column_indices)
            4
            >>> # The id of the column first selected
            >>> column_indices[0]
            3
            >>> ########
            >>> # Now, we do Landmarking feature selection,
            >>> # using the VI (Variation of Information) metric. Note that
            >>> # no outcome column will be specified.
            >>> results = \
                    src.select_features(selection_method='Landmarking',
            ...                         metric='VI',
            ...                         column_set_id=candidate_column_set['id'],
            ...                         row_sampling=150, max_columns=3)
            >>> results['column_indices'] # List of landmarks
            [1, 2, 4]
            >>> nearest_landmarks = results['nearest_landmarks']
            >>> # key: ID from input; value: ID of nearest landmark
            >>> landmark_map = \
                    dict((lm['column_index'], lm['landmark_index'])
            ...          for lm in nearest_landmarks)
            >>> sorted(landmark_map.items())
            [(1, 1), (2, 2), (3, 2), (4, 4), (5, 1)]
            >>> ########
            >>> # Finally we demo Automated Feature Selection with
            >>> # Min-Redundancy Max-Relevance (mRMR) combined with Max-Score Min-Size.
            >>> # This will provide additional results to the mRMR case. In particular,
            >>> # an optimal subset of features that combines high total score with
            >>> # small size.
            >>> results = \
                    src.select_features(selection_method='mRMR-MSMS',
            ...                         metric='MI',
            ...                         outcome_spec=outcome_spec,
            ...                         column_set_id=
            ...                         candidate_column_set['id'],
            ...                         row_sampling=150, max_columns=4)
            >>> column_indices = results['column_indices']
            >>> len(column_indices)
            4
            >>> # The id of the column first selected
            >>> column_indices[0]
            3
            >>> # The optimal column set recommended by the mRMR-MSMS algorithm
            >>> results['recommended_columnset']
            [3, 2]
            >>> # All scored column subsets, with their size and
            >>> # corresponding OAA Metric-based scoring
            >>> scored_columnsets = results['all_scored_columnsets']
            >>> len(scored_columnsets)
            2
            >>> scored_columnsets[0]['size']
            2
            >>> round(scored_columnsets[0]['score'], 1)
            95.2
            >>> _ = src.delete_column_set('candidate_column_set') # ignore-in-doc
        """
        feature_selection_input = {}

        if outcome_spec is not None:
            outcome_spec['outcome_column_index'] = self._get_outcome_column_index(
                outcome_spec['outcome_column_name'],
                outcome_spec['outcome_column_index'])
            feature_selection_input['outcome_spec'] = outcome_spec.serialize()

        feature_selection_input['selection_method'] = selection_method
        feature_selection_input['metric'] = metric
        feature_selection_input['column_set_id'] = column_set_id
        feature_selection_input['group_id'] = group_id
        feature_selection_input['row_sampling'] = row_sampling
        feature_selection_input['max_columns'] = max_columns
        feature_selection_input['adjacency_weight_function'] = adjacency_weight_function

        # Make the query
        if async_:
            endpoint = self.curl + '/feature_selection/async'
            async_task = json_funcs._post_(self.connection.session,
                                           endpoint, feature_selection_input)
            return async_jobs.AsyncJob(self.connection, async_task, endpoint)
        else:
            return json_funcs._post_(self.connection.session,
                                     self.curl + '/feature_selection',
                                     feature_selection_input)

    def create_column_set(self, column_list, name, metadata={}, create_new=False):
        """
        Creates a column set from a list of columns. The list of columns
        can contain either a list of column indices
        OR a list of column names.

        .. note::
          Both column indices and column names can be obtained by investigating the `source.columns` attribute.

        Args:
            column_list: A list of column headers or column indices.
            name: User defined name of the column set.
            metadata (dict): Metadata for the column set stored as key-value pairs.
            create_new (bool): force to create a new column set

        Returns:
            A column_set dictionary.

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set1 = \
            src.create_column_set(column_list=columns_for_analysis,
        ...                       name="test_column_set")
        >>> column_set2 = src.create_column_set(column_list=columns_for_analysis[:2],
        ...                                     name="test_column_set2")
        >>> column_set3 = src.create_column_set(column_list=list(range(3)),
        ...                                     name='test_column_set3')
        >>> _ = src.delete_column_set(name="test_column_set") #ignore-in-doc
        >>> _ = src.delete_column_set(name="test_column_set2") #ignore-in-doc
        >>> _ = src.delete_column_set(id=column_set3['id']) #ignore-in-doc
        """
        if getattr(self, 'column_names', None) is None:
            self.__get_full_source__()

        name = name.strip()

        if all(type(x) == int for x in column_list):
            column_indices = sorted(set(column_list))
        else:
            try:
                column_indices = sorted(set(self.colname_to_ids[column_name] for column_name in column_list))
            except KeyError as e:
                error_message = "Column %s does not exist" % e
                LOGGER.exception(error_message)
                return self.__error__(error_message)

        if len(column_indices) == len(self.column_names):
            all_column_set = self.get_column_set(name='All columns')
            if (len(all_column_set['column_indices']) == len(column_indices)):
                return all_column_set

        column_info = {
            'column_indices': column_indices,
            'name': name,
            'create_new': create_new,
        }

        response = json_funcs._post_(self.connection.session, self.curl + '/column_sets/safe', column_info)
        conflict_code = response.get('conflict_code', None)
        if conflict_code:
            existing = response.get('column_set')
            existing['metadata'] = self.__get_metadata_for_entity(existing['id'])
            if conflict_code == 'COLUMN_SET_NAME_EXISTS':
                raise ValueError("Column set `" + existing['name'] + "` already exists. Please use another name.")
            elif conflict_code == 'COLUMN_SET_CONTENT_EXISTS':
                warnings.warn("Column_set name doesn't match, "
                              "but columns in `" + existing['name'] + "` match. Returning it")
                return existing
            elif conflict_code == 'COLUMN_SET_NAME_AND_CONTENT_EXISTS':
                return existing
            else:
                raise ValueError("Column set " + name + " already exists. " + conflict_code)
        else:
            new_column_set = response.get('column_set')
            self.__add_metadata_to_entity(new_column_set['id'], 'columnset', metadata)
            new_column_set['metadata'] = self.__get_metadata_for_entity(new_column_set['id'])
            self.column_sets.append(new_column_set)
            return new_column_set

    def get_column_sets(self):
        """Returns column sets for the given source.

        Returns:
            A list of column set dictionaries.

        :Example:

        >>> src = extraglobs['src'] #ignore-in-doc
        >>> column_sets = src.get_column_sets()
        >>> len(column_sets) > 0
        True
        >>> 'All columns' in [i['name'] for i in column_sets]
        True
        """
        if hasattr(self, 'column_sets'):
            return self.column_sets
        else:
            self.__get_full_source__()
            return self.column_sets

    def get_column_set(self, name=None, id=None):
        """
        Returns a column set by name or id.

        Args:
            id: identifier of the column set. Optional with name. If
                both id and name are provided, only id is used.
            name: Name of the column set. Optional with id.

        Returns:
            A column set dictionary

        :Example:

        >>> src = extraglobs['src'] #ignore-in-doc
        >>> src.sync() #ignore-in-doc
        >>> # Creating a column set
        >>> colsets = src.get_column_sets()
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = \
            src.create_column_set(column_list=columns_for_analysis,
        ...                       name="test_column_set1")
        >>> column_set = src.get_column_set(id=column_set['id'])
        >>> columns = sorted(column_set['column_indices'])
        >>> columns
        [1, 2, 3, 4]
        >>> for col_id in columns:
        ...    print(src.id_to_colnames[col_id])
        relative weight
        blood glucose
        insulin level
        insulin response
        >>> _ = src.delete_column_set('test_column_set1') #ignore-in-doc
        """
        if id:
            try:
                colset = json_funcs._get_(self.connection.session,
                                          self.curl + '/column_sets/' +
                                          id)
                colset['metadata'] = self.__get_metadata_for_entity(id)
                return colset
            except HTTPError as e:
                if e.response.status_code == 404:
                    return self.__error__("Column set with id {} "
                                          "does not exist".format(id))
                else:
                    raise
        elif name:
            # We need to get the list of column sets since there is no
            # endpoint to get column_set by name
            column_sets = self.get_column_sets()
            for column in column_sets:
                if column['name'] == name:
                    # Get Detailed Column Set Info
                    colset = json_funcs._get_(self.connection.session,
                                              self.curl + '/column_sets/' +
                                              column['id'])
                    colset['metadata'] = self.__get_metadata_for_entity(column['id'])
                    return colset
            return self.__error__("Column set with name {} "
                                  "does not exist".format(name))

        return self.__error__("Please provide a name or an id")

    def update_column_set(self, id, name=None, metadata={}):
        """
        Updates the name or metadata of an existing column set.

        .. note::

          If an existing metadata key is used, its value is updated by this function.

        Args:
            id (str): id of the existing column set.
            name (str): optional new name for the column set.
            metadata (dict): Metadata for the column set stored as key-value pairs. New key-value pairs are
                added to the existing metadata and existing key value pairs are updated.

        Returns:
            A column_set dictionary.

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set1 = \
            src.create_column_set(column_list=columns_for_analysis,
        ...                       name="test_column_set")
        >>> column_set1["name"]
        'test_column_set'
        >>> updated_column_set = src.update_column_set(column_set1['id'],
        ...                                     name="column_set")
        >>> updated_column_set['name']
        'column_set'
        >>> _ = src.delete_column_set(name="column_set") #ignore-in-doc
        """

        if name is None and not metadata:
            return self.__error__("Please provide either a new column name or new metadata.")

        if id:
            try:
                json_funcs._get_(self.connection.session,
                                 self.curl + '/column_sets/' +
                                 id)
                if name is not None:
                    json_funcs._put_(self.connection.session,
                                     self.curl + '/column_sets/' +
                                     id,
                                     {'name': name})
                if metadata:
                    self.__add_metadata_to_entity(id, 'columnset', metadata, update=True)

                return self.get_column_set(id=id)
            except HTTPError as e:
                if e.response.status_code == 404:
                    return self.__error__("Column set with id {} "
                                          "does not exist".format(id))
                else:
                    raise
        else:
            return self.__error__("Please provide an id")

    def __add_metadata_to_entity(self, entity_id, entity_type, metadata_dict, update=False):
        if not metadata_dict:
            return False
        try:
            post_body = {
                "entityId": entity_id,
                "entityType": entity_type,
                "keyvals": metadata_dict,
                "update": update
            }
            json_funcs._post_(self.connection.session, self.connection.CORE_REQUEST_STUB + 'metadata/', post_body)
            return True
        except HTTPError as e:
            LOGGER.exception(e)
            return False

    def __get_metadata_for_entity(self, entity_id):
        try:
            metadata_lst = json_funcs._get_(self.connection.session,
                                            self.connection.CORE_REQUEST_STUB + 'metadata?entityId=' + entity_id)
            return metadata_lst
        except HTTPError as e:
            LOGGER.exception(e)
            return []

    def delete_column_set(self, name=None, id=None):
        """
        Delete a column set with the given name or id.

        Args:
            id: identifier of the column set. Optional with name. If
                both id and name are provided, only id is used.
            name: Name of the column set. Optional with id.

        Returns:
            True if successful, else gives a warning and returns None.

        :Example:

        Check out the example under :func:`create_column_set`
        """

        if id:
            json_funcs._delete_(self.connection.session,
                                self.curl + '/column_sets/{}'.format(id))
            if self.column_sets:
                for i in range(len(self.column_sets)):
                    if self.column_sets[i]['id'] == id:
                        del self.column_sets[i]
                        break
            return True
        elif not name:
            raise ValueError("Please provide a name or an id")

        column_sets = self.get_column_sets()
        for i in range(len(column_sets)):
            if column_sets[i]['name'] == name.strip():
                json_funcs._delete_(self.connection.session,
                                    self.curl + '/column_sets/' +
                                    column_sets[i]['id'])
                del self.column_sets[i]
                return True
        warnings.warn("Column set with name '%s' does not exist" % name)

    def delete_column_sets(self, ids=[]):
        """
        Deletes a list of column_sets by id.

        Args:
            ids ([str]): List of column_set identifiers.

        Returns:
            True if successful
        """
        if len(ids) > 0:
            for id_ in ids:
                self.delete_column_set(id=id_)
        else:
            raise ValueError("Please provide a list of ids")
        return True

    def share_column_set(self, column_set_id, user_id):
        """Share a column set with a user.

        Args:
            column_set_id (str): id of the column to be shared
            user_id (str): id of the user to be shared with

        Returns:
            True if successful
        """

        error_message = ''
        if column_set_id is None:
            error_message = error_message + 'Column set id is missing'
        if user_id is None:
            error_message = error_message + 'User id is missing'
        if len(error_message) > 0:
            return self.__error__(error_message)

        post_params = {}
        share_url = self.curl + '/column_sets/%s/users/%s' % (column_set_id, user_id)
        json_funcs._post_(self.connection.session, share_url, post_params)

        return True

    def get_valid_metrics(self, column_set, group_id=None, for_ui=None):
        """
        Returns a list of metrics that are valid/compatible
        with the current :class:`source <ayasdi.core.source.Source>`, group and column set.

        Args:
            column_set: column_set dictionary. Returned by
                :func:`create_column_set <ayasdi.core.source.Source.create_column_set>` or
                :func:`get_column_set <ayasdi.core.source.Source.get_column_set>`.
            group_id: The id of a group for evaluating the
                compatible metrics (Optional). Default=All rows
            for_ui: An optional flag that returns the list of valid metrics
                that are displayed in the platform UI. This list is likely
                shorter than the default list. (Optional)

        Returns:
            A list of metric specification dictionaries

        :Example:

        >>> src = extraglobs['src'] #ignore-in-doc
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = \
        src.create_column_set(column_list=columns_for_analysis,
        ...                   name="test_column_set1")
        >>> metric_list = src.get_valid_metrics(column_set=column_set)
        >>> 'Correlation' in [metric['id'] for metric in metric_list]
        True
        >>> _ = src.delete_column_set('test_column_set1') #ignore-in-doc
        """
        self.sync()
        params_dict = {'column_set_id': column_set['id']}
        if group_id is not None:
            params_dict['row_group_id'] = group_id
        if for_ui is not None:
            params_dict['for_ui'] = for_ui
        return json_funcs._post_(self.connection.session,
                                 self.curl + '/get_valid_metrics',
                                 params_dict)

    def get_valid_lenses(self, column_set, group_id=None, for_ui=None):
        """
        Returns a list of lenses that are valid and compatible
        with the current :class:`source <ayasdi.core.source.Source>`, group, and column_set_id.

        Args:
            column_set: column_set dictionary. Returned by
                :func:`create_column_set <ayasdi.core.source.Source.create_column_set>` or
                :func:`get_column_set <ayasdi.core.source.Source.get_column_set>`.
            group_id: The id of a group for evaluating the
                compatible lenses (Optional). Default=All rows
            for_ui: An optional flag that returns the list of valid lenses
                that are displayed in the platform UI. This list is likely
                shorter than the default list. (Optional)

        Returns:
            A list of lens specification dictionaries

        :Example:

        >>> src = extraglobs['src'] #ignore-in-doc
        >>> columns_for_analysis = ["relative weight",
        ...                         "blood glucose", "insulin level",
        ...                         "insulin response"]
        >>> column_set = \
        src.create_column_set(column_list=columns_for_analysis,
        ...                   name="test_column_set1")
        >>> lens_list = src.get_valid_lenses(column_set=column_set)
        >>> 'Gaussian Density' in [lens['id'] for lens in lens_list]
        True
        >>> _ = src.delete_column_set('test_column_set1') #ignore-in-doc
        """
        self.sync()
        params_dict = {'column_set_id': column_set['id']}
        if group_id is not None:
            params_dict['row_group_id'] = group_id
        if for_ui is not None:
            params_dict['for_ui'] = for_ui
        return json_funcs._post_(self.connection.session,
                                 self.curl + '/get_valid_lenses',
                                 params_dict)

    def get_auto_analysis_suggestions(self, column_set_id=None):
        """
        Returns a list of auto analysis suggestions.
        Each of these suggestions can be used to replace the ``params_dict``
        parameter in :func:`create_network <ayasdi.core.source.Source.create_network>` or
        :func:`create_network_async <ayasdi.core.source.Source.create_network_async>`.

        Args:
            column_set_id (int): id of the column_set . Returned by
                :func:`create_column_set <ayasdi.core.source.Source.create_column_set>` or
                :func:`get_column_set <ayasdi.core.source.Source.get_column_set>`.

        Returns:
            A list of analysis ``params_dict`` values.

        :Example:

        >>> src = extraglobs['src'] #ignore-in-doc
        >>> colsets = src.get_column_sets() #ignore-in-doc
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set1 = \
            src.create_column_set(column_list=columns_for_analysis,
        ...                       name="test_column_set1")
        >>> suggestions = src.get_auto_analysis_suggestions(column_set_id=column_set1['id'])
        >>> len(suggestions) # Number of analysis parameters suggested
        6
        >>> suggestions[0]['metric']
        {'id': 'Norm Correlation'}
        """
        if column_set_id is None:
            raise ValueError('Please pass a value to the parameter column_set_id')
        suggestions = json_funcs._post_(self.connection.session, self.curl + '/suggest_networks',
                                        {'column_set_id': column_set_id})
        return suggestions['network_specifications']

    def create_network(self, name, params_dict, async_=False, disjoint_network=False, metadata={},
                       ext_params=None):
        """
        Creates a network (Topological Model) on the source.


        Args:
            name (str): User defined name of the network. If a network already exists with this name,
                the existing network is returned. Else, a new network is created.
            params_dict (dict): dictionary of network creation parameters. Includes parameters to specify 'metric',
                'lenses', 'column_set_id', 'row_group_id', and 'clustering_algorithm'. For details
                about params_dict creation, see :doc:`/userdoc/create_network_supp_overview`.
            async\_: If set to True, this network is created asynchronously. This function is obsolete. Plaese use
                :func:`create_network_async <ayasdi.core.source.Source.create_network_async>` instead.
                Default=False
            disjoint_network: If set to True, the network is
                created with disjoint nodes (nodes do not share points). Default=False
            metadata (dict): Metadata for the column set stored as key-value pairs.


        Returns:
            If async\_=False, an :class:`ayasdi.core.networks.Network` object; if
            async\_=True, an :class:`ayasdi.core.jobs.Job` object.

        .. note::
           For more information about `create_network`, see :doc:`/userdoc/create_network_supp_overview`.

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> networks = src.get_networks()
        >>> for network in networks:
        ...     deleted = src.delete_network(id=network.id)
        >>> networks = src.get_networks()
        >>> networks # doctest: +SKIP
        []
        >>> # Creating a :class:`ayasdi.core.networks.Network` object
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = \
        src.create_column_set(column_list=columns_for_analysis,
        ...                   name="test_column_set1")
        >>> # Specifying three or less lenses is recommended
        >>> # for better performance and results.
        >>> network = src.create_network("test_network1",{
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': column_set['id'],
        ...        'lenses': [{'resolution': 5, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 5, 'id': 'MDS coord 2',
        ...                    'equalize': True, 'gain': 3.0}]
        ...        }
        ... )
        >>> # Adding data lens and clustering parameter
        >>> network = src.create_network("test_data_lens_network", {
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': column_set['id'],
        ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 30, 'id': 'MDS coord 2',
        ...                   'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 3,
        ...                    'column_index':
        ...                     src.colname_to_ids["clinical classification"],
        ...                    'equalize': True, 'gain': 1.0}
        ...                   ] ,
        ...        'clustering_algorithm': {'type': 'sl_hermite'}})
        >>> # When a network is available
        >>> networks = src.get_networks()
        >>> len(networks)
        2
        >>> _network_names = sorted([n.name for n in networks])
        >>> _network_names
        ['test_data_lens_network', 'test_network1']
        >>> network = src.get_network(name="test_network1")
        >>> _ = src.delete_network(name="test_network1") #ignore-in-doc
        >>> _ = src.delete_network(name="test_data_lens_network") #ignore-in-doc
        >>> _ = src.delete_column_set('test_column_set1') #ignore-in-doc
        >>> # Testing network creation on groups
        >>> filter_set = src.create_filter_set([{'column_name' :
        ...                                      'clinical classification',
        ...                                         'in_set' : [3]},
        ...                                         {'column_name' :
        ...                                          'relative weight',
        ...                                          'in_range' : [0.8, 1],
        ...                                          'not' : True}],
        ...                                      as_and=True)
        >>> # You can also specify and create a network using the "row_group_id" parameter
        >>> new_group2 = src.create_group(name="filter_set_group",
        ...                              filter_set=filter_set
        ...                              )
        >>> network2 = src.create_network("test_network_on_group",
        ...                               params_dict={
        ...        'row_group_id': new_group2['id'],
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': column_set['id'],
        ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 30, 'id': 'MDS coord 2',
        ...                   'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 3,
        ...                    'column_index':
        ...                    src.colname_to_ids["clinical classification"],
        ...                    'equalize': True, 'gain': 1.0}
        ...                   ]
        ...        }
        ... )
        >>> _ = src.delete_group(id=new_group2['id']) #ignore-in-doc
        >>> _ = src.delete_network(id=network2.id) #ignore-in-doc
        """
        existing = self._find_existing_network(name)
        if existing is not None:
            return existing

        analysis_params = self._build_network_request_object(disjoint_network, name, params_dict, ext_params)
        analysis_params['metadata'] = metadata

        # call endpoint
        if async_:
            network_job = json_funcs._post_(self.connection.session,
                                            self.curl + '/networks/async',
                                            analysis_params)

            jobid = network_job['jobId']
            entity_uri = '{core}/networks/async/{jobid}'.format(
                core=self.curl, jobid=jobid)

            return jobs.Job(self.connection, network_job, type='new', uri=entity_uri, id=jobid)

        else:
            created_network = json_funcs._post_(self.connection.session,
                                                self.curl + '/networks',
                                                analysis_params)

            network = networks.Network(self, created_network)
            self.networks.append(network)
            return network

    def _find_existing_network(self, name):
        network_list = self.get_networks()
        for network in network_list:
            if network.name == name.strip():
                print("Network with name '%s' already exists" % name)
                network.sync()
                return network
        return None

    def _build_network_request_object(self, disjoint_network, name, params_dict, ext_params=None):
        grapher_flow = 'Landmark'
        if len(params_dict.get('lenses', [])) > 3:
            warnings.warn('While using more than 3 lenses is supported via the SDK, '
                          'please be aware that adding too many lenses can overload '
                          'the server and/or produce results that are difficult to interpret.')
        metric = params_dict['metric']
        # backward compatibility with obsolete metric name
        if metric.get('id') == 'Sequence DTW Metric Eucl':
            warnings.warn('The metric name "Sequence DTW Metric Eucl" is obsolete and will not be supported '
                          'in future versions. Please use the updated name "DTW Needleman Wunsch".')
            metric['id'] = 'DTW Needleman Wunsch'

        analysis_params = {'name': name,
                           'column_set_id': params_dict['column_set_id'],
                           'metric': metric,
                           'lenses': params_dict['lenses'],
                           'disjoint_graph': disjoint_network,
                           'grapher_flow': grapher_flow,
                           'ext_params': ext_params or {}
                           }
        # Params
        if 'row_group_id' in params_dict:
            analysis_params['row_group_id'] = params_dict['row_group_id']
        if 'clustering_algorithm' in params_dict:
            analysis_params['clustering_algorithm'] = \
                params_dict['clustering_algorithm']
        return analysis_params

    def create_network_async(self, name, params_dict, disjoint_network=False, ext_params=None, metadata={}):
        """Creates a network (Topological Model) asynchronously.

        Args:
            name (str): User defined name of the network. If a network already exists with this name,
                the existing network is returned. Else, a new network is created.
            params_dict (dict): dictionary of network creation parameters. Includes parameters to specify 'metric',
                'lenses', 'column_set_id', 'row_group_id', and 'clustering_algorithm'. For details
                about params_dict creation, see :doc:`/userdoc/create_network_supp_overview`.
            disjoint_network: If set to True, the network is
                created with disjoint nodes (nodes do not share points). Default=False
            metadata (dict) : Metadata for the network stored as key-value pairs. (optional)

        Returns:
            An :class:`AsyncJob <ayasdi.core.async_jobs.AsyncJob>` object.

        :Example:
        >>> #Please see the example under create_network

        """
        existing = self._find_existing_network(name)
        if existing is not None:
            return AsyncJob(self.connection,
                            id='None',
                            endpoint=self.curl + '/networks/async',
                            status='complete',
                            result=existing)

        analysis_params = self._build_network_request_object(disjoint_network, name, params_dict, ext_params)
        analysis_params['metadata'] = metadata
        url = self.curl + '/networks/async'
        jobid = json_funcs._post_(self.connection.session, url, analysis_params)
        source = self

        def rest_to_network(rest_response):
            net = networks.Network(source, rest_response)
            source.networks.append(net)
            return net

        return AsyncJob(
            self.connection,
            jobid,
            url,
            result_converter=rest_to_network)

    def outcome_auto_analysis(self,
                              name='Outcome',
                              column_set_id=None,
                              metrics=None,
                              group_id=None,
                              scoring_type=None,
                              number_of_returned_results=None,
                              search_space_options=None,
                              max_generated_graphs=None,
                              disjoint_network=False,
                              outcome_spec=None,
                              data_lenses=None):
        """
        Creates networks for the current source where localization of the outcome column is optimized.

        .. note::
          This function is always run asynchronously. For an walk-through of the process, see the
          :doc:`Outcome Autoanalysis <tutorials/outcome_autoanalysis>` tutorial.
          **WARNING:** Even for moderately-sized datasets, this function is time-consuming.

        Args:
            name (str): User defined prefix for the network names. Default='Outcome'.
            column_set_id (int): id of the column_set . Returned by
                :func:`create_column_set <ayasdi.core.source.Source.create_column_set>` or
                :func:`get_column_set <ayasdi.core.source.Source.get_column_set>`.
            metrics (list): List of metrics to constrain the analysis. By default, outcome auto analysis
                performs an evaulation of all available metrics.
                (optional)
            group_id: Id of group to use for creating the network. Default=All rows.
            scoring_type: An optional flag that if set to 'Full' will string
                together outcome_auto_analysis together with
                outcome_lens_param_optimization for each of the returned
                networks
                WARNING: setting this to full is VERY time consuming
                and resource intensive.
            number_of_returned_results: The maximum number of networks
                to be returned. Default is 6. (optional)
            search_space_options: If this flag is set to
                'use_lens_pairs', the search space is limited to pairs of lenses,
                instead of considering single lenses as well. (optional)
            max_generated_graphs: The maximum number of good metric and lens
                combinations that will get constructed for choosing the best
                graphs. This number must be at least as
                large as ``number_of_returned_results``. Default=10(optional)
            disjoint_network: If True, the network is
                created with disjoint nodes (nodes that that do not share any data points). Default=False.
            outcome_spec (OutcomeSpec): An :class:`OutcomeSpec <ayasdi.core.outcome_spec.OutcomeSpec>` object.
            data_lenses (list): List of column indices that can be used as data lenses and
                considered as lens candidates and scored in addition to the ones suggested by OAA.

        Returns:
            :class:`Job <ayasdi.core.jobs.Job>` objects.

            Networks can be extracted from these jobs as shown in the example below.

            Each :class:`network <ayasdi.core.networks.Network>` object has a scores attribute, which has a list of
            :class:`scores <ayasdi.core.score.Score>`, where each score looks like:

            .. raw:: html

                <div class="highlight"><pre>
                u'scores': [{"score": 0.7909172010167155,
                "params": "{\"classes_of_interest\":[\"1.0\",\"2.0\"],\"outcome_column_index\":4}", "type": "OUTCOME",}]
                </pre></div>

        :Example:

        >>> import ayasdi.core as ac
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> src.sync() #ignore-in-doc
        >>> # Creating a column set
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = src.create_column_set(column_list=
        ...                                    columns_for_analysis,
        ...                                    name="test_column_set1")
        >>> #Delete all previous networks in the source if needed
        >>> outcome_spec = ac.OutcomeSpec(outcome_column_name="clinical classification")
        >>> running_jobs = src.outcome_auto_analysis(name="test_outcome",
        ...                               column_set_id=column_set['id'],
        ...                               outcome_spec=outcome_spec)
        >>> remaining = len(running_jobs)
        >>> import time  #To sleep between checking job status.
        >>> while remaining:
        ...    for ind, job in enumerate(running_jobs):
        ...       time.sleep(15)
        ...       job.sync()
        ...       if job.status != "in_progress":
        ...          remaining -= 1
        ...          finished_job = running_jobs.pop(ind)
        ...          break
        >>> remaining
        0
        >>> src.sync()
        >>> networks = src.get_networks()
        >>> outcome_networks = [i.name for i in networks
        ...                     if 'test_outcome' in i.name]
        >>> 'test_outcome 1' in outcome_networks
        True
        >>> for network in outcome_networks:
        ...     _ = src.delete_network(name=network)
        >>> _ = src.delete_column_set('test_column_set1') #ignore-in-doc
        """
        self.sync()
        params_dict = {'name_base': name}
        if column_set_id is not None:
            params_dict['column_set_id'] = column_set_id
        if scoring_type is not None:
            params_dict['scoring_type'] = scoring_type
        if metrics is not None:
            params_dict['metric_ids'] = metrics
        if group_id is not None:
            params_dict['group_id'] = group_id
        if search_space_options is not None:
            params_dict['search_space_options'] = search_space_options
        if number_of_returned_results is not None:
            params_dict['number_of_returned_results'] = number_of_returned_results
        if max_generated_graphs is not None:
            params_dict['max_generated_graphs'] = max_generated_graphs
        if disjoint_network is not None:
            params_dict['disjoint_network'] = disjoint_network
        if data_lenses is not None:
            params_dict['data_lenses'] = data_lenses
        params_dict['async'] = {}
        if outcome_spec is not None:
            outcome_spec['outcome_column_index'] = self._get_outcome_column_index(
                outcome_spec['outcome_column_name'],
                outcome_spec['outcome_column_index'])
            params_dict['outcome_spec'] = outcome_spec.serialize()
        run_jobs = json_funcs._post_(
            self.connection.session,
            self.curl + '/outcome_auto_analysis',
            params_dict)
        return [jobs.Job(self.connection, [run_job]) for run_job in run_jobs]

    def _get_outcome_column_index(self,
                                  outcome_column_name,
                                  outcome_column_index):
        if outcome_column_name is not None and outcome_column_name in self.colname_to_ids:
            outcome_column_index = self.colname_to_ids[outcome_column_name]
        return outcome_column_index

    def get_networks(self):
        """
        Retreive :class:`network <ayasdi.core.networks.Network>` objects for the
        current :class:`source <ayasdi.core.source.Source>`.

        Returns:
            A list of :class:`network <ayasdi.core.networks.Network>` objects.

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> networks = src.get_networks()
        >>> for network in networks:
        ...     deleted = src.delete_network(id=network.id)
        >>> networks = src.get_networks()
        >>> networks # doctest: +SKIP
        []
        >>> # Creating a :class:`ayasdi.core.networks.Network` object
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = \
        src.create_column_set(column_list=columns_for_analysis,
        ...                   name="test_column_set1")
        >>> # Specifying three or less lenses is recommended
        >>> # for better performance and results.
        >>> network = src.create_network("test_network1",{
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': column_set['id'],
        ...        'lenses': [{'resolution': 5, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 5, 'id': 'MDS coord 2',
        ...                    'equalize': True, 'gain': 3.0}]
        ...        }
        ... )
        >>> # Adding data lens and clustering parameter
        >>> network = src.create_network("test_data_lens_network",{
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': column_set['id'],
        ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 30, 'id': 'MDS coord 2',
        ...                   'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 3,
        ...                    'column_index':
        ...                     src.colname_to_ids["clinical classification"],
        ...                    'equalize': True, 'gain': 1.0}
        ...                   ] ,
        ...        'clustering_algorithm': {'type': 'sl_hermite'}})
        >>> # When a network is available
        >>> networks = src.get_networks()
        >>> len(networks)
        2
        """
        try:
            return self.__do_get_networks()
        except AttributeError as e:
            LOGGER.exception(e)
            self.__get_full_source__()
            return self.__do_get_networks()

    def __do_get_networks(self):
        for i in range(len(self.networks)):
            if isinstance(self.networks[i], dict):
                self.networks[i] = networks.Network(self, self.networks[i])
        return self.networks

    def get_network(self, name=None, id=None):
        """
        Retreive a :class:`network <ayasdi.core.networks.Network>` object by id or name.

        Args:
           id (str): The id of the requested
               :class:`network <ayasdi.core.networks.Network>` (optional with name).
           name (str): The name of the requested
               :class:`network <ayasdi.core.networks.Network>` (optional with id).

        Returns:
           A :class:`network <ayasdi.core.networks.Network>` object -
            if multiples exist, then a list of
            :class:`network <ayasdi.core.networks.Network>` objects.

        :Example:

        See usage in :func:`get_networks`
        """
        if id is not None and id != '':
            network_json = json_funcs._get_(self.connection.session,
                                            self.curl + '/networks/' +
                                            id)
            return networks.Network(self, network_json)

        if not name:
            return self.__error__("Please provide either a name or an id.")

        network_list = self.get_networks()
        for network in network_list:
            if network.name == name:
                # We have to make another Network GET call because
                # the existing Network object doesn't have all
                # attributes such as 'node_count'
                network_json = json_funcs._get_(self.connection.session,
                                                self.curl + '/networks/' +
                                                network.id)
                return networks.Network(self, network_json)

        return self.__error__("Network with name '%s' does not exist" %
                              name)

    def delete_networks(self, ids=[]):
        """
        Deletes multiple :class:`networks <ayasdi.core.networks.Network>` from the current source.

        Args:
            ids ([str]): List of network ids.

        Returns:
            True if successful, else prints and returns an error message.
        """
        if len(ids) > 0:
            for id_ in ids:
                self.delete_network(id=id_)
        else:
            raise ValueError("Please provide a list of ids")
        return True

    def delete_network(self, name=None, id=None):
        """
        Delete a single :class:`network <ayasdi.core.networks.Network>`.

        To delete multiple networks, use :func:`delete_networks <ayasdi.core.source.Source.delete_networks>`.

        Args:
            id (str) : The id of the requested :class:`network <ayasdi.core.networks.Network>`
               (optional with name).
            name (str): The name of the requested :class:`network <ayasdi.core.networks.Network>`
               (optional with id).

        Returns:
            True if successful, else prints and returns an error message.

        :Example:

        See usage in :func:`get_networks`
        """
        network_list = self.get_networks()
        if id is not None and id != '':
            json_funcs._delete_(self.connection.session,
                                self.curl + '/networks/' +
                                id)
            for i in range(len(network_list)):
                if network_list[i].id == id:
                    del self.networks[i]
                    break
            return True
        elif not name:
            return self.__error__("Please provide either a name or an id.")

        for i in range(len(network_list)):
            if network_list[i].name == name:
                json_funcs._delete_(self.connection.session,
                                    self.curl +
                                    '/networks/' +
                                    network_list[i].id)
                del self.networks[i]
                return True

        return self.__error__("Network with name '%s' does not exist" %
                              name)

    def share_network(self, network_id, user_id):
        """Share a network with a user.

        Args:
            network_id (str): id of the network to be shared
            user_id (str): id of the user to be shared with

        Returns:
            True if successful
        """

        error_message = ''
        if network_id is None:
            error_message = error_message + 'Network id is missing'
        if user_id is None:
            error_message = error_message + 'User id is missing'
        if len(error_message) > 0:
            return self.__error__(error_message)

        post_params = {}
        share_url = self.curl + '/networks/%s/users/%s' % (network_id, user_id)
        json_funcs._post_(self.connection.session, share_url, post_params)

        return True

    def outcome_lens_param_optimization(self,
                                        name='Outcome Lens Optima',
                                        column_set_id=None,
                                        group_id=None,
                                        type='FULL',
                                        network=None,
                                        metric=None,
                                        lenses=None,
                                        disjoint_network=None,
                                        outcome_spec=None):
        """
        Creates networks for a given source, a given outcome column,
        and metric and lens combination and runs these analyses.
        This function is always run asynchronously. See example
        of usage in the tutorial. This method does a narrower optimization than the full OutcomeAutoAnalysis. 
        The users select the given Metric and Lenses and the method returns optimal networks created using those Metric and Lenses, 
        varying only the lens parameters (gain, resolution).

        Args:
            name: User defined prefix for network names.
                Default='Outcome Lens Optima'
            column_set_id (str): id of the column_set . Returned by
                :func:`create_column_set <ayasdi.core.source.Source.create_column_set>` or
                :func:`get_column_set <ayasdi.core.source.Source.get_column_set>`.
            group_id: Id of group to use for creating the network. Default=All rows.
            type: Lens scoring type: FULL or QUICK
            network: An existing network to optimize the lens parameters on
                (optional with metric and lenses)
            metric: A metric for optimization (optional with network).
            lenses: A list of lenses for optimization(optional with network).
            disjoint_network: If True, the network is
                created with disjoint nodes (nodes that that do not share any data points).
                Default=False (optional)
            outcome_spec (OutcomeSpec): An :class:`OutcomeSpec <ayasdi.core.outcome_spec.OutcomeSpec>` object.

        Returns:
            :class:`Job <ayasdi.core.jobs.Job>` objects.

            Networks can be extracted from these jobs as shown in the example below.

        :Example:

        >>> import ayasdi.core as ac
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> src.sync() #ignore-in-doc
        >>> # Creating a column set
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = \
        src.create_column_set(column_list=columns_for_analysis,
        ...                   name="test_column_set1")
        >>> # Delete all previous networks in the source if needed
        >>> outcome_spec = ac.OutcomeSpec(outcome_column_name="clinical classification")
        >>> running_jobs = \
        src.outcome_lens_param_optimization(name="test_params",
        ...                                 column_set_id=column_set['id'],
        ...                                 metric='Euclidean (L2)',
        ...                                 lenses=
        ...                                 ['Gaussian Density'],
        ...                                 outcome_spec=outcome_spec)
        >>> remaining = len(running_jobs)
        >>> # sleep between checking job status.
        >>> import time
        >>> while remaining:
        ...    for ind, job in enumerate(running_jobs):
        ...       time.sleep(15)
        ...       job.sync()
        ...       if job.status != "in_progress":
        ...          remaining -= 1
        ...          finished_job = running_jobs.pop(ind)
        ...          break
        >>> remaining
        0
        >>> src.sync()
        >>> networks = src.get_networks()
        >>> param_networks = [i.name for i in networks
        ...                   if 'test_params' in i.name]
        >>> for network in param_networks: #ignore-in-doc
        ...     _ = src.delete_network(name=network) # ignore-in-doc
        >>> _ = src.delete_column_set(name='test_column_set1') #ignore-in-doc
        """
        self.sync()
        params_dict = {'name_base': name, 'async': {}, 'type': type}

        if column_set_id is not None:
            params_dict['column_set_id'] = column_set_id
        if group_id is not None:
            params_dict['group_id'] = group_id
        if network is not None:
            metric = network.metric
            lenses = network.lenses
        else:
            metric = {'id': metric}
            lenses = [{'id': lens} for lens in lenses]
        params_dict['metric_id'] = metric
        params_dict['lens_ids'] = lenses

        if disjoint_network is not None:
            params_dict['disjoint_network'] = disjoint_network
        if outcome_spec is not None:
            outcome_spec['outcome_column_index'] = self._get_outcome_column_index(
                outcome_spec['outcome_column_name'],
                outcome_spec['outcome_column_index'])
            params_dict['outcome_spec'] = outcome_spec.serialize()

        run_jobs = json_funcs._post_(self.connection.session,
                                     self.curl +
                                     '/outcome_auto_analysis_lens'
                                     '_param_optimization', params_dict)
        return [jobs.Job(self.connection, [run_job]) for run_job in run_jobs]

    def outcome_affine_selector(self, column_set_id=None,
                                outcome_column_index=None,
                                sub_column_set_ids=None,
                                num_results=None):
        """
        Using an outcome column, outcome_affine_selector
        will approximate an optimized
        affine metric combination on two sub column sets.

        .. note::
           In other words, given two column sets,
           this call enables you to find
           the optimal weighted combination of metrics on those
           columns with respect to an outcome column.

           This function is always run asynchronously.
           See example of usage in the tutorial.

        Args:
            column_set_id (str): The id of the column set that contains all the
                columns provided in the sub column set
            outcome_column_index: Index of the column used for analysis.
            sub_column_set_ids: List of column set ids that will be used for
                each submetric in the resulting Affine metric combination
            num_results: The maximum number of results you want returned
                by this algorithm

        Returns:
            A :class:`Job <ayasdi.core.jobs.Job>` object.

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> src.sync() #ignore-in-doc
        >>> # Creating a column set
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = \
        src.create_column_set(column_list=columns_for_analysis,
        ...                           name="test_column_set1")
        >>> sub_col_set1 = src.create_column_set(column_list=
        ...                                      ["relative weight",
        ...                                       "blood glucose"],
        ...                                      name='subcol1')
        >>> sub_col_set2 = \
        src.create_column_set(column_list=["insulin level",
        ...                                "insulin response"],
        ...                                name='subcol2')
        >>> # Delete all previous networks in the source if needed
        >>> affine_job = \
        src.outcome_affine_selector(outcome_column_index=
        ...                         src.colname_to_ids["clinical classification"],
        ...                         column_set_id=column_set['id'],
        ...                         sub_column_set_ids=
        ...                         [sub_col_set2['id'],
        ...                          sub_col_set2['id']],
        ...                         num_results=3)
        >>> import time  #To sleep between checking job status.
        >>> while affine_job.status == 'in_progress':
        ...       time.sleep(15)
        ...       affine_job.sync()
        >>> # To view the output, print the json object:
        >>> top_metric = affine_job.json['result']['metrics'][0]
        >>> top_metric['id']
        'Affine'
        >>> # Example of using the first metric
        >>> # returned in a network creation call
        >>> network = src.create_network("Affine_selector_top_metric",
        ...                              {'column_set_id':column_set['id'],
        ...                              'metric':top_metric,
        ...                              'lenses':[{'id':'Gaussian Density',
        ...                                         'resolution':30, 'gain':3,
        ...                                         'equalize':True}]})
        >>> _ = src.delete_column_set(name="subcol1")
        >>> _ = src.delete_column_set(name="subcol2")
        >>> _ = src.delete_network(name='Affine_selector_top_metric')
        >>> _ = src.delete_column_set(name='test_column_set1')
        """
        self.sync()
        params_dict = {'async': {}}

        if column_set_id is not None:
            params_dict['column_set_id'] = column_set_id

        params_dict['outcome_column_index'] = outcome_column_index
        params_dict['sub_column_set_ids'] = sub_column_set_ids
        params_dict['desired_num_resulting_metrics'] = num_results
        run_jobs = json_funcs._post_(self.connection.session,
                                     self.curl +
                                     '/outcome_affine_metric_selector',
                                     params_dict)
        return jobs.Job(self.connection, run_jobs[0])

    def create_coloring(self, name, row_indices=None, column_id=None,
                        column_name=None, filter_set=None, network=None,
                        node_group=None, node_ids=None,
                        lens_specification=None, row_specifications=None,
                        disjoint_group_ids=None, custom_array=None, network_id=None, metadata={}):
        """
        Creates a new coloring for the current :class:`source <ayasdi.core.source.Source>`.

        A coloring indicates a scheme by which you can color any network.
        To get actual values for the coloring from any network,
        use :func:`network.get_coloring_values <ayasdi.core.networks.Network.get_coloring_values>`

        Args:
            name: User defined name of this coloring.
            row_indices: Row indices to be used for coloring.
            column_id: Index of the column used for coloring (optional with
                column_name, lens_specification, or filter_set).
            column_name: Name of the column used for coloring (optional with
                column_id, lens_specification, or filter_set).
            filter_set: The filter set to color by.
                See :func:`create_filter_set`
            network(Deprecated, use network_id instead): The :class:`network <ayasdi.core.networks.Network>` object to
                work on. Used only if either the node_group parameter or the node_ids parameter is set.
            network_id (str): The id of a :class:`network <ayasdi.core.networks.Network>` object to work on. Used only
                if either the node_group parameter or the node_ids parameter is set.
            node_group: The node group to focus on. Only used if the ``network`` parameter is specified.
            node_ids: A list of node ids to focus on. Only used if the ``network`` parameter is specified.
            lens_specification: Color by the following lens_specification
                (optional with column_id, filter_set, and column_name). A
                lens_specification must be a dictionary
                with the following keys - lens_id, metric_id, and column_set_id
            row_specifications: If a row_specification is provided, this is passed automatically.
                Rarely used.
            disjoint_group_ids([str]): A list of disjoint group identifiers to be used for group membership
                coloring.
            custom_array([float]): A list of double values of the same size as the total points in the source file, used
                for the custom data coloring similar to a column data coloring. Rather than providing a column index or
                column name for retrieving the column data, a user can provide the custom data directly.
            metadata (dict): Metadata for the coloring stored as key-value pairs.

        Returns:
            A coloring dictionary as shown in the example below.

        :Example:

        >>> src = extraglobs['src'] # ignore-in-doc
        >>> metadata = {'features': 'selected features', 'algorithm': 'new fancy algorithm'}
        >>> new_coloring = src.create_coloring(name='test_coloring', column_id=4, metadata=metadata)
        >>> sorted(new_coloring.keys())  # doctest: +NORMALIZE_WHITESPACE
        ['coloring_palette_specification', 'column_index',
         'entity_uri', 'id', 'metadata', 'name']
        >>> # Coloring based on filter sets for categorical data.
        >>> src.sync()
        >>> filter_set = \
            src.create_filter_set([{'column_name':
        ...                         'clinical classification',
        ...                         'in_set': [3]},
        ...                         {'column_name': 'relative weight',
        ...                          'in_range': [0.8, 1],
        ...                          'not': True}], as_and=True)
        >>> new_coloring = src.create_coloring(name='test_filter_set',
        ...                                    filter_set=filter_set)
        >>> sorted(new_coloring.keys())  # doctest: +NORMALIZE_WHITESPACE
        ['coloring_palette_specification', 'entity_uri',
         'filter_set', 'id', 'metadata', 'name']
        >>> coloring2 = \
            src.create_coloring(name="test_rowspec_coloring",
        ...                     row_specifications=
        ...                     [{'row_indices': list(range(10))}])
        >>> src.sync()
        >>> _ = src.delete_coloring(name="test_rowspec_coloring") #ignore-in-doc
        >>> _ = src.delete_coloring(name="test_coloring") #ignore-in-doc
        >>> _ = src.delete_coloring(name="test_filter_set") #ignore-in-doc
        """
        # Return preexisting colorings with the same name
        coloring = self.get_coloring(name=name)
        if 'msg' not in coloring:
            return coloring
        # or build the post call
        coloring_info = {'name': name}
        if column_name is not None:
            column_id = self.colname_to_ids[column_name]
            coloring_info['column_index'] = str(column_id)
        elif column_id is not None:
            coloring_info['column_index'] = str(column_id)
        elif filter_set is not None:
            coloring_info['filter_set'] = filter_set
        elif lens_specification is not None:
            coloring_info['lens_coloring_description'] = lens_specification
        elif disjoint_group_ids is not None:
            coloring_info['disjoint_group_ids'] = disjoint_group_ids
        elif custom_array is not None:
            coloring_info['custom_array'] = custom_array
        if row_indices is not None:
            coloring_info['row_specifications'] = \
                [{'row_indices': row_indices}]
        elif any(v is not None for v in {network, network_id}):
            if all(v is not None for v in {network, network_id}):
                raise ValueError("Do not pass both network and network_id. Only pass one of them")
            if network is not None:
                warnings.warn("Deprecated: pass network_id instead.")
                network_id = network.id
            if node_group is None and node_ids is None:
                return self.__error__("Network provided but \
                                      no node_group or node_ids")
            elif node_group is not None:
                coloring_info['row_specifications'] = \
                    [{'node_specification':
                        {'network_id': network_id,
                            'node_group_id': node_group['id']}}]

            elif node_ids is not None:
                coloring_info['row_specifications'] = \
                    [{'node_specification': {'network_id': network_id,
                                             'node_ids': node_ids}}]
        elif row_specifications is not None:
            coloring_info['row_specifications'] = row_specifications
        if list(coloring_info.keys()) == ["name"]:
            return self.__error__("No required arguments are provided.")
        coloring_info['metadataMap'] = metadata
        # Get the column id and create coloring.
        coloring = json_funcs._post_(self.connection.session,
                                     self.curl + '/colorings',
                                     coloring_info)
        self.colorings.append(coloring)
        return coloring

    def get_colorings(self):
        """
        Returns colorings for the current :class:`source <ayasdi.core.source.Source>`.

        Returns:
            A list of coloring dictionaries.

        :Example:

        >>> src = extraglobs['src'] #ignore-in-doc
        >>> colorings = src.get_colorings()
        >>> # See list of colorings
        >>> [x['name'] for x in colorings]
        ['Rows per Node', 'Edges per Node']
        """

        try:
            return self.colorings
        except AttributeError as e:
            LOGGER.exception(e)
            self.__get_full_source__()
            return self.colorings

    def get_coloring(self, name=None, id=None):
        """Returns a coloring by name or id.

        Args:
           id (str): The id of the requested coloring (optional with name)
           name (str): The name of the requested coloring (optioanl with id)

        Returns:
           A coloring dictionary

        :Example:
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> coloring = src.get_coloring(name="Rows per Node")
        >>> # Since this is a coloring of rows per node,
        >>> # no column_id is present
        >>> sorted(coloring.keys())
        ['entity_uri', 'id', 'name']
        >>> coloring = src.get_coloring(id='1')
        >>> coloring['name']
        'Edges per Node'
        """
        if id is not None:
            try:
                return json_funcs._get_(self.connection.session,
                                        self.curl + '/colorings/' +
                                        id)
            except HTTPError as e:
                if e.response.status_code == 404:
                    return self.__error__("Coloring with id {} does "
                                          "does not exist".format(id))
                else:
                    raise
        elif name is not None:
            colorings = self.get_colorings()
            for coloring in colorings:
                if coloring['name'] == name:
                    return coloring
            return self.__error__("Coloring with name '%s' does not exist" %
                                  name, False)
        else:
            return self.__error__("Please provide a name or an id")

    def delete_colorings(self, ids=[]):
        """
        Deletes a list of colorings by id.

        Args:
            ids ([str]): List of coloring ids.

        Returns:
            True if successful, else prints a message and returns None.
        """
        if len(ids) > 0:
            for id_ in ids:
                self.delete_coloring(id=id_)
        else:
            raise ValueError("Please provide a list of ids")
        return True

    def delete_coloring(self, name=None, id=None):
        """
        Deletes a coloring with a given name or id.

        Args:
            id: The id of the requested coloring (optional with name).
            name: The name of the requested coloring (optional with id).

        Returns:
            True if successful, else prints a message and returns None.

        :Example:

        >>> src = extraglobs['src'] #ignore-in-doc
        >>> src.sync()
        >>> src.delete_coloring(name="test")
        True
        """
        if not name and not id:
            raise ValueError("Please provide an id or a name")
        colorings = self.get_colorings()
        for ind, coloring in enumerate(colorings):
            if coloring['name'] == name or coloring['id'] == id:
                json_funcs._delete_(self.connection.session,
                                    self.curl +
                                    '/colorings/' +
                                    coloring['id'])
                del self.colorings[ind]
                return True
        raise AttributeError("Coloring with given parameters does not exist")

    def share_coloring(self, coloring_id, user_id):
        """Share a coloring with a user.

        Args:
            coloring_id (str): id of the coloring to be shared
            user_id (str): id of the user to be shared with

        Returns:
            True if successful
        """

        error_message = ''
        if coloring_id is None:
            error_message = error_message + 'Coloring id is missing'
        if user_id is None:
            error_message = error_message + 'User id is missing'
        if len(error_message) > 0:
            return self.__error__(error_message)

        post_params = {}
        share_url = self.curl + '/colorings/%s/users/%s' % (coloring_id, user_id)
        json_funcs._post_(self.connection.session, share_url, post_params)

        return True

    def compare_groups(self, group_1_name, group_2_name="Rest",
                       name=None,
                       column_set_id=None,
                       comparison_type='continuous_and_categorical',
                       async_=False,
                       metadata={}):

        """Compare groups in the current :class:`source <ayasdi.core.source.Source>`.

        .. note::
           Categorical comparisons are skipped for columns where more than 98% of the rows
           have the same value.
           If the source has a large number of columns,
           use :func:`iter_compare_groups <ayasdi.core.source.Source.iter_compare_groups>` instead.

        Args:
            group_1_name (str): Primary group for comparison
            group_2_name (str): Secondary group for comparison. Defaults to 'Rest'.
                Alternatively, use 'All'.
            name (str): User defined name for the comparison. Defaults to empty string,
                in which case a generic name is created.
            column_set_id (str): id of the column_set . Returned by
                :func:`create_column_set <ayasdi.core.source.Source.create_column_set>` or
                :func:`get_column_set <ayasdi.core.source.Source.get_column_set>`.
            comparison_type (str): Type of comparison to compute: 'continuous_only',
                'categorical_only', or 'continuous_and_categorical' (default).
            async_: when True, runs ``compare_groups`` asynchronously and returns an
                :class:`ayasdi.core.async_jobs.AsyncJob` object. The object's "result" field is set to a dictionary
                that describes the result set.
            metadata (dict): Metadata for the coloring stored as key-value pairs.

        Returns:
            A comparison dictionary.
            The following keys are present in a comparison dictionary:
               - id : Id of the comparison
               - name : Name of the comparison
               - column_set_id : Column set id used for the comparison
               - row_sets : Group over which comparison is done
               - continuous_explainers : Comparisons for continuous columns
               - categorical_explainers : Comparisons for categorical columns

            The comparison_type returns one of the following sets of keys based on the comparison_type selected:
                * continuous_only - categorical_explainers is null; continuous_explainers:
                  {column index; ks_score; p_value;
                  quartiles; t_test_p_value; diff_means; primary_group_mean; secondary_group_mean;
                  ks_sign; group0_percent_null; group1_percent_null;
                  bh_p_value; bh_t_test_p_value}

                * categorical_only - continuous_explainers is null; categorical_explainers:
                  {column index; hypergeometric_p_values[], percent_in_group, name}

                * continuous_and_categorical (default value) - complete continuous and categorical explainer listings
                  as described

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> source = extraglobs['src'] #ignore-in-docs
        >>> for comp in source.get_comparisons(): #ignore-in-docs
        ...     _ = source.delete_comparison(name=comp['name']) #ignore-in-docs
        >>> len(source.get_comparisons())
        0
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = \
            source.create_column_set(column_list=columns_for_analysis,
        ...                       name="test_column_set")
        >>> group1 = source.create_group(name="test_group1",
        ...                              row_indices=list(range(10)))
        >>> group2 = source.create_group(name="test_group2",
        ...                              row_indices=list(range(5, 15)))
        >>> comparison = source.compare_groups("test_group1", "test_group2")
        >>> comparison = source.compare_groups("test_group1", "All",
        ...                                    column_set_id=column_set['id'],
        ...                                    name="testVsAll")
        >>> comparison = source.compare_groups("test_group1", "Rest",
        ...                                    column_set_id=column_set['id'],
        ...                                    name="testVsRest")
        >>> source.sync()
        >>> comparisons = source.get_comparisons()
        >>> len(comparisons)
        3
        >>> source.delete_comparison(name="test_group1 vs. test_group2 "
        ...                          "on All columns")
        True
        >>> source.delete_comparison(name="testVsAll")
        True
        >>> source.delete_comparison(name="testVsRest")
        True
        >>> source.sync()
        >>> # Async version below
        >>> compare_job = source.compare_groups("test_group1", "test_group2",
        ...                                     comparison_type='continuous_only',
        ...                                     async_=True)
        >>> compare_job.sync()
        >>> source.sync()
        >>> comparisons = source.get_comparisons()
        >>> comparisons[0]['name']
        'test_group1 vs. test_group2 on All columns'
        >>> new_comp = source.rename_comparison(id=comparisons[0]['id'],
        ...                                     new_name="new_comparison_name")
        >>> new_comp['name']
        'new_comparison_name'
        >>> comparisons = source.get_comparisons()
        >>> comparisons[0]['name']
        'new_comparison_name'
        >>> source.delete_comparison(name="new_comparison_name")
        True
        >>> source.delete_column_set(id=column_set['id'])
        True
        """

        compare_info = self._compare_groups_helper(group_1_name, group_2_name,
                                                   name,
                                                   column_set_id,
                                                   comparison_type,
                                                   metadata)

        if 'msg' in compare_info:
            return compare_info

        if async_:
            endpoint = self.curl + '/comparisons/async'
            async_task = json_funcs._post_(self.connection.session,
                                           endpoint, compare_info)
            return async_jobs.AsyncJob(self.connection, async_task, endpoint)
        else:
            comparison = json_funcs._post_(self.connection.session,
                                           self.curl + '/comparisons',
                                           compare_info)
        return comparison

    def compare_multiple_groups(self,
                                primary_group_ids,
                                secondary_group=None,
                                prefix=None,
                                column_set_id=None,
                                comparison_type='continuous_and_categorical',
                                async_=False,
                                secondary_group_ids=None,
                                metadata={}):

        """
        Creates multiple comparisons of primary groups to a secondary group, either on all columns or on a specified
        column set.

        Args:
            primary_group_ids ([str]): Ids of groups that will be compared separately.
            secondary_group (str): Id of the group to which the primary groups are compared. Valid
                entries are the id of an existing group, 'All' (all the source data, including the primary group) or
                'Rest' (all the source data, excluding the primary group). If not provided, defaults to 'Rest'.
            column_set_id (str): If provided, specifies that the multiple comparisons run against a particular
                column set. If not provided (None), the multiple comparisons run against all columns.
            prefix (str): Optional prefix to identify these comparisons, such as 'IGC' for ICG-1, ICG-2, etc.. If not
                provided, no prefix is added.
            comparison_type (str): Type of a comparison to compute: 'continuous_only','categorical_only', or
                'continuous_and_categorical' (default).
            async\_: when True, runs ``compare_multiple_groups`` asynchronously and returns an
                :class:`ayasdi.core.async_jobs.AsyncJob` object. The object's "result" field is set to a dictionary
                that describes the result set.
            secondary_group_ids ([str]): Ids of groups that will be compared together.

        Returns:

            A list of comparison dictionaries.
            The following keys are present in a comparison dictionary:
               - id : Id of the comparison
               - name : Name of the comparison
               - column_set_id : Column set id used for the comparison
               - row_sets : Group over which comparison is done
               - continuous_explainers : Comparisons for continuous columns
               - categorical_explainers : Comparisons for categorical columns

            The comparison_type returns one of the following sets of keys based on the comparison_type selected:
                * continuous_only - categorical_explainers is null; continuous_explainers:
                  {column index; ks_score; p_value;
                  quartiles; t_test_p_value; diff_means; primary_group_mean; secondary_group_mean;
                  ks_sign; group0_percent_null; group1_percent_null;
                  bh_p_value; bh_t_test_p_value}

                * categorical_only - continuous_explainers is null; categorical_explainers:
                  {column index; hypergeometric_p_values[], percent_in_group, name}

                * continuous_and_categorical (default value) - complete continuous and categorical explainer listings
                  as described

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> source = extraglobs['src'] #ignore-in-docs
        >>> for comp in source.get_comparisons(): #ignore-in-docs
        ...     _ = source.delete_comparison(name=comp['name']) #ignore-in-docs
        >>> len(source.get_comparisons())
        0
        >>> group1 = source.create_group(name="test_group1",
        ...                              row_indices=list(range(10)))
        >>> group2 = source.create_group(name="test_group2",
        ...                              row_indices=list(range(5, 15)))
        >>> comparisons = source.compare_multiple_groups([group1['id'], group2['id']])
        >>> len(comparisons)
        2
        >>> source.sync()
        >>> comparisons = source.get_comparisons()
        >>> len(comparisons)
        2
        """
        if secondary_group and secondary_group_ids:
            raise ValueError("Ambiguous arguments. Please specify only one of 'secondary_group'"
                             " or 'secondary_group_ids'.")

        secondary_groups_0 = []
        if secondary_group_ids:
            secondary_groups_0 = secondary_group_ids
        elif secondary_group:
            secondary_groups_0.append(secondary_group)
        else:
            secondary_groups_0.append('Rest')

        secondary_group_ids_1 = []
        for secondary_group in secondary_groups_0:
            if secondary_group == 'Rest':
                secondary_group_ids_1.append('1')
            elif secondary_group == 'All':
                secondary_group_ids_1.append('0')
            else:
                try:
                    int(secondary_group)
                except ValueError:
                    raise ValueError(
                        "secondary_group has to be 'All', 'Rest' or an integer string as a valid group id. "
                        "The provided: '%s' is not." % secondary_group)
                secondary_group_ids_1.append(secondary_group)

        if column_set_id is None:
            column_set_id = self.get_column_set(name='All columns')['id']
        compare_info = {'primary_group_ids': primary_group_ids,
                        'secondary_group_ids': secondary_group_ids_1,
                        'column_set_id': column_set_id,
                        'comparison_type': comparison_type,
                        'metadata': metadata}
        if prefix is not None:
            compare_info['prefix'] = prefix
        if async_:
            endpoint = self.curl + '/comparisons/multiple_comparisons/async'
            async_task = json_funcs._post_(self.connection.session,
                                           endpoint, compare_info)
            status_endpoint = self.curl + '/comparisons/async'
            return async_jobs.AsyncJob(self.connection, async_task, status_endpoint)
        else:
            comparisons = json_funcs._post_(self.connection.session,
                                            self.curl + '/comparisons/multiple_comparisons',
                                            compare_info)
            return comparisons

    def iter_compare_groups(self, group_1_name, group_2_name="Rest",
                            name=None,
                            column_set_id=None,
                            comparison_type='continuous_and_categorical',
                            async_=False,
                            metadata={}):

        """Compare groups in the current :class:`source <ayasdi.core.source.Source>` and returns a generator.

        .. note::

          If there are a lot of columns in the source (e.g. > 10000), this is preferred over
          :func:`compare_groups <ayasdi.core.source.Source.compare_groups>`
          Categorical comparisons are skipped for columns where more than 98% of the rows
          have the same value.


        Args:
            group_1_name (str): Primary group for comparison
            group_2_name (str): Secondary group for comparison. Defaults to 'Rest'.
                Alternatively, use 'All'.
            name (str): User defined name for the comparison. Defaults to empty string,
                in which case a generic name is created.
            column_set_id (str): id of the column_set . Returned by
                :func:`create_column_set <ayasdi.core.source.Source.create_column_set>` or
                :func:`get_column_set <ayasdi.core.source.Source.get_column_set>`.
            comparison_type (str): Type of comparison to compute: 'continuous_only',
                'categorical_only', or 'continuous_and_categorical' (default).
            async\_: when True, runs ``compare_groups`` asynchronously and returns an
                :class:`ayasdi.core.async_jobs.AsyncJob` object. The object's "result" field is set to a dictionary
                that describes the result set.
            metadata (dict): Metadata for the coloring stored as key-value pairs.

        Returns:
            See the return type for :func:`compare_groups <ayasdi.core.source.Source.compare_groups>`

        :Example:
        >>> import ayasdi.core as ac
        >>>
        >>> source = extraglobs['src'] #ignore-in-docs
        >>> for comp in source.get_comparisons(): #ignore-in-docs
        ...     _ = source.delete_comparison(name=comp['name']) #ignore-in-docs
        >>> len(source.get_comparisons())
        0
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = \
            source.create_column_set(column_list=columns_for_analysis,
        ...                       name="test_column_set")
        >>> group1 = source.create_group(name="test_group1",
        ...                              row_indices=list(range(10)))
        >>> group2 = source.create_group(name="test_group2",
        ...                              row_indices=list(range(5, 15)))
        >>> comparison_stub1 = source.iter_compare_groups("test_group1", "test_group2")
        >>> comparison_stub2 = source.iter_compare_groups("test_group1", "All",
        ...                                    column_set_id=column_set['id'],
        ...                                    name="testVsAll")
        >>> comparison_stub3 = source.iter_compare_groups("test_group1", "Rest",
        ...                                    column_set_id=column_set['id'],
        ...                                    name="testVsRest")
        >>> source.sync()
        >>> comparison_stubs = source.get_comparisons()
        >>> len(comparison_stubs)
        3
        >>> categorical_comparisons = \
            list(source.iter_get_categorical_comparison(id=comparison_stub1['id']))
        >>> len(categorical_comparisons)
        16
        >>> continuous_comparisons = \
            list(source.iter_get_continuous_comparison(id=comparison_stub2['id']))
        >>> len(continuous_comparisons)
        4
        """
        compare_info = self._compare_groups_helper(group_1_name, group_2_name,
                                                   name=name,
                                                   column_set_id=column_set_id,
                                                   comparison_type=comparison_type,
                                                   metadata=metadata)

        if 'msg' in compare_info:
            return compare_info

        if async_:
            endpoint = self.curl + '/comparisons/stub/async'
            async_task = json_funcs._post_(self.connection.session,
                                           endpoint, compare_info)
            return async_jobs.AsyncJob(self.connection, async_task, endpoint)
        else:
            comparison = json_funcs._post_(self.connection.session,
                                           self.curl + '/comparisons/stub',
                                           compare_info)
        return comparison

    def _compare_groups_helper(self, group_1_name, group_2_name="Rest",
                               name=None,
                               column_set_id=None,
                               comparison_type='continuous_and_categorical',
                               metadata={}):

        # Get first group to compare
        groups = self.get_groups()
        group1 = None
        for group in groups:
            if group['name'] == group_1_name:
                group1 = group
        if not group1:
            return self.__error__("Group with name '%s' not found!" %
                                  group_1_name)

        # Get second group
        group2 = None
        if group_2_name in ["Rest", "Remaining"]:
            group2 = {'id': '1'}
        elif group_2_name == "All":
            group2 = {'id': '0'}
        else:
            for group in groups:
                if group['name'] == group_2_name:
                    group2 = group
        if not group2:
            return self.__error__("Group with name '%s' not found!" %
                                  group_2_name)

        self.sync()

        # Get column names
        if column_set_id is None:
            columns = [i['name'] for i in self.columns]
            column_set_name = "All columns"
            full_column_set = self.create_column_set(column_list=columns, name=column_set_name)
            column_set_id = full_column_set['id']
        else:
            full_column_set = self.get_column_set(id=column_set_id)
            column_set_name = column_set_id
            if self._is_invalid_column_set(full_column_set):
                error_msg = full_column_set
                return error_msg

        if name is None:
            name = "{} vs. {} on {}".format(group_1_name, group_2_name, column_set_name)

        if comparison_type not in \
                ['continuous_only', 'categorical_only', 'continuous_and_categorical']:
            raise AssertionError('comparison_type has to be continuous_only,\
                                 categorical_only or \
                                 continuous_and_categorical')

        compare_info = {'primary_node_group_id': group1['id'],
                        'secondary_node_group_id': group2['id'],
                        'column_set_id': column_set_id,
                        'comparison_type': comparison_type,
                        'name': name,
                        'metadata': metadata}
        return compare_info

    def _is_invalid_column_set(self, colset):
        if 'msg' in colset:
            return True
        else:
            return False

    def get_comparisons(self, group_name=None, group_id=None):
        """
        Returns comparisons for the current :class:`source <ayasdi.core.source.Source>`.
        Optionally, limit the comparisons to those that involve a specific group.

        Args:
            group_name (str): (optional) The name of the group.
            group_id (str): (optional) The id of the group.

        Returns:
            A list of comparison dictionaries.

        :Example:

        >>> src = connection.upload_source('./test/db_test12.txt', allow_duplicate=True) #ignore-in-doc
        >>> src.sync() #ignore-in-doc
        >>> group1 = src.create_group(name='group1', row_indices=list(range(50)))
        >>> group2 = src.create_group(name='group2', row_indices=list(range(50, 100)))
        >>> comparison = src.compare_groups('group1')
        >>> comparison = src.compare_groups('group2')
        >>> comparison = src.compare_groups('group1', 'group2')
        >>> comparisons = src.get_comparisons()
        >>> len(comparisons)
        3
        >>> comparisons = src.get_comparisons(group_id=group2['id'])
        >>> len(comparisons)
        2
        >>> connection.delete_source(name=src.name)
        """
        # Get the source again and return comparisons
        # comparisons = json_funcs._get_(self.connection.session,
        #                                self.curl + '/comparisons')
        self.__get_full_source__()
        comparisons = self.comparisons
        ret_comps = []
        if group_id:
            for comp in comparisons:
                groups = comp['row_sets']
                for group in groups:
                    if 'id' in group:
                        if group['id'] == int(group_id):
                            ret_comps.append(comp)
                            break
            return ret_comps

        if group_name:
            for comp in comparisons:
                groups = comp['row_sets']
                for group in groups:
                    if group['name'] == group_name:
                        ret_comps.append(comp)
                        break
            return ret_comps

        return comparisons

    def get_comparison(self, name=None, id=None, top_explainers_filter_spec=None):
        """
        Returns a existing comparison by name or id.

        To obtain the top
        explainers for a particular comparison, use the ``top_explainers_filter_spec`` parameter.

        Args:
            name (str): specifies an existing comparison by its name.
            id (str): specifies an existing comparison by its id.
            top_explainers_filter_spec (TopExplainersFilterSpec): A
              :class:`TopExplainersFilterSpec <ayasdi.core.top_explainers_filter_spec.TopExplainersFilterSpec>`
              object (optional)

        Returns:
            A comparison dictionary

        :Example:

        >>> src = connection.upload_source('./test/db_test12.txt')
        >>> group1 = src.create_group(name='group1', row_indices=list(range(100)))
        >>> comparison = src.compare_groups('group1')
        >>> top_explainers = src.get_comparison(id=comparison['id'],
        ...                                     top_explainers_filter_spec=TopExplainersFilterSpec())
        >>> connection.delete_source(name=src.name)
        """
        selected_comparison = self._validate_comparison_helper(name, id)

        if 'msg' in selected_comparison:
            return selected_comparison

        try:
            end_point = self.curl + '/comparisons/' + selected_comparison
            if top_explainers_filter_spec is not None and \
                    isinstance(top_explainers_filter_spec, TopExplainersFilterSpec):
                query = []
                if top_explainers_filter_spec.min_ks_score is not None:
                    query.append('min_ks_score=%s' % top_explainers_filter_spec.min_ks_score)
                if top_explainers_filter_spec.max_p_value is not None:
                    query.append('max_p_value=%s' % top_explainers_filter_spec.max_p_value)
                if top_explainers_filter_spec.max_number_of_continuous_explainers is not None:
                    query.append('max_number_of_continuous_explainers=%s' %
                                 top_explainers_filter_spec.max_number_of_continuous_explainers)
                if top_explainers_filter_spec.max_number_of_categorical_explainers is not None:
                    query.append('max_number_of_categorical_explainers=%s' %
                                 top_explainers_filter_spec.max_number_of_categorical_explainers)
                if len(query) > 0:
                    end_point += '?' + '&'.join(query)
            return json_funcs._get_(self.connection.session, end_point)
        except HTTPError as e:
            if e.response.status_code == 404:
                return self.__error__('Comparison with id {} does not'
                                      'exist'.format(id))
            else:
                raise

    def iter_get_continuous_comparison(self, name=None, id=None):
        """
        Retrieve a existing continuous comparison by name or id as a stream.

        .. note::

          If there are a lot of columns in the source (e.g. > 10000), this is preferred over
          :func:`get_comparisons <ayasdi.core.source.Source.get_comparisons>`

        Args:
            name (str): specifies an existing comparison by its name.
            id (str): specifies an existing comparison by its id.

        Returns:
            A generator object that iterates over a stream of continuous comparisons.

        :Example:
            Please refer documentation for :func:`iter_compare_groups`

        """
        selected_comparison = self._validate_comparison_helper(name, id)

        if 'msg' in selected_comparison:
            return selected_comparison

        try:
            return json_funcs._iter_get_(self.connection.session, self.curl +
                                         '/comparisons/' + selected_comparison +
                                         '/continuous/stream')
        except HTTPError as e:
            if e.response.status_code == 404:
                return self.__error__('Comparison with id {} does not'
                                      'exist'.format(id))
            else:
                raise

    def iter_get_categorical_comparison(self, name=None, id=None):
        """
        Retrieve a existing categorical comparison by name or id as a stream.

        .. note::

          If there are a lot of columns in the source (e.g. > 10000), this is preferred over
          :func:`get_comparisons <ayasdi.core.source.Source.get_comparisons>`

        Args:
            name (str): specifies an existing comparison by its name.
            id (str): specifies an existing comparison by its id.

        Returns:
            A generator object that iterates over a stream of categorical comparisons.

        :Example:
            Please refer documentation for :func:`iter_compare_groups`

        """
        selected_comparison = self._validate_comparison_helper(name, id)

        if 'msg' in selected_comparison:
            return selected_comparison

        try:
            return json_funcs._iter_get_(self.connection.session, self.curl +
                                         '/comparisons/' + selected_comparison +
                                         '/categorical/stream')
        except HTTPError as e:
            if e.response.status_code == 404:
                return self.__error__('Comparison with id {} does not'
                                      'exist'.format(id))
            else:
                raise

    def _validate_comparison_helper(self, name=None, id=None):
        """
        A helper method that validates get_comparison params.
        """
        selected_comparison = None
        if id is not None:
            selected_comparison = id
        elif name is not None:
            comparisons = self.get_comparisons()
            for comparison in comparisons:
                if comparison['name'] == name:
                    selected_comparison = comparison['id']
            if selected_comparison is None:
                return self.__error__('Comparison with name {} does not'
                                      'exist'.format(name))
        else:
            return self.__error__("Please provide either a name or an id.")
        return selected_comparison

    def delete_comparison(self, name=None, id=None):
        """
        Deletes a comparison with a given name or id.

        Args:
            id (str): The id of the comparison (optional with name).
            name (str): The name of the comparison (optional with id).

        Returns:
            True if the comparison was successfully deleted,
            else prints and returns an error message

        :Example:

        See usage in :func:`compare_groups`
        """
        selected_comparison = None
        index = None
        comparisons = self.get_comparisons()

        for ind, comparison in enumerate(comparisons):
            if name is not None:
                if comparison['name'] == name:
                    selected_comparison = comparison['id']
                    index = ind
            elif id is not None:
                if comparison['id'] == id:
                    selected_comparison = comparison['id']
                    index = ind
            else:
                return self.__error__('Please provide either a name '
                                      'or an id.')
        if selected_comparison is None:
            return self.__error__('Comparison with the provided '
                                  'parameters does not exist.')

        try:
            json_funcs._delete_(self.connection.session, self.curl +
                                '/comparisons/' + selected_comparison)
            del self.comparisons[index]
            return True
        except HTTPError as e:
            if e.response.status_code == 404:
                raise HTTPError(e, 'Comparison with id {} does not'
                                   'exist'.format(id))
            else:
                raise

    def delete_comparisons(self, ids=[]):
        """
        Deletes a list of comparisons.

        Args:
            ids ([str]): List of comparison identifiers.

        Returns:
            True if successful
        """
        if len(ids) > 0:
            for id_ in ids:
                self.delete_comparison(id=id_)
        else:
            raise ValueError("Please provide a list of ids")
        return True

    def rename_comparison(self, id, new_name):
        """
        Renames a comparison.

        Args:
            id (str): The id of the comparison
            new_name (str): The new name of the comparison

        Returns:
            A comparison dictionary

        """
        all = self.get_comparisons()
        if id not in [x['id'] for x in all]:
            raise AttributeError('Comparison {} does not exist'.format(id))
        url = '{base}/comparisons/{id}'.format(base=self.curl, id=id)
        return json_funcs._put_(self.connection.session, url, {"name": new_name})

    def share_comparison(self, comparison_id, user_id):
        """Share a comparison with a user.

        Args:
            comparison_id (str): id of the comparison to be shared
            user_id (str): id of the user to be shared with

        Returns:
            True if successful
        """

        error_message = ''
        if comparison_id is None:
            error_message = error_message + 'Comparison id is missing'
        if user_id is None:
            error_message = error_message + 'User id is missing'
        if len(error_message) > 0:
            return self.__error__(error_message)

        post_params = {}
        share_url = self.curl + '/comparisons/%s/users/%s' % (comparison_id, user_id)
        json_funcs._post_(self.connection.session, share_url, post_params)

        return True

    def create_group(self, name=None, row_indices=None, filter_set=None,
                     group_id=None, network=None, node_ids=None,
                     new_source_name=None, network_id=None, metadata={}):
        """
        Creates a group from current :class:`source <ayasdi.core.source.Source>`.

        This function also allows creating a new source for this group using the ``new_source_name`` parameter.

        Args:
            name (str) : User defined name of the group. If a group with this name exists, it is returned. (required)
            row_indices ([int]) : Row indices used to populate the group. Defaults to all rows.
                (optional with ``network params``)
            filter_set (dict) : Rows that match this filter set are used to populate the group.
                See :func:`create_filter_set`.
            network (Depreated, use network_id instead) : A :class:`network <ayasdi.core.networks.Network>` object.
                Used only if the ``node_ids`` parameter is set.
            network_id (str): The id of a :class:`network <ayasdi.core.networks.Network>` object. Used only if the
                ``node_ids`` parameter is set.
            node_ids ([int]) : A list of node ids in the ``network`` parameter used to populate the group
            new_source_name (str) : Creates a source based on the specified group. If a source with the specified name
                already exists, nothing is done. (optional)
            metadata (dict) : Metadata for the group stored as key-value pairs. (optional)
            group_id (str) : ID of the group that will be used with the filter_set or network to create the group.
                group_id parameter requires the filter_set or network parameter to be passed to the method.

        Returns:
          A dictionary representing the group

        :Example:

         >>> #As seen in :func:`get_groups`

        """
        if all(v is not None for v in {network, network_id}):
            raise ValueError("Do not pass both network and network_id. Only pass one of them")

        if network is not None:
            warnings.warn("Deprecated: pass network_id instead.")
            network_id = network.id
        param_dict = self.__get_row_specifications__(network_id, node_ids,
                                                     row_indices, filter_set,
                                                     group_id)
        if name is None:
            return self.__error__('A name argument is required '
                                  'to create groups.')
        if group_id is not None and (filter_set is None and network is None):
            return self.__error__('The filter_set or network argument are '
                                  'required when creating groups with '
                                  'group_id.')
        # build the post call
        param_dict['name'] = name
        param_dict['metadata'] = metadata
        # If network is given, only choose that,
        # keep node group and node information,
        # but ignore row_indices
        group = json_funcs._post_(self.connection.session,
                                  self.curl + '/groups',
                                  param_dict)
        if new_source_name is not None:
            source_names = [source.name for source in
                            self.connection.get_sources()]
            if new_source_name in source_names:
                self.__error__('The source name already exists. New source not created')
            else:
                self.__source_from_group__(group['id'], new_source_name)
        return group

    def get_groups(self):
        """Retrieves a list of groups in the current :class:`source <ayasdi.core.source.Source>`.

        Returns:
            A list of group dictionaries

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> src.sync()
        >>> groups = src.get_groups() #ignore-in-doc
        >>> for group in groups: #ignore-in-doc
        ...     _ = src.delete_group(name=group['name']) #ignore-in-doc
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = \
            src.create_column_set(column_list=columns_for_analysis,
        ...                       name="test_column_set1")
        >>> network = src.create_network("test_network1",{
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': column_set['id'],
        ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 30, 'id': 'MDS coord 2',
        ...                   'equalize': True, 'gain': 3.0}]})
        >>> filter_set = src.create_filter_set([{'column_name':
        ...                                      'clinical classification',
        ...                                      'in_set': [3]},
        ...                                     {'column_name':
        ...                                      'relative weight',
        ...                                      'in_range': [0.8, 1],
        ...                                      'not': True}], as_and=True)
        >>> new_group = src.create_group(name="filter_set_group",
        ...                              filter_set=filter_set,
        ...                              new_source_name=
        ...                              "filter_set_group.csv")
        >>> sources = [i.name for i in connection.get_sources()]
        >>> 'filter_set_group.csv' in sources
        True
        >>> src.sync()
        >>> len(src.get_groups())
        1
        >>> _ = src.delete_column_set('test_column_set1') #ignore-in-doc
        >>> _ = src.delete_group(name='filter_set_group') #ignore-in-doc
        >>> _ = src.delete_network(name='test_network1')  #ignore-in-doc
        >>> connection.delete_source(name="filter_set_group.csv"
        ...                          ) #ignore-in-doc
        """
        groups = json_funcs._get_(self.connection.session,
                                  self.curl + '/groups')
        return groups

    def get_group(self, name=None, id=None):
        """Retrieve a group identified by name or id.

        Args:
            id (str): The id of the group (optional with name).
            name (str): The name of the group (optional with id).

        Returns:
          A group dictionary

        :Example:

        >>> #as seen in :func:`get_groups`
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> src.sync()
        >>> group = src.create_group(name='test_get_group',
        ...                          row_indices=list(range(10)))
        >>> group != None
        True
        >>> group = src.get_group(name='test_get_group')
        >>> group['row_count'] == 10
        True
        >>> group['name'] == 'test_get_group'
        True
        >>> src.delete_group(name='test_get_group')
        True
        """
        if id is None and name is None:
            raise ValueError("Invalid Argument :: please pass "
                             "either id or name")

        if id is None:
            id = self._get_id_for_group_name(name)
        if id is not None:
            return self._get_group_by_id(id)

        return self.__error__("Group with given parameter does not exist",
                              False)

    def delete_group(self, id=None, name=None):
        """
        Delete a group identified by its name or id.

        Args:
            id (str) : id of the group (optional with name).
            name (str) : name of the group (optional with id).

        Returns:
            True if the group was deleted successfully, else prints and
            returns an error message.

        :Example:

         as seen in :func:`get_groups`
        """
        if id is not None:
            try:
                json_funcs._delete_(self.connection.session,
                                    self.curl + '/groups/' + id)
                return True
            except HTTPError as e:
                if e.response.status_code == 404:
                    return self.__error__("Group with id {} does "
                                          "does not exist".format(id))
                else:
                    raise
        elif name is not None:
            groups = self.get_groups()
            for ind, group in enumerate(groups):
                if group['name'] == name:
                    json_funcs._delete_(self.connection.session,
                                        self.curl + '/groups/' +
                                        group['id'])
                    return True
            return self.__error__("Group with name {} does "
                                  "does not exist".format(name))
        return self.__error__("Please enter a name or an id.")

    def delete_groups(self, ids=[]):
        """
        Deletes a list of groups by id.

        Args:
            ids ([str]): List of group ids.

        Returns:
            True if successful
        """
        if len(ids) > 0:
            for id_ in ids:
                self.delete_group(id=id_)
        else:
            raise ValueError("Please provide a list of ids")
        return True

    def rename_group(self, id, new_name):
        """Rename an existing group.

        Args:
          id (str) : id of the group
          new_name (str) : new name of the group

        Returns:
          A group dictionary

        :Example:

        >>> src = extraglobs['src'] # ignore-in-doc
        >>> src.sync()
        >>> group = src.create_group(name='test_rename_group',
        ...                          row_indices=list(range(11)))
        >>> group is not None
        True
        >>> group['name'] == 'test_rename_group'
        True
        >>> group2 = src.rename_group(group['id'], 'test_rename_groupX')
        >>> group2 is not None
        True
        >>> group2['name'] == 'test_rename_groupX'
        True
        >>> _ = src.delete_group(name='test_rename_groupX')
        """

        param_dict = {}
        param_dict['name'] = new_name
        try:
            return json_funcs._put_(self.connection.session,
                                    self.curl + '/groups/' + id,
                                    param_dict)
        except HTTPError as e:
            if e.response.status_code == 404:
                return self.__error__("Group with id {} does "
                                      "does not exist".format(id))
            else:
                raise

    def share_group(self, group_id, user_id):
        """Share a group with a user.

        Args:
            group_id (str): id of the group to be shared
            user_id (str): id of the user to be shared with

        Returns:
            True if successful
        """

        error_message = ''
        if group_id is None:
            error_message = error_message + 'Group id is missing'
        if user_id is None:
            error_message = error_message + 'User id is missing'
        if len(error_message) > 0:
            return self.__error__(error_message)

        post_params = {}
        share_url = self.curl + '/groups/%s/users/%s' % (group_id, user_id)
        json_funcs._post_(self.connection.session, share_url, post_params)

        return True

    def _get_id_for_group_name(self, name):
        groups = self.get_groups()
        matched = [group for group in groups if group['name'] == name]

        if len(matched) > 1:
            raise ValueError("Multiple groups found for given name: %s, "
                             "please use Id instead." % name)

        return matched[0]['id'] if matched else None

    def _get_group_by_id(self, id):
        uri = '%s/groups/%s' % (self.curl, id)
        group = json_funcs._get_(self.connection.session, uri)
        if group:
            group['row_count'] = len(group.get('row_indices', []))
            return group

        return self.__error__("Group with id '%s' does not exist" % id, False)

    def export(self, row_indices=None, filter_set=None, network_name=None,
               node_group_name=None, node_ids=None, column_indices=None,
               column_set=None, row_range=None, column_range=None,
               network=None, group_id=None, use_given_column_order=False, **kwargs):
        """
        Export a slice of the current :class:`source <ayasdi.core.source.Source>`.

        Args:
            row_indices ([int]) : Indices of the rows to be exported. Default=All rows.
                (optional with network params)
            filter_set (dict) : Rows that match this filter set are exported.
                See :func:`create_filter_set`.
            network_name (str) : Name of the :class:`network <ayasdi.core.networks.Network>`.
                Must provide with either the
                ``node_group_name`` or the ``node_ids`` parameter.
            node_group_name (str) : Node group within the network to export.
                See :func:`network.get_node_group <ayasdi.core.networks.Network.get_node_group>`
            node_ids (list) : A list of node ids from the ``network`` to be exported
            column_indices (list) : Column indices selected for export.
            column_set (dict): Column_set object to export data from.
                (Optional with column_indices)
            row_range ([int,int]): A range of rows to return the data from (given as a list
                of start, end).
                - When combined with column_indices, column_set
                or row_indices, then only the data limited by these columns
                or row index boundaries are returned.
                - When combined with network, node_group, node_ids, then only
                the data limited by these network parameters are returned.
            column_range ([int,int]): A range of columns to return the data from (given as
                a list of start, end)
                - When combined with column_indices, column_set, or row_indices,
                then only the data limited by these column index boundaries or
                row index boundaries are returned.
                - When combined with network, node_group, node_ids, then only
                the data limited by these network parameters are returned.
            network (obj): The :class:`network <ayasdi.core.networks.Network>` object.
                Used instead of network_name.
            group_id (str): the id of the group that needs to be exported.
            use_given_column_order (bool): if True, the columns will be exported in the same order as provided by the
                user. Default is False, in which case the columns are returned ordered by index in the original source,
                with duplicates removed.

        Returns:
            A dictionary with keys `row_indices`, `column_indices`, and `data`.

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> export = src.export(row_indices=list(range(10)),
        ...                     column_indices=list(range(3)))
        >>> export['row_indices']
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        >>> export['column_indices']
        [0, 1, 2]
        >>> export['data']  # doctest: +NORMALIZE_WHITESPACE
        [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
         [0.81, 0.95, 0.94, 1.04, 1.0, 0.76, 0.91, 1.1, 0.99, 0.78],
         [80, 97, 105, 90, 90, 86, 100, 85, 97, 97]]
        >>> # Using Filter Set and column_set
        >>> filter_set = \
            src.create_filter_set([{'column_name':
        ...                         'clinical classification',
        ...                         'in_set': [3]},
        ...                        {'column_name': 'relative weight',
        ...                         'in_range': [0.8, 1], 'not': True}],
        ...                       as_and=True)
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = \
            src.create_column_set(column_list=columns_for_analysis,
        ...                       name="test_column_set1")
        >>> export = src.export(filter_set=filter_set,
        ...                     column_set=column_set)
        >>> # Datetime Example
        >>> dt_source = connection.upload_source('./test/db_datetime_test.txt')
        >>> dt_source.sync()
        >>> dt_export = dt_source.export()
        >>> # check that generated datetime columns exist
        >>> len(dt_export['column_indices'])
        24
        >>> dt_colname_set = set([x['name'] for x in dt_source.columns])
        >>> # Confirm generated column names
        >>> set(['x_Date', 'x_DayOfMonth', 'x_DayOfWeek', 'x_Month',
        ... 'x_SecondOfDay', 'x_Timezone', 'x_Epoch', 'x_Weekend', 'x_Year',
        ... 'x_YearMonth']).issubset(dt_colname_set)
        True
        >>> connection.delete_source(name='db_datetime_test.txt')
        """
        if len(kwargs) > 0:
            warnings.warn("Warning: parameter(s) {invalid_params} are not "
                          "used in this method and will cause an exception to "
                          "be raised in the next release of the Ayasdi SDK. "
                          "Please remove this parameter to continue using "
                          "this method.".format(invalid_params=list(kwargs.keys())))

        network_id = None
        if network is not None:
            network_id = network.id

        param_dict = self.__get_row_specifications__(network_id, node_ids,
                                                     row_indices, filter_set)

        # If a column_set is provided, then that is chosen,
        # else column_indices or all columns are chosen.
        if column_set is not None:
            param_dict['column_specifications'] = \
                [{'column_set_id': column_set['id']}]
        else:
            column_indices = column_indices or [col['index'] for col in self.columns]
            param_dict['column_specifications'] = \
                [{'column_indices': column_indices}]
            param_dict['use_given_column_order'] = use_given_column_order
        # If column_indices not specified,
        # form a request without column_indices
        if row_range is not None:
            param_dict['row_range'] = {}
            param_dict['row_range']['start'] = row_range[0]
            param_dict['row_range']['end'] = row_range[1]
        if column_range is not None:
            param_dict['column_range'] = {}
            param_dict['column_range']['start'] = column_range[0]
            param_dict['column_range']['end'] = column_range[1]

        # convert all row input formats to list
        if network_name is None:
            if group_id is not None:
                group = self.get_group(id=group_id)
                row_indices = group[u'row_indices']
            row_indices = self._get_row_list(row_indices, row_range)
        else:
            if row_indices is not None or row_range is not None:
                return 'Please choose either a row filter or a network.'
            elif node_group_name is None:
                return 'Please specify a node group name.'
            else:
                network = self.get_network(name=network_name)
                node_group = \
                    network.get_node_group(name=node_group_name)
                # get row ids from node groups
                node_params = {
                    'network_nodes_descriptions': [
                        {
                            'network_id': network.id,
                            'node_ids': node_group['node_ids']
                        }
                    ]
                }

                response = json_funcs._iter_post_(self.connection.session,
                                                  self.curl +
                                                  '/retrieve_row_indices/stream',
                                                  node_params)

                row_indices = list(response)

        # convert column inputs to lists
        col_indices = self._get_column_list(column_indices, column_range, use_given_order=use_given_column_order)

        # get number of rows and columns for batching
        col_batch_size = self._get_column_batch_size(row_indices, row_range)

        # if there are fewer than 100000 rows
        col_batches, row_batches = \
            self._get_column_batches(col_indices, row_indices, col_batch_size)

        data = []
        row_indices = []
        col_indices = []
        for col_batch in col_batches:
            col = []
            for row_batch in row_batches:
                for column_spec in param_dict['column_specifications']:
                    if 'column_indices' in column_spec:
                        column_spec['column_indices'] = col_batch
                for row_spec in param_dict['row_specifications']:
                    if 'row_indices' in row_spec:
                        row_spec['row_indices'] = row_batch

                export_val = json_funcs._post_(self.connection.session,
                                               self.curl + '/retrieve_subset',
                                               param_dict)

                col_indices.extend(export_val['column_indices'])
                row_indices.extend(export_val['row_indices'])

                if col_batch_size == 0:
                    col.extend(sum(export_val['data'], []))
                else:
                    col = export_val['data']

            if col_batch_size >= 1:
                data = data + col
            else:
                data.append(col)

        # dedup row and column indices and populate output
        out_dict = {}
        out_dict['data'] = data
        out_dict['row_indices'] = utils.ordered_dedup(row_indices)
        out_dict['column_indices'] = col_indices

        return out_dict

    def retrieve_subset_to_file(self,
                                file_name,
                                file_type='csv',
                                filter_set=None,
                                group_id=None,
                                row_indices=None,
                                column_set_id=None,
                                column_indices=None,
                                row_range=None,
                                column_range=None,
                                async_=False,
                                tmp_dir=None,
                                max_column_batch_size=10000,  # for internal use
                                max_row_batch_size=100000  # for internal use
                                ):
        """
        Export a slice of the current :class:`source <ayasdi.core.source.Source>` to a file.

        .. note::
          For performance reasons, this
          method internally uses pagination to download multiple files, and then
          concatenates the files into a single file.

          Specify rows (exactly one of row_indices, row_range, or group_id). If more
          than one is specified there will be an exception.

          Specify columns(exactly one of column_indices, column_range, or column_set_id).
          If more than one is specified there will be an exception.

        Args:
            file_name (str): The absolute path of the file to write.
              Ignored if the ``async\_`` parameter is set to True. See :func:`synchronize_retrieve_subset_to_file`
            file_type (str): The file type to export. Currently only 'csv' is supported.
              Ignored if the ``async\_`` parameter is set to True. See :func:`synchronize_retrieve_subset_to_file`
            filter_set: Select rows that match this column-based filter set.
                (Optional)
                See :func:`create_filter_set`
            group_id (str): The group to retrieve.
            row_indices ([int]): Indices of the rows to be returned. Default=All rows
            column_set_id (str): The id of the column_set to export data from.
            column_indices ([int]): A list of column indices to fetch data from.
            row_range ([int,int]): A range of rows given as a list/tuple of (start, end).
            column_range ([int,int]): A range of columns to return given as
                a list/tuple of (start, end)
            async\_ (bool): Set to True to run the job asynchronously, otherwise False.
            tmp_dir (str): Directory to store temporary files. If tmp_dir is None,
                this method creates a local directory to store temporary files.

        Returns:

            A job_id string if async_ is set to True, else writes the file
            and returns True if successful.

        Example:

        >>> src = connection.upload_source('./test/db_datetime_test.txt')
        >>> src.sync()
        >>> # Synchronous Call
        >>> src.retrieve_subset_to_file(file_name='test.csv',
        ...                             file_type='csv',
        ...                             row_indices=list(range(10)),
        ...                             column_indices=list(range(3)),
        ...                             async_=False)
        True
        >>> # Asynchronous Call
        >>> job_info = src.retrieve_subset_to_file(file_name='test.csv',
        ...                                      file_type='csv',
        ...                                      row_indices=list(range(10)),
        ...                                      column_indices=list(range(3)),
        ...                                      async_=True)
        >>> # Blocking Call to Retrieve File:
        >>> src.synchronize_retrieve_subset_to_file(**job_info)
        True
        >>> connection.delete_source(name='db_datetime_test.txt')
        """
        param_dict = {}

        num_row_specs = len([x for x in [row_range, group_id, row_indices]
                             if x is not None])
        if num_row_specs > 1:
            raise ValueError("Please specify exactly one of row_indices,"
                             "row_range or group_id")
        elif num_row_specs == 0:
            row_range = (0, self.row_count)

        num_col_specs = len([x for x in [column_range, column_set_id, column_indices]
                             if x is not None])
        if num_col_specs > 1:
            raise ValueError("Please specify exactly one of column_range,"
                             "column_set_id or column_indices")
        elif num_col_specs == 0:
            column_range = (0, self.column_count)

        if column_set_id is not None:
            column_set = self.get_column_set(id=column_set_id)
            column_indices = column_set['column_indices']
        if group_id is not None:
            group = self.get_group(id=group_id)
            row_indices = group['row_indices']
        if column_indices is not None and \
                any(((x >= self.column_count) or x < 0) for x in column_indices):
            raise ValueError("Column index out of range. Please check your column_indices")
        if row_indices is not None and \
                any(((x >= self.row_count) or x < 0) for x in row_indices):
            raise ValueError("Column index out of range. Please check your column_indices")
        if column_range is not None and (column_range[0] < 0 or
                                         column_range[1] > self.column_count):
            raise ValueError("Column range invalid. Please check your input.")
        if row_range is not None and (row_range[0] < 0 or
                                      row_range[1] > self.row_count):
            raise ValueError("Column range invalid. Please check your input.")

        col_range_batches, col_index_batches = \
            self._get_range_and_index_batches(column_range,
                                              column_indices,
                                              max_column_batch_size)

        # Create temp file directory
        tmp_dir = tempfile.mkdtemp(dir=tmp_dir)
        LOGGER.info("retrieve_subset_to_file temp directory created: {}".format(tmp_dir))

        results_list = []
        col_count = 0
        for cur_col_range, cur_col_indices in \
                six.moves.zip_longest(col_range_batches, col_index_batches):
            results_list.append([])

            # Set up parameters
            if cur_col_range is not None:
                param_dict['column_specifications'] = \
                    [{'column_indices': list(range(cur_col_range[0], cur_col_range[1]))}]
            elif cur_col_indices:
                param_dict['column_specifications'] = \
                    [{'column_indices': list(cur_col_indices)}]

            row_range_batches, row_index_batches = \
                self._get_range_and_index_batches(row_range,
                                                  row_indices,
                                                  max_row_batch_size, )
            row_count = 0
            for cur_row_range, cur_row_indices in \
                    six.moves.zip_longest(row_range_batches, row_index_batches):
                LOGGER.info("retrieve_subset_to_file (row batch, col batch): "
                            "({}, {})".format(row_count, col_count))

                if cur_row_range is not None:
                    param_dict['row_specifications'] = \
                        [{'row_indices': list(range(cur_row_range[0], cur_row_range[1]))}]
                elif cur_row_indices is not None:
                    param_dict['row_specifications'] = \
                        [{'row_indices': list(cur_row_indices)}]

                if filter_set is not None:
                    if 'row_specifications' in param_dict:
                        param_dict['row_specifications'] += [{'filter_set': filter_set}]
                        param_dict['row_join_type'] = 'intersection'
                    else:
                        param_dict['row_specifications'] = [{'filter_set': filter_set}]

                cur_filename = '{}_{}.{}'.format(row_count,
                                                 col_count,
                                                 file_type)
                cur_filename = os.path.join(tmp_dir, cur_filename)
                # Get result filenames or jobs and store inside results_list
                result = self._post_retrieve_subset_to_file(cur_filename,
                                                            file_type,
                                                            param_dict,
                                                            async_)
                results_list[col_count].append(result)
                row_count += 1
            col_count += 1
        if async_ is True:
            result_dict = {'jobs': results_list,
                           'file_name': file_name,
                           'file_type': file_type,
                           'tmp_dir': tmp_dir}
            return result_dict
        # concatenate the results of the different files into single file
        result = self._concatenate_csv_files(results_list, file_name)
        # Delete tempdirectory and everything underneath
        shutil.rmtree(tmp_dir)
        return result

    def synchronize_retrieve_subset_to_file(self, jobs, file_name, tmp_dir,
                                            file_type='csv'):
        """
        Synchronizes the job from :func:`retrieve_subset_to_file`
        and writes the result to "file_name".

        See `retrieve_subset_to_file` for an example.

        Args:
            jobs (list): The list of jobs from a retrieve_subset_to_file
                call with async\_ set to True. With pagination this may
                contain multiple jobs.
            file_name (str): The full path of the file to write
            tmp_dir (str): The directory where temp files are stored
            file_type (str): The type of the file. Currently only 'csv' is
                supported.

        Returns:
            True if the HTTP request and file write are successful

        """
        for row in jobs:
            for job_info in row:
                job_id = job_info['job_id']
                tmp_file_name = job_info['file_name']

                endpoint = self.curl + '/retrieve_subset/csv/blockingasync/' + job_id
                file_funcs._get_download_(self.connection.session,
                                          endpoint,
                                          file_name=tmp_file_name)
        result = self._concatenate_csv_files(jobs, file_name)
        shutil.rmtree(tmp_dir)
        return result

    def create_group_set(self,
                         name=None,
                         group_ids=None,
                         categorical_group_set=None,
                         continuous_group_set=None,
                         sampled_group_set=None,
                         stratified_sampled_group_set=None,
                         network_based_sampled_group_set=None,
                         metadata={}):
        """
        Creates a :class:`GroupSet <ayasdi.core.groupconfig.GroupSet>` object.

        .. note::
              A :class:`GroupSet <ayasdi.core.groupconfig.GroupSet>` has the following attributes:
                - u'groups'
                - u'entity_uri'
                - u'creationTime'
                - u'creatorID'
                - u'id'
                - u'name'


            The dictionary format reflects the types of groups included, how the group set was created, and (for
            ``continuous_group_set``s) the bucketing method.

            You can create a group_set by simply specifying a list of ids, OR you can create any of the following
            types of group sets:

                * categorical_group_set
                * continuous_group_set
                * network_based_sampled_group_set
                * sampled_group_set
                * stratified_sampled_group_set

        For details about each type of group set and how it is specified, see
        :doc:`/userdoc/create_group_set_supp_overview`.

        Args:
            name (str): User defined name of the groupset.
            group_ids ([str]) : specifies that the group set should be created from the included list of row ids.
            categorical_group_set (dict) : requires the further specification of ``group_id``,
                ``categorical_column_id``, and (optional) number_categories. See
                :doc:`/userdoc/create_group_set_supp_overview`.
            continuous_group_set (dict) : requires the further specification of ``group_id``,
                ``rolling_direction_forward``,``continuous_column_id``, ``max_group_count`` and bucketing mode.
                For further information, see :doc:`/userdoc/create_group_set_supp_overview`.
            sampled_group_set (dict) : requires the further specification of EITHER ``num_rows_in_group`` OR
                ``percent_in_group``. See :doc:`/userdoc/create_group_set_supp_overview`.
            stratified_sampled_group_set (dict) : requires the further specification of ``group_id``,
                ``outcome_column_index``, and a list of specifications, each of which indicates the random seed and
                number of rows in the result group. See :doc:`/userdoc/create_group_set_supp_overview`.
            network_based_sampled_group_set (dict) : requires the further specification of the ``network_id`` and a
                list of specifications, each of which indicates the random seed and number of rows in the result
                group. See :doc:`/userdoc/create_group_set_supp_overview`.
            metadata (dict) : Metadata for the group stored as key-value pairs. (optional)

        Returns:
            An :class:`ayasdi.core.groupconfig.GroupSet` object.

        The following example creates two groups from a catagorical column with a column index of 6.

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = connection.upload_source("./test/categorical_group_"
        ...                                "set_creator.txt")
        >>> group = src.create_group(name='group')
        >>> group_set = src.create_group_set(
        ...     name='group_set',
        ...     categorical_group_set={
        ...         "group_id": group['id'],
        ...         "categorical_column_id": "6",
        ...         "number_categories": 2})
        >>> # We create 2 groups from categorical column with column index 6.
        >>> groups = src.get_groups()
        >>> len(groups)
        4
        >>> groups[0]['name']
        'group'
        >>> groups[0]['row_count']
        6
        >>> groups[1]['name']
        'clinical classification = 3'
        >>> groups[1]['row_count']
        3
        >>> groups[2]['name']
        'clinical classification = 1'
        >>> groups[2]['row_count']
        2
        >>> groups[3]['name']
        'clinical classification = rest'
        >>> groups[3]['row_count']
        1
        >>> group_set1 = src.create_group_set(name='group_set1',
        ...                                   group_ids=[groups[1]['id'],
        ...                                   groups[2]['id']])
        >>> group_set1.name
        'group_set1'
        >>> connection.delete_source(name='categorical_group_set_creator.txt')
        >>> src = connection.upload_source("./test/categorical_group_"
        ...                                "set_creator.txt")
        >>> group = src.create_group(name='group')
        >>> group_set = src.create_group_set(
        ...     name='group_set',
        ...     stratified_sampled_group_set={
        ...         "group_id": group['id'],
        ...         "outcome_column_index": "6",
        ...         "specifications": [{"num_rows_in_group": 4, "seed": 1234},
        ...                            {"num_rows_in_group": 5, "seed": 1100}]})
        >>> groups = src.get_groups()
        >>> len(groups)
        3
        >>> groups[0]['name']
        'group'
        >>> groups[0]['row_count']
        6
        >>> groups[1]['name']
        'group_set_4_1234'
        >>> groups[1]['row_count']
        4
        >>> groups[2]['name']
        'group_set_5_1100'
        >>> groups[2]['row_count']
        5
        >>> connection.delete_source(name='categorical_group_set_creator.txt')
        >>> src = connection.upload_source("./test/network_based_sampled_group_"
        ...                                "set_creator.txt")
        >>> col_set = src.create_column_set(column_list = range(7),
        ...                                 name= 'col_set')
        >>> network = src.create_network('network', {
        ...                'metric' : {'id' : 'Cosine'},
        ...                'column_set_id' : col_set['id'],
        ...                'lenses' : [{'resolution' : 30, 'gain' : 2.5,
        ...                             'id' : 'Gaussian Density',
        ...                             'equalize' : False}]})
        >>> group_set = src.create_group_set(
        ...     name='group_set',
        ...     network_based_sampled_group_set={
        ...         "network_id": network.id,
        ...         "specifications": [{"num_rows_in_group": 4, "seed": 1234},
        ...                            {"num_rows_in_group": 5, "seed": 1100}]})
        >>> groups = src.get_groups()
        >>> len(groups)
        2
        >>> groups[0]['name']
        'group_set_4_1234'
        >>> groups[0]['row_count']
        50
        >>> groups[1]['name']
        'group_set_5_1100'
        >>> groups[1]['row_count']
        50
        >>> connection.delete_source(
        ...              name='network_based_sampled_group_set_creator.txt')
        >>> src = connection.upload_source("./test/continuous_group_set_creator.txt")
        >>> group_set_continuous_0 = src.create_group_set(
        ...     name='group_set_continuous_0',
        ...     continuous_group_set={
        ...         "rolling_direction_forward": True,
        ...         "continuous_column_id": "2",
        ...         "max_group_count": 3,
        ...         "non_cumulative_buckets":
        ...         {"start_bucketing_value": "90",
        ...          "bucket_size": 2}})
        >>> groups = src.get_groups()
        >>> len(groups)
        3
        >>> groups[0]['row_count']
        2
        >>> groups[1]['row_count']
        2
        >>> groups[2]['row_count']
        2
        >>> connection.delete_source(name='continuous_group_set_creator.txt')
        """
        post_params = dict()

        if name is None:
            return self.__error__('A name argument is required '
                                  'to create group sets.')
        else:
            post_params['name'] = name

            # if a group set with the given name exists, return it
            # TODO: Fix this -- we should raise an error if a groupset
            # already exists rather than return the existing.
            try:
                group_set = self.get_group_set(name=name)
                print("Group set with the given name already exists.")
                return group_set
            except HTTPError:
                pass
            except ValueError:
                pass

        if group_ids is not None:
            post_params['group_ids'] = group_ids
        if categorical_group_set is not None:
            post_params['categorical_group_set'] = categorical_group_set
        if continuous_group_set is not None:
            post_params['continuous_group_set'] = continuous_group_set
        if sampled_group_set is not None:
            post_params['sampled_group_set'] = sampled_group_set
        if stratified_sampled_group_set is not None:
            if 'disjoint' not in stratified_sampled_group_set:
                stratified_sampled_group_set['disjoint'] = False
            post_params['stratified_sampled_group_set'] = \
                stratified_sampled_group_set
        if network_based_sampled_group_set is not None:
            if 'disjoint' not in network_based_sampled_group_set:
                network_based_sampled_group_set['disjoint'] = False
            post_params['network_based_sampled_group_set'] = \
                network_based_sampled_group_set
        post_params['metadata'] = metadata
        group_set_stub = json_funcs._post_(self.connection.session,
                                           self.curl + '/group_sets',
                                           post_params)
        gcconnection = groupconfig.GroupCentricConnection(self.connection,
                                                          self.id)
        group_set = groupconfig.GroupSet(gcconnection, group_set_stub)
        return group_set

    def get_group_sets(self):
        """
        Get all group sets on a source.

        Returns:
            A list of :class:`GroupSet <ayasdi.core.groupconfig.GroupSet>` objects.

        :Example:

        >>> #see `source.create_group_set`
        """
        self.sync()
        all_sets = []
        all_stubs = json_funcs._get_(self.connection.session,
                                     self.curl + '/group_sets')
        gcconnection = groupconfig.GroupCentricConnection(self.connection,
                                                          self.id)
        for group_set_stub in all_stubs:
            all_sets.append(groupconfig.GroupSet(gcconnection, group_set_stub))
        return all_sets

    def get_group_set(self, name=None, id=None):
        """
        Get a single group set by name or id.

        .. note::
           If name and id are provided, only the ``name`` parameter is used
        Args:

            id (str) : id of the :class:`groupset <ayasdi.core.groupconfig.GroupSet>` object
                 (optional with name).
            name (str) : name of the :class:`groupset <ayasdi.core.groupconfig.GroupSet>` object
                 (optional with id).

        Returns:
            An :class:`GroupSet <ayasdi.core.groupconfig.GroupSet>` object.

        :Example:

        >>> #see `source.create_group_set`
        """
        all_sets = self.get_group_sets()
        if name is not None:
            ids = [x.id for x in all_sets if x.name == name]
            if len(ids) < 1:
                raise ValueError('Group set with name "{name}"" not found'
                                 .format(name=name))
            elif len(ids) > 1:
                raise ValueError('Multiple groups with name "{name}"" found. \
                    Please searching using id'.format(name=name))
            else:
                id = ids[0]
        elif id is not None:
            ids = [x.id for x in all_sets if x.id == id]
            if len(ids) < 1:
                raise ValueError('Group set with id "{id}" not found'
                                 .format(id=id))
            elif len(ids) == 1:
                id = ids[0]
        else:
            raise ValueError("Invalid Argument :: please pass "
                             "either id or name")

        url = '{stub}/group_sets/{id}'.format(stub=self.curl, id=id)
        group_set_stub = json_funcs._get_(self.connection.session, url)
        gcconnection = groupconfig.GroupCentricConnection(self.connection,
                                                          self.id)
        group_set = groupconfig.GroupSet(gcconnection, group_set_stub)

        return group_set

    def score_groups(self, algorithm, metric, normalize_method='arithmetic', group_ids=None,
                     group_set_id=None, column_set_id=None, outcome_column_index=None,
                     refresh=False):
        """
        Compute the scores of clustering metrics to a list of groups or a group set.

        .. note::
            Supported clustering metric algorithms are "adjustedRandScore",
            "mutualInformationScore", "AdjustedmutualInformationScore",
            "normalizedMutualInformationScore", "silhouetteScore", "calinskiharabaszScore".

        Args:
            algorithms (str): clustering metric algorithm. Supported clustering metric
                              algorithms are "adjusted_rand_score", "mutual_information_score",
                              "adjusted_mutual_information_score", "normalized_mutual_information_score",
                              "silhouette_score", "calinski_harabasz_score".
            normalize_method (str): Average method for algorithms, "adjusted_mutual_information_score",
                                  "normalized_mutual_information_score". The supported methods are
                                  "min", "max", "geometric", "arithmetic", default = 'arithmetic'.
                                  (optional)
            metric (param): metric dictionary of format {'id': 'metric name'}.
            group_ids ([str]): list of group ids. (Optional with group_set_id)
            group_set_id (str): list of group ids. (Optional with group_ids)
            column_set_id (str): column set id. (optional)
            outcome_column_index (int): ground truth column id (optional)
            refresh (bool): force to compute the score again, default = False. (optional)

        Returns:
            double value of the score.

        >>> import ayasdi.core as ac
        >>>
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> group1 = src.create_group(name='a', row_indices=[0, 1, 2])
        >>> group2 = src.create_group(name='b', row_indices=[3, 4, 5, 6])
        >>> group3 = src.create_group(name='c', row_indices=[7, 8, 9])
        >>> group_ids = [group1['id'], group2['id'], group3['id']]
        >>> score = src.score_groups(algorithm='silhouette_score',
        ...                          metric= {'id': 'Norm Correlation'},
        ...                          group_ids=group_ids)
        >>> print(score)
        -0.12514990374264667
        """
        url = self.curl + '/clustering_scores'

        if refresh:
            url = url + '?refresh=true'

        params = {'group_ids': group_ids,
                  'algorithm': algorithm,
                  'metric': metric}

        if normalize_method is not None:
            params['normalize_method'] = normalize_method

        if group_ids is not None:
            params['group_ids'] = group_ids
        elif group_set_id is not None:
            params['group_set_id'] = group_set_id
        else:
            raise ValueError('Please provide either a list of group ids or a group set id.')

        if column_set_id is not None:
            params['column_set_id'] = column_set_id

        if outcome_column_index is not None:
            params['outcome_column_id'] = outcome_column_index

        score = json_funcs._post_(self.connection.session, url, data=params)
        return score

    def delete_group_set(self, name=None, id=None, delete_containing_groups=False):
        """
        Delete a group set identified by its name or id.

        Args:
            id (str) : id of the :class:`groupset <ayasdi.core.groupconfig.GroupSet>` object
                  (optional with name).
            name (str) : Name of the :class:`groupset <ayasdi.core.groupconfig.GroupSet>` object
                  (optional with id).
            delete_containing_groups (bool) : True if the groups in the groupset are desired to be deleted.

        Returns:
            True if the group set was deleted successfully, else
            prints and returns an error message.

        :Example:

        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> src.sync()
        >>> group = src.create_group(name='test_group',
        ...                          row_indices=list(range(11)))
        >>> group is not None
        True
        >>> gs = src.create_group_set(name="orig_groupset",
        ...                           group_ids=[group['id']])
        >>> src.delete_group_set(id=gs.id)
        True
        """

        group_set_id = None
        if id is not None:
            group_set_id = id
        elif name is not None:
            group_sets = self.get_group_sets()
            for ind, group_set in enumerate(group_sets):
                if group_set.name == name:
                    group_set_id = group_set.id

            if group_set_id is None:
                return self.__error__("Group set with name {} does "
                                      "does not exist".format(name))
        else:
            return self.__error__("Please enter a name or an id.")

        try:
            json_funcs._delete_(self.connection.session,
                                self.curl + '/group_sets/' + group_set_id +
                                '?delete_containing_groups=' + str(delete_containing_groups))
            return True
        except HTTPError as e:
            if e.response.status_code == 404:
                return self.__error__("Group set with id {} does "
                                      "does not exist".format(group_set_id))
            else:
                raise

    def delete_group_sets(self, ids=[], delete_containing_groups=False):
        """
        Deletes a list of group_sets by id.

        Args:
            ids ([str]): List of :class:`groupset <ayasdi.core.groupconfig.GroupSet>` ids.
            delete_containing_groups (boolean) : True if the groups in the groupsets are desired to be deleted.

        Returns:
            True if successful
        """
        if len(ids) > 0:
            for id_ in ids:
                self.delete_group_set(id=id_, delete_containing_groups=delete_containing_groups)
        else:
            raise ValueError("Please provide a list of ids")
        return True

    def rename_group_set(self, id, new_name):
        """
        Renames the :class:`GroupSet <ayasdi.core.groupconfig.GroupSet>` object.

        Args:
          id (str) : id of the :class:`groupset <ayasdi.core.groupconfig.GroupSet>`
          new_name (str) : new name of the group set

        Returns:
          An :class:`GroupSet <ayasdi.core.groupconfig.GroupSet>` object.

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> src.sync()
        >>> group = src.create_group(name='test_group',
        ...                          row_indices=list(range(11)))
        >>> group is not None
        True
        >>> gs = src.create_group_set(name="orig_groupset",
        ...                           group_ids=[group['id']])
        >>> gs is not None
        True
        >>> gs.name == "orig_groupset"
        True
        >>> gs2 = src.rename_group_set(gs.id, 'test_rename_group')
        >>> gs2 is not None
        True
        >>> gs2.name == 'test_rename_group'
        True
        """

        param_dict = {}
        param_dict['name'] = new_name
        group_set_stub = json_funcs._put_(self.connection.session,
                                          self.curl + '/group_sets/' +
                                          id,
                                          param_dict)
        gcconnection = groupconfig.GroupCentricConnection(self.connection,
                                                          self.id)
        group_set = groupconfig.GroupSet(gcconnection, group_set_stub)
        return group_set

    def get_group_membership(self, subset=[]):
        """
        Returns a list of all row ids and each group the row belongs to.

        Args:
            subset ([int]): list of rows to constrain. Default=All rows

        Returns:
            A dictionary with ``row indices`` as keys, and lists of groups each row
            belongs to as values

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> for group in src.get_groups(): #ignore-in-doc
        ...     _ = src.delete_group(name=group['name']) #ignore-in-doc
        >>> # Create groups
        >>> grp1 = src.create_group(name='group1', row_indices=list(range(5)))
        >>> grp2 = src.create_group(name='group2', row_indices=[3,4,5])
        >>> # Get group membership for first 15 rows
        >>> # For all rows, leave arguments blanksour
        >>> group_dict = src.get_group_membership(list(range(10)))
        >>> len(group_dict)
        10
        >>> sorted_membership = [value for (key, value) in
        ...                      sorted(group_dict.items())]
        >>> # get source dataset to attach membership
        >>> src.sync()
        >>> dataset = src.export(row_indices=list(range(10)))
        >>> # Add column indices to data
        >>> dataset['data'].insert(0, dataset['row_indices'])
        >>> # Add group membership to data
        >>> dataset['data'].append(sorted_membership)
        >>> # Pivot data to be in rows instead of columns
        >>> data_by_row = list(zip(*dataset['data']))
        >>> # look at first five rows
        >>> import pprint
        >>> pp = pprint.PrettyPrinter()
        >>> pp.pprint([[x[0], x[-1]] for x in data_by_row[:5]])
        [[0, ['group1']],
         [1, ['group1']],
         [2, ['group1']],
         [3, ['group1', 'group2']],
         [4, ['group1', 'group2']]]
        """

        row_dict = defaultdict(list)

        groups = self.get_groups()
        for group in groups:
            uri = 'sources/%s/groups/%s' % (self.id, group['id'])

            group_details = json_funcs._get_(self.connection.session,
                                             self.connection.CORE_REQUEST_STUB +
                                             uri)

            row_indices = group_details['row_indices']

            # populate row dict with groups
            for row in row_indices:
                # skip if subset is not null and the row is outside of the set
                if subset and row not in subset:
                    continue
                row_dict[row].append(group['name'])

        # get rows that weren't in any groups
        rows_in_groups = set(row_dict.keys())
        if subset:
            all_rows = set(subset)
        else:
            all_rows = set(range(self.row_count))
        missing_rows = all_rows - rows_in_groups

        for row in missing_rows:
            row_dict[row] = []

        return row_dict

    def append_group_membership(self, group_ids, column_prefix):
        """
        Appends a column to the current :class:`source <ayasdi.core.source.Source>` for each supplied group.
        The rows in each appended column have a 1 for membership
        in the group and a 0 otherwise.

        .. note::
           This function returns a new source object.


        Args:
            group_ids ([int]): a list of group ids
            column_prefix (str): User defined prefix for new column names.

        Returns:
            The updated source. This is an in-place change that returns the
            existing source with the newly-appended columns.

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = connection.upload_source("./test/db_test2.txt", allow_duplicate=True) #ignore-in-doc
        >>> for group in src.get_groups(): #ignore-in-doc
        ...     _ = src.delete_group(name=group['name']) #ignore-in-doc
        >>> grp1 = src.create_group(name='group1', row_indices=list(range(5)))
        >>> grp2 = src.create_group(name='group2', row_indices=[3,4,5])
        >>> s = src.append_group_membership(column_prefix="PREFIX_",
        ...                                 group_ids=[grp1['id'],
        ...                                 grp2['id']])
        >>> connection.delete_source(id=src.id) # ignore-in-doc

        """
        # Construct post dict and post
        query = {'group_ids': group_ids,
                 'column_prefix': column_prefix
                 }
        ret = json_funcs._post_(self.connection.session,
                                self.curl +
                                '/append_group_membership',
                                query)
        return ret

    def __get_row_specifications__(self, network_id=None, node_ids=None,
                                   row_indices=None, filter_set=None,
                                   group_id=None):
        """
        Convert arguments to row specifications. Called internally
        """
        param_dict = {'row_specifications': []}
        if network_id is not None:

            if node_ids is None:
                return self.__error__("Network provided but no node_ids ")
            else:
                param_dict['row_specifications'] += \
                    [{'node_specification': {'network_id': network_id,
                                             'node_ids': node_ids}}]
            if row_indices is not None:
                print("Network information used instead of the "
                      "provided row_indices argument.")
            if group_id is not None:
                param_dict['row_specifications'] += \
                    [{'group_id': group_id}]
                param_dict['row_join_type'] = 'intersection'
        if filter_set is not None:
            param_dict['row_specifications'] += \
                [{'filter_set': filter_set}]
            if group_id:
                param_dict['row_specifications'] += \
                    [{'group_id': group_id}]
                param_dict['row_join_type'] = 'intersection'
        else:
            if network_id is None:
                row_indices = row_indices or list(range(self.row_count))
                param_dict['row_specifications'] += \
                    [{'row_indices': row_indices}]

        return param_dict

    def __source_from_group__(self, group_id, source_name):
        """Creating source from a group id. Called internally.
        """
        param_dict = {'name': source_name}
        group_source = json_funcs._post_(self.connection.session,
                                         self.curl +
                                         '/groups/%s/create_source' %
                                         group_id,
                                         param_dict)
        return Source(self.connection, group_source)

    def annotate(self, annotation_source, annotation_source_column,
                 target_source_column):
        """
        Annotates the current :class:`source <ayasdi.core.source.Source>` with another based on matching join columns.

        Args:
            annotation_source (str): The source object that is used for annotations.
            annotation_source_column (int): Column in the annotation source
                to be used.
            target_source_column (int): Column in the current source to be used.

        Returns:
              A dictionary with information about the annotation source.

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = connection.upload_source("./test/db_test2.txt", allow_duplicate=True) #ignore-in-doc
        >>> annotation_source = \
            connection.upload_source('./test/db_annotation_test.txt')
        >>> a = src.annotate(annotation_source=annotation_source,
        ...              annotation_source_column="ID",
        ...              target_source_column="ID"
        ... )  # doctest: +NORMALIZE_WHITESPACE
        >>> a['name']
        'db_annotation_test.txt'
        >>> len(a['columns'])
        2
        >>> # Synchronize the source to get the new column
        >>> src.sync()
        >>> annotated_column = src.colname_to_ids['db_annotation1']
        >>> retrieved_data = src.export(row_indices=list(range(5)),
        ...                             column_indices=[annotated_column])
        >>> retrieved_data['row_indices']  # doctest: +NORMALIZE_WHITESPACE
        [0, 1, 2, 3, 4]
        >>> retrieved_data['column_indices']
        [9]
        >>> retrieved_data['data']  # doctest: +NORMALIZE_WHITESPACE
        [[0.972981901602, 0.304074171521, 0.155121226925, 0.428381381418,
          0.527103963241]]
        >>> annotation = src.get_annotation(name="db_annotation_test.txt")
        >>> connection.delete_source(name="db_annotation_test.txt")
        >>> connection.delete_source(id=src.id) # ignore-in-doc
        """
        # Sync the sources and check if the columns exist.
        annotation_source.sync()
        self.sync()
        try:
            source_column_id = self.column_names.index(target_source_column)
        except ValueError:
            error_message = "'%s' column not found in target source" % \
                            target_source_column
            LOGGER.exception(error_message)
            return self.__error__(error_message)
        try:
            annotation_column_id = \
                annotation_source.column_names.index(annotation_source_column)
        except ValueError:
            error_message = "'%s' column not found in annotation source" % \
                            annotation_source_column
            LOGGER.exception(error_message)
            return self.__error__("'%s' column not found in annotation source"
                                  % annotation_source_column)
        # Construct post dict and post
        annotation_params = {'id': annotation_source.id,
                             'join_column_index': annotation_column_id,
                             'source_join_column_index': source_column_id}
        annotation_results = json_funcs._post_(self.connection.session,
                                               self.curl + '/annotations',
                                               annotation_params)
        return annotation_results

    def get_annotations(self):
        """Get annotations in the current :class:`source <ayasdi.core.source.Source>`.

        Returns:
              A dictionary with information about the annotation source.

        """
        return json_funcs._get_(self.connection.session,
                                self.curl + '/annotations')

    def get_annotation(self, name=None, id=None):
        """Get annotation by name or id.

        Args:
            id (str) : id of the annotation
                  (optional with name).
            name (str) : Name of the annotation
                  (optional with id).

        Returns:
              A dictionary with information about the annotation source.

        :Example:

        >>> #See source.annotate example
        """

        selected_annotation = None
        if id is not None:
            selected_annotation = id
        elif name is not None:
            annotations = self.get_annotations()
            for annotation in annotations:
                if annotation['name'] == name:
                    selected_annotation = annotation['id']
                    break
            if not selected_annotation:
                return self.__error__('Annotation with name {} does'
                                      'not exist'.format(name))
        else:
            return self.__error__('Please enter either a name or an id.')

        try:
            return json_funcs._get_(self.connection.session,
                                    self.curl + '/annotations/' +
                                    selected_annotation)
        except HTTPError as e:
            if e.response.status_code == 404:
                return self.__error__('Annotation with id {} does not '
                                      'exist'.format(selected_annotation))
            else:
                raise

    def get_transformation_sequence(self):

        """
        Returns the transformation sequence applied to the current :class:`source <ayasdi.core.source.Source>`.

        .. note::
          The returned transformation sequence can be readily applied to another source that fulfils the same schema as
          the current :class:`source <ayasdi.core.source.Source>`.

        Returns:
            A transformation sequence dictionary if transformations were previously
            applied on the source. If no transformation is applied,
            then it returns a message "Transformation sequence not found"

        :Example:
        >>> import ayasdi.core as ac
        >>> src2 = connection.upload_source('./test/db_test2_ace.txt')
        >>> sqr_transform_step = ac.SquareTransformationStep(
        ...     description='step description',
        ...     column_name='blood glucose',
        ...     new_column_name='blood glucose squared',
        ...     virtual=True)
        >>> tc = ac.TransformationConfiguration.create(
        ...     connection,
        ...     'description',
        ...     sqr_transform_step)
        >>> new_source = tc.apply(source_id=src2.id,
        ...                       new_source_name='db_test2_new')
        >>> new_source.sync()
        >>> trans_seq = new_source.get_transformation_sequence()
        >>> connection.delete_source(name='db_test2_ace.txt')
        >>> connection.delete_source(name='db_test2_new')
        """

        self.sync()

        resp = self.connection.session.get(
            self.connection.CORE_REQUEST_STUB + 'transformations/' + self.id,
            headers={'accept': 'application/json'})

        if resp.status_code == 404:
            return self.__error__("Transformation sequence not found", False)
        elif resp.status_code == 200:
            return json.loads(resp.text)
        else:
            resp.raise_for_status()

    def get_transformation_config(self, source_id=None):
        """
        Get merged :class:`TransformationConfig <ayasdi.core.transformations.TransformationConfiguration>`
        associated with the current :class:`source <ayasdi.core.source.Source>`.

        .. note::
          The returned :class:`TransformationConfig <ayasdi.core.transformations.TransformationConfiguration>` object
          can be readily applied to another source that fulfils the same schema as
          the current :class:`source <ayasdi.core.source.Source>`.

        Args:
            source_id : if provided, returns the merged transformation configuration associated with the
                source id. If not provided (default), returns the transformation config of the source.

        Returns:
            A merged :class:`TransformationConfig <ayasdi.core.transformations.TransformationConfiguration>`
            object that contains steps that
            was applied to this specified source.

        :Example:
        >>> import ayasdi.core as ac
        >>> src = connection.upload_source("./test/db_test2.txt", allow_duplicate=True)
        >>> sqr_transform_step = ac.SquareTransformationStep(
        ...     description='step description',
        ...     column_name='blood glucose',
        ...     new_column_name='blood glucose sqr',
        ...     virtual=False)
        >>> tc = ac.TransformationConfiguration.create(
        ...     connection,
        ...     'description',
        ...     sqr_transform_step)
        >>> new_source = tc.apply(source_id=src.id,
        ...                       new_source_name='db_test2_new')
        >>> new_source.sync()
        >>> src.sync()
        >>> transform_config = new_source.get_transformation_config()
        >>> transform_config.steps[0].function
        'sqr'
        >>> transform_config.steps[0].new_column_name
        'blood glucose sqr'
        >>> transform_config.steps[0].column_name
        'blood glucose'
        >>> connection.delete_source(id=src.id) #ignore-in-doc
        >>> connection.delete_source(id=new_source.id) #ignore-in-doc
        """
        source_id2 = self.id
        if source_id:
            source_id2 = source_id

        try:
            config_json = json_funcs._get_(self.connection.session, self.connection.CORE_REQUEST_STUB +
                                           'transformations/' + source_id2 + '/export')
            transform_config = transformations.TransformationConfiguration(self.connection, "", [])
            return transform_config._deserialize(config_json)

        except HTTPError as e:
            if e.response.status_code == 404:
                return self.__error__("Source with id {} does not exists.".format(source_id2))
            else:
                raise ValueError("HTTPError, code=" + str(e.response.status_code))

    def get_transformed_sources(self, function=None, column_names=[]):

        """
        Returns a list of :class:`sources <ayasdi.core.source.Source>` transformed on the
        current :class:`source <ayasdi.core.source.Source>`.

        Args:
            function(str): Name of transformation function. (Optional)
            column_names ([str]): Name of columns which transformation is applied. (Optional)

        Returns:
            A list of transformed sources from the current one.

        :Example:
        >>> import ayasdi.core as ac
        >>> src2 = connection.upload_source('./test/db_test2_ace.txt')
        >>> sqr_transform_step = ac.SquareTransformationStep(
        ...     description='step description',
        ...     column_name='blood glucose',
        ...     new_column_name='blood glucose squared',
        ...     virtual=True)
        >>> tc = ac.TransformationConfiguration.create(
        ...     connection,
        ...     'description',
        ...     sqr_transform_step)
        >>> new_source = tc.apply(source_id=src2.id,
        ...                       new_source_name='db_test2_new1')
        >>> new_source.sync()
        >>> trans_sources = src2.get_transformed_sources()
        >>> len(trans_sources)
        1
        >>> trans_sources[0].name
        'db_test2_new1'
        >>> connection.delete_source(id=src2.id)
        >>> connection.delete_source(id=new_source.id)
        """

        self.sync()

        url = self.connection.CORE_REQUEST_STUB + 'transformations/' + self.id + '/transformed'
        params = {'function': function, 'columnNames': ','.join(column_names)}
        sources = json_funcs._get_(self.connection.session, url, params=params)

        return [Source(self.connection, i) for i in sources]

    def get_group_features(self, group_list,
                           column_id=None, column_name=None):
        """
        Get column values for every row in selected groups.

        Args:
            group_list([int]): list of groups. See :func:`get_groups`
            column_id (int): Column index for retrieval. (Optional with column name)
            column_name (str): Column name for retrieval. (Optional with column id).

        Returns:
         A dictionary mapping group id to dictionary mapping row number
         to value as a string. Sample result:

        .. code-block:: python

             {10017L: {1L: 'I. setosa', 2L: 'I. setosa', 3L: 'I. setosa'},
             10018L: {132L: 'I. virginica', 133L: 'I. virginica',
             134L: 'I. virginica'}}
        """

        request = {
            'group_list': [i['id'] for i in group_list],
            'column_id': column_id,
            'column_name': column_name
        }

        endpoint = self.curl + '/groups/features'
        response = json_funcs._post_(self.connection.session, endpoint, request)
        data = response['data']
        data = [(int(g), dict([(int(r), v)
                               for (r, v) in l.items()]))
                for (g, l) in data.items()]
        data_dictionary = dict(data)
        return data_dictionary

    def get_stats(self, params=[], group_id=None, complement=False, filter_set=None, group_ids=None,
                  filter_sets=None, async_=False):
        """
        Gets descriptive statistics for the current :class:`source <ayasdi.core.source.Source>`.

        .. note::
            To obtain statistics, invoke ``get_stats`` by specifying a dictionary for each column of interest, noting
            the desired statistics and relevant metadata in json format. The result set supplies the requested
            statistics as a dictionary that is itself a list of dictionaries. The computed value for each function is
            included with the "result" key.

        For detailed information, see :doc:`userdoc/get_stats_supp_overview`.

        Args:
            params ([list]) : list of nested dictionaries, one per column of interest. Each dictionary should
                contain a column key (the name of the column of interest) and at least one function key (the
                statistics to compute). You can also add other metadata, such as ``"ignore_nulls" : True`` or a
                ``bins`` specification. See **Supported Functions**, below.
            group_id (int) : Group specific stats computation. Default=All rows (optional)
            complement (bool): if True, select all rows within the source that are not contained
                in the group_id. (Requires ``group_id`` parameter, optional)
            filter_set: if provided, selects rows that match this column-based filter set.
                See :func:`create_filter_set`. (optional)
            group_ids: if provided, compute statistics against groups that are identified
                by a list of ids. (optional)
            filter_sets: if provided, compute statistics on rows that match a list of column-based
                filter sets. See :func:`create_filter_set`. (optional)
            async\_: when True, runs asynchronously and returns an :class:`AsyncJob <ayasdi.core.async_jobs.AsyncJob>`
              object. The object's "result" field is set to a list of dictionaries in json format.

        **Supported Functions**

            *Categorical* : "count", histogram", "mode", "num_nulls", "num_uniques", "uniques"

            *Continuous* : "avg", "count", "distribution", "histogram", "max", "median, "min", "mode", "num_nulls",
            "num_uniques", "stddev", "sum", "uniques"

            For details, see :doc:`/userdoc/get_stats_supp_overview`.


        Returns:
            A list of dictionaries

        :Example:
        >>> src = connection.upload_source("./test/diabetes_test_points.txt")  # ignore-in-doc
        >>> result = src.get_stats([
        ...        {
        ...           "column":"insulin level",
        ...           "functions":[
        ...              {
        ...                 "name":"avg",
        ...                 "ignore_nulls":True
        ...              }
        ...           ]
        ...        }
        ...     ])
        >>> result['params'][0]['functions'][0]['result']
        [339.3333333333333]

        **Sample Results Set**

        In the following response we see statistics for two columns, "Balance" and "Net Worth".

        .. raw:: html

                    <div class="highlight"><pre>
                    {u'complement': False,
                     u'creation_time': None,
                     u'creator_id': None,
                     u'group_id': None,
                     u'params': [{u'column': u'balance',
                        u'functions': [{u'bins': None,
                        u'ignore_nulls': False,
                        u'name': u'median',
                        u'ntiles': None,
                        u'result': 259.0,
                        u'type': u'double'},
                       {u'bins': None,
                        u'ignore_nulls': False,
                        u'name': u'avg',
                        u'ntiles': None,
                        u'result': 255.61606513454538,
                        u'type': u'double'}]},
                     {u'column': u'net_worth',
                      u'functions': [{u'bins': None,
                        u'ignore_nulls': False,
                        u'name': u'median',
                        u'ntiles': None,
                        u'result': 310.5068644,
                        u'type': u'double'}]}],
                    u'warnings': None}
                </pre></div>

        """
        self.sync()

        if group_id is not None and group_ids is not None:
            raise ValueError("Cannot set both group_id and group_ids. Please use one ")

        if filter_set is not None and filter_sets is not None:
            raise ValueError("Cannot set both filter_set and filter_sets. Please use one ")

        if complement is True and group_id is None and filter_set is None:
            raise ValueError("Please specify group_id(s) or filter_set(s) if choosing to complement")

        if group_id is not None and filter_set is not None:
            raise ValueError("Cannot set both group_id and filter_set. Please use one ")

        if group_ids is not None and filter_sets is not None:
            raise ValueError("Cannot set both group_ids and filter_sets. Please use one ")

        for param in params:
            if param['column'] not in self.column_names:
                raise ValueError("invalid column name : {}".format(param['column']))

        params_dict = {
            'params': params
        }

        if group_id is not None:
            params_dict['group_ids'] = [group_id]
        if filter_set is not None:
            params_dict['filter_sets'] = [filter_set]
        if group_ids is not None:
            params_dict['group_ids'] = group_ids
        if filter_sets is not None:
            params_dict['filter_sets'] = filter_sets

        if complement is True:
            params_dict['complement'] = True

        def get_stats_async_converter(stats_response):
            return json.loads(stats_response)

        # Make the query
        if async_:
            endpoint = self.curl + '/stats/async'
            async_task = json_funcs._post_(self.connection.session,
                                           endpoint, params_dict)

            return async_jobs.AsyncJob(self.connection, async_task, endpoint,
                                       result_converter=get_stats_async_converter)
        else:
            return json_funcs._post_(self.connection.session,
                                     self.curl + '/stats', params_dict)

    def iter_correlation_stats(self, group_id=None, complement=False, method="pearson", column_set_id=None,
                               outcome_column_name=None, outcome_column_index=None, imputation_strategy='mean'):
        """
        Calculate correlations between columns within a column_set.

        .. note::
            This enables users to efficiently remove columns that either have significant
            correlations with each other or insignificant correlations with an outcome column.
            These can be calculated for the entire data set, or for a group specified by the group_id.
            If outcome columnn is specified then it computes only correlations of all columns
            in column_set with outcome_column.

            This function only works for numerical columns.
            Returned results are sorted by correlation value.

        Args:
            group_id (str): specifies a group over which correlations are calculated. (optional)
            complement (bool): if True, select all rows within the source that are not contained
                in the group_id. (Requires ``group_id`` parameter, optional)
            method (str): pearson or spearman. Default="pearson" (optional)
            column_set_id (str): id of the column set with all numeric columns (required)
            outcome_column_name (str): name of outcome column (optional)
            outcome_column_index (int): index of outcome column (optional)
            imputation_strategy (str): strategy for imputing nulls - ``mean`` or ``median``. Default="mean"
                (optional)

        Returns:
             An iterator where each element is a tuple as shown below:
             The tuple is structured as
               (column1, column2, correlation value)
               sorted in descending order on correlation value.

        :Example:
        >>> src = connection.upload_source("./test/diabetes_test_points.txt")  # ignore-in-doc
        >>> columns = ["relative weight", "blood glucose", "insulin level"]
        >>> col_set = src.create_column_set(columns, "test_column_set")
        >>> outcome_col = "insulin response"
        >>> corr = src.iter_correlation_stats(column_set_id=col_set['id'],
        ...                                    outcome_column_name=outcome_col,
        ...                                    imputation_strategy="median")
        >>> result = [i for i in corr]
        >>> result[0]
        ('insulin response', 'relative weight', 0.3887174211012653)
        """

        if complement is True and group_id is None:
            raise ValueError("Please specify group_id if choosing to complement")

        if column_set_id is None:
            raise ValueError("Please specify column_set_id")

        if outcome_column_index is not None and outcome_column_name is not None:
            raise ValueError("Both outcome_column_index and outcome_column_name cannot be specified")

        valid_imputations = ['mean', 'median']
        if imputation_strategy not in valid_imputations:
            raise ValueError("Invalid null imputation strategy. Supported are " + str(valid_imputations))

        params_dict = {
            'method': method,
            'complement': complement,
            'column_set_id': column_set_id,
            'imputation_strategy': imputation_strategy
        }

        if outcome_column_name is not None:
            params_dict["outcome_column_id"] = self.colname_to_ids[outcome_column_name]
        if outcome_column_index is not None:
            params_dict["outcome_column_id"] = outcome_column_index
        if group_id is not None:
            params_dict["group_id"] = group_id

        correlations = json_funcs._iter_post_(self.connection.session,
                                              self.curl + '/stats/correlation', params_dict)

        for item in correlations:
            _correlation = None
            if 'correlation' in item:
                _correlation = item['correlation']

            yield ((item["first_column"], item["second_column"], _correlation))

    def create_chart(self, name, group_name, x_axis_col, y_axis_col,
                     chart_type='scatter', max_nodes=10000):
        """
        Creates a chart on the current :class:`source <ayasdi.core.source.Source>`.

        Args:
            name (str): User defined name of the chart
            group_name (str): Restrict chart source data to specified group.
            x_axis_col (str): column name for x-axis
            y_axis_col (str): column name for y-axis
            chart_type (str): chart type, default='scatter' (optional)
            max_nodes (int): maximum number of nodes to plot, default=10000 (optional)

        Returns:
            Chart dictionary. See ``print plot`` in the example.

        :Example:
        >>> src = connection.upload_source("./test/db_test2.txt")
        >>> plot = src.create_chart(
        ...     name='Test Chart',
        ...     group_name='All Groups',
        ...     x_axis_col='clinical classification',
        ...     y_axis_col='relative weight')

        **Example Dictionary**

        .. code-block:: python

            {u'name': u'Test Chart', group_name: 'All Groups', u'max_nodes': 10, u'properties':
                {u'axes': [
                    {u'range': [1.0, 3.0], u'lens_index': 0},
                    {u'range': [0.71, 1.2], u'lens_index': 1}]},
                u'lens_specifications': [
                    {u'column_index': 6},
                    {u'column_index': 1}],
                u'nodes': [
                    {u'y': 0.83125, u'x': 1.0, u'values': [1.0, 0.83125], u'id': 0, u'row_count': 8},
                    {u'y': 0.947272727272, u'x': 1.0, u'values': [1.0, 0.947272727272], u'id': 1, u'row_count': 11},
                    {u'y': 1.092307692307, u'x': 1.0, u'values': [1.0, 1.092307692307], u'id': 2, u'row_count': 13},
                    {u'y': 1.014999999999, u'x': 1.5, u'values': [1.5, 1.014999999999], u'id': 3, u'row_count': 2},
                    {u'y': 0.953333333333, u'x': 2.0, u'values': [2.0, 0.953333333333], u'id': 4, u'row_count': 12},
                    {u'y': 1.107, u'x': 2.0, u'values': [2.0, 1.107], u'id': 5, u'row_count': 20},
                    {u'y': 1.2, u'x': 2.0, u'values': [2.0, 1.2], u'id': 6, u'row_count': 3},
                    {u'y': 0.7924, u'x': 3.0, u'values': [3.0, 0.7924], u'id': 7, u'row_count': 25},
                    {u'y': 0.956857142857, u'x': 3.0, u'values': [3.0, 0.956857142857], u'id': 8, u'row_count': 35},
                    {u'y': 1.115333333333, u'x': 3.0, u'values': [3.0, 1.115333333333], u'id': 9, u'row_count': 15}
                    {u'y': 1.2, u'x': 3.0, u'values': [3.0, 1.2], u'id': 10, u'row_count': 1}],
                u'type': u'scatter',
                u'id': u'-3195280903870236327'}
        """
        if chart_type == 'scatter':
            return self._create_scatterplot(name, group_name, x_axis_col,
                                            y_axis_col, chart_type, max_nodes)
        else:
            warnings.warn('Unsupported Chart Type')
            return

    def get_all_charts(self):
        """Get all charts created on the current :class:`source <ayasdi.core.source.Source>`.

        Returns:
            List of chart dictionaries

        :Example:
        >>> #see `create_chart`
        """
        url = '{base}/charts'.format(base=self.curl)
        return json_funcs._get_(self.connection.session, url)

    def get_chart(self, name=None, id=None):
        """Get charts with the given name or id.

        Args:
            id (str) : id of the chart
                  (optional with name).
            name (str) : Name of the chart
                  (optional with id).

        Returns:
              A list of chart dictionaries

        :Example:

        >>> #see `create_chart`
        """
        charts = self.get_all_charts()

        if name is not None:
            chart_list = [x for x in charts if x['name'] == name]
        elif id is not None:
            chart_list = [x for x in charts if x['id'] == id]
        else:
            print('Chart name or id must be supplied.')
            return

        return chart_list

    def _create_scatterplot_from_dict(self, params_dict):
        del params_dict['id']
        url = '{base}/charts'.format(base=self.curl)
        return json_funcs._post_(self.connection.session, url, params_dict)

    def _create_scatterplot(self, name, group_name, x_axis_col, y_axis_col,
                            type='scatter', max_nodes=10000):
        # get column indices for axes
        self.sync()
        cols = self.columns
        x_col_idx = [x['index'] for x in cols if x['name'] == x_axis_col]
        if not x_col_idx:
            print('Column {col} does not exist'.format(col=x_axis_col))
            return
        else:
            x_col_idx = x_col_idx[0]

        y_col_idx = [x['index'] for x in cols if x['name'] == y_axis_col]
        if not y_col_idx:
            print('Column {col} does not exist'.format(col=y_axis_col))
            return
        else:
            y_col_idx = y_col_idx[0]

        # get group id
        if group_name == 'All Groups' or group_name is None:
            group = None
        else:
            group = self.get_group(name=group_name)

            if 'msg' in group:
                print('Group {grp} does not exist'.format(grp=group_name))
                return

        params_dict = {
            'name': name,
            'max_nodes': max_nodes,
            'lens_specifications': [
                {'column_index': x_col_idx}, {'column_index': y_col_idx}
            ],
            'type': type,
            'properties': {'axes': [{'lens_index': 0}, {'lens_index': 1}]}
        }
        if group:
            params_dict['group_id'] = group['id']
        url = '{base}/charts'.format(base=self.curl)
        return json_funcs._post_(self.connection.session, url, params_dict)

    def delete_chart(self, name=None, id=None):
        """Delete chart by name or id.

        Args:
            id (str) : id of the chart
                  (optional with name).
            name (str) : Name of the chart
                  (optional with id).

        """
        charts = self.get_all_charts()
        if name is not None:
            chart_list = [x for x in charts if x['name'] == name]
        elif id is not None:
            chart_list = [x for x in charts if x['id'] == id]
        else:
            raise ValueError('Chart name or id must be supplied.')

        if not chart_list:
            raise AttributeError('Chart not found')
        elif len(chart_list) > 1:
            raise ValueError('Multiple charts named %s found. '
                             'Please delete by id.' % name)
        else:
            chartId = chart_list[0]['id']

        url = '{base}/charts/{chartId}'.format(base=self.curl, chartId=chartId)

        json_funcs._delete_(self.connection.session, url)

    def delete_charts(self, ids=[]):
        """
        Deletes a list of charts by id.

        Args:
            ids ([str]): List of chart ids.
        Returns:
            True if successful
        """
        if len(ids) > 0:
            for id_ in ids:
                self.delete_chart(id=id_)
        else:
            raise ValueError("Please provide a list of ids")
        return True

    def share_chart(self, chart_id, user_id):
        """Share a chart with a user.

        Args:
            chart_id (str): id of the chart to be shared
            user_id (str): id of the user to be shared with

        Returns:
            True if successful
        """

        error_message = ''
        if chart_id is None:
            error_message = error_message + 'Chart id is missing'
        if user_id is None:
            error_message = error_message + 'User id is missing'
        if len(error_message) > 0:
            return self.__error__(error_message)

        post_params = {}
        share_url = self.curl + '/charts/%s/users/%s' % (chart_id, user_id)
        json_funcs._post_(self.connection.session, share_url, post_params)

        return True

    def optimize_format(self):
        """
        Optimizes the storage format of an existing dataset, adding a new ``__row_index__`` column
        as the last column of the dataset.

        .. note::
            If run against a source that is already optimized, raises a 400 HTTP error.

            (Primarily affects datasources that were uploaded prior to release 7.11, when uploaded
            datasources were not automatically indexed.)

        Returns:
           An :class:`AsyncJob <ayasdi.core.async_jobs.AsyncJob>` object

        :Example:
            >>> src = extraglobs['src'] #ignore-in-doc
            >>> try:
            ...     job = src.optimize_format()
            ... except HTTPError as e:
            ...     if e.response.status_code == 400:
            ...         print("source already optimized")
            ...     else:
            ...         raise
            ... else:
            ...     job.sync() # doctest: +ELLIPSIS
            E...
        """
        endpoint = self.curl + '/optimize_format/async'
        async_task = json_funcs._post_(self.connection.session,
                                       endpoint, None)
        return async_jobs.AsyncJob(self.connection, async_task, endpoint)

    def calculate_feature_weights(self, num_features, column_set_id, network_id=None,
                                  node_group=None, group_id=None):
        """
        Calculate the L1 feature weights for every row in the group either from group_id or from node_group, as well as
        the lens values.

        Args:
            group_id (str): The id of the group
            network_id (str): The id of the network
            node_group (str): the id of the node group (One of 'group_id' or '(network_id and node_group)' is required)
            num_features (int): The number of features to be considered
            column_set_id (str): the id of the column set

        Returns:
            A dictionary of query results

        :Example:

        >>> src = extraglobs['src'] #ignore-in-doc
        >>> # Delete all previous networks in the source if needed
        >>> networks = src.get_networks()
        >>> for network in networks:
        ...     del_status = src.delete_network(name=network.name)
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> import uuid
        >>> column_set = src.create_column_set(column_list=columns_for_analysis, name=str(uuid.uuid4()))
        >>> network = src.create_network(str(uuid.uuid4()),{
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': column_set['id'],
        ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 30, 'id': 'MDS coord 2',
        ...                   'equalize': True, 'gain': 3.0}]
        ...        }
        ... )
        >>> new_node_group = network.create_node_group(name=str(uuid.uuid4()),
        ...                                            nodes=list(range(10)))
        >>> feature_weights = src.calculate_feature_weights(
        ...     network_id=network.id, node_group=new_node_group,
        ...     num_features=3, column_set_id=column_set['id'])
        >>> feature_weights['row_indices']  # doctest: +NORMALIZE_WHITESPACE
        [4, 5, 6, 8, 10, 11, 13, 15, ..., 130, 133, 135]
        >>> feature_weights['features_per_row'] == 3
        True
        >>> feature_weights['lens_values']  # doctest: +NORMALIZE_WHITESPACE
        [8557.265167776704, 8344.413745273972, ...]
        >>> # The below distances should match the number of row_indices
        >>> len(feature_weights['lens_metadata'])
        56
        >>> distances_for_pt1 = \
        feature_weights['lens_metadata'][0]['distances']
        >>> distances_for_pt1
        [0.5109614018267576, 0.44461945402717024, 0.043828486804372575]
        >>> _ = src.delete_network(name=network.name) #ignore-in-doc
        >>> _ = src.delete_column_set(column_set['name']) #ignore-in-doc
        """

        warnings.warn(message_funcs._show_labs())
        warnings.warn("Deprecated: call compute_feature_weights() instead.")
        query_feature_weights = self._create_feature_weights_request(num_features=num_features,
                                                                     column_set_id=column_set_id,
                                                                     network_id=network_id,
                                                                     node_group=node_group,
                                                                     group_id=group_id,
                                                                     metric={'id': '1'},
                                                                     lens={'id': '10'})
        query_results = json_funcs._post_(self.connection.session,
                                          self.curl +
                                          '/retrieve_feature_weights',
                                          query_feature_weights)
        return query_results

    @staticmethod
    def _create_feature_weights_request(num_features, column_set_id, network_id=None, node_group=None,
                                        group_id=None, metric=None, lens=None, sub_group_id=None, zscore=None):
        if group_id is None:
            if network_id is None or node_group is None:
                raise AttributeError("One of 'group_id' or '(network_id and node_group_id)' is required.")
        # Construct post dict and post
        query_feature_weights = {'column_specifications': [{'column_set_id': column_set_id}],
                                 'metric': metric,
                                 'lens': lens,
                                 'sub_group_id': sub_group_id,
                                 'features_per_row': num_features,
                                 'zscore': zscore}
        if group_id is not None:
            query_feature_weights['row_specifications'] = [{'group_id': group_id}]
        else:
            query_feature_weights['row_specifications'] = [{'node_specification': {'network_id': network_id,
                                                                                   'node_group_id': node_group['id'],
                                                                                   'node_ids': node_group['node_ids']}}]
        return {k: v for k, v in query_feature_weights.items() if v is not None}

    def compute_feature_weights(self, num_features, column_set_id, network_id=None,
                                node_group=None, group_id=None, sub_group_id=None, landmarking=False, zscore=False):
        """
        Calculate the L1 feature weights for every row in the group either from the group_id or node_group.

        Args:
            group_id (str): The id of the group
            network_id (str): The id of the network
            node_group (str): the id of the node group (One of 'group_id' or '(network_id and node_group)' is required)
            num_features (int): The number of features to be considered
            column_set_id (str): the id of the column set
            sub_group_id (str): The id of a sub group of rows to compute the feature weights on. When the feature
                weights of only a subset of data are necessary, the subset group can be passed here.
            landmarking (bool): Computes the feature weights of rows with data whether against a landmarks set of rows
                or not. The default is False which means computing the feature weights with data against the whole data
                space.
            zscore (bool): Applies zscore transformation to the data before computing the feature weights. The default
                is false.

        Returns:
            A dictionary of query results:
            {'row_indices' : [1, 2,...],
             'feature_weights': [[{'feature_weight': 0.2, 'column_index': 1},
                                  {'feature_weight': 0.15, 'column_index': 3},
                                  {'feature_weight': 0.1, 'column_index': 4}]
                                  ...
                                ]
            }

        :Example:

        >>> src = extraglobs['src'] #ignore-in-doc
        >>> # Delete all previous networks in the source if needed
        >>> networks = src.get_networks()
        >>> for network in networks:
        ...     del_status = src.delete_network(name=network.name)
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> import uuid
        >>> column_set = src.create_column_set(column_list=columns_for_analysis, name=str(uuid.uuid4()))
        >>> network = src.create_network(str(uuid.uuid4()),{
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': column_set['id'],
        ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 30, 'id': 'MDS coord 2',
        ...                   'equalize': True, 'gain': 3.0}]
        ...        }
        ... )
        >>> new_node_group = network.create_node_group(name=str(uuid.uuid4()),
        ...                                            nodes=list(range(10)))
        >>> feature_weights = src.compute_feature_weights(
        ...     network_id=network.id, node_group=new_node_group,
        ...     num_features=3, column_set_id=column_set['id'])
        >>> feature_weights['row_indices']  # doctest: +NORMALIZE_WHITESPACE
        [4, 5, 6, 8, 10, 11, 13, 15, ..., 130, 133, 135]
        >>> len(feature_weights['feature_weights']) == len(feature_weights['row_indices'])
        True
        >>> _ = src.delete_network(name=network.name) #ignore-in-doc
        >>> _ = src.delete_column_set(column_set['name']) #ignore-in-doc
        """

        warnings.warn(message_funcs._show_labs())
        metric = None
        if landmarking:
            metric = {'id': '1'}
        query_feature_weights = self._create_feature_weights_request(num_features=num_features,
                                                                     column_set_id=column_set_id,
                                                                     network_id=network_id,
                                                                     node_group=node_group,
                                                                     group_id=group_id,
                                                                     sub_group_id=sub_group_id,
                                                                     metric=metric,
                                                                     zscore=zscore)
        query_results = json_funcs._post_(self.connection.session,
                                          self.curl + '/feature_weights',
                                          query_feature_weights)
        return query_results

    def create_filter_set(self, conditions, as_and=True):
        """
        Creates a filter set from the list of conditions.

        Args:
            conditions (list): A list of conditions
                where each condition is of the form


                    ``{'column_name' : <column_name>,
                    <condition_type> : condition, ...}``


                where:
                    - column_name is the selected_column
                    - condition_type includes:
                        - ``in_range`` is a list with [start, end]
                            (optional with in_set)
                        - ``in_set`` is a list with [value1, value2, ...]
                            (optional with in_range and preferred)
                        - ``not`` ignores the values from `in_range` or `in_set`
                        - ``contains`` treats values given in 'in_range'
                            or 'in_set' as substrings.

            as_and (bool): If True, an intersection of the conditions.
                Else, a union of the conditions is considered

        Returns:
            A filter set that can be used either in export or coloring.

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = extraglobs['src'] # ignore-in-doc
        >>> src.sync()
        >>> filter_set = \
            src.create_filter_set([{'column_name':
        ...                         'clinical classification',
        ...                         'in_set': [3]},
        ...                        {'column_name': 'relative weight',
        ...                         'in_range': [0.8, 1], 'not': True}],
        ...                       as_and=True)
        >>> subset = src.export(filter_set=filter_set)
        >>> column_id = src.colname_to_ids['clinical classification']
        >>> selected_column = subset['data'][column_id]
        >>> # Checking if the subsetting based on filter_sets worked.
        >>> set(selected_column) == {3}
        True
        >>> column_id = src.colname_to_ids['relative weight']
        >>> selected_column = subset['data'][column_id]
        >>> [i for i in selected_column if 0.8 <= i <= 1]
        []
        """

        ret_dict = {'filters': [], 'require_all': as_and}
        valid_column_keys = ['column_name', 'column_index']
        subset.validate_conditions(conditions, valid_column_keys)
        for col_key in valid_column_keys:
            ret_dict = subset.process_conditions(col_key, conditions, ret_dict)
        return ret_dict

    # ### METADATA HELPER FUNCTIONS ### #
    def _get_network_details(self, networks, col_set_dict, out_dict):
        node_group_network_dict = {}
        for network in networks:
            network.sync()
            try:
                col_set_dict[network.column_set_id]
            except KeyError:
                error_message = "Column set `%s` is not present anymore." \
                                "Comparison ignored" % network.column_set_id
                LOGGER.exception(error_message)
                print(error_message)
                continue

            node_groups = []
            for node_group in network.node_groups:
                node_group_network_dict.setdefault(node_group['name'], [])
                node_group_network_dict[node_group['name']] \
                    .append(network.name)

                node_groups.append({'name': node_group['name'],
                                    'nodes': node_group['node_ids']})

            out_dict['networks'].append({'metric': network.metric,
                                         'lenses': network.lenses,
                                         'column_set':
                                             col_set_dict[
                                                 network.column_set_id],
                                         'node_groups': node_groups,
                                         'name': network.name,
                                         'grapher_flow': network.grapher_flow,
                                         'edge_count': network.link_count,
                                         'node_count': len(network.nodes)})
        return [out_dict, node_group_network_dict]

    def get_lens_values(self, metric, lens, column_set_id, group_id=None):
        """
        Calculates lens values based on provided metric and lens.

        Args:
            metric (dict): metric definition as a dictionary (ex. {'id': 'Norm Correlation'})
            lens (str or int): lens name or identifier (ex. 11 or "L-Infinity Centrality")
            column_set_id (str): column set id
            group_id (str): group id

        Returns:
            A list of lens values.

        **Example return values**
        .. code-block:: python
             [2773.149112471235, 2898.932907122895, 2898.932907122895, 2766.5263418229006, 2672.467212146858]
        """
        request = {
            'group_id': group_id,
            'column_set_id': column_set_id,
            'metric': metric,
            'lens': lens,
        }
        response = json_funcs._post_(self.connection.session, self.curl + '/lens', request)
        return response['lens_values']

    def rename_source(self, new_name):
        """
        Renames this source.

        Args:
            new_name (str): The new name of the source

        Returns:
            This source

        """
        request = {
            'name': new_name
        }
        resp = json_funcs._put_(self.connection.session, self.curl + '/rename', request)
        src = Source(self.connection, source_info={'id': resp['id']})
        src.sync()
        return src

    def export_metadata(self, filename, networks=None, column_sets=None,
                        colorings=None, comparisons=None, charts=None,
                        groups=None):
        """
        :doc:`LABS feature <labs>` -- Downloads source properties such as
        column_sets, networks, node_groups, colorings, and comparisons.

        .. note::
          This feature will not work for networks built on affine metrics.

        Args:
            filename: (Required) The file where the resulting file
                is saved in `json` format.
            networks: A list of networks to be saved in the file.
                Default: all
            column_sets : A list of column_sets to be saved in the file.
                Default: all
            colorings : A list of colorings to be saved in the file.
                Default: all
            comparisons : A list of comparisons to be saved in the file.
                Default: all
            charts: A list of charts to be saved in the file.
                Default: all
            groups: A list of all groups to be saved in the file.
                Default: all

        Returns:
              None. Creates a json file stored under 'filename'.

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = extraglobs['src'] # ignore-in-doc
        >>> for coloring in src.get_colorings(): # ignore-in-doc
        ...     if coloring['name'] not in ['Rows per Node', 'Edges per Node']: # ignore-in-doc
        ...         _ = src.delete_coloring(id=coloring['id']) # ignore-in-doc
        >>> for colset in src.get_column_sets(): # ignore-in-doc
        ...     if colset['name'] != 'All columns':
        ...         _ = src.delete_column_set(id=colset['id']) # ignore-in-doc
        >>> for grp in src.get_groups(): # ignore-in-doc
        ...     _ = src.delete_group(id=grp['id']) # ignore-in-doc
        >>> for comp in src.get_comparisons(): # ignore-in-doc
        ...     _ = src.delete_comparison(id=comp['id']) # ignore-in-doc
        >>> for chart in src.get_all_charts(): # ignore-in-doc
        ...     _ = src.delete_chart(id=chart['id']) # ignore-in-doc
        >>> group1 = src.create_group(name='group1', row_indices=list(range(10)))
        >>> filter_set = src.create_filter_set([{'column_name':
        ...                                      'clinical classification',
        ...                                      'in_set': [3]},
        ...                                     {'column_name':
        ...                                      'relative weight',
        ...                                      'in_range': [0.8, 1],
        ...                                      'not': True}], as_and=True)
        >>> group2 = src.create_group(name='group2', filter_set=filter_set)
        >>> comparison = src.compare_groups("group1", "group2")
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = src.create_column_set(column_list=
        ...                                    columns_for_analysis,
        ...                                    name="test_column_set1")
        >>> network = src.create_network("test_network1", {
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': column_set['id'],
        ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 30, 'id': 'MDS coord 2',
        ...                   'equalize': True, 'gain': 3.0}]})
        >>> group = src.create_group(name="node_group",
        ...                          network=network,
        ...                          node_ids=list(range(10)))
        >>> group2 = src.create_group(name="node_group2",
        ...                           network=network,
        ...                           node_ids=list(range(10, 15)))
        >>> comparison2 = src.compare_groups("node_group", "node_group2")
        >>> plot = src.create_chart(name='Test Chart',
        ...     group_name='All Groups', x_axis_col='clinical classification',
        ...     y_axis_col='relative weight', chart_type='scatter')
        >>> len(src.get_column_sets())
        2
        >>> len(src.get_networks())
        1
        >>> len(src.get_colorings())
        2
        >>> len(src.get_comparisons())
        2
        >>> len(src.get_all_charts())
        1
        >>> src.export_metadata("./test/metadata.json")
        Metadata saved.
        >>> new_src = connection.upload_source("./test/db_metadata_test.txt")
        >>> annotation_source = connection.upload_source(
        ...     './test/db_annotation_test.txt')  #ignore-in-doc
        >>> a = new_src.annotate(annotation_source=annotation_source,
        ...              annotation_source_column="ID",
        ...              target_source_column="ID"
        ... )   #ignore-in-doc
        >>> new_src.sync()
        >>> src.sync() #ignore-in-doc
        >>> new_src.import_metadata("./test/metadata.json")
        Creating column sets
        Creating charts
        Creating networks
        Creating colorings
        No colorings were found
        Creating node_groups if present
        Creating groups if present
        Creating Comparisons
        Metadata applied.
        >>> new_src.sync()
        >>> # a new columnsset for all columns will be created for annotated
        >>> # source including newly added columns.
        >>> len(new_src.get_column_sets()) == len(src.get_column_sets())
        True
        >>> len(new_src.get_networks()) == len(src.get_networks())
        True
        >>> len(new_src.get_colorings()) == len(src.get_colorings())
        True
        >>> len(new_src.get_groups()) == len(src.get_groups())
        True
        >>> len(new_src.get_comparisons()) == len(src.get_comparisons())
        True
        >>> len(new_src.get_all_charts()) == len(src.get_all_charts())
        True
        >>> connection.delete_source(id=new_src.id) #ignore-in-doc
        >>> _ = src.delete_comparison(id=comparison['id']) #ignore-in-doc
        >>> _ = src.delete_comparison(id=comparison2['id']) #ignore-in-doc
        >>> _ = src.delete_network(name='test_network1')  #ignore-in-doc
        >>> _ = src.delete_chart(id=plot['id']) #ignore-in-doc
        """
        warnings.warn(message_funcs._show_labs())

        # Set up output
        out_dict = {'networks': [], 'column_sets': [],
                    'colorings': [], 'comparisons': [],
                    'groups': []}
        out_dict['created_by'] = self.connection.username
        out_dict['created_at'] = str(datetime.datetime.now())
        out_dict['original_source'] = self.name

        # Get all items
        self.sync()
        if column_sets is None:
            column_sets = self.get_column_sets()
        if networks is None:
            networks = self.get_networks()
        if colorings is None:
            colorings = self.get_colorings()
        if comparisons is None:
            comparisons = self.get_comparisons()
        if charts is None:
            charts = self.get_all_charts()
        if groups is None:
            groups = self.get_groups()

        # Save off charts
        out_dict['charts'] = charts

        # Getting column set details
        # Raise an error if there are multiple column sets with the same name
        col_set_names = [i['name'] for i in column_sets]
        if len(col_set_names) != len(set(col_set_names)):
            raise AttributeError("Multiple column sets with the same name. "
                                 "Metadata not saved.")
        col_set_dict = dict([(col_set['id'], col_set['name'])
                             for col_set in column_sets])
        for col_set in column_sets:
            if col_set['name'] == "All columns":
                continue
            col_set = self.get_column_set(id=col_set['id'])
            col_names = [self.id_to_colnames[i] for i in
                         col_set['column_indices']]
            out_dict['column_sets'].append({'name': col_set['name'],
                                            'column_list': col_names})

        # Getting network details, including node_groups
        out_dict, node_group_network_dict = \
            self._get_network_details(networks, col_set_dict, out_dict)

        # Getting coloring details
        for coloring in colorings:
            if coloring['id'] in ['0', '1']:
                continue
            del coloring['id']
            if 'entity_uri' in coloring:
                del coloring['entity_uri']
            if 'coloring_palette_specification' in coloring:
                del coloring['coloring_palette_specification']
            if 'column_index' in coloring:
                coloring['column_id'] = coloring['column_index']
                del coloring['column_index']
            if 'lens_coloring_description' in coloring:
                coloring['lens_specification'] = \
                    coloring['lens_coloring_description']
                del coloring['lens_coloring_description']
            out_dict['colorings'].append(coloring)

        group_names = defaultdict(int)
        for group_stub in groups:
            full_group = self.get_group(id=group_stub['id'])
            group_names[full_group['name']] += 1
            if group_stub.get('topological_model_id') is None:
                row_indices = None
                filter_set = None
                if 'row_specifications' in full_group:
                    for spec in full_group['row_specifications']:
                        if 'filter_set' in spec:
                            filter_set = spec['filter_set']
                        elif 'row_indices' in spec:
                            row_indices = spec['row_indices']
                        else:
                            row_indices = full_group.get('row_indices')
                            break
                else:
                    row_indices = full_group.get('row_indices')
                group = {'name': full_group['name'],
                         'filter_set': filter_set,
                         'row_indices': row_indices}
                out_dict['groups'].append(group)
        # Getting comparison details. If there is no node group corresponding
        # to this comparisons groups or if multiple analyses have node groups
        # with the same label, then don't save the comparison.
        for comparison in comparisons:
            group_1_name = comparison['row_sets'][0]['name']
            group_2_name = comparison['row_sets'][1]['name']
            try:
                column_set_name = col_set_dict[comparison['column_set_id']]
            except KeyError:
                error_message = "Column set `%s` is not present anymore. " \
                                "Comparison ignored" % comparison[
                                    'column_set_id']
                LOGGER.exception(error_message)
                print(error_message)
                continue
            if not group_1_name.strip() in ['Rest', 'All']:
                if group_1_name not in group_names:
                    print("Group '%s' in comparison is not available. "
                          "Comparison ignored!" % group_1_name)
                    continue
                elif group_names.get(group_1_name, 0) > 1:
                    print("Multiple groups with the name '%s'. "
                          "Comparison ignored!" % group_1_name)
                    continue
            if group_2_name.strip() not in ['Rest', 'All']:
                if group_2_name not in group_names:
                    print("Group '%s' in comparison is not available. "
                          "Comparison ignored!" % group_2_name)
                    continue
                elif group_names.get(group_2_name, 0) > 1:
                    print("Multiple groups with the name '%s'. "
                          "Comparison ignored!" % group_2_name)
                    continue
            comparison_dict = {
                'name': comparison['name'],
                'column_set_name': column_set_name,
                'group1': group_1_name,
                'group2': group_2_name}
            if group_2_name in node_group_network_dict and \
                    group_2_name in node_group_network_dict:
                comparison_dict['network'] = node_group_network_dict[group_1_name][0]
            out_dict['comparisons'].append(comparison_dict)
        with open(filename, 'w') as json_file:
            json.dump(out_dict, json_file, sort_keys=True, indent=4)
        print("Metadata saved.")

    def import_metadata(self, filename, skip_additional_features=False):
        """
        `LABS Feature <labs.html>`_ - Applies metadata saved using
        :func:`export_metadata`.

        Args:
            filename (str): The json_file where the metadata
                has been saved (required).
            skip_additional_features (bool) : Skip features that can cause
                errors when importing networks (optional).

        Returns:
              None

        :Example:

        as seen in :func:`export_metadata`

        """

        warnings.warn(message_funcs._show_labs())
        with open(filename) as json_file:
            metadata = json.load(json_file)
        self.sync()
        # Apply column sets
        print("Creating column sets")
        for column_set in metadata['column_sets']:
            self.create_column_set(column_set['column_list'],
                                   column_set['name'])
        self.sync()
        col_set_dict = dict([(col_set['name'], col_set['id']) for col_set
                             in self.get_column_sets()])

        # Create charts
        if metadata.get('charts'):
            print('Creating charts')
        else:
            print('No charts were found')

        for chart in metadata.get('charts', []):
            self._create_scatterplot_from_dict(chart)

        # Create analyses
        good_networks = []
        print("Creating networks")
        if not metadata.get('networks'):
            print("No networks were found")
        for network in metadata.get('networks', []):
            network_param_dict = {
                'metric': network['metric'],
                'column_set_id': col_set_dict[network['column_set']],
                'lenses': network['lenses'],
            }

            job_obj = self.create_network(name=network['name'],
                                          params_dict=network_param_dict,
                                          async_=True)

            # if network already exists
            if isinstance(job_obj, networks.Network):
                created_network = job_obj
            else:
                while job_obj.status == 'in_progress':
                    time.sleep(10)
                    job_obj.sync()

                created_network = networks.Network(self, job_obj.json)

            # if the metadata is missing these attributes go ahead append
            if ('edge_count' not in network or 'node_count' not in network):
                good_networks.append(network)
            # else if the counts match up, append
            elif (network['edge_count'] == created_network.link_count and
                  network['node_count'] == len(created_network.nodes)):
                good_networks.append(network)
            else:
                print('Network %s nodes or edges do not match source. \
                        Omitting.' % network['name'])

            self.sync()
        if skip_additional_features:
            print('Metadata applied.')
            return

        # Creating colorings
        print("Creating colorings")
        if not metadata.get('colorings'):
            print("No colorings were found")
        for coloring in metadata.get('colorings', []):
            if 'column_id' not in coloring or 'filter_set' not in coloring:
                self.create_coloring(**coloring)

        print('Creating node_groups if present')
        for network in good_networks:
            network_obj = self.get_network(name=network['name'])
            for node_group in network['node_groups']:
                node_ids = node_group['nodes']
                name = node_group['name']
                self.create_group(network=network_obj,
                                  name=name,
                                  node_ids=node_ids)

        print('Creating groups if present')
        if not metadata.get('groups'):
            print("No groups were found")
        for group in metadata.get('groups', []):
            self.create_group(name=group['name'],
                              filter_set=group.get('filter_set'),
                              row_indices=group.get('row_indices'))

        print('Creating Comparisons')
        if not metadata.get('comparisons'):
            print("No comparisons were found")
        for comparison in metadata.get('comparisons', []):
            self.compare_groups(comparison['group1'],
                                comparison['group2'],
                                column_set_id=self.get_column_set(name=comparison['column_set_name'])['id'],
                                name=comparison['name'])
        print('Metadata applied.')

    def update_columns(self, columns):
        """
        `LABS Feature <labs.html>`_ - Modifies column name and/or variable type.

        Args:
            columns (list): The list of columns to be modified in the following format:
                ``[{'column_index': <column_index>,
                'name': <new_name>,
                'variable_type': <'categorical', 'continuous', 'both', 'sequence', 'csv_vector', or 'date_time'>}]``
                (One of 'name' or 'variable_type' is required.)

        Returns:
            list of updated column summaries.

        :Example:

        >>> import ayasdi.core as ac
        >>> src = extraglobs['src'] # ignore-in-doc
        >>> src.sync()
        >>> src.columns[1]['variable_type']
        'both'
        >>> updated_columns = src.update_columns(
        ... columns=[{'column_index': 1, 'name': 'Relative Weight1', 'variable_type': 'continuous'}])
        >>> len(updated_columns)
        1
        >>> src.sync()
        >>> src.columns[1]['name']
        'Relative Weight1'
        >>> src.columns[1]['variable_type']
        'continuous'
        """
        warnings.warn(message_funcs._show_labs())
        endpoint = self.curl + '/column_info'
        return json_funcs._put_(self.connection.session,
                                endpoint,
                                data=columns)

    def create_column(self, name, values=None, filename=None):
        """
        Append a single column with data to an existing source.

        Args:
            name (str): The new name of the column. If name is already in use, the system will append a _1 or _2, etc.
            values (list): optional with filename. Use this list of data as rows in the new column
            filename (str): optional with values. Use this file as data for the new column. Format of the file must be
                a single column of values with only newlines to separate the rows. The file should not contain headers,
                (the column name), only values.

        Returns:
              None

        :Example:

        >>> import ayasdi.core as ac
        >>> src = connection.upload_source("./test/db_test2.txt", allow_duplicate=True) # ignore-in-doc
        >>> src.sync()
        >>> random_column_values = range(src.row_count)
        >>> src.create_column(name='new_column', values=random_column_values)
        >>> src.sync()
        >>> src.columns[7]['name']
        'new_column'
        >>> connection.delete_source(id=src.id) # ignore-in-doc
        """
        if values is None and filename is None:
            raise ValueError('Expected either values or filename args')

        m = None
        if values:
            # encode values
            mapped_values = '\n'.join(map(str, values))
            m = MultipartEncoder([('column_name', name),
                                  ('file', mapped_values)])
        else:
            # read values from file
            m = MultipartEncoder([('column_name', name),
                                  ('file', (filename, open(filename, 'rb'), 'text/plain'))])

        endpoint = self.curl + '/create_column'
        ret = json_funcs._post_(self.connection.session,
                                endpoint, m,
                                content_type=m.content_type)

        if (ret.get('warnings')):
            print(ret.get('warnings'))

    def get_column_metadata(self, index):
        """
        Retrieve the metadata for a column.

        Args:
            index: The index of the column

        Returns:
              Metadata associated with this column

        :Example:
        >>> import ayasdi.core as ac
        >>> src = connection.upload_source("./test/db_test2.txt", allow_duplicate=True) # ignore-in-doc
        >>> src.update_column_metadata(index=1, metadata_name='alternate')
        >>> src.get_column_metadata(1).get('metadata').get('name')
        'alternate'
        >>> connection.delete_source(id=src.id) # ignore-in-doc
        """
        endpoint = self.curl + '/column_metadata/' + str(index)
        ret = json_funcs._get_(self.connection.session, endpoint)
        return ret

    def update_column_metadata(self, index, metadata_name=None, metadata_other=None):
        """
        Update the metadata for a column.

        Args:
            index: The index of the column
            metadata_name: new value for the 'name' parameter in the metadata. You must set at least one of name, other.
            metadata_other: new value for the 'other' parameter in the metadata

        Returns:
              None
        """
        if metadata_name is None and metadata_other is None:
            raise ValueError('Expected either metadata_name or metadata_other args')

        endpoint = self.curl + '/column_metadata'
        meta = {'name': metadata_name,
                'other': metadata_other}
        param = {'column_id': index,
                 'metadata': meta}
        json_funcs._post_(self.connection.session, endpoint, data=param)

    def delete_column_metadata(self, index):
        """
        Delete the metadata for a column.

        Args:
            index: The index of the column

        Returns:
              None
        """
        endpoint = self.curl + '/column_metadata/' + str(index)
        json_funcs._delete_(self.connection.session, endpoint)

    def get_all_columns_metadata(self):
        """
        Return the metadata for all columns in this source.

        Args:
            None

        Returns:
            List of metadata for each column
        """
        endpoint = self.curl + '/column_metadata'
        ret = json_funcs._get_(self.connection.session, endpoint)
        return ret

    def detect_anomalous_rows(self, column_set_id, group_id,
                              threshold=0.5, num_features=5, algorithm='CentralityScoring',
                              log_transform=False,
                              async_=False):
        """
        Computes anomalous rows using feature weight detection method.

        Args:
            column_set_id: ID of the column set with the columns to be considered
            group_id: ID of the group of rows to be considered
            threshold: The minimum score for a row to be considered an anomaly (Default is 0.5)
            num_features: Number of top features to be displayed per anomalous row (Default is 5)
            algorithm: Currently supported algorithms: CentralityScoring (Default is CentralityScoring)
            log_transform: Apply log transform on the lens value before converting to risk score (Defaults to False)
            async_ (bool): when True, runs it asynchronously and returns an
                :class:`ayasdi.core.async_jobs.AsyncJob` object. The object's "result" field is set to
                the anomaly result.
        Returns:
            If ``async_=True`` returns an anomalies Json object. Other returns an
                :class:`ayasdi.core.async_jobs.AsyncJob` object.
        :Example:
        >>> import ayasdi.core as ac
        >>> src = connection.upload_source("./test/db_test2.txt", allow_duplicate=True) # ignore-in-doc
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = \
            src.create_column_set(column_list=columns_for_analysis,
        ...                       name="test_column_set")
        >>> group = src.create_group(name="test_group1",
        ...                          row_indices=list(range(10)))
        >>> anomaly_obj = src.detect_anomalous_rows(column_set_id=column_set['id'], group_id=group['id'],
        ...                                         num_features=4)
        Training is running in asynchronous mode.
        Remember to call ready() to check status.
        >>> len(anomaly_obj['anomalies'])
        3
        >>> connection.delete_source(id=src.id) # ignore-in-doc
        """
        spec = AnomalyFeatureWeightSpec(threshold=threshold, num_features=num_features,
                                        algorithm=algorithm, log_transform=log_transform)

        anomaly = Anomaly.create(self.connection, self.id, 'model', spec, column_set_id=column_set_id,
                                 group_id=group_id, async_=True)

        while not anomaly.ready():
            time.sleep(5)

        data_spec = SourceSubset(source_id=self.id, column_set_id=column_set_id, group_id=group_id)
        return anomaly.predict(data_spec, async_)

    def detect_anomalous_rows_random_sample(self, threshold, column_set_id,
                                            metric, lenses,
                                            sample_size=10000, sample_number=5,
                                            group_id=None,
                                            algorithm='connected_components',
                                            group_classifier_spec=RandomForestSpec(),
                                            min_row_count=10, async_=False):
        """
        Computes anomalous rows using random sample detection method.

        Automatically chooses sample size as min((int)(self.row_count * 0.75) + 1, 500,000).  
        If group_id is specified, the group must cantain at least as many rows as the sample size

        Args:
            column_set_id (int): ID of the column set with the columns to be considered.
            metric (param): a metric to create a network
            lenses (param): A list of lenses to create a network
            threshold (float): The minimum score for a row to be considered an anomaly
            sample_number (int): number of samples used for anomaly detection and must be an odd number. Value 
                is based on these rules:
                    - source row count <= 13,333: sample_number (Default is 5)
                    - source row count > 13,333, but <= 133K : min(3, sample_number)
                    - source row count > 133K : 1

            group_id (int): ID of the group of rows to be considered. If it is None, all rows are used (Default is None)
            algorithm (str): algorithm for autogrouping (Default is connected_components)
            group_classifier_spec: a :class:`ModelSpec` object to specify parameters used in group classifier
                algorithms. It can be one of these subclasses:
                    - :class:`ayasdi.core.models.random_forest_spec.RandomForestSpec` for random forest algorithm,
                    - :class:`ayasdi.core.models.decision_tree_spec.DecisionTreeSpec` for decision tree algorithm,
                    - :class:`ayasdi.core.models.logistic_regression_spec.LogisticRegressionSpec` for logistic
                      regression algorithm.
                    - :class:`ayasdi.core.models.gbdt_spec.GbdtSpec` for gradient boosted decision tree algorithm.
                default= RandomForestSpec().
            min_row_count (int): minimum number of rows in a non singleton group (Default is 10)
            async_ (bool): when True, runs it asynchronously and returns an
                :class:`ayasdi.core.async_jobs.AsyncJob` object. The object's "result" field is set to
                the anomaly result.
        Returns:
            If ``async_=False`` returns an anomalies Json object. Other returns an
                :class:`ayasdi.core.async_jobs.AsyncJob` object.
        :Example:
        >>> import ayasdi.core as ac
        >>> src = connection.upload_source("./test/db_test2.txt", allow_duplicate=True) # ignore-in-doc
        >>> columns_for_analysis = ["relative weight", "blood glucose",
        ...                         "insulin level", "insulin response"]
        >>> column_set = src.create_column_set(column_list=columns_for_analysis,
        ...                       name="test_column_set")
        >>> anomaly_obj = src.detect_anomalous_rows_random_sample(
        ...     column_set_id=column_set['id'], threshold=0.3,
        ...     metric={'id': 'Norm Correlation'},
        ...     lenses= [{'resolution': 30, 'id': 'MDS coord 1',
        ...               'equalize': True, 'gain': 3.0},
        ...              {'resolution': 30, 'id': 'MDS coord 2',
        ...               'equalize': True, 'gain': 3.0}],
        ...     sample_size=100, sample_number=3)
        Setting the sample size to 109 with sample_number set to 3
        Training is running in asynchronous mode.
        Remember to call ready() to check status.
        >>> anomaly_obj is not None
        True
        >>> connection.delete_source(id=src.id) # ignore-in-doc
        """
        source_sample_size = (int)(self.row_count * 0.75) + 1
        if source_sample_size <= 10000:
            # automatically scale the sample_size
            sample_size = source_sample_size
        elif source_sample_size <= 100000:
            # If the source row_count is in the <=133K
            sample_size = source_sample_size
            sample_number = min(3, sample_number)
        else:
            # If the dataset is > 133K
            sample_size = min(source_sample_size, 500000)
            sample_number = 1
        min_row_count = max(min_row_count, int(0.001 * sample_size))
        print("Setting the sample size to {} with sample_number set to {}".format(sample_size, sample_number))

        spec = AnomalyRandomSampleSpec(metric=metric, lenses=lenses, threshold=threshold,
                                       algorithm=algorithm, sample_size=sample_size,
                                       sample_number=sample_number, min_row_count=min_row_count)

        anomaly = Anomaly.create(self.connection, self.id, 'model', spec, column_set_id=column_set_id,
                                 group_id=group_id, async_=True)

        while not anomaly.ready():
            time.sleep(5)

        data_spec = SourceSubset(source_id=self.id, column_set_id=column_set_id, group_id=group_id)
        return anomaly.predict(data_spec, async_)
