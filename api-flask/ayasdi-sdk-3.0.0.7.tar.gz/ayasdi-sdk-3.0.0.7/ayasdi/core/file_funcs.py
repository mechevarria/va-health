#!/usr/bin/env python
"""Helper functions for writing files from HTTP responses
"""
from __future__ import absolute_import, unicode_literals, division, print_function
import json
import logging

from requests.exceptions import RequestException

LOGGER = logging.getLogger(__name__)


def _post_download_(session, url, data, file_name, content_type=None, params=None):
    """
    This function creates a POST request and writes the result body to a
    file specified.

    Args:
        session (ayasdi.core.session.Session): The current session
        url (str): The URL endpoint for the POST request
        data (dict): The data to be POSTed
        file_name (str): The absolute path of the file to be written
        content_type (str): The content type to be set in the headers

    Returns:
        True if the POST request and file write were successful
    """
    if not content_type:
        data = json.dumps(data)
        content_type = 'application/json'
    resp = session.post(url, data=data, stream=True,
                        headers={'content-type': content_type},
                        params=params)
    try:
        resp.raise_for_status()
    except RequestException:
        error_message = "Error Response: ", resp.text
        LOGGER.exception(error_message)
        raise
    return _write_file_from_response(resp, file_name)


def _get_download_(session, url, file_name, params=None):
    """
    This function creates a GET request and writes the result body to a
    file specified.

    Args:
        session (ayasdi.core.session.Session): The current session
        url (str): The URL endpoint for the POST request
        file_name (str): The absolute path of the file to be written

    Returns:
        True if the POST request and file write were successful
    """
    resp = session.get(url, stream=True, params=params)
    try:
        resp.raise_for_status()
    except RequestException:
        error_message = "Error Response: ", resp.text
        LOGGER.exception(error_message)
        raise
    return _write_file_from_response(resp, file_name)


def _write_file_from_response(response, file_name, chunk_size=1024):
    """
    Private helper function. Given an HTTP Response object,
        and a file path in file_name, write the contents of
        the response to a local file.

    Args:
        response (requests.Response): HTTP response object
        file_name (str): Name of file to write output
        chunk_size (int): Size of chunks in bytes (Optional)
    """
    with open(file_name, 'wb') as local_file:
        for chunk in response.iter_content(chunk_size):
            local_file.write(chunk)
    return True
