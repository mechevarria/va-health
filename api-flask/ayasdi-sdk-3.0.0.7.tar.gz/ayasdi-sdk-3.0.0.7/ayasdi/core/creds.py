# Credentials store
# Lifted shamelessly from
# http://stackoverflow.com/questions/15956952/
# how-do-i-decrypt-using-hashlib-in-python
from __future__ import absolute_import, unicode_literals, division, print_function
import getpass
import logging
import os
import keyring
import six
try:
    import cPickle as pickle
except ImportError:
    import pickle

LOGGER = logging.getLogger(__name__)


def save_creds(loc, username, password):
    """Save the current credentials to password store.
    """
    save_loc = os.path.join(os.path.expanduser("~"),
                            ".ayasdiapi")
    creds_file = os.path.join(save_loc, "creds")
    try:
        os.mkdir(save_loc)
    except OSError as e:
        LOGGER.exception(e)
        pass
    creds = {}
    try:
        with open(creds_file, 'rb') as creds_obj:
            creds = pickle.load(creds_obj)
    except IOError as e:
        LOGGER.exception(e)
    if loc not in creds:
        creds[loc] = {}
    if username not in creds[loc]:
        creds[loc][username] = ''
    with open(creds_file, 'wb') as creds_obj:
        pickle.dump(creds, creds_obj, 0)
    keyring.set_password(loc, username, password)


def get_creds(loc, username=None):
    """Given a location, get the username and password.
    """
    # Save url and username in ~/.ayasdiapi/creds.
    # If this file doesn't exist create it, else add new location and username
    # with empty password
    save_loc = os.path.join(os.path.expanduser("~"),
                            ".ayasdiapi")
    creds_file = os.path.join(save_loc, "creds")
    creds = None
    while not creds:
        try:
            with open(creds_file, 'rb') as creds_obj:
                creds = pickle.load(creds_obj)
                creds[loc]
        except (IOError, KeyError) as e:
            LOGGER.exception(e)
            if username is None:
                username = six.moves.input("Enter username: ")
            password = getpass.getpass("Enter password: ").strip()
            save_creds(loc, username, password)
            creds = None
    # If username is provided, get the password for that.
    # Else get the first username in ~/.ayasdiapi/creds
    # and return that and its password.
    if not username:
        un, pw = list(creds[loc].items())[0]
        pw = keyring.get_password(loc, un)
    else:
        un = username
        pw = keyring.get_password(loc, un)
    return un, pw
