#!/usr/bin/env python

from __future__ import absolute_import, unicode_literals, division, print_function

import logging
import warnings
import webbrowser

from ayasdi.core import groupconfig
from ayasdi.core import json_funcs
from ayasdi.core.jobs import Job
from ayasdi.core.async_jobs import AsyncJob
from ayasdi.core.score import Score
from ayasdi.core.utils import grammar_join
from ayasdi.core.data_spec import DataSpec
from ayasdi.core.data_point_list import DataPointList

LOGGER = logging.getLogger(__name__)


class Network(object):
    """
    An instance of the Network class is obtained from the :class:`Source <ayasdi.core.source.Source>` class using
    either :class:`source.create_network <ayasdi.core.source.Source.create_network>`
    or :class:`source.get_network <ayasdi.core.source.Source.get_network>`.

    .. note::
      A network object is only created using the source class. It cannot be instantiated using this class directly.

    Networks have the following attributes:
       - clustering_algorithm
       - coloring_values
       - column_set_id
       - comparisons
       - config
       - creationTime
       - creatorId
       - curl
       - entity_uri
       - file_source
       - grapher_flow
       - id
       - json
       - lenses
       - link_count
       - links
       - metric
       - name
       - node_count
       - node_groups
       - nodes
       - notes
       - row_count


    **AVAILABLE FUNCTIONS**

        Functions applied on the Network class are split into the following major groups


    **Synchronize and show the UI**:

       .. autosummary::
          Network.sync
          Network.sync_to_platform
          Network.show
          Network.source

    **Create autogroups**:

       .. autosummary::
          Network.autogroup
          Network.check_autogroup_status
          Network.get_autogroup_create_result
          Network.autogroup_create

    **Work with node groups**:

       .. autosummary::
          Network.create_node_group
          Network.get_node_groups
          Network.get_node_group
          Network.delete_node_group

    **Work with nodes and points**:

       .. autosummary::
          Network.get_nodes
          Network.get_neighboring_nodes
          Network.get_points
          Network.get_edges

    **Scoring, predictions, colorings and comparing**:

       .. autosummary::
          Network.scores
          Network.compute_score
          Network.create_coloring
          Network.get_colorings
          Network.get_coloring_values
          Network.get_multiple_coloring_values
          Network.topological_predict
          Network.iter_topological_predict
          Network.bootstrapped_topopredict
          Network.score_groups
          Network.compare_graphs
          Network.compare_to


    Args:
        source (:class:`Source <ayasdi.core.source.Source>`): the source object upon which this network is based.
        network_info (str): Network information returned by the Source class.


    :Example:

    >>> src = connection.upload_source("./test/db_test2.txt")
    >>> columns = ["relative weight", "blood glucose",
    ...            "insulin level", "insulin response"]
    >>> col_set = src.create_column_set(columns, "test_column_set")
    >>> network = src.create_network("test_network1",{
    ...        'metric': {'id': 'Norm Correlation'},
    ...        'column_set_id': col_set['id'],
    ...        'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
    ...                    'equalize': True, 'gain': 3.0},
    ...                   {'resolution': 30, 'id': 'MDS coord 2',
    ...                   'equalize': True, 'gain': 3.0}]
    ...        }
    ... )
    >>> extraglobs['src'], extraglobs['network'], extraglobs['col_set'] = src, network, col_set  # ignore-in-doc
    """

    def __init__(self, source, network_info):
        """
        Creates a network class through either \
        :func:`source.create_network <ayasdi.core.source.Source.create_network>` \
        or :func:`source.get_network <ayasdi.core.source.Source.get_network>`.
        """

        self.file_source = source
        self.json = network_info
        for key, value in network_info.items():
            setattr(self, key, value)
        self.connection = source.connection
        self.curl = self.connection.CORE_REQUEST_STUB + \
            'sources/%s/networks/%s' % (source.id, self.id)
        self.comparisons = []  # Good idea to store some comparisons here
        if not hasattr(self, '_scores'):
            self.scores = []
        for i, score_dict in enumerate(self.scores):
            if isinstance(score_dict, dict):
                from ayasdi.core.score import Score
                self.scores[i] = Score(**score_dict)

    def __repr__(self):
        """
        Returns:
            A string containing a printable representation of an object.
        """

        return "<Network '%s' from source '%s'> %s" % \
               (self.name, self.source.name, self.json)

    def __error__(self, msg, with_print=True):
        """
        Error message to be printed out and returned.
        """

        msg = {'msg': msg}
        if with_print:
            print(msg)
        return msg

    def sync(self):
        """
        Force refreshes the current network. Effectively, this returns the full network object, including
        links, node_groups, etc.

        :Example:

        >>> network = extraglobs['network'] # ignore-in-doc
        >>> network.sync()
        >>> hasattr(network, 'node_groups') # After getting full src, these exist
        True
        >>> hasattr(network, 'links')
        True
        >>> extraglobs['network'] = network # ignore-in-doc
        """

        self.__get_full_network__()

    def __get_full_network__(self):
        """
        Returns the full network object, including networks, node groups, etc.
        """
        ret_network = json_funcs._get_(self.connection.session, self.curl)
        for key, value in ret_network.items():
            setattr(self, key, value)
        self.json = ret_network

    def sync_to_platform(self):
        """Update the network ``name`` and ``x-y coordinates`` on the Ayasdi Platform.

        Args:
            None

        Returns:
            True if successful.

        :Example:

        >>> network = extraglobs['network'] # ignore-in-doc
        >>> network.sync()
        >>> # Update the coordinates of the first node
        >>> network.nodes[0]['x'] += 1.5
        >>> network.nodes[0]['y'] -= 1.5
        >>> network.sync_to_platform()
        True
        """
        network_dict = {'name': self.name,
                        'nodes': self.nodes}
        ret_network = json_funcs._put_(self.connection.session,
                                       self.curl,
                                       network_dict)
        for key, value in ret_network.items():
            setattr(self, key, value)
        self.json = ret_network
        return True

    def show(self):
        """Displays the current network in a browser window.
        """

        url = "%ssources/%s/networks/%s" % \
              (self.connection.CORE_LOGIN_STUB, self.source.id, self.id)
        result = webbrowser.open_new_tab(url)
        if result is False:
            warnings.warn("Could not open web browser. Please navigate to: {}".format(url))

    @property
    def source(self):
        """
        Returns the parent :class:`source <ayasdi.core.source.Source>` of the current
        :class:`network <ayasdi.core.networks.Network>`.


        Returns:
            A :class:`Source <ayasdi.core.source.Source>` object

        :Example:

        >>> network = extraglobs['network'] # ignore-in-doc
        >>> src = network.source
        """
        return self.file_source

    def autogroup(self,
                  algorithm="Community",
                  async_=False,
                  cutoff_strength=None,
                  coloring_values=None,
                  column_index=None,
                  column_type=None,
                  hampel_bounds=None,
                  threshold_percentage=None,
                  spot_type=None,
                  bounds=None
                  ):
        """
        Runs autogrouping on the network. Returns a list of groups.

        Args:
            algorithm (str): one of ``Community``, ``AHCL``, ``connected_components``, ``hotspot``. Default="Community"
            cutoff_strength (float): defines cutoff parameter for termination of the grouping process. Required for
                ``AHCL``, not allowed for other algorithms. Must be in [0, 1].
            coloring_values ([float]): The coloring values to be used in AHCL. (See :func:`get_coloring_values`).
                Optional with column_index.
            column_index (int): The index for the column to be used in AHCL. Optional with coloring_values.
            column_type (str): This indicates the type for the column represented by column_index.
                  One of 'continuous' or 'categorical'.
            hampel_bounds (bool): if true, use hampel_bounds function to calculate the boundary in hotspot only.
                  Optional with threshold_percentage.
            threshold_percentage (num): The pecentage in [0, 1] to calculate the boundary in hotspot only, default=95.
                  Optional with hampel_bounds.
            spot_type (str): The type of hotspot algorithm, ``hot`` or ``cold`` in hotspot only, default=``hot``.
            bounds ([float]): minimum and maximum bounds of coloring values in AHCL and hotspot only. It has a format
                  [minimum_coloring_value, maximum_coloring_value].

        Returns:
            A list of groups, where each group is a list of node ids

        :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> network = extraglobs['network'] #ignore-in-doc
        >>> source = network.source
        >>> new_coloring = source.create_coloring(name='test', column_id=4)
        >>> coloring_values = network.get_coloring_values(name="test")
        >>> autogroups = network.autogroup(algorithm="Community")
        >>> len(autogroups)
        13
        >>> autogroups[0]
        [0, 49, 17, 18, 5, 21, 22]
        >>> new_coloring = source.create_coloring(name='test', column_id=4)
        >>> coloring_values = network.get_coloring_values(name="test")
        >>> autogroups = network.autogroup(algorithm="AHCL",
        ...                                cutoff_strength=0.8,
        ...                                coloring_values=coloring_values)
        >>> len(autogroups)
        17
        >>> autogroups[0]
        [8]
        >>> autogroups = network.autogroup(algorithm="connected_components")
        >>> len(autogroups)
        8
        >>> # Async calls
        >>> autogroup_job = network.autogroup(algorithm="Community",
        ...                                   async_=True)
        >>> # Wait until this job is completed if necessary.
        >>> import time
        >>> while autogroup_job.status == 'in_progress':
        ...     time.sleep(10)
        ...     autogroup_job.sync()
        >>> node_id_list = [node_dict['node_ids'] for node_dict in
        ...                 autogroup_job.json['node_group_specifications']]
        >>> for ag in sorted(node_id_list):
        ...     print(sorted(ag))
        [0, 5, 17, 18, 21, 22, 49]
        [4, 24, 25, 26, 36, 40]
        [8]
        [7, 14, 16, 20, 27, 29, 31, 56, 62, 63, 69]
        [3, 6, 9, 11, 13, 19, 23, 30, 32, 34, 57]
        [33, 51, 52]
        [43]
        [12, 28, 35, 37, 39, 44, 45, 47, 48, 50, 53]
        [54]
        [55]
        [64]
        [1, 2, 10, 58, 65]
        [15, 38, 41, 42, 46, 59, 60, 61, 66, 67, 68]
        >>> autogroups = network.autogroup(algorithm='hotspot',
        ...                                coloring_values=coloring_values)
        >>> len(autogroups)
        2
        """
        if column_type is not None and column_type not in ['continuous', 'categorical']:
            raise ValueError("'column_type' has to be either 'continuous' or 'categorical', but the provided %s is not."
                             % column_type)

        # backend has more extensive validation. Here it is a very simple check to fail fast the obvious wrong input
        if bounds is not None and (not isinstance(bounds, list) or len(bounds) != 2 or bounds[0] > bounds[1]):
            raise ValueError("bounds should be given as [minimum_coloring_value, maximum_coloring_value]")

        autogroup_params = {'autogroup_algorithm_id': algorithm,
                            'cutoff_strength': cutoff_strength,
                            'coloring_values': coloring_values,
                            'column_index': column_index,
                            'column_type': column_type,
                            'hampel_bounds': hampel_bounds,
                            'threshold_percentage': threshold_percentage,
                            'spot_type': spot_type,
                            'bounds': bounds
                            }

        autogroup_params = {k: v for k, v in autogroup_params.items() if
                            v is not None}

        if async_:
            autogroup_job = json_funcs._post_(self.connection.session,
                                              self.curl +
                                              '/suggest_node_groups/async',
                                              autogroup_params)
            jobid = autogroup_job['jobId']
            entity_uri = '{core}/suggest_node_groups/async/{jobid}'.format(
                core=self.curl, jobid=jobid)

            return Job(self.connection, autogroup_job, type='new', uri=entity_uri, id=jobid)

        else:
            autogroups = json_funcs._post_(self.connection.session,
                                           self.curl +
                                           '/suggest_node_groups',
                                           autogroup_params)
            if 'node_group_specifications' in autogroups:
                return [i['node_ids']
                        for i in autogroups['node_group_specifications']]
            else:
                return []

    def check_autogroup_status(self, jobid):
        """Checks the status of an asynchrous autogroup job"""
        job_url = '{core}/suggest_node_groups/async/{jobid}'.format(
            core=self.curl, jobid=jobid)
        job_status = json_funcs._get_(self.connection.session, job_url)
        return job_status

    def get_autogroup_create_result(self, json_result):
        """
        Fetches the result of :func:`autogroup_create` if this is run asynchronously.

        Args:
            json_result: a dictionary result from :func:`autogroup_create` where async\_ = True

        Returns:
            A :class:`GroupSet <ayasdi.core.groupconfig.GroupSet>` object.

        :Example:

        >>> network = extraglobs['network'] #ignore-in-doc
        >>> source = network.source
        >>> autogroups = network.autogroup_create(algorithm="Community",
        ...                                       async_=True) # doctest: +ELLIPSIS
        C...
        >>> # Wait until this job is completed if necessary.
        >>> import time
        >>> while autogroups.status == 'in_progress':
        ...     time.sleep(10)
        ...     autogroups.sync()
        >>> res = network.get_autogroup_create_result(autogroups.json)

        """

        gcconnection = \
            groupconfig.GroupCentricConnection(self.source.connection,
                                               self.source.id)

        # TODO: __error__ is a weird pattern. We should call it "warning" instead
        # since it doesn't raise an exception
        try:
            gss = json_result['group_set_stub']
        except Exception:
            return self.__error__('Specified criteria for group creation could not be met.')

        group_set = groupconfig.GroupSet(gcconnection, gss)
        return group_set

    def autogroup_create(self,
                         algorithm="Community",
                         name='autogroup_create',
                         async_=False,
                         cutoff_strength=None,
                         coloring_values=None,
                         min_row_count=None,
                         min_node_count=None,
                         column_index=None,
                         column_type=None,
                         hampel_bounds=None,
                         threshold_percentage=None,
                         spot_type=None,
                         bounds=None,
                         use_async_job=False
                         ):
        """
        Runs autogrouping on the network, returning a GroupSet containing the created groups.

        .. note::
            For a walk-through of
            this procedure, see :doc:`Intro to Groups and Autogrouping <../../tutorials/groups_autogroups>`.

        Args:
            algorithm (str): one of ``Community``, ``AHCL``, ``connected_components``, ``hotspot``. Default="Community"
            name (str): User defined base name for the created group_set and groups. If not specified, the platform uses
                "autogroup_create" by default.
            async\_ (bool): if specified, runs the function asynchronously (optional)
            cutoff_strength (float): This defines cutoff parameter for termination of the grouping process. Required for
                ``AHCL``, not allowed for other algorithms. Must be in [0, 1].
            coloring_values ([float]): The coloring values to be used in AHCL. (See :func:`get_coloring_values`).
                Optional with column_index.
            column_index (int): The index for the column to be used in AHCL. Optional with coloring_values.
            column_type (str): This indicates the type for the column represented by column_index.
                  One of 'continuous' or 'categorical'.
            min_row_count (num): The minimum number of rows necessary to form a group. (optional)
            min_node_count (num): The minimum number of nodes necessary to form a group, default=1. (optional)
            hampel_bounds (bool): if true, use hampel_bounds function to calculate the boundary for hotspot only.
                  Optional with threshold_percentage.
            threshold_percentage (num): The pecentage in [0, 1] to calculate the boundary, default=95 for hotspot only.
                  Optional with hampel_bounds.
            spot_type (str): The type of hotspot algorithm, ``hot`` or ``cold`` for hotspot only, default=``hot``.
            bounds ([float]): The minimum and maximum bounds of coloring values for AHCL and hotspot. It has a format
                  [minimum_coloring_value, maximum_coloring_value]. (optional)
            use_async_job (bool): if true, return AsyncJob object instead of Job object

        Returns:
            If async\_=False, a :class:`GroupSet <ayasdi.core.groupconfig.GroupSet>` object; if
            async\_=True, an :class:`ayasdi.core.jobs.Job` object if use_async_job=False or an
            :class:`ayasdi.core.jobs.AsyncJob` object if use_async_job=True

        :Example:

        >>> network = extraglobs['network'] #ignore-in-doc
        >>> source = network.source
        >>> autogroups = network.autogroup_create(algorithm="Community",
        ...                                       name="xyz",
        ...                                       min_node_count=5)
        >>> len(autogroups.groups) > 0
        True
        >>> autogroups_job = network.autogroup_create(algorithm="Community",
        ...                                           name="job",
        ...                                           min_node_count=5,
        ...                                           async_=True) # doctest: +ELLIPSIS
        C...
        >>> isinstance(autogroups_job, Job)
        True
        >>> autogroups_job = network.autogroup_create(algorithm="Community",
        ...                                           name="async_job",
        ...                                           min_node_count=5,
        ...                                           async_=True,
        ...                                           use_async_job=True) # doctest: +ELLIPSIS
        C...
        >>> isinstance(autogroups_job, AsyncJob)
        True
        >>> autogroups = autogroups_job.get_result()
        >>> len(autogroups.groups) > 0
        True
        """
        if column_type is not None and column_type not in ['continuous', 'categorical']:
            raise ValueError("column_type has to be either 'continuous' or 'categorical', but the provided %s is not."
                             % column_type)

        # backend has more extensive validation. Here it is a very simple check to fail fast the obvious wrong input
        if bounds is not None and (not isinstance(bounds, list) or len(bounds) != 2 or bounds[0] > bounds[1]):
            raise ValueError("bounds should be given as [minimum_coloring_value, maximum_coloring_value]")

        autogroup_params = {'autogroup_algorithm_id': algorithm,
                            'create_groups_with_name': name,
                            'cutoff_strength': cutoff_strength,
                            'coloring_values': coloring_values,
                            'min_row_count': min_row_count,
                            'min_node_count': min_node_count,
                            'column_index': column_index,
                            'column_type': column_type,
                            'hampel_bounds': hampel_bounds,
                            'threshold_percentage': threshold_percentage,
                            'spot_type': spot_type,
                            'bounds': bounds
                            }

        autogroup_params = {k: v for k, v in autogroup_params.items() if
                            v is not None}

        if async_:
            autogroup_job = \
                json_funcs._post_(self.connection.session,
                                  self.curl + '/suggest_node_groups/async',
                                  autogroup_params)
            jobid = autogroup_job['jobId']

            if use_async_job:
                print('Creating autogroups is running in asynchronous mode.')
                print('Remember to call ready() to check status.')
                entity_uri = '{core}/suggest_node_groups/async'.format(core=self.curl)
                return AsyncJob(self.connection,
                                autogroup_job,
                                entity_uri,
                                result_converter=self.get_autogroup_create_result)
            else:
                # use Job object by default for backward compatibility
                print('Creating autogroups is running in asynchronous mode.')
                print('Remember to check "status" attribute to check status.')
                entity_uri = '{core}/suggest_node_groups/async/{jobid}'.format(core=self.curl, jobid=jobid)
                return Job(self.connection, autogroup_job, type='new', uri=entity_uri, id=jobid)
        else:
            autogroups = json_funcs._post_(self.connection.session,
                                           self.curl + '/suggest_node_groups',
                                           autogroup_params)

            return self.get_autogroup_create_result(autogroups)

    def create_node_group(self, **kwargs):
        """
        Creates a node group.

        .. seealso::
           :func:`get_node_groups`, :func:`get_node_group`,
           :func:`delete_node_group`

        Args:
            nodes ([int]): list of node ids.
            name (str) : User defined name of this node group

        Returns:
            A dictionary containing node group


        :Example:

        >>> network = extraglobs['network'] #ignore-in-doc
        >>> #No node groups are present initially
        >>> deletion = network.delete_node_group(name="test_group_CNG")
        ...                                     # doctest: +SKIP
        {'msg': 'Node_Group with given parameters does not exist'}
        >>> new_node_group = network.create_node_group(name="test_group_CNG",
        ...                                            nodes=list(range(10)))
        >>> network.sync() #Optional
        >>> node_group_names = [group['name'] for group in network.node_groups]
        >>> 'test_group_CNG' in node_group_names #ignore-in-doc
        True
        >>> network.delete_node_group(name="test_group_CNG") #ignore-in-doc
        True
        """
        if 'name' not in kwargs:
            return self.__error__('A name argument is reqd \
                                  to create node groups.')
        if 'nodes' not in kwargs:
            return self.__error__('A nodes argument is reqd \
                                  to create node groups.')
        # Return preexisting node group with the same name
        existing_node_group = self.get_node_group(name=kwargs['name'])
        if 'msg' not in existing_node_group:
            return existing_node_group
        # or build the post call
        node_groups_info = {'name': kwargs['name']}
        node_groups_info['node_ids'] = kwargs['nodes']
        # Get the column id and create node_groups.
        node_groups = json_funcs._post_(self.connection.session,
                                        self.curl + '/node_groups',
                                        node_groups_info)
        self.node_groups.append(node_groups)
        return node_groups

    def get_node_groups(self):
        """
        Returns node groups in the current :class:`network <ayasdi.core.networks.Network>`.

        .. seealso::
           :func:`get_node_group`, :func:`create_node_group`, and
           :func:`delete_node_group`.

        Returns:
            A list of node groups

        :Example:

        >>> network = extraglobs['network'] #ignore-in-doc
        >>> node_groups = network.get_node_groups()


        """
        try:
            return self.node_groups
        except AttributeError as e:
            LOGGER.exception(e)
            self.__get_full_network__()
            return self.node_groups

    def get_node_group(self, **kwargs):
        """
        Returns a node group by name.

        Args:
            id (int) : The id of the node group (optional with name).
            name (str) : The name of the node group (optional with id).

        Returns:
            A node group dictionary


        """
        node_groups = self.get_node_groups()
        for nodegroup in node_groups:
            if 'name' in kwargs:
                if nodegroup['name'] == kwargs['name']:
                    return nodegroup
            elif 'id' in kwargs:
                if nodegroup['id'] == kwargs['id']:
                    return nodegroup
        return self.__error__("Nodegroup with name '%s' does not exist" %
                              kwargs['name'], False)

    def delete_node_group(self, **kwargs):
        """
        Deletes a node_group with a given name or id.

        Args:
            id (int) : Id of the requested node_group (optional with name).
            name (str) : Name of the requested node_group (optional with id).

        Returns:
            A node group dictionary (if only one exists) or a list of node_group dictionaries (if multiples exist).


        :Example:

        See sample usage in :func:`create_node_group`

        """
        node_groups = self.get_node_groups()
        selected_node_group = None
        for ind, node_group in enumerate(node_groups):
            if 'name' in kwargs:
                if node_group['name'] == kwargs['name']:
                    selected_node_group = node_group['id']
            elif 'id' in kwargs:
                if node_group['id'] == kwargs['id']:
                    selected_node_group = node_group['id']
            if selected_node_group:
                json_funcs._delete_(self.connection.session,
                                    self.curl +
                                    '/node_groups/' +
                                    selected_node_group)
                del self.node_groups[ind]
                return True
        return self.__error__("Node_Group with given parameters "
                              "does not exist")

    def get_nodes(self):
        """
        Returns a list of all node ids in the network.

        Returns:
            A list of node ids in the network

        :Example:

        >>> network = extraglobs['network'] #ignore-in-doc
        >>> all_nodes = network.get_nodes()
        """

        try:
            return self.nodes
        except AttributeError as e:
            LOGGER.exception(e)
            self.__get_full_network__()
            return self.nodes

    def _get_deg_1_neighbors(self, node):
        edges = self.get_edges()

        return (
            # ignore duplicates
            set(
                # flatten list of lists
                sum(
                    # both 'to' and 'from' are neighbors
                    [[x['from'], x['to']] for x in edges
                     if x['from'] == node or x['to'] == node],
                    []
                )
                # subtract original node
            ) - set([node]))

    def get_neighboring_nodes(self, node_list, degrees=1):
        """
        Returns neighboring nodes up to ``n`` degrees, for a specified list of nodes.

        Args:
            node_list ([int]) : list of nodes as integers
            degrees (int) : desired number of layers of neighboring nodes, default=1

        Returns:
            Dictionary with nodes as keys and lists of neighboring nodes as values

        :Example:

        >>> network = extraglobs['network'] #ignore-in-doc
        >>> results = network.get_neighboring_nodes([50])
        >>> sorted(list(results[50]))
        [12, 28, 35, 39, 53]
        """
        neighbors = {}
        # populate original list
        for node in node_list:
            neighbors[node] = self._get_deg_1_neighbors(node)

            # we've already done one degree
            for deg in range(degrees - 1):
                # don't change a list you're iterating over
                new_nodes = set()
                for n2 in neighbors[node]:
                    new_nodes = new_nodes.union(self._get_deg_1_neighbors(n2))

                neighbors[node] = neighbors[node].union(new_nodes)

        return neighbors

    def get_points(self, node_ids=None, node_group=None,
                   node_group_id=None):
        """
        Returns points at nodes or a node group for the current analysis.

        Args:
            node_ids ([int]) : list of node ids from which to retrieve information
            node_group (dict) : node group dictionary from which points are to be retrieved (optional with
                node_group_id)
            node_group_id (str) : node group id for points retrieval (optional with node_group)

        Returns:
            A dictionary of nodes to points.

        :Example:

        >>> network = extraglobs['network'] #ignore-in-docs
        >>> new_node_group = network.create_node_group(name="test_group",
        ...                                            nodes=list(range(10)))
        >>> point_dict = network.get_points(node_group=new_node_group)
        >>> point_dict['8']
        [44, 53, 57, 111, 133]
        >>> point_dict = network.get_points(node_ids=list(range(5)))
        >>> point_dict['2']
        [88, 91, 98, 109, 130, 135]
        """
        points = self.iter_get_points(node_ids, node_group, node_group_id)

        if type(points) is dict and 'msg' in points:
            return points

        return {str(key): value for key, value in [(item['nodeId'], item['row_indices']) for item in list(points)]}

    def iter_get_points(self, node_ids=None, node_group=None,
                        node_group_id=None):
        """
        Iterate over nodes and the points they contain as seen in :func:`get_points`.

        Args:
            node_ids ([int]) : list of node ids from which to retrieve information
            node_group (dict) : node group dictionary from which points are to be retrieved (optional with
                node_group_id)
            node_group_id (str) : node group id for points retrieval (optional with node_group)

        Returns:
            A generator containing node ids and points.

        :Example:

        >>> network = extraglobs['network'] #ignore-in-docs
        >>> new_node_group = network.create_node_group(name="test_group",
        ...                                            nodes=list(range(10)))
        >>> points = network.iter_get_points(node_group=new_node_group)
        >>> point = next(points)
        >>> point['nodeId']
        0
        >>> point['row_indices']
        [13, 17, 24, 29, 33, 54]
        >>> next(points)
        {'nodeId': 1, 'row_indices': [6, 10, 41, 68, 85, 92, 100, 107, 109, 135]}
        """
        node_group_dict = self._validate_get_points(node_ids, node_group, node_group_id)

        if 'msg' in node_group_dict:
            return node_group_dict

        return json_funcs._iter_post_(self.connection.session,
                                      self.curl + '/retrieve_row_indices/stream',
                                      node_group_dict)

    def _validate_get_points(self, node_ids=None, node_group=None,
                             node_group_id=None):
        node_group_dict = {}
        # If none of node_group/node_group_id/list_of_nodes is available
        # return with an error message.
        if node_group_id is None and node_group is not None:
            node_group_id = node_group['id']

        if not isinstance(node_ids, list):
            node_ids = None
        if node_ids is None and node_group_id is None:
            return self.__error__('Either a node group or a '
                                  'list of nodes have to be specified.')

        # populate the param dict with required post params
        if node_group_id is not None:
            node_group = self.get_node_group(id=node_group_id)
            node_group_dict['node_ids'] = node_group['node_ids']
        elif node_ids is not None:
            node_group_dict['node_ids'] = node_ids

        return node_group_dict

    def get_edges(self):
        """
        Returns network edges, equivalent to network.links.
        """
        return self.links

    @property
    def scores(self):
        """Network scores - list of :class:`score <ayasdi.core.score.Score>` objects"""
        return getattr(self, '_scores', None)

    @scores.setter
    def scores(self, val):
        self._scores = val
    
    def create_coloring(self, name, custom_array):
        """
        Creates a new coloring for the current :class:`Network` object, which can only color the same network.

        Args:
            name: User defined name of this coloring.
            custom_array([float]): A list of double values of the same size as the number of nodes in the
                :class:`Network` object, each being a coloring value for a node.

        Returns:
            A coloring dictionary as shown in \
            :func:`Source.create_coloring() <ayasdi.core.source.Source.create_coloring>`.
        """
        source = self.file_source
        coloring = source.get_coloring(name=name)
        if 'msg' not in coloring:
            return coloring
        coloring_info = {'name': name, 'network_id': self.id, 'custom_array': custom_array}
        curl = self._get_curl_cut_to_source();
        coloring = json_funcs._post_(self.connection.session,
                                     curl + 'colorings',
                                     coloring_info)
        source.colorings.append(coloring)
        return coloring

    def _get_curl_cut_to_source(self):
        index = self.curl.find('networks')
        return self.curl[0:index]

    def get_colorings(self):
        """
        Retrieves colorings created from the current :class:`Network` object.

        Returns:
            A list of coloring dictionaries as shown in \
            :func:`Source.get_colorings() <ayasdi.core.source.Source.get_colorings>`
        """
        source = self.file_source
        colorings = source.get_colorings()
        result = []
        for coloring in colorings:
            if 'network_id' in coloring and coloring['network_id'] == self.id:
                result.append(coloring)
        return result

    def get_coloring_values(self, name=None, id=None):
        """
        Returns coloring values based on name or id of coloring.

        .. note::
            A coloring scheme has to be initially created on
            the source using :func:`ayasdi.core.source.Source.create_coloring`

        Args:
            id (int) : Id of the coloring (optional with name)
            name (str) : Name of the coloring (optional with id)

        Returns:
            A list of coloring values

        >>> network = extraglobs['network'] #ignore-in-doc
        >>> new_coloring = \
            network.source.create_coloring(name='test', column_id=4)
        >>> coloring_values = network.get_coloring_values(name="test")

        """
        coloring = self.file_source.get_coloring(name=name, id=id)
        # if get_coloring returns an error message, propogate it up
        if 'msg' in coloring:
            return coloring

        coloring_values = json_funcs._post_(self.connection.session,
                                            self.curl + '/coloring_values',
                                            {'coloring_id': coloring['id']})
        return coloring_values['values']

    def get_multiple_coloring_values(self, names=None, ids=None):
        """
        Returns coloring values based on a list of coloring names or ids.

        .. note::
            A coloring scheme has to be initially
            created on the source using :func:`ayasdi.core.source.Source.create_coloring`

        Args:
            ids ([int]) : Ids of the coloring (optional with ``names``)
            names ([str]) : Names of the coloring (optional with ``ids``)

        Returns:
            A dictionary with coloring ids as keys and coloring_values as values.

        >>> network = extraglobs['network'] #ignore-in-doc
        >>> new_coloring1 = \
            network.source.create_coloring(name='test1', column_id=4)
        >>> new_coloring2 = \
            network.source.create_coloring(name='test2', column_id=3)
        >>> coloring_values_dict = network.get_multiple_coloring_values(names=["test1", "test2"])
        >>> network.source.delete_coloring(name="test1") #ignore-in-doc
        True
        >>> network.source.delete_coloring(name="test2") #ignore-in-doc
        True

        """
        colorings = []
        is_names_list = False
        if ids is not None:
            for id in ids:
                coloring_for_id = self.file_source.get_coloring(id=id)
                if 'msg' in coloring_for_id:
                    raise ValueError(
                        'Fetching the coloring with id {} failed with message {}'.format(id, coloring_for_id['msg'])
                    )
                colorings.append(coloring_for_id)
        elif names is not None:
            for name in names:
                coloring_for_id = self.file_source.get_coloring(name=name)
                if 'msg' in coloring_for_id:
                    raise ValueError(
                        'Fetching the coloring with name {} failed with message {}'.format(name, coloring_for_id['msg'])
                    )
                colorings.append(coloring_for_id)
            is_names_list = True
        else:
            raise ValueError('Either names or ids list is required')

        coloring_ids = [coloring['id'] for coloring in colorings]

        coloring_values_by_id = json_funcs._post_(self.connection.session, self.curl + '/coloring_values',
                                                  {'coloring_ids': coloring_ids})

        if is_names_list:
            coloring_values_by_name = {}
            for coloring in colorings:
                coloring_values_by_name[coloring['name']] = coloring_values_by_id[coloring['id']]
            return coloring_values_by_name
        else:
            return coloring_values_by_id

    ####################################
    # Node group related functions     #
    ####################################
    def __make_remaining__(self, group1):
        """
        Creates a group that is the complement of group1.
        """
        group_nodes = set(str(id) for id in group1['node_ids'])
        network_nodes = set(node['id'] for node in self.get_nodes())
        remaining_nodes = network_nodes.difference(group_nodes)
        if len(remaining_nodes) > 0:
            remaining_group = self.create_node_group(
                name='Complement of ' + group1['name'],
                nodes=list(remaining_nodes))
            return remaining_group
        else:
            raise ValueError('The complement of this group is empty.')

    def bootstrapped_topopredict(self, data_spec, predict_columns, neighbors_count=None, n_iterations=1,
                                 sample_size=10000):
        """ Perform bootstrapped topological prediction.

           A number of bootstrapped samples are retrieved from the dataset and consensus in the topological predict
           output amongst these are used for the predictive output.

        :param data_spec: A :class:`DataSpec <ayasdi.core.data_spec.DataSpec>` object.
        :param predict_columns: List of {column_id or column_name, calculation_method ('mode', 'mean', 'median')}
        :param neighbors_count: number of qualified inputs required for prediction.
        :param n_iterations: Number of bootstrapped samples/iterations to be run.
        :param sample_size: Size of each bootstrapped sample. Default=10000.
        :return: The predict outcomes for all query data points in the form of:
                 [
                   [{'column_id': <column_index>, 'calculation_method': ‘mean’, #other options are median, mode
                     'predicted_value': <predicted_value>},
                    {column_id: <column_index>, 'calculation_method': ‘mean’, #other options are median, mode,
                     predicted_value: <predicted_value>},
                     ...], # output for test row 1,
                   ...
                 ]

        :Example:

        >>> import ayasdi.core as ac
        >>> network = extraglobs['network'] #ignore-in-doc
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> col_set = extraglobs['col_set'] #ignore-in-doc
        >>> predictions = network.bootstrapped_topopredict(
        ...     data_spec=ac.DataPointList([[0.81, 80, 356, 124], [0.95, 97, 289, 117]]),
        ...     predict_columns=[{'column_id':0, 'calculation_method':'mean'}],
        ...     neighbors_count=10, n_iterations=2)
        >>> output = [prediction['predicted_columns'][0]['predicted_value'] for prediction in predictions]
        >>> predictions = network.bootstrapped_topopredict(data_spec=ac.SourceSubset(source_id=src.id,
        ...                                                                          column_set_id=col_set['id']),
        ...                                                predict_columns=[{'column_id':0,
        ...                                                                  'calculation_method':'mean'}],
        ...                                                neighbors_count=10, n_iterations=2)
        >>> output = [prediction['predicted_columns'][0]['predicted_value'] for prediction in predictions]
        """
        data_point_group_id = None
        data_point_array = None
        query_source_id = None
        query_columnset_id = None
        if not isinstance(data_spec, DataSpec):
            raise ValueError('data_spec has to be an data array or an instance of DataSpec.')
        elif isinstance(data_spec, DataPointList):
            data_point_array = data_spec.points
        else:
            data_point_group_id = data_spec.group_id
            query_source_id = data_spec.source_id
            query_columnset_id = data_spec.column_set_id
        result = self.iter_topological_predict(data_point_group_id=data_point_group_id,
                                               data_point_array=data_point_array,
                                               data_point_row_ids=None,
                                               search_in_groupset_ids=None,
                                               search_in_group_ids=None,
                                               neighbors_count=neighbors_count,
                                               max_neighbors_count=None,
                                               return_closest_rows=False,
                                               return_closest_rows_column_set_id=None,
                                               return_containing_nodes=False,
                                               return_containing_groups=False,
                                               selection_criteria='ALL',
                                               predict_columns=predict_columns,
                                               query_source_id=query_source_id,
                                               query_columnset_id=query_columnset_id,
                                               strategy='bootstrapped',
                                               n_iterations=n_iterations,
                                               sample_size=sample_size)
        return list(result)

    ###############################
    # Topological Predict function #
    ###############################
    def topological_predict(self, data_point_group_id=None,
                            data_point_array=None,
                            data_point_row_ids=None,
                            search_in_groupset_ids=None,
                            search_in_group_ids=None,
                            neighbors_count=None,
                            max_neighbors_count=None,
                            return_closest_rows=False,
                            return_closest_rows_column_set_id=None,
                            return_containing_nodes=False,
                            return_containing_groups=False,
                            selection_criteria='ALL',
                            predict_columns=None,
                            query_source_id=None,
                            query_columnset_id=None,
                            strategy='FAST',
                            **kwargs):
        '''
        Predicts point neighborhood and/or values for networks that were not created using affine metrics.

        .. note::
            For more information, see `Topological Prediction with the Ayasdi SDK
            <https://ayasdicommunity.force.com/s/article/ka00P0000009I9zQAE/Topological-Prediction>`__


        Args:
            data_point_group_id (int) : group_id for the query data
            data_point_array ([str]) : list of lists of feature values, where each list represents one point
            data_point_row_ids (str) : Ids of points in current source to be predicted
            search_in_groupset_ids ([str]) : list of IDs of groupsets within which to search for neighbors. Required for
                search_in_group_ids. (optional)
            search_in_group_ids ([str]) : list of IDs of groups within which to search for neighbors. Required for
                search_in_groupset_ids. (optional)
            neighbors_count (int) : number of qualified inputs required for prediction
            max_neighbors_count (int) : maximum number of neighbors inquire when looking for qualified neighbors
            query_source_id (str, int) : query source ID; if not specified, will use network's source. (Note:
                If specified, data_point_group_id or data_point_row_ids should pertain to the query source ID.)
            return_closest_rows (bool) : specifies whether to return the row IDs of closest neighbors. Default=False
            return_closest_rows_column_set_id (str) : ID of column set to use when returning closest neighbors
            return_containing_nodes (bool) : specifies whether to return all nodes that contain nearest neighbors
                Default=False
            return_containing_groups (bool) : specifies whether to return all groups that contain nearest neighbors.
                Default=False
            selection_criteria (str) : if there is a desire to predict within groups, specifies how to select the group.
                Valid criteria are 'all', 'centrality', 'biggest', 'smallest', 'mode'
            predict_columns (list) : list of {column_id or column_name, calculation_method ('mode', 'mean', 'median'),
                interpolation_source ('neighbor-rows', 'containing-nodes', 'containing-groups')}
            query_columnset_id (str, int): query columnset ID. If not specified all columns will be used. Only
                applies when query_source_id is specified, otherwise ignored.
            strategy (str): strategy. Either 'fast' or 'high_precision'. Default='fast'

        Returns:
            Results (dict) : A list in the following format:

            ..code-block::

                [
                    {
                        <row_id> : # ID of point predicted
                        # List of IDs of nearest neighboring points
                        <closest_row_ids> : []
                        # Data of points corresponding to closest_row_ids
                        <closest_rows_values> : [[],[],..]
                        # List of nodes that contain nearest neighbors
                        <containing_nodes> : []
                        <containing_groups> : [
                            # List of groups that contain the nodes
                            # in containing_nodes
                            {
                                <group_id>: # ID of group
                                # Percentage of neighboring points
                                # that fall in this group
                                <probability>:
                            }
                        ]
                        # List of dicts pertaining to predicted results
                        # for specified columns
                        <predicted_columns> : [
                            {
                                <column_id> : # ID of column being predicted
                                <predicted_values> : [] # Predicted value
                                # Standard deviation of column values for
                                # neighbors used in prediction
                                # (when applicable)
                                <std_deviation> :
                                # Number of neighbors that have the same value
                                # as the predicted value (when applicable)
                                <prediction_prevalence> :
                                <status> : string # Status message
                            }
                            {
                                <column_id> :
                                ...
                            }
                        ]
                    }
                    {
                        <row_id> :
                        ...
                    }
                ]

        :Example:

        >>> network = extraglobs['network'] #ignore-in-doc
        >>> raw_data = [[0.81, 80, 356, 124], [0.95, 97, 289, 117]]
        >>> col_predict = [{'column_id':0, 'calculation_method':'mean'}]
        >>> neighbors = 10
        >>> predictions = \
            network.topological_predict(data_point_array=
        ...                             raw_data,
        ...                             predict_columns=col_predict,
        ...                             neighbors_count=neighbors)
        >>> output = []
        >>> for prediction in predictions:
        ...     output.append(prediction['predicted_columns'
        ...                              ][0]['predicted_values'][0])
        >>> output
        [43.6, 28.3]
        >>> src = extraglobs['src'] # ignore-in-doc
        '''
        result = self.iter_topological_predict(data_point_group_id,
                                               data_point_array,
                                               data_point_row_ids,
                                               search_in_groupset_ids,
                                               search_in_group_ids,
                                               neighbors_count,
                                               max_neighbors_count,
                                               return_closest_rows,
                                               return_closest_rows_column_set_id,
                                               return_containing_nodes,
                                               return_containing_groups,
                                               selection_criteria,
                                               predict_columns,
                                               query_source_id,
                                               query_columnset_id,
                                               strategy,
                                               **kwargs)
        return list(result)

    ###############################
    # Topological Predict function #
    ###############################
    def iter_topological_predict(self, data_point_group_id=None,
                                 data_point_array=None,
                                 data_point_row_ids=None,
                                 search_in_groupset_ids=None,
                                 search_in_group_ids=None,
                                 neighbors_count=None,
                                 max_neighbors_count=None,
                                 return_closest_rows=False,
                                 return_closest_rows_column_set_id=None,
                                 return_containing_nodes=False,
                                 return_containing_groups=False,
                                 selection_criteria='ALL',
                                 predict_columns=None,
                                 query_source_id=None,
                                 query_columnset_id=None,
                                 strategy='FAST',
                                 **kwargs):
        '''Predict point neighborhood and/or values iteratively

        .. note::
            For more information check out
            `Topological Prediction with the Ayasdi SDK
            <https://ayasdicommunity.force.com/s/article/ka00P0000009I9zQAE/Topological-Prediction>`__

            This function is not supported for networks created using affine metrics.

        Args:
            data_point_group_id (int) : group_id for the query data
            data_point_array ([str]) : list of lists of feature values, where each list represents one point
            data_point_row_ids (str) : Ids of points in current source to be predicted
            search_in_groupset_ids ([str]) : list of IDs of groupsets within which to search for neighbors. Required for
                search_in_group_ids. (optional)
            search_in_group_ids ([str]) : list of IDs of groups within which to search for neighbors. Required for
                search_in_groupset_ids. (optional)
            neighbors_count (int) : number of qualified inputs required for prediction
            max_neighbors_count (int) : maximum number of neighbors inquire when looking for qualified neighbors
            query_source_id (str, int) : query source ID; if not specified, will use network's source. (Note:
                If specified, data_point_group_id or data_point_row_ids should pertain to the query source ID.)
            return_closest_rows (bool) : specifies whether to return the row IDs of closest neighbors. Default=False
            return_closest_rows_column_set_id (str) : ID of column set to use when returning closest neighbors
            return_containing_nodes (bool) : specifies whether to return all nodes that contain nearest neighbors
                Default=False
            return_containing_groups (bool) : specifies whether to return all groups that contain nearest neighbors.
                Default=False
            selection_criteria (str) : if there is a desire to predict within groups, specifies how to select the group.
                Valid criteria are 'all', 'centrality', 'biggest', 'smallest', 'mode'
            predict_columns (list) : list of {column_id or column_name, calculation_method ('mode', 'mean', 'median'),
                interpolation_source ('neighbor-rows', 'containing-nodes', 'containing-groups')}
            query_columnset_id (str, int): query columnset ID. If not specified all columns will be used. Only
                applies when query_source_id is specified, otherwise ignored.
            strategy (str): strategy. Either 'fast' or 'high_precision'. Default='fast'

        Returns:
            Generator that iterates over Topological Prediction results.
            Each prediction is in the following format

            ..code-block::


                {
                    <row_id> : # ID of point predicted
                    # List of IDs of nearest neighboring points
                    <closest_row_ids> : []
                    # Data of points corresponding to closest_row_ids
                    <closest_rows_values> : [[],[],..]
                    # List of nodes that contain nearest neighbors
                    <containing_nodes> : []
                    <containing_groups> : [
                        # List of groups that contain the nodes
                        # in containing_nodes
                        {
                            <group_id>: # ID of group
                            # Percentage of neighboring points
                            # that fall in this group
                            <probability>:
                        }
                    ]
                    # List of dicts pertaining to predicted results
                    # for specified columns
                    <predicted_columns> : [
                        {
                            <column_id> : # ID of column being predicted
                            <predicted_values> : [] # Predicted value
                            # Standard deviation of column values for
                            # neighbors used in prediction
                            # (when applicable)
                            <std_deviation> :
                            # Number of neighbors that have the same value
                            # as the predicted value (when applicable)
                            <prediction_prevalence> :
                            <status> : string # Status message
                        }
                        {
                            <column_id> :
                            ...
                        }
                    ]
                }
                {
                    <row_id> :
                    ...
                }


        :Example:

        >>> network = extraglobs['network'] #ignore-in-doc
        >>> raw_data = [[0.81, 80, 356, 124], [0.95, 97, 289, 117]]
        >>> col_predict = [{'column_id':0, 'calculation_method':'mean'}]
        >>> neighbors = 10
        >>> predictions = \
            network.iter_topological_predict(data_point_array=
        ...                                  raw_data,
        ...                                  predict_columns=col_predict,
        ...                                  neighbors_count=neighbors)
        >>> output = []
        >>> for prediction in predictions:
        ...     output.append(prediction['predicted_columns'
        ...                              ][0]['predicted_values'][0])
        >>> output
        [43.6, 28.3]
        >>> src = extraglobs['src'] # ignore-in-doc
        '''

        if len(kwargs) > 0:
            warnings.warn("Warning: parameter(s) {invalid_params} are not "
                          "used in this method and will cause an exception to "
                          "be thrown in the next release of the Ayasdi SDK. "
                          "Please remove this parameter to continue using "
                          "this method.".format(invalid_params=list(kwargs.keys())))

        source_count = 0
        predict_params = {'search_in_groupset_ids': search_in_groupset_ids,
                          'search_in_group_ids': search_in_group_ids,
                          'neighbors_count': neighbors_count,
                          'max_neighbors_count': max_neighbors_count,
                          'return_closest_rows': return_closest_rows,
                          'return_closest_rows_column_set_id':
                              return_closest_rows_column_set_id,
                          'return_containing_nodes': return_containing_nodes,
                          'return_containing_groups': return_containing_groups,
                          'selection_criteria': selection_criteria,
                          'predict_columns': predict_columns,
                          'algorithm': strategy}
        if query_source_id is not None:
            predict_params['query_source_id'] = str(query_source_id)
        if query_columnset_id is not None:
            predict_params['query_columnset_id'] = str(query_columnset_id)

        predict_params = {k: v for k, v in list(predict_params.items()) if
                          v is not None}

        if data_point_group_id is not None:
            try:
                int(data_point_group_id)
            except ValueError:
                return self.__error__('data_point_group_ids is not an int.')
            predict_params['data_point_group_id'] = data_point_group_id
            source_count += 1

        if data_point_array is not None:
            if not isinstance(data_point_array, list):
                return self.__error__('data_point_array is not a list '
                                      'of lists.')
            for v2 in data_point_array:
                if not isinstance(v2, list):
                    return self.__error__('data_point_array[n] is not a list.')
            predict_params['data_point_array'] = data_point_array
            source_count += 1

        if data_point_row_ids is not None:
            if not isinstance(data_point_row_ids, list):
                return self.__error__('data_point_row_ids is not a list.')
            predict_params['data_point_row_ids'] = data_point_row_ids
            source_count += 1

        if source_count > 1:
            return self.__error__('Exactly one query source may be specified.')

        if search_in_groupset_ids is not None and not \
                isinstance(search_in_groupset_ids, list):
            return self.__error__('search_in_groupset_ids is not a list.')

        if search_in_group_ids is not None and not isinstance(search_in_group_ids, list):
            return self.__error__('search_in_group_ids is not a list.')

        if neighbors_count is not None and not isinstance(neighbors_count, int):
            return self.__error__('neighbors_count is not an int.')

        if max_neighbors_count is not None and not isinstance(max_neighbors_count, int):
            return self.__error__('max_neighbors_count is not an int.')

        if return_closest_rows is not None and not isinstance(return_closest_rows, bool):
            return self.__error__('return_closest_rows is not a bool.')

        if return_containing_nodes is not None and not \
                isinstance(return_containing_nodes, bool):
            return self.__error__('return_containing_nodes is not a bool.')

        if return_containing_groups is not None and \
           not isinstance(return_containing_groups, bool):
            return self.__error__('return_containing_groups is not a bool.')

        if return_containing_groups:
            if search_in_groupset_ids is None and search_in_group_ids is None:
                return self.__error__('Provide either \"search_in_groupset_ids\" or \"search_in_group_ids\"'
                                      ' when requesting containing groups (\"return_containing_groups\" is True).')

        if predict_columns is not None:
            if not isinstance(predict_columns, list):
                return self.__error__('predict_columns is not a list.')
            for v2 in predict_columns:
                if not isinstance(v2, dict):
                    return self.__error__('predict_columns is not a list of dicts.')

                predict_column_fields = {'column_id', 'column_name', 'calculation_method', 'interpolation_source'}
                unknown_fields = set(v2.keys()) - predict_column_fields
                if unknown_fields:
                    return self.__error__('predict_columns contains unknown fields: ' + grammar_join(unknown_fields) +
                                          '. Verify that all names are provided as following: ' +
                                          grammar_join(predict_column_fields, 'or') + '.')

                v3_column_name = v2.get('column_name', None)
                v3_column_id = v2.get('column_id', None)

                if v3_column_name is None and v3_column_id is None:
                    return self.__error__('one of column_name or column_id in predict_columns is required.')

                if v3_column_id and not isinstance(v3_column_id, int):
                    return self.__error__('predict_columns.column_id is not integer.')

        sample_size = kwargs.get('sample_size', None)  # Secret argument
        predict_params['sample_size'] = sample_size
        n_iterations = kwargs.get('n_iterations', None)
        predict_params['n_iterations'] = n_iterations
        random_seed = kwargs.get('random_seed', None)  # Secret argument
        predict_params['random_seed'] = random_seed

        result = json_funcs._iter_post_(self.connection.session,
                                        self.curl + '/topological_predict/stream',
                                        predict_params)

        return result

    ######################################
    # Deploy Topological Predict service #
    ######################################
    def deploy_topological_predict_service(self,
                                           search_in_groupset_ids=None,
                                           search_in_group_ids=None,
                                           neighbors_count=None,
                                           max_neighbors_count=None,
                                           selection_criteria='ALL',
                                           predict_columns=None,
                                           strategy='FAST',
                                           **kwargs):
        """
        Deploys a topological prediction service

        Args:
            search_in_groupset_ids ([str]) : list of IDs of groupsets within which to search for neighbors. Required for
                search_in_group_ids. (optional)
            search_in_group_ids ([str]) : list of IDs of groups within which to search for neighbors. Required for
                search_in_groupset_ids. (optional)
            neighbors_count (int) : number of qualified inputs required for prediction
            max_neighbors_count (int) : maximum number of neighbors inquire when looking for qualified neighbors
            selection_criteria (str) : if there is a desire to predict within groups, specifies how to select the group.
                Valid criteria are 'all', 'centrality', 'biggest', 'smallest', 'mode'
            predict_columns (list) : list of {column_id or column_name, calculation_method ('mode', 'mean', 'median'),
                interpolation_source ('neighbor-rows', 'containing-nodes', 'containing-groups')}
            strategy (str): strategy. Either 'fast' or 'high_precision'. Default='high_precision'

        Returns:
            URL of the deployed topological predict service

        :Example:

        >>> network = extraglobs['network'] #ignore-in-doc
        >>> col_predict = [{'column_id':0, 'calculation_method':'mean'}]
        >>> neighbors = 10
        >>> #network.deploy_topological_predict_service(predict_columns=col_predict, neighbors_count=neighbors)
        """

        if len(kwargs) > 0:
            warnings.warn("Warning: parameter(s) {invalid_params} are not "
                          "used in this method and will cause an exception to "
                          "be thrown in the next release of the Ayasdi SDK. "
                          "Please remove this parameter to continue using "
                          "this method.".format(invalid_params=list(kwargs.keys())))

        predict_params = {'search_in_groupset_ids': search_in_groupset_ids,
                          'search_in_group_ids': search_in_group_ids,
                          'neighbors_count': neighbors_count,
                          'max_neighbors_count': max_neighbors_count,
                          'selection_criteria': selection_criteria,
                          'predict_columns': predict_columns,
                          'algorithm': strategy}

        predict_params = {k: v for k, v in list(predict_params.items()) if
                          v is not None}

        if search_in_groupset_ids is not None and not \
                isinstance(search_in_groupset_ids, list):
            return self.__error__('search_in_groupset_ids is not a list.')

        if search_in_group_ids is not None and not isinstance(search_in_group_ids, list):
            return self.__error__('search_in_group_ids is not a list.')

        if neighbors_count is not None and not isinstance(neighbors_count, int):
            return self.__error__('neighbors_count is not an int.')

        if max_neighbors_count is not None and not isinstance(max_neighbors_count, int):
            return self.__error__('max_neighbors_count is not an int.')

        if predict_columns is not None:
            if not isinstance(predict_columns, list):
                return self.__error__('predict_columns is not a list.')
            for v2 in predict_columns:
                if not isinstance(v2, dict):
                    return self.__error__('predict_columns is not a list of dicts.')

                predict_column_fields = {'column_id', 'column_name', 'calculation_method', 'interpolation_source'}
                unknown_fields = set(v2.keys()) - predict_column_fields
                if unknown_fields:
                    return self.__error__('predict_columns contains unknown fields: ' + grammar_join(unknown_fields) +
                                          '. Verify that all names are provided as following: ' +
                                          grammar_join(predict_column_fields, 'or') + '.')

                v3_column_name = v2.get('column_name', None)
                v3_column_id = v2.get('column_id', None)

                if v3_column_name is None and v3_column_id is None:
                    return self.__error__('one of column_name or column_id in predict_columns is required.')

                if v3_column_id and not isinstance(v3_column_id, int):
                    return self.__error__('predict_columns.column_id is not integer.')

        sample_size = kwargs.get('sample_size', None)  # Secret argument
        predict_params['sample_size'] = sample_size
        random_seed = kwargs.get('random_seed', None)  # Secret argument
        predict_params['random_seed'] = random_seed

        result = json_funcs._post_(self.connection.session,
                                   self.curl + '/topological_predict/deploy',
                                   predict_params)

        return result['url']

    def undeploy_topo_predict_service(self):
        """
        Stops a deployed topological predict service

        Args:
            None

        Returns:
            None

        :Example:
        >>> network = extraglobs['network'] #ignore-in-doc
        >>> network.undeploy_topo_predict_service()
        """
        json_funcs._delete_(self.connection.session,
                            self.curl + '/topological_predict/undeploy/' + self.id)
        return None

    def compute_score(self, outcome_spec=None):
        """
        Scores the network with the scoring algorithm used in OutcomeAutoAnalysis to determine
        optimal lens parameters. This is the score stored in network.scores() with type "OUTCOME".
        The score will have a value in most cases within the range [0,1], with 1 being a perfect score.
        Negative scores could be possible, but they are indication of particularly poor networks.
        See example of usage in the tutorial.

        Args:
            outcome_spec: an :class:`OutcomeSpec <ayasdi.core.outcome_spec.OutcomeSpec>` object

        Returns:
            A :class:`Score <ayasdi.core.score.Score>` object

        :Example:
        >>> from ayasdi.core import OutcomeSpec
        >>> network = extraglobs['network'] #ignore-in-doc
        >>> outcome_spec = OutcomeSpec(outcome_column_name="clinical classification")
        >>> score = network.compute_score(outcome_spec=outcome_spec).score
        >>> score
        0.712...
        """
        params_dict = dict()
        if outcome_spec is not None:
            index = self.source._get_outcome_column_index(
                outcome_spec['outcome_column_name'],
                outcome_spec['outcome_column_index'])
            outcome_spec['outcome_column_index'] = index
            params_dict['outcome_spec'] = outcome_spec.serialize()

        result = json_funcs._post_(self.connection.session, self.curl + '/score', params_dict)['score']
        score = Score(**result)
        # Explicitly sync the scores field in the Network object by adding the newly calculated score
        if score.id not in [s.id for s in self.scores]:
            self.scores.append(score)
        return score

    def score_groups(self, algorithm, normalize_method='arithmetic', group_ids=None, group_set_id=None,
                     outcome_column_index=None, refresh=False):
        """
        Compute the scores of clustering metrics to a list of groups or a group set

        .. note::
            Supported clustering metric algorithms are "adjustedRandScore",
            "mutualInformationScore", "AdjustedmutualInformationScore",
            "normalizedMutualInformationScore", "silhouetteScore", "calinskiharabaSzscore".

        Args:
            algorithms (str): clustering metric algorithm. Supported clustering metric
                              algorithms are "adjusted_rand_score", "mutual_information_score",
                              "adjusted_mutual_information_score", "normalized_mutual_information_score",
                              "silhouette_score", "calinski_harabasz_score".
            normalize_method (str): Average method for algorithms, "adjusted_mutual_information_score",
                                  "normalized_mutual_information_score". The supported methods are
                                  "min", "max", "geometric", "arithmetic", default = 'arithmetic'.
                                  (optional)
            group_ids ([str]): list of group ids. (Optional with group_set_id)
            group_set_id (str): list of group ids. (Optional with group_ids)
            outcome_column_index (int): ground truth column id. (optional)
            refresh (bool): force to compute the score again, default = False. (optional)

        Returns:
            double value of the score.

        >>> import ayasdi.core as ac
        >>> src = extraglobs['src'] #ignore-in-doc
        >>> network = extraglobs['network'] #ignore-in-doc
        >>> group1 = src.create_group(name='a', row_indices=[0, 1, 2])
        >>> group2 = src.create_group(name='b', row_indices=[3, 4, 5, 6])
        >>> group3 = src.create_group(name='c', row_indices=[7, 8, 9])
        >>> group_ids = [group1['id'], group2['id'], group3['id']]
        >>> score = network.score_groups(algorithm='silhouette_score',
        ...                              group_ids=group_ids)
        >>> print(score)
        -0.1610639388059965
        """

        return self.file_source.score_groups(algorithm, self.metric, normalize_method, group_ids, group_set_id,
                                             self.column_set_id, outcome_column_index, refresh)

    def compare_to(self, network_id, degree=None):
        """
        Compute the jaccard similarity of two networks self and the one represented by network_id. The two networks have
        to be created on the same source file and same point set. The jaccard similarity indicates how similar the
        neighbor points of each point are in the two graphs.

        Args:
            network_id (str): The ID of the network to compare with self.
            degree (int): the level of the neighbor nodes to search. degree 0 means a node itself only. degree 1 means a
                node itself as well as the neighbor nodes of that node. degree 2 means the degree 1 nodes plus the
                neighbor nodes of degree 1 nodes. Same for degree 3, 4,..., default = 0. (Optional, non negative).

        Returns:
            A dictionary informing the similarity of two graphs as well as the four jacard values : min, max, mean, and
            median, e.g:
            {'similarity': 0.25, 'jaccard_values': {'min': 0, 'max': 1, 'mean': 0.28, 'median': 0.25}}
            All values in the dictionary are in [0, 1] and being closer to 1 means being more similar.

        >>> src = extraglobs['src'] #ignore-in-doc
        >>> network1 = extraglobs['network'] #ignore-in-doc
        >>> network2 = src.create_network('compare_graphs_test',{
        ...        'metric': {'id': 'Norm Correlation'},
        ...        'column_set_id': src.get_column_sets()[0]['id'],
        ...        'lenses': [{'resolution': 30, 'id': 'UMAP lens 1',
        ...                    'equalize': True, 'gain': 3.0},
        ...                   {'resolution': 30, 'id': 'UMAP lens 2',
        ...                   'equalize': True, 'gain': 3.0}]
        ...        }
        ... )
        >>> comparison = network1.compare_to(network_id=network2.id, degree=1)
        >>> expected = {'similarity': 0.18181818181818182, 'jaccard_values':
        ... {'min': 0.0, 'max': 0.8333333333333334, 'mean': 0.2253610227391786, 'median': 0.18181818181818182}}
        >>> expected == comparison
        True
        >>> comparison = network1.compare_to(network_id=network1.id)
        >>> expected = {'similarity': 1.0, 'jaccard_values': {'min': 1.0, 'max': 1.0, 'mean': 1.0, 'median': 1.0}}
        >>> expected == comparison
        True

        """
        params = {'network_id': network_id, 'degree': degree}
        compare = json_funcs._post_(self.connection.session,
                                    self.curl + '/compare_graphs',
                                    params)
        return compare

    def compare_graphs(self, network_id, degree=None):
        """This method does the same as :func:`compare_to` and see :func:`compare_to` for the usage."""
        warnings.warn("Deprecated: use compare_to() instead.")
        return self.compare_to(network_id, degree)
