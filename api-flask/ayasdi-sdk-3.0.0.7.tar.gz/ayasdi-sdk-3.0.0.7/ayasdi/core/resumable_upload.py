#!/usr/bin/env python
"""A library to access the Ayasdi Core API
"""

from __future__ import absolute_import, unicode_literals, division, print_function
import json
import logging
import warnings

from requests_toolbelt import MultipartEncoder

from ayasdi.core import json_funcs
from ayasdi.core import source
from ayasdi.core import async_jobs

from ayasdi._version import __version__  # noqa: F401
from logging import NullHandler

LOGGER = logging.getLogger(__name__)
LOGGER.addHandler(NullHandler())


# prevents warnings.warn from spitting out garbage on the second line.
def warning_on_one_line(message, category, filename, lineno, file=None, line=None):
    return '%s:%s: %s: %s\n' % (filename, lineno, category.__name__, message)


warnings.formatwarning = warning_on_one_line


class ResumableUpload(object):
    """
    An instance of a Resumable Upload class

    **Available ResumableUpload Functions:**

       .. autosummary::
          ResumableUpload.upload
          ResumableUpload.start
          ResumableUpload.finish
          ResumableUpload.get_token
          ResumableUpload.get_source

    Args:
        api (ayasdi.api.Api): an instance of API connection
        filename (string) : filename shown in created source
        allow_duplicate (bool): if True, uploads a source name with a number appended if one with the same name
            exists on the platform. For example, "my_source.txt" becomes "my_source.txt 1". If False, returns the
            existing source on the platform. Default=False
        upload_spec (dict): specification for overriding the column type and data type detect lines.
            column_type_overrides for overriding column types. Legal types can be "string, "double, "long" and
                    "datetime".
            column_type_detect_lines for overriding data type detect lines.
        async\_ (bool): if True, uploads the source asynchronously. Default=False

    Returns:
        The Job object
    """
    def __init__(self, api, filename, upload_token=None, upload_spec=None,
                 check_duplicate=True, allow_duplicate=False, metadata=None, async_=False):

        self.api = api
        self.filename = filename
        self.upload_spec = upload_spec
        self.check_duplicate = check_duplicate
        self.allow_duplicate = allow_duplicate
        self.source_object = None
        self.token = upload_token
        self.finished = False
        self.metadata = metadata
        self.async_ = async_

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.finish()

    def upload(self, data):
        """Resumable Upload data with token already got

        Args:
            data (data same as in requests post function): data to be post to server

        Returns:

        """
        if self.finished:
            raise RuntimeError("Cannot upload data after the resumable upload is finished.")

        if self.source_object is None and self.token is not None:
            self.token = self._continue_resumable_upload_source(self.token, data)

    def start(self):
        """
        Start a Resumable Upload, obtain a token with upload ID, and save it for future upload.

        Args:
            filename (str) : filename in source

        Returns:
            upload_token (dict) : Token to be used for resumable upload
                e.g. {"fileName":"diabetes.txt",
                "expireTime":"2017-12-01 19:38:25.426 Z",
                "uploadId":"97d430b9-f17c-4b5c-8741-09f0ef6fbdbd"}
            source (:class:`ayasdi.core.source.Source`) :
                The source object corresponding to the uploaded file.

        """
        if self.token is None:
            self.token, self.source_object = self._start_resumable_upload_source(
                self.filename, self.check_duplicate, self.allow_duplicate,
                upload_spec=self.upload_spec, metadata=self.metadata)

    def finish(self):
        """Finish resumable Uploading and create source from uploaded data

        Args:

        Returns:
            source (:class:`ayasdi.core.source.Source`) :
                The source object corresponding to the uploaded file.

        """
        if self.source_object is None and self.token is not None:
            self.source_object = self._finish_resumable_upload_source(self.token)
        self.finished = True
        return self.source_object

    def get_token(self):
        """
        Get obtained resumable upload token
        """
        return self.token

    def get_source(self):
        """
        Get the created source
        """
        return self.source_object

    def _start_resumable_upload_source(self, filename, check_duplicate=True,
                                       allow_duplicate=False, upload_spec=None, metadata=None):
        """
        Start an Resumable Upload and obtain a token with upload Id to be used for future upload.

        Args:
            filename (str) : filename in source
            upload_spec (dict): specification for overriding the column type and data type detect lines.
                column_type_overrides for overriding column types. Legal types can be "string, "double, "long" and
                    "datetime".
                column_type_detect_lines for overriding data type detect lines.
            allow_duplicate (bool): if True, uploads a source name with a number attached if one with the same name
                exists on the platform. For example, "my_source.txt" becomes "my_source.txt 1". If False, returns the
                existing source on the platform. Default=False
            metadata (dict): optional user defined metadata. Allows only simple key,value pairs in the dictionary.
                Default is None.
                For example, can add metadata={'key':'value'}.
        """
        if filename is None:
            raise ValueError("filename cannot be None.")

        on_duplicate = 'error'

        if check_duplicate or allow_duplicate:
            file_uploaded, source_objects = self.api._check_file_uploaded(filename)
            if file_uploaded:
                if not allow_duplicate:
                    if len(source_objects) > 1:
                        LOGGER.warning("Multiple sources with the same name found. To retrieve a " +
                                       "list of all sources with this name, use the get_sources() " +
                                       "function and specify the name as a function argument.")
                    src = source_objects[0]
                    src.sync()
                    return (None, src)
                else:
                    on_duplicate = 'create_with_new_name'

        url = self.api.CORE_REQUEST_STUB + 'sources/upload'

        if upload_spec is None:
            m = MultipartEncoder([('name', filename),
                                  ('allow_duplicate', str(allow_duplicate)),
                                  ('on_duplicate', on_duplicate),
                                  ('metadata', str(metadata))])
        else:
            m = MultipartEncoder([('name', filename),
                                  ('on_duplicate', on_duplicate),
                                  ('allow_duplicate', str(allow_duplicate)),
                                  ('uploadSpec', json.dumps(upload_spec)),
                                  ('metadata', str(metadata))])

        token_dict = json_funcs._post_(self.api.session,
                                       url, m,
                                       content_type=m.content_type)
        return (token_dict, None)

    def _continue_resumable_upload_source(self, upload_token, data):
        """Resumable Upload a new file or return a previously uploaded filesource.

        Args:
            upload_token (dict): Token to be used for resumable upload
                e.g. {"fileName":"diabetes.txt",
                "expireTime":"2017-12-01 19:38:25.426 Z",
                "uploadId":"97d430b9-f17c-4b5c-8741-09f0ef6fbdbd"}
            data (data same as in requests post function): data to be post to server

        Returns:
            upload_token (dict): Renewed token to be used for next resumable upload
                e.g. {"fileName":"diabetes.txt",
                "expireTime":"2017-12-01 19:38:25.426 Z",
                "uploadId":"97d430b9-f17c-4b5c-8741-09f0ef6fbdbd"}


        """
        if upload_token is None:
            raise ValueError("Upload token cannot be None.")

        url = self.api.CORE_REQUEST_STUB + 'sources/upload/{upload_id}'.format(
            upload_id=upload_token['uploadId'])
        token_dict = json_funcs._post_(self.api.session, url, data, content_type='application/octet-stream')
        return token_dict

    def _finish_resumable_upload_source(self, upload_token):
        """Finish resumable Uploading and create source from uploaded data

        Args:
            upload_token (dict): Token to be used for resumable upload
                e.g. {"fileName":"diabetes.txt",
                "expireTime":"2017-12-01 19:38:25.426 Z",
                "uploadId":"97d430b9-f17c-4b5c-8741-09f0ef6fbdbd"}

        Returns:
            source (:class:`ayasdi.core.source.Source`) :
                The source object corresponding to the uploaded file.

        """
        if upload_token is None:
            raise ValueError('Upload token cannot be None.')

        if self.async_:
            url = self.api.CORE_REQUEST_STUB + 'sources/upload/{upload_id}/async'.format(
                upload_id=upload_token['uploadId'])
            async_task = json_funcs._post_(self.api.session, url, None)

            get_async_job_url = self.api.CORE_REQUEST_STUB + 'sources/async'
            upload_source_job = async_jobs.AsyncJob(self.api, async_task, get_async_job_url)
            upload_source_job.sync()
            src_dict = upload_source_job.result
        else:
            url = self.api.CORE_REQUEST_STUB + 'sources/upload/{upload_id}?status=finish'.format(
                upload_id=upload_token['uploadId'])
            src_dict = json_funcs._post_(self.api.session, url, None,
                                         content_type='application/octet-stream')

        source_object = source.Source(self.api, src_dict)
        source_object.sync()
        return source_object
