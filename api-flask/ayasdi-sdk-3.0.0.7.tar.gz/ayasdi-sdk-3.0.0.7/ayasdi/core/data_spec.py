#!/usr/bin/env python
"""
Class :class:`DataSpec` defines rectangular data (rows and columns).
Rows must have the same structure. Columns can have different types
including integers, floating point numbers, strings, or datetimes.

.. code:: python

    import ayasdi.core as ac

.. seealso::

    :class:`ayasdi.core.data_point_list.DataPointList`
    :class:`ayasdi.core.source_subset.SourceSubset`

.. autosummary::

  DataSpec
  DataSpec.source_subset
  DataSpec.data_point_list

"""


class DataSpec(object):
    """
    The Class that encapsulates a specification of either a portion of a datasource object to be used,
    or a list of data points specified independent of any source object.

    To instantiate a DataSpec, instantiate one of the two subclasses: :class:`ayasdi.core.source_subset.SourceSubset`
    or :class:`ayasdi.core.data_point_list.DataPointList`.

    The ``SourceSubset`` subclass enables you to specify a combination of source, group, and column_set,
    eliminating the need to specify each of these parameters individually each time a method is
    invoked.

    To instantiate a SourceSubset, specify any combination of this class's three properties:
    source_id, group_id, and/or column_set_id.


    The ``DataPointList`` subclass enables you to specify individual data points (equivalent to a "row"
    in a Source object), in the form of a Python list in which each element corresponds to the value
    for a column in the original Source object of interest.

    To instantiate a DataPointList, specify a list of lists, where each list represents a data point
    without any reference to a Source object.

    **Restrictions**
        - all rows must have the same number of elements
        - supported data types: integers, floats, strings (other types to be added in the future)

    Examples:

.. code:: python

    import ayasdi.core as ac

    source_subset = ac.SourceSubset(source_id=src.id, group_id = group['id'], column_set_id = col_set['id'])

    data_point_list = ac.DataPointList([[1,2,3,4,5], [9,10,11,12,13], [21,22,23,24,25]])

    """

    def __init__(self, source_subset=None, data_point_list=None):
        self._source_subset = source_subset
        self._data_point_list = data_point_list

    @property
    def source_subset(self):
        """
        Data query on a source
        """
        return self._source_subset

    @source_subset.setter
    def source_subset(self, val):
        self._source_subset = val

    @property
    def data_point_list(self):
        """
        Data as a collection of rows
        """
        return self._data_point_list

    @data_point_list.setter
    def data_point_list(self, val):
        self._data_point_list = val

    def serialize(self):
        """
        Converts the instance into a dictionary
        """
        dictionary = {}

        if self.source_subset is not None:
            dictionary.update(self.source_subset.serialize())

        if self.data_point_list is not None:
            dictionary.update(self.data_point_list.serialize())

        return dictionary
