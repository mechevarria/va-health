class TopExplainersFilterSpec(object):
    """
    The :class:`ayasdi.core.top_explainers_filter_spec` class creates a TopExplainersFilterSpec object for use in
    comparisons called by :class:`ayasdi.core.source.Source.get_comparison`. The type of top explainers data
    retrieved depends on the query parameters (fields) specified.

    Args:
        min_ks_score (double, int): filter all continuous explainers whose ks score's absolute value is
            greater than or equal to this score. Legal values range from 0 to 1. Default=0.6 (optional)
        max_p_value (double, int): filter all continuous and categorical explainers whose p value
            or hyper geometric p value is smaller than or equal to this score. Legal values range from 0 to 1.
            Default=0.05 (optional)
        max_number_of_continuous_explainers (int): further limit the continuous explainers to the top
            max_number_of_continous_explainers ones. If not specified, continuous explainers are not limited
            further. (optional)
        max_number_of_categorical_explainers (int): further limit the categorical explainers to the top
            max_number_of_categorical_explainers ones. if not specified, categorical explainers are not limited
            further. (optional)

    :Example:

        >>> import ayasdi.core as ac
        >>>
        >>> src = connection.upload_source('./test/db_test12.txt')
        >>> group1 = src.create_group(name='group1', row_indices=list(range(100)))
        >>> comparison = src.compare_groups('group1')
        >>> top_explainers = src.get_comparison(id=comparison['id'],
        ...                                     top_explainers_filter_spec=TopExplainersFilterSpec())
        >>> connection.delete_source(name=src.name)
    """

    @property
    def min_ks_score(self):
        """
        filter all continuous explainers whose ks scores have an absolute value greater than or equal to
        the min_ks_score
        """
        return getattr(self, '_min_ks_score', None)

    @property
    def max_p_value(self):
        """
        filter all continuous and categorical explainers whose p values or hyper geometric p values are
        less than or equal to the max_p_value
        """
        return getattr(self, '_max_p_value', None)

    @property
    def max_number_of_continuous_explainers(self):
        """
        further limit the continuous explainers returned, to the top max_number_of_continous_explainers
        """
        return getattr(self, '_max_number_of_continuous_explainers', None)

    @property
    def max_number_of_categorical_explainers(self):
        """
        further limit the categorical explainers returned, to the top max_number_of_categorical_explainers
        """
        return getattr(self, '_max_number_of_categorical_explainers', None)

    def __init__(self, min_ks_score=0.6, max_p_value=0.05, max_number_of_continuous_explainers=None,
                 max_number_of_categorical_explainers=None):
        self._min_ks_score = min_ks_score
        self._max_p_value = max_p_value
        self._max_number_of_continuous_explainers = max_number_of_continuous_explainers
        self._max_number_of_categorical_explainers = max_number_of_categorical_explainers
