#!/usr/bin/env python
import json


class Score(object):
    """The Score of a topological network generated either with an ``outcome`` or in an ``unsupervised`` manner.

        Args:
            id (int):            Score identifier
            analysisid (int):    id of the :class:`network <ayasdi.core.networks.Network>` object
            type (str):           Either 'OUTCOME' or 'UNSUPERVISED'
            score (double):       The output score
            params (dict):         If the type is ``OUTCOME``, then a dictionary of the parameters
                  passed to outcome auto analysis, else an empty dictionary.
            created (timestamp):  Timestamp for when the score was created.
        """

    def __init__(self,
                 id=None,
                 analysisid=None,
                 type=None,
                 score=None,
                 params=None,
                 created=None,
                 updated=None):
        self.id = id
        self.analysisid = analysisid
        self.type = type
        self.score = score
        self.params = params
        self.created = created
        self.updated = updated

    def __repr__(self):
        return json.dumps(self.serialize(to_print={'type', 'score', 'params'}))

    def serialize(self, to_print=None):
        return {
            k: self.__dict__[k]
            for k in self.__dict__.keys()
            if not to_print or k in to_print
        }
