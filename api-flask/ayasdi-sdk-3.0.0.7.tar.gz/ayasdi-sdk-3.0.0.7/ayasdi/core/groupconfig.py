#!/usr/bin/env python
"""Module that interacts with the GCUI endpoints.

TODO: Add updates (put endpoints where applicable)
"""
from __future__ import absolute_import, unicode_literals, division, print_function
import logging

from ayasdi.core import json_funcs

LOGGER = logging.getLogger(__name__)


class GroupCentricConnection(object):
    """Main class dealing with the connection object that responds
    to get, create, and delete GCViewConfigs, GroupSets, and Groups.
    Ideally all these functions live in the API/Source class, which will happen
    once we are out of demo mode.
    """
    def __init__(self, api, source_id):
        self.connection = api
        self.source_id = source_id
        self.group_url = self.connection.CORE_REQUEST_STUB + \
            'sources/%s/groups' % source_id
        self.groupset_url = self.connection.CORE_REQUEST_STUB + \
            'sources/%s/group_sets' % source_id
        self.gcviewconfig_url = self.connection.CORE_REQUEST_STUB + \
            'gc_view_configs'

    def __error__(self, msg, with_print=True):
        """Error message to be printed out and returned.
        """
        msg = {'msg': msg}
        if with_print:
            print(msg)
        return msg

    def get_groups(self):
        """Get all groups.
        """
        groups = json_funcs._get_(self.connection.session,
                                  self.group_url)
        return [Group(self, group) for group in groups]

    def get_group(self, id=None, name=None):
        """Get all groups.

        Args:
            id: The id of the requested Group (optional with name).
            name: The name of the requested Group (optional with id).

        :Example:

        See usage in :func:`get_networks`

        """
        groups = self.get_groups()
        selected_group = None
        for group in groups:
            if name is not None and group.name == name:
                selected_group = group.id
            elif id is not None and group.id == id:
                selected_group = group.id
        if selected_group:
            group_json = json_funcs._get_(self.connection.session,
                                          self.group_url + '/' +
                                          selected_group)
            return Group(self, group_json)
        return self.__error__("Group with name '%s' does not exist" % name)

    def delete_group(self, id=None, name=None):
        """Delete the specified group.

        Args:
            id: The id of the requested Group (optional with name).
            name: The name of the requested Group (optional with id).

        :Example:

        See usage in :func:`get_networks`

        """
        groups = self.get_groups()
        selected_group = None
        for group in groups:
            if name is not None and group.name == name:
                selected_group = group.id
            elif id is not None and group.id == id:
                selected_group = group.id
        if selected_group:
            json_funcs._delete_(self.connection.session,
                                self.group_url + '/' +
                                selected_group)
            return True
        return self.__error__("Group with name '%s' does not exist" % name)

    def create_group(self, name, row_indices):
        """Creates a group with network/source based information."""

        # TODO: Only considering rownames and row_indices as row_specs for now
        # Add others here.
        post_params = {'name': name,
                       'row_specifications':
                       [{'row_indices': row_indices}]}
        group_stub = json_funcs._post_(self.connection.session,
                                       self.group_url,
                                       post_params)
        return Group(self, group_stub)

    def get_groupsets(self):
        """Get all groups."""

        groupsets = json_funcs._get_(self.connection.session,
                                     self.groupset_url)
        return [GroupSet(self, groupset) for groupset in groupsets]

    def get_groupset(self, id=None, name=None):
        """Get all groups.

        Args:
            id: The id of the requested GroupSet (optional with name).
            name: The name of the requested GroupSet (optional with id).

        :Example:

        See usage in :func:`get_networks`

        """
        groupsets = self.get_groupsets()
        selected_groupset = None
        for groupset in groupsets:
            if name is not None and groupset.name == name:
                selected_groupset = groupset.id
            elif id is not None and groupset.id == id:
                selected_groupset = groupset.id
        if selected_groupset:
            groupset_json = json_funcs._get_(self.connection.session,
                                             self.groupset_url + '/' +
                                             selected_groupset)
            return GroupSet(self, groupset_json)
        return self.__error__("Groupset with name '%s' does not exist" %
                              name)

    def delete_groupset(self, id=None, name=None):
        """Delete the specified group.

        Args:
            id: The id of the requested Group (optional with name).
            name: The name of the requested Group (optional with id).

        :Example:

        See usage in :func:`get_networks`

        """
        groupsets = self.get_groupsets()
        selected_groupset = None
        for groupset in groupsets:
            if name is not None and groupset.name == name:
                selected_groupset = groupset.id
            elif id is not None and groupset.id == id:
                selected_groupset = groupset.id
        if selected_groupset:
            json_funcs._delete_(self.connection.session,
                                self.groupset_url + '/' +
                                selected_groupset)
            return True
        return self.__error__("Groupset with name '%s' does not exist" %
                              name)

    def get_gcviewconfigs(self):
        """Get all groups."""

        gcviewconfigs = json_funcs._get_(self.connection.session,
                                         self.gcviewconfig_url)
        return [GCViewConfig(self, gcviewconfig)
                for gcviewconfig in gcviewconfigs]

    def get_gcviewconfig(self, id=None, name=None):
        """Get all groups.

        Args:
            id: The id of the requested Gcviewconfig (optional with name).
            name: The name of the requested Gcviewconfig (optional with id).

        :Example:

        See usage in :func:`get_networks`

        """
        gcviewconfigs = self.get_gcviewconfigs()
        selected_gcviewconfig = None
        for gcviewconfig in gcviewconfigs:
            if name is not None and gcviewconfig.name == name:
                selected_gcviewconfig = gcviewconfig.id
            elif id is not None and gcviewconfig.id == id:
                selected_gcviewconfig = gcviewconfig.id
        if selected_gcviewconfig:
            gcviewconfig_json = json_funcs._get_(self.connection.session,
                                                 self.gcviewconfig_url + '/' +
                                                 selected_gcviewconfig)
            return GCViewConfig(self, gcviewconfig_json)
        return self.__error__("Gcviewconfig with name '%s' does not exist" %
                              name)

    def delete_gcviewconfig(self, id=None, name=None):
        """Delete the specified group.

        Args:
            id: The id of the requested Group (optional with name).
            name: The name of the requested Group (optional with id).

        :Example:

        See usage in :func:`get_networks`

        """
        gcviewconfigs = self.get_gcviewconfigs()
        selected_gcviewconfig = None
        for gcviewconfig in gcviewconfigs:
            if name is not None and gcviewconfig.name == name:
                selected_gcviewconfig = gcviewconfig.id
            elif id is not None and gcviewconfig.id == id:
                selected_gcviewconfig = gcviewconfig.id
        if selected_gcviewconfig:
            json_funcs._delete_(self.connection.session,
                                self.gcviewconfig_url + '/' +
                                selected_gcviewconfig)
            return True
        return self.__error__("GCViewConfig with name '%s' does not exist" %
                              name)

    def create_gcviewconfig(self, kwargs):
        """Creates a group with network/source based information."""

        # TODO: Only considering rownames and row_indices as row_specs for now
        # Add others here.
        gcviewconfig_stub = json_funcs._post_(self.connection.session,
                                              self.gcviewconfig_url,
                                              kwargs)
        return GCViewConfig(self, gcviewconfig_stub)


class Group(object):
    def __init__(self, gc_connection, group_info):
        self.json = group_info
        self.gc_connection = gc_connection
        self.connection = self.gc_connection.connection
        self.source_id = self.gc_connection.source_id
        for key, value in group_info.items():
            setattr(self, key, value)
        self.curl = '%s/%s' % (self.gc_connection.group_url,
                               self.id)

    def __repr__(self):
        return '<Group name:%s id:%s>' % (self.name, self.id)

    def sync(self):
        ret_group = json_funcs._get_(self.connection.session, self.curl)
        for key, value in ret_group.items():
            setattr(self, key, value)
        self.json = ret_group


class GroupSet(object):
    def __init__(self, gc_connection, groupset_info):
        self.json = groupset_info
        self.gc_connection = gc_connection
        self.connection = self.gc_connection.connection
        self.source_id = self.gc_connection.source_id
        for key, value in groupset_info.items():
            setattr(self, key, value)
        self.curl = '%s/%s' % (self.gc_connection.groupset_url,
                               self.id)

    def __getitem__(self, key):
        return self.__dict__[key]

    def __repr__(self):
        return '<GroupSet name:%s id:%s>' % (self.name, self.id)

    def sync(self):
        ret_groupset = json_funcs._get_(self.connection.session, self.curl)
        for key, value in ret_groupset.items():
            setattr(self, key, value)
        self.json = ret_groupset


class GCViewConfig(object):
    def __init__(self, gc_connection, gcviewconfig_info):
        self.json = gcviewconfig_info
        self.gc_connection = gc_connection
        self.connection = self.gc_connection.connection
        self.source_id = self.gc_connection.source_id
        for key, value in gcviewconfig_info.items():
            setattr(self, key, value)
        self.curl = '%s/%s' % (self.gc_connection.gcviewconfig_url,
                               self.id)

    def __repr__(self):
        return '<Gcviewconfig name:%s id:%s>' % (self.name, self.id)

    def sync(self):
        ret_gcviewconfig = json_funcs._get_(self.connection.session, self.curl)
        for key, value in ret_gcviewconfig.items():
            setattr(self, key, value)
        self.json = ret_gcviewconfig
