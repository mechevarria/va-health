#!/usr/bin/env python
from __future__ import absolute_import, unicode_literals, division, print_function
import logging

from ayasdi.care import carepath

LOGGER = logging.getLogger(__name__)


class Patient(object):
    def __init__(self, parent, patient_info):
        """Initializing a patient object

        :param parent:
        :param patient_info:
        :return:
        """
        self.json = patient_info
        self.parent = parent
        for key, value in patient_info.items():
            if key == "events":
                self.events = [carepath.Event(i) for i in value]
            else:
                setattr(self, key, value)

    def __repr__(self):
        return "<Patient id %s: encounter id: %s>" % (
            self.patient_id, self.encounter_id)

    def export(self, format='csv'):
        pass
