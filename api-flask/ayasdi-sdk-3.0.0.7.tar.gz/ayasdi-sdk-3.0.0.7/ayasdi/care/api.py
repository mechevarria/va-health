#!/usr/bin/env python
"""A library to access the Ayasdi Core API
"""
from __future__ import absolute_import, unicode_literals, division, print_function
import logging

from requests.exceptions import SSLError

from ayasdi.care import creds
from ayasdi.care import json_funcs
from ayasdi.care import procedure
from ayasdi.care import user
from ayasdi.session import Session

LOGGER = logging.getLogger(__name__)


class Api(object):
    """Instantiate a new connection.

    .. note::
        Here is a listing of available functions in the Api class.

        .. autosummary::
           Api
           Api.get_procedures
           Api.get_cookie_dict
           Api.get_cookie_domains

    Args:

     username (str) : Your Ayasdi Core username
     password (str) :  Your Ayasdi Core password
     save_password (bool) : If set to True, then the user entered
        username and password are saved in the keyring
     cookie_dict (dict) : Cookie dictionary used for single sign-on login
     cookie_domain (string) : Cookie domain string meant
        for single sign-on login
     session (ayasdi.session.Session): An optional session object

    Returns:

     Api connection (:class:`Api`) :  The Api connection

    :Example:

    >>> connection = Api(url, username, password) # doctest: +SKIP

    """

    def __init__(self, url="https://workbench.ayasdi.com",
                 username=None, password=None, save_password=False,
                 cookie_dict=None, cookie_domain="", session=None,
                 verify=True, trace_id=None):
        '''Instantiate a new ayasdi.core.Api connection.

        #TODO:Replace with core.api.py init. Maybe change the CARE_LOGIN_STUB
        '''
        self.target_url = url
        if session is None:
            self.session = Session()
            self.session.verify = verify
        else:
            self.session = session
        if trace_id is not None:
            self.session.trace_id = trace_id

        if not self.target_url.strip():
            raise Exception("Blank URL cannot be accessed.")
        if not self.target_url.endswith('/'):
            self.target_url += "/"
        self.care_request_url = "%sv0/care/" % self.target_url
        self.password = None
        self.is_connected = False

        if not cookie_dict:
            # If username is given, check creds for this user's
            #   password on this server.
            # Else check creds for both username and password.
            # If both are given, save the password to be used with cli.
            if not username:
                username, password = creds.get_creds(self.target_url)
            elif not password:
                username, password = creds.get_creds(self.target_url,
                                                     username=username)
            else:
                self.password = password
            self.username = username
            try:
                resp = self.session.post(
                    self.target_url + 'login',
                    data={"username": username,
                          "passphrase": password},
                    headers={'accept': 'application/json'})
            except SSLError as e:
                error_message = "SSLError: %s" % e
                LOGGER.exception(error_message)
                print(error_message)
                self.session.verify = False
                resp = self.session.post(
                    self.target_url + 'login',
                    data={"username": username,
                          "passphrase": password},
                    headers={'accept': 'application/json'})

            # Did login work?
            if resp.status_code not in [200, 204]:
                print("Unable to connect. Status code: %s" % resp.status_code)
            else:
                self.is_connected = True
                if save_password:
                    creds.save_creds(self.target_url, username, password)
        else:
            for name, value in cookie_dict.items():
                self.session.cookies.set(name, value, domain=cookie_domain)
            self.is_connected = True

    def get_last_traceid(self):
        """
        Returns the x-traceid header from the last request to the API server.

        Execute an API call
        >>> p = connection.get_procedures();

        Verify trace id has been set
        >>> isinstance(connection.get_last_traceid(), basestring)
        True

        """
        return self.session.last_traceid

    def get_cookie_dict(self):
        """
        Returns a dict of cookie name-value pairs in the session.

        Returns:
            dict: Dict object containing all the cookie name-value pairs
        """

        return self.session.cookies.get_dict()

    def get_cookie_domains(self):
        """
        Returns a list of all cookie-domains in the session

        Returns:
            A list of all cookie-domain strings
        """

        return self.session.cookies.list_domains()

    def get_procedures(self):
        """Get uploaded procedures.

        Args:

          None

        Returns:

          procedures (list) : A list of :class:`ayasdi.care.procedure.
          Procedure` objects.

        :Example:

        >>> procedures = connection.get_procedures()
        >>> type(procedures[0])
        <class 'ayasdi.care.procedure.Procedure'>
        >>> #Getting source names
        >>> procedure_names = [p.name for p in procedures]
        >>> 'Laparoscopic Cholecystectomy' in procedure_names
        True

        """
        procedures_list = json_funcs._get_(self.session,
                                           self.care_request_url +
                                           'procedures')
        return [procedure.Procedure(self, i) for i in procedures_list]

    def delete_procedures(self, id):
        """
        Delete a procedure by id. It does an implicit bumpup
        :return: none

        """
        json_funcs._delete_(self.session, self.care_request_url +
                            'procedures' + "/" + id)

    def create_procedures(self, id):
        """
        Careate a procedure in care. It does an implicit bumpup
        :return: a procedure pbject

        """
        param_dict = {'source_id': id}
        procedure_json = json_funcs._post_(self.session,
                                           self.care_request_url +
                                           'procedures',
                                           param_dict)
        return procedure.Procedure(self, procedure_json)

    def get_user(self):
        """Get current user.

        Args:
          None

        Returns:
          User: An object of :class:`ayasdi.care.user.User`.

        :Example:

        >>> user = connection.get_user() # doctest: +SKIP
        >>> type(user) # doctest: +SKIP
        <class 'ayasdi.care.user.User'>

        """
        user_json = json_funcs._get_(self.session,
                                     self.target_url +
                                     'v0/users/self')
        return user.User(self, user_json)

    def rollback(self):
        """
        Rollback a bad state in care
        :param self:
        :return: none
        """
        json_funcs._get_(self.session, self.care_request_url + 'rollback')
