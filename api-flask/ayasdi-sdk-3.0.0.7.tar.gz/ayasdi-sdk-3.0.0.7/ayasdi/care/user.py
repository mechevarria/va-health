#!/usr/bin/env python
from __future__ import absolute_import, unicode_literals, division, print_function
import logging
from ayasdi.care import json_funcs

LOGGER = logging.getLogger(__name__)


class User:
    def __init__(self, connection, user_info={}):
        """Initializing a patient object

        :param user_info:
        :return:
            User object
        """

        self.json_keys = set()
        for key, value in user_info.items():
            if key == 'primaryTeam':
                self.activeTeam = value
            else:
                setattr(self, key, value)
            self.json_keys.add(key)

        self.session = connection.session
        self.curl = connection.target_url + 'v0/users/{}'.format(self.id)

    def set_active_team(self, name=None, id=None):
        """ Set a user's own active team. Must be a team in
            the list of the user's teams

        Args:
            id (str): identifier of team. Optional with name.
            name (str): name of active team. Optional with id.

        Returns:
            True if successful
        """

        if not name and not id:
            raise ValueError("Invalid Argument :: please pass "
                             "either id or name")
        elif id:
            for item in self.teams:
                if item['id'] == id:
                    self.activeTeam = item
                    json_funcs._put_(self.session, self.curl, self.json())
                    return True
        elif name:
            for item in self.teams:
                if item['name'] == name:
                    self.activeTeam = item
                    json_funcs._put_(self.session, self.curl, self.json())
                    return True

        raise ValueError("Please provide a valid name or id that "
                         " exists in the list of user's teams: "
                         "{}".format(self.teams))

    def json(self):
        """ Get the dict representation of User that can be
            converted to a JSON string for a POST request

        Returns:
            Python dict of user data
            """

        data = dict()
        for key in self.json_keys:
            if key == 'primaryTeam':
                data[key] = self.activeTeam
            else:
                data[key] = getattr(self, key, None)
        return data
