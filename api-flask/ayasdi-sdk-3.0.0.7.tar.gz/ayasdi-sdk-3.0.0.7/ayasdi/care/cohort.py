#!/usr/bin/env python
from __future__ import absolute_import, unicode_literals, division, print_function
import logging

from ayasdi.care import json_funcs
from ayasdi.care import patient_group

LOGGER = logging.getLogger(__name__)


class Cohort(object):
    """Instance of cohort object, created from Procedure

    :Example:

    >>> procedure = connection.get_procedures()[0]
    >>> cohort = procedure.get_cohort(name='Best')
    >>> extraglobs['cohort'] = cohort #ignore-in-doc
    """

    def __init__(self, parent, cohort_stub):
        """Initializing a cohort

        :param parent:
        :param cohort_stub:
        :return:
        """

        self.treatment_groups = None
        self.cohort_group = None
        self.json = cohort_stub
        self.parent = parent
        self.session = parent.session
        for key, value in cohort_stub.items():
            setattr(self, key, value)
        self.curl = self.parent.care_request_url + \
            'procedures/%s/cohorts/%s' % \
            (parent.id, self.id)

    def __repr__(self):
        return "<Cohort %s: id: %s>" % (self.name, self.id)

    def sync(self):
        """Force refresh the current cohort.

        :params: None
        :returns: None

        :Example:

        >>> cohort = extraglobs['cohort'] #ignore-in-doc
        >>> cohort.sync()
        >>> # treatment groups now exist
        >>> cohort.treatment_groups
        [{u'id': u'9195465693657247385', u'name': u'16 Patients at $2090'}]
        """

        return_cohort = json_funcs._get_(self.session, self.curl)
        for key, value in return_cohort.items():
            if key == "treatment_groups":
                self.treatment_groups = [patient_group.PatientGroup(self, i)
                                         for i in value]
            elif key == "cohort_group":
                self.cohort_group = patient_group.PatientGroup(self, value)
            else:
                setattr(self, key, value)
        self.json = return_cohort

    def compare_to(self, another_cohort):
        """compare cohort against another patient group

        :param another_cohort: cohort object to compare against
        :type another_cohort: :class:`ayasdi.care.cohort.Cohort`
        :returns: comparison
        """
        return self.parent.compare_patient_groups(self, another_cohort)

    def find_treatment_groups(self):
        # TODO: Call out json objects with variable names that reflect this.
        param_dict = {}
        json_funcs._post_(self.session,
                          self.curl + '/find_treatment_groups',
                          param_dict)
        self.sync()
        return self

    def create_treatment_group(self, group_id=None, row_indices=None):
        param_dict = {}
        param_dict['id'] = group_id
        param_dict['indices'] = row_indices
        ret_value = json_funcs._post_(self.session,
                                      self.curl + '/treatment_groups',
                                      param_dict)

        treatment_group = patient_group.PatientGroup(self, ret_value)
        self.sync()
        return treatment_group

    def export_treatment_group(self, format="csv"):
        pass
