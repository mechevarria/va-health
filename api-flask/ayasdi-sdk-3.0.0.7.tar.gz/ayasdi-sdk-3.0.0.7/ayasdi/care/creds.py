# Credentials store
# Lifted shamelessly from
# http://stackoverflow.com/questions/15956952/
# how-do-i-decrypt-using-hashlib-in-python
from __future__ import absolute_import, division, print_function
try:
    import cPickle as pickle
except ImportError:
    import pickle
import getpass
import logging
import os

import keyring

from ayasdi.care import config

LOGGER = logging.getLogger(__name__)


def save_creds(loc, username, password):
    """Save the current credentials to password store.
    """
    save_loc = os.path.join(os.path.expanduser("~"),
                            ".ayasdiapi")
    creds_file = os.path.join(save_loc, "creds")
    try:
        os.mkdir(save_loc)
    except OSError as e:
        LOGGER.exception(e)
        pass
    creds = {}
    try:
        with open(creds_file) as creds_obj:
            creds = pickle.load(creds_obj)
    except IOError as e:
        LOGGER.exception(e)
        pass
    if loc not in creds:
        creds[loc] = {}
    if username not in creds[loc]:
        creds[loc][username] = ''
    with open(creds_file, 'w') as creds_obj:
        pickle.dump(creds, creds_obj)
    keyring.set_password(loc, username, password)


def get_creds(loc, username=None):
    """Given a location, get the username and password.
    """

    def ask_username_pwd():
        username = input("Enter username: ").strip()
        password = getpass.getpass("Enter password: ").strip()
        return username, password

    # Save url and username in ~/.ayasdiapi/creds.
    # If this file doesn't exist create it, else add new location and username
    # with empty password
    save_loc = os.path.join(os.path.expanduser("~"),
                            ".ayasdiapi")
    creds_file = os.path.join(save_loc, "creds")
    creds = None
    while not creds:
        try:
            with open(creds_file) as creds_obj:
                creds = pickle.load(creds_obj)
                creds[loc]
        except (IOError, KeyError) as e:
            LOGGER.exception(e)
            username, _ = ask_username_pwd()
            save_creds(loc, username, _)
            creds = None
    # If username is provided, get the password for that.
    # Else get the first username in ~/.ayasdiapi/creds
    # and return that and its password.
    if not username:
        u, p = list(creds[loc].items())[0]
    else:
        u = username
    p = keyring.get_password(loc, u)
    return u, p


def remove_creds():
    save_loc = os.path.join(os.path.expanduser("~"),
                            ".ayasdiapi")
    creds_file = os.path.join(save_loc, "creds")
    os.remove(creds_file)


if __name__ == "__main__":
    u, p = get_creds(config.Config().CARE_LOGIN_STUB)
