#!/usr/bin/env python
'''A config singleton class that holds the session and
module level information.
There are two advantages to making the config be a singleton class.
First, this makes sure that only a single session is created.
Second, this circumvents passing around the session as arguments.
'''
from __future__ import absolute_import, unicode_literals, division, print_function
import logging

from ayasdi import session

LOGGER = logging.getLogger(__name__)


class Singleton(object):
    '''A singleton class. Copied shamelessly from
    http://stackoverflow.com/questions/6760685/
        creating-a-singleton-in-python.

    '''
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not isinstance(cls._instance, cls):
            cls._instance = object.__new__(cls, *args, **kwargs)
        return cls._instance


class Config(Singleton):
    '''A singleton class that holds the session.

    >>> config1 = Config()
    >>> config2 = Config()
    >>> config1 == config2
    True
    >>> config1.session == config2.session
    True
    '''
    CARE_LOGIN_STUB = None
    CARE_REQUEST_STUB = None
    session = session.Session()
