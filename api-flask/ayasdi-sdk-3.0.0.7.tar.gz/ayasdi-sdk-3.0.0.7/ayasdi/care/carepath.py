#!/usr/bin/env python
from __future__ import absolute_import, unicode_literals, division, print_function
import logging
from ayasdi.care import json_funcs

LOGGER = logging.getLogger(__name__)


class Carepath(object):
    def __init__(self, procedure, carepath_info):
        """Initializing a carepath object

        :param parent:
        :param carepath_info:
        :return:
        """
        self.json = carepath_info
        if 'epochs' not in self.json:
            self.json['epochs'] = []
        if 'predicates' not in self.json:
            self.json['predicates'] = []
        self.__extract__(carepath_info)
        self.procedure = procedure
        self.session = procedure.session
        if 'id' not in self.json:
            self.id = None
        self.curl = self.procedure.curl + '/carepaths/%s' % self.id

    def __repr__(self):
        if self is None:
            return "Carepath null"
        else:
            return "<CarePath %s: code: %s>" % (self.name, self.id)

    def sync(self):
        """Refreshes carepath

        :returns: None
        """
        return_carepath = json_funcs._get_(self.session, self.curl)
        self.__extract__(return_carepath)
        self.json = return_carepath

    def __extract__(self, carepath_info):
        for key, value in carepath_info.items():
            if key == "events":
                self.events = [Event(i) for i in value]
            elif key == "predicates":
                self.predicates = [Predicate(i) for i in value]
            else:
                setattr(self, key, value)

    def __csv__(self, output_file):
        resp = self.session.get(self.curl + '/csv')
        resp.raise_for_status()
        with open(output_file, 'w') as f:
            f.write(resp.text)

    def __pdf__(self, output_pdf):
        resp = self.session.get(self.curl + '/pdf')
        resp.raise_for_status()
        with open(output_pdf, 'wb') as f:
            f.write(resp.content)

    def export(self, output_file, filetype="csv"):
        """Export carepath to file

        :param output_file: name of file to output to
        :type output_file: string
        :param filetype: type of file to export, csv or pdf. defaults to csv
        :type filetype: string

        :returns: None
        """
        if filetype == "csv":
            self.__csv__(output_file)
        elif filetype == "pdf":
            self.__pdf__(output_file)

    def deploy(self):
        """Deploys the carepath"""
        if not self.status == "draft":
            raise Exception("Only draft carepaths can be deployed")
        param_dict = {}
        json_funcs._post_(self.session,
                          self.curl + '/deploy',
                          param_dict)
        self.sync()


class Event(object):
    def __init__(self, event_info):
        self.json = event_info
        for key, value in list(event_info.items()):
            setattr(self, key, value)

    def __repr__(self):
        return "<Event code: %s>" % self.code


class Predicate(object):
    def __init__(self, predicate_info):
        self.json = predicate_info
        for key, value in predicate_info.items():
            setattr(self, key, value)
