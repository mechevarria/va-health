#!/usr/bin/env python
from __future__ import absolute_import, unicode_literals, division, print_function
import logging
import warnings

from ayasdi.care import carepath
from ayasdi.care import cohort
from ayasdi.care import json_funcs
from ayasdi.care import patient
from ayasdi.care import patient_group

from ayasdi.core.utilities.source import subset

LOGGER = logging.getLogger(__name__)


# prevents warnings.warn from spitting out garbage on the second line.
def warning_on_one_line(message, category, filename, lineno, file=None, line=None):
    return '%s:%s: %s: %s\n' % (filename, lineno, category.__name__, message)


warnings.formatwarning = warning_on_one_line


class Procedure(object):
    def __init__(self, parent, procedure_stub):
        """Initialize a procedure object.

        :Example:
        >>> procedure = connection.get_procedures()[0]
        >>> procedure.name
        u'Laparoscopic Cholecystectomy'
        >>> procedure.sync()
        >>> 'cohorts' in procedure.json
        True
        >>> len(procedure.cohorts)
        1
        >>> procedure.cohorts[0].name
        u'Best'
        >>> 'carepaths' in procedure.json
        True
        >>> extraglobs['procedure'] = procedure #ignore-in-doc
        """
        self.cohorts = None
        self.carepaths = None
        self.json = procedure_stub
        self.parent = parent
        self.session = parent.session
        self.care_request_url = parent.care_request_url
        for key, value in procedure_stub.items():
            setattr(self, key, value)
        self.curl = self.parent.care_request_url + 'procedures/%s' % self.id
        self.cohorts_url = self.curl + '/cohorts'
        self.carepaths_url = self.curl + '/carepaths'

    def __repr__(self):
        return "<Procedure %s: id: %s>" % (self.name, self.id)

    def sync(self):
        """Synchronizes with current state at the backend.

        :Example:
        See :func:__init__
        """
        ret_procedure = json_funcs._get_(self.session, self.curl)
        for key, value in ret_procedure.items():
            if key == "cohorts":
                cohorts = [cohort.Cohort(self, i) for i
                           in value]
                self.cohorts = cohorts
            elif key == "carepaths":
                carepaths = [carepath.Carepath(self, i) for i
                             in value]
                self.carepaths = carepaths
            else:
                setattr(self, key, value)
        # TODO: Repeat for carepaths and columns
        self.json = ret_procedure

    def get_patients(self, patient_ids, include_events=True):
        """Gets a list of patient objects from patient ids

        :param patient_ids: Patient id list.
        :param include_events: Whether events need to be included in the return
        :returns: None

        :Example:
        >>> procedure = extraglobs['procedure'] #ignore-in-doc
        >>> len(procedure.get_patients())

        """
        param_dict = {'patient_ids': patient_ids,
                      'include_events': include_events}
        retrieved_patients = \
            json_funcs._post_(self.session,
                              self.curl + '/retrieve_patients',
                              param_dict)
        return [patient.Patient(self, i) for i in retrieved_patients]

    def create_filter_set(self, conditions, as_and=True):
        # TODO:Remove and replace with a call to source.create_filter_set
        ret_dict = {'filters': [], 'require_all': as_and}
        valid_column_keys = ['column_name', 'column_index']
        subset.validate_conditions(conditions, valid_column_keys)
        for col_key in valid_column_keys:
            ret_dict = subset.process_conditions(col_key, conditions, ret_dict)
        return ret_dict

    def create_cohort(self, filter_set, name="Untitled"):
        """Creates a cohort based on a filter set

        :param filter_set: A filter set created by :func:`create_filter_set`
        :returns: None
        """
        if not filter_set:
            filter_set = {'filters': []}
            name = "All patients"
        param_dict = {'filter_set': filter_set, 'name': name}
        new_cohort = json_funcs._post_(self.session,
                                       self.cohorts_url,
                                       param_dict)
        return cohort.Cohort(self, new_cohort)

    def get_cohorts(self):
        """Get cohorts associated with the procedure

        :param: None
        :returns: None

        :Example:

        >>> procedure = extraglobs['procedure'] #ignore-in-doc
        >>> cohorts = \
            first_procedure.get_cohorts() # doctest: +NORMALIZE_WHITESPACE
        [<Cohort Best: id: -7212832343890437856>,
         <Cohort sample2: id: -6552416126036274848>,
         <Cohort All patients: id: -5351045836661522972>,
         <Cohort sample2: id: 404247003462772456>,
         <Cohort sample2: id: 4230333575615880856>,
         <Cohort sample2: id: 5408948468616212497>]
        >>> cohorts[0].name
        u'Best'
        >>> len(cohorts)
        6

        """
        try:
            return self.cohorts
        except AttributeError as e:
            LOGGER.exception(e)
            self.sync()
            return self.cohorts

    def get_cohort(self, id=None, name=None):
        """Get cohorts associated with the procedure

        :param id: The id of the requested cohort (optional with name).
        :param name: The name of the requested cohort (optional with id).
        :returns: list of matching cohorts

        :Example:

        >>> procedure = extraglobs['procedure'] #ignore-in-doc
        >>> procedure.get_cohort(name='Best')
        <Cohort Best: id: -7212832343890437856>
        """
        self.sync()
        matching_cohorts = []
        for current_cohort in self.get_cohorts():
            if name is not None and current_cohort.name == name:
                matching_cohorts.append(current_cohort)
            elif id is not None and current_cohort.id == id:
                return current_cohort
        if len(matching_cohorts) > 1:
            print("Multiple cohorts with the same name. Return All")
            return matching_cohorts

    def delete_cohort(self, id):
        """Delete a cohort by id

        :param name: Name of the cohort to be deleted.
            If there are multiples, this fails.
        :param id: Id of the cohort to be deleted.

        :returns: None

        :Example:

        >>> procedure = extraglobs['procedure'] #ignore-in-doc
        >>> procedure.delete_cohort(name='sample2')
        """

        json_funcs._delete_(self.session, self.cohorts_url + "/" + id)

    def create_managed_carepath(self, carepath_dict):
        """Create managed carepath

        :param carepath_dict: Dictionary of carepath parameters
        :type carepath_dict: dict

        :returns: A :class:`ayasdi.care.carepath.Carepath` object.
        :rtype: :class:`ayasdi.care.carepath.Carepath`,
            :class:`ayasdi.care.carepath.Carepath`

        :Example:

        >>> procedure = extraglobs['procedure'] #ignore-in-doc
        >>> cohort = [x for x in procedure.get_cohorts()
                      if x.name == 'Best'][0]
        >>> cp_json = {'events':
            [{u'p_value': 0.00047152612, u'code': u'LAB1725', u'interval':
                u'ONE TIME', u'num_foreground': 40, u'time': -8497.0,
                u'num_background': 451, u'percent_background': 0.27943,
                u'percent_foreground': 0.51282054},
            {u'p_value': 0.0018038475, u'code': u'LAB1725',
                u'interval': u'None',
                u'num_foreground': 10, u'time': -8497.0,
                u'num_background': 44,
                u'percent_background': 0.027261462, u'percent_foreground':
                0.12820514}]}
        >>> carepath = procedure.create_managed_carepath(cp_json)
        >>> carepath.name
        u'UntitledCarepath'
        >>> procedure.delete_managed_carepath(carepath.id)

        """

        if 'events' not in carepath_dict:
            raise Exception("Events are a required field in the "
                            "input carepath dictionary")
        if 'predicates' not in carepath_dict:
            raise Exception(
                "Adherence predicates are a required field "
                "in the input carepath dictionary")
        # if not isinstance(carepath_dict['events'], list) or
        # len(carepath_dict['events']) == 0:
        #     raise Exception("Events cannot be empty")
        first_event_time = carepath_dict['events'][0]['time']
        if 'epochs' in carepath_dict and len(carepath_dict['epochs']) > 0:
            epochs = carepath_dict['epochs']
        else:
            epochs = [{"name": "All events", 'start': first_event_time}]
        # TODO: Replicate the epoch logic that occurs in the API
        param_dict = {'status': 'draft',
                      'description': carepath_dict.get('description', ''),
                      'epochs': epochs,
                      'events': carepath_dict['events'],
                      'owner_email': self.parent.username,
                      'name': carepath_dict.get('name', 'UntitledCarepath'),
                      'predicates': carepath_dict['predicates']
                      }
        managed_carepath = json_funcs._post_(self.session,
                                             self.carepaths_url,
                                             param_dict)
        return carepath.Carepath(self, managed_carepath)

    def delete_managed_carepath(self, id):
        """Deletes managed carepath from id

        :param id: id of carepath
        :type id: string

        :returns: None

        :Example:
        See an example usage in :func:`create_managed_carepath`
        """

        json_funcs._delete_(self.session, self.carepaths_url + "/" + id)

    def get_managed_carepaths(self):
        """Returns a list of managed carepaths associated with this procedure.

        :param: None
        :returns: list of carepaths
        :rtype: list

        :Example:

        >>> procedure = extraglobs['procedure'] #ignore-in-doc
        >>> len(procedure.get_managed_carepaths())
        1
        """

        try:
            return self.carepaths
        except AttributeError as e:
            LOGGER.exception(e)
            self.sync()
            return self.carepaths

    def compare_patient_groups(self, primary_group, secondary_group):
        """Compares two patient groups.
        Primary and secondary groups are obtained from the procedures,
            which contain patient filters, which contain these.

        :param primary_group: primary group, can be cohort, patient_group,
            or id string
        :param secondary_group: secondary_group, can be cohort,
            patient_group, or id string
        :type secondary_group: string

        :returns: comparison

        :Example:

        >>> procedure = extraglobs['procedure'] #ignore-in-doc
        >>> cohort1 = procedure.get_cohorts()[0]
        >>> cohort2 = procedure.get_cohort(name='All patients')
        >>> comparison = procedure.compare_patient_groups(cohort1, cohort2)
        >>> comparison['row_sets']
        [{u'row_count': 807, u'name': u'All Patients in Cohort'},
         {u'row_count': 74, u'name': u'All Patients in Cohort'}]
        """

        def get_group_id(group):
            if isinstance(group, cohort.Cohort):
                group.sync()
                return group.cohort_group.id
            elif isinstance(group, patient_group.PatientGroup):
                return group.id
            elif isinstance(group, str):
                return group

        # Check if secondary_group is one of Rest or All
        secondary_group_id = None
        if not (primary_group and secondary_group):
            raise Exception("Neither primary nor secondary groups "
                            "can be empty")
        if isinstance(secondary_group, str):
            if secondary_group == "Rest":
                secondary_group_id = '1'
            elif secondary_group == "All":
                secondary_group_id = '0'

        # Set the primary group
        primary_group_id = get_group_id(primary_group)
        if not secondary_group_id:
            secondary_group_id = get_group_id(secondary_group)
        comparison = json_funcs._post_(self.session,
                                       self.curl + '/compare_patient_groups',
                                       {'secondary_caregroup_id':
                                        secondary_group_id,
                                        'primary_caregroup_id':
                                        primary_group_id})
        return comparison

    def retrieve_adherence(self, managed_carepath,
                           group_by="primary_procedure_physician_desc"):
        """Retrieves a list of scores, either for physicians or facilites,
            that indicate managed_carepath similarity to the data

        :param managed_carepath: managed_carepath object
        :type managed_carepath: :class:`ayasdi.care.carepath.Carepath` object.
        :param group_by:
        :type group_by: string, a valid column name by which the carepaths are grouped by,
            defaults to 'primary_procedure_physician_desc'

        :returns:

        :Example:

        >>> procedure = extraglobs['procedure'] #ignore-in-doc
        >>> cp1 = procedure.get_managed_carepaths()[0]
        >>> cp1.deploy()

        >>> adherence = procedure.retrieve_adherence(cp1)
        >>> adherence[0]
        {u'count': 2, u'adherence': 0.5, u'group': u'Physician 50',
         u'per_event_adherence': [0.5, 0.5]}
        """

        if group_by not in {column['name'] for column in self.columns}:
            raise Exception("Group by only available for valid column names in the current procedure")
        if not managed_carepath.status == "deployed":
            raise Exception("Only deployed carepaths can have an adherence.")
        param_dict = {'group_by': group_by, 'carepath_id': managed_carepath.id}
        # TODO: Change these hardcoded values when those are not required.
        adherence = json_funcs._post_(self.session,
                                      self.curl + '/retrieve_adherence',
                                      param_dict)
        return adherence

    def retrieve_summary(self, group_by="primary_procedure_physician_desc"):
        """Retrieves summary (min, max, variance, pct) for patients or
            physicians in the procedure.

        :param group_by: parameter to group summary by,
            defaults to primary_procedure_physician_desc
        :type group_by: string

        :returns: summary list

        :Example:
        >>> procedure = extraglobs['procedure'] #ignore-in-doc
        >>> summary = procedure.retrieve_summary()
        >>> len(summary)
        72
        >>> summary[0]['data'][0]['mean']
        1933.46
        """

        if group_by not in {column['name'] for column in self.columns}:
            raise Exception("Group by only available for valid column names in the current procedure")
        columns_in_response = ["variable_direct_cost", "length_of_stay",
                               "has_diabetes", "has_hypertension",
                               "is_readmitted"]
        param_dict = {'group_by': group_by, 'columns': columns_in_response}
        # TODO: Change these hardcoded values when those are not required.
        summary = json_funcs._post_(self.session,
                                    self.curl + '/retrieve_summary',
                                    param_dict)
        return summary

    def get_code_categories(self):
        """Retrieves the code category dictionary for the procedure.

        Args:
          None

        Returns:
          code_categories (dict): A dictionary of code to
            categories of the form
              {parent_category1:
               [{category1: [code1, code2, ...]}, ...],
               parent_category2: ...}

        :Example:
        >>> procedure = extraglobs['procedure'] #ignore-in-doc
        >>> code_category_dict = procedure.get_code_categories()
        >>> sorted(code_category_dict.keys())
        [u'Labs', u'Meds', u'Orders', u'Surgery']
        >>> sorted(code_category_dict['Surgery'].keys()[:3])
        [u'CARDIOPULMONARY', u'ENDOSCOPY', u'RECOVERY ROOM']
        >>> sorted(code_category_dict['Surgery']['ENDOSCOPY'][:3])
        [u'500000287', u'500000293', u'500001151']

        """
        ret_category_map = json_funcs._get_(self.session,
                                            self.curl + '/categories')
        ret_dict = {}
        for parent_category in ret_category_map:
            parent_category_name = parent_category['name']
            ret_dict[parent_category_name] = {}
            for category in parent_category['subcategories']:
                category_name = category['name']
                ret_dict[parent_category_name][category_name] = [
                    code['name'] for code in category['subcategories']]
        return ret_dict
