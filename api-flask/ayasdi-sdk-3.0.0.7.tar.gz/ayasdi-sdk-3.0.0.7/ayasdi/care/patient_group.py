#!/usr/bin/env python
from __future__ import absolute_import, unicode_literals, division, print_function
import logging

from ayasdi.care import carepath
from ayasdi.care import json_funcs

LOGGER = logging.getLogger(__name__)


class PatientGroup(object):
    def __init__(self, parent, patient_group_info):
        """Initializing a patient_group object

        :param parent:
        :param patient_group_info:
        :return:

        :Example:

        >>> procedure = connection.get_procedures()[0]
        >>> procedure.sync()
        >>> cohort = procedure.get_cohorts()[0]
        >>> patient_group = cohort.cohort_group
        >>> extraglobs['patient_group'] = patient_group #ignore-in-doc
        """
        self.json = patient_group_info
        self.parent = parent
        self.procedure = parent.parent
        # If this is a cohort_group, no carepath.
        self.carepath = None
        for key, value in patient_group_info.items():
            if key == "carepath":
                self.carepath = carepath.Carepath(self.procedure, value)
            else:
                setattr(self, key, value)
        self.curl = self.procedure.care_request_url + \
            'procedures/%s/cohorts/%s/treatment_groups/%s' % \
            (self.procedure.id, self.parent.id, self.id)

    def __repr__(self):
        return "<PatientGroup %s: id: %s>" % (self.name, self.id)

    def get_patients(self, include_events=True):
        """Get patients associated with Patient Group
        :param include_events: boolean defaults to True
        :returns:

        :Example:

        >>> patient_group = extraglobs['patient_group'] #ignore-in-doc
        >>> patients = patient_group.get_patients()
        >>> len(patients)
        612
        >>> patients[0].__dict__.keys() # doctest: +NORMALIZE_WHITESPACE
        ['procedure_date', 'is_readmitted', 'parent',
         'primary_procedure_physician_desc', 'time_range',
         'facility_name', 'has_hypertension', 'has_diabetes',
         'reason_readmit_code', 'fixed_direct_cost',
         'primary_icd_diagnosis', 'primary_icd_diagnosis_desc',
         'json', 'reason_readmit_desc', 'total_direct_cost',
         'length_of_stay', 'patient_id', 'variable_direct_cost',
         'events', 'encounter_id']
        >>>
        """
        return self.procedure.get_patients(self.patient_ids, include_events)

    def compute_consensus(self):
        param_dict = {}
        ret_value = json_funcs._post_(self.procedure.session,
                                      self.curl + '/consensus',
                                      param_dict)
        consensus_carepath = carepath.Carepath(self.procedure, ret_value)
        self.parent.sync()
        return consensus_carepath

    def compare_to(self, other_patient_group):
        """Compare to another patient group. Calls procedure.compare_patient_groups

        :param other_patient_group: second group to compare to
        :type other_patient_group:
            :class:`ayasdi.care.patient_group.PatientGroup`
        """
        return self.procedure.compare_patient_groups(self, other_patient_group)

    def export(self, format='csv'):
        pass
