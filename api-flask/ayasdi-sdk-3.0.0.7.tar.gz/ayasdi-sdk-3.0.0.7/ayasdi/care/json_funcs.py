from __future__ import absolute_import, unicode_literals, division, print_function
import json
import logging
LOGGER = logging.getLogger(__name__)


def _post_(session, url, data_dict):
    """Function to post to given url.
    """
    resp = session.post(url,
                        data=json.dumps(data_dict),
                        headers={'content-type': 'application/json',
                                 'accept': 'application/json'})
    try:
        resp.raise_for_status()
    except Exception:
        error_message = "Error Response: ", resp.text
        LOGGER.exception(error_message)
        print(error_message)
        raise
    return json.loads(resp.text)


def _put_(session, url, data_dict):
    """Function to post to given url.
    """
    resp = session.put(url,
                       data=json.dumps(data_dict),
                       headers={'content-type': 'application/json',
                                'accept': 'application/json'})
    try:
        resp.raise_for_status()
    except Exception:
        error_message = "Error Response: ", resp.text
        LOGGER.exception(error_message)
        print(error_message)
        raise
    return json.loads(resp.text)


def _get_(session, url):
    """Function to get from given url.
    """
    resp = session.get(url, headers={'accept': 'application/json'})
    try:
        resp.raise_for_status()
    except Exception:
        error_message = "Error Response: ", resp.text
        LOGGER.exception(error_message)
        print(error_message)
        raise
    # Hack since outcome_auto_analysis returns this
    # when the process completes.
    # Remove the next couple of lines when that
    # is fixed.
    if resp.status_code == 303:
        return json.loads("{}")
    return json.loads(resp.text)


def _delete_(session, url):
    """Function to delete at the given url endpoint.
    """
    resp = session.delete(url, headers={'accept': 'application/json'})
    try:
        resp.raise_for_status()
    except Exception:
        error_message = "Error Response: ", resp.text
        LOGGER.exception(error_message)
        print(error_message)
        raise
    return True
