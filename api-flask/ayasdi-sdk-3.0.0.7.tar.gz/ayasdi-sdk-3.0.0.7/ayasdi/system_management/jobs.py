from __future__ import absolute_import, unicode_literals, division, print_function
import logging

from ayasdi.system_management import base

LOGGER = logging.getLogger(__name__)


class Job(base.Resource):
    def __repr__(self):
        return '<Job: {}>'.format(self.id)


class JobManager(base.Manager):
    resource_class = Job

    def list(self, params=None):
        """
        Returns a list of system jobs.

        Args:
            params (dict, optional): A dictionary of additional parameters
                to pass along with the request. Available parameters include:
                    - per_page (int): Number of results to show per page.
                    - page (int): The page of results to list.

        Returns:
            A list of Job objects
        """

        return self._list('/jobs', 'jobs', params=params)

    def get(self, job_id):
        """
        Retrieve a specific job by id.

        Args:
            job_id (string): The id of the job to retrieve.

        Returns:
            A Job object
        """
        return self._get('/jobs/{}'.format(job_id))
