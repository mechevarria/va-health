from __future__ import absolute_import, unicode_literals, division, print_function
import logging

from ayasdi.system_management import base

LOGGER = logging.getLogger(__name__)


class SystemEvents(base.Resource):
    def __repr__(self):
        return '<System Events : {}>'.format(self.traceId)


class SystemEventsManager(base.Manager):
    resource_class = SystemEvents

    def aggregates(self, username=None, status=None, before=None, after=None, per_page=None, page=None):
        """Returns a list of system events aggregates.

               Args:
                   username (string): The user can filter aggregates by username.
                   status (string): The user can filter aggregates by status of its corresponding job
                   before (date): The before filter date in format yyyy-MM-ddThh:mm:ss.SSSXXX
                   after (date): The after filter date in format yyyy-MM-ddThh:mm:ss.SSSXXX
                   per_page (int): The number of aggregates per page. Default value : 50
                   page (int): The number of page for the aggregates list. Default value : 1

               Returns:
                   System Events Aggregates (list) : A list of system events aggregates.

               :Example:

               >>> connection = Client(host, username, password) # doctest: +SKIP
               >>> connection.systemevents.aggregates() # doctest: +SKIP
               [<System Events : 1510078767.411-52618-1180-211>,
               <System Events : 1510010890.009-37878-1209-32>,
               <System Events : 1510010890.040-37952-1209-44>]
               >>> aggregates_list = connection.systemevents.aggregates() # doctest: +SKIP
               >>> aggregate = aggregates_list[0] # doctest: +SKIP
               >>> aggregate.created # doctest: +SKIP
               '2017-11-07T18:19:35.791Z'

        """
        params = {}
        if per_page is not None:
            params['per_page'] = per_page
        else:
            params['per_page'] = 50
        if page is not None:
            params['page'] = page
        else:
            params['page'] = 1
        if username is not None:
            params['user'] = username
        if status is not None:
            params['status'] = status
        if before is not None and after is not None:
            params['before'] = before
            params['after'] = after
        return self._list('/systemevents', 'systemEventsAggregate', params=params)

    def get(self, trace_id, per_page=50):
        """Returns a list of system events for the trace_id specified.

               Args:
                   trace_id : The trace_id for which the system events is needed

               Returns:
                   SystemEvents (list) : A list of SystemEvents objects for the specified trace_id

               :Example:

               >>> connection = Client(host, username, password) # doctest: +SKIP
               >>> connection.systemevents.get('1510078767.411-52618-1180-211') # doctest: +SKIP
               [<System Events : 1510078767.411-52618-1180-211>,
               <System Events : 1510078767.411-52618-1180-211>,
               <System Events : 1510078767.411-52618-1180-211>]
               >>> system_events_list = connection.systemevents.get('1510078767.411-52618-1180-211') # doctest: +SKIP
               >>> system_event = system_event_list[0] # doctest: +SKIP
               >>> system_event.type # doctest: +SKIP
               'OBJECT_CREATE_SUCCESS'

               """
        params = {'per_page': per_page}
        return self._list('/systemevents/%s' % trace_id, 'systemEvents', params=params)
