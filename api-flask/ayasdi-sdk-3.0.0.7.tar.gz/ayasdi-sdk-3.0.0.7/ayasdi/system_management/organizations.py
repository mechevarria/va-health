from __future__ import absolute_import, unicode_literals, division, print_function

import logging

from ayasdi.system_management import base

LOGGER = logging.getLogger(__name__)


class Org(base.Resource):
    def __repr__(self):
        return '<Org: {}>'.format(self.id)

    def update(self, name=None, max_seats=None, notes=None, enabled=None):
        """
        Update this org with new properties.

        Args:
            name (string, optional): New name for the org.
            max_seats (int, optional): The maximum amount of users to be allowed in the org.
            notes (string, optional): New notes for the org.
            enabled (bool, optional): Set this to True to enable the org,
                or False to disable the org.

        Returns:
            The updated Org object
        """
        return self.manager.update(self.id, name=name, max_seats=max_seats,
                                   notes=notes, enabled=enabled)

    def delete(self):
        """
        Delete this org.

        Returns:
            True if successful
        """
        self.manager.delete(self.id)


class OrgManager(base.Manager):
    resource_class = Org

    def create(self, name, max_seats, notes=''):
        """
        Create a new org in system management.

        Args:
            name (string): Name of the org.
            max_seats (int): The maximum amount of users to be allowed
                in the org.
            notes (string, optional): Additional notes to attach to the org.

        Returns:
            A new Org object
        """
        body = {
            'name': name,
            'maxSeats': max_seats,
            'notes': notes
        }
        return self._post('/organizations', body)

    def list(self, params=None):
        """
        Returns a list of all orgs.

        Args:
            params (dict, optional): A dictionary of additional parameters
                to pass along with the request. Available parameters include:
                    - per_page (int): Number of results to show per page.
                    - page (int): The page of results to list.

        Returns:
            A list of Org objects
        """
        return self._list('/organizations', 'organizations', params=params)

    def get(self, org_id):
        """
        Retrieve a specific org by id.

        Args:
            org_id (string): The id of the org to retrieve.

        Returns:
            An Org object
        """
        return self._get('/organizations/{}'.format(org_id))

    def delete(self, org_id):
        """
        Delete a specific org by id.

        Args:
            org_id (string): The id of the org to delete.

        Returns:
            True if successful
        """
        self._delete('/organizations/{}'.format(org_id))

    def update(self, org_id, name=None, max_seats=None, notes=None, enabled=None):
        """
        Update an org's name, max_seats, notes, and/or enabled status.

        Args:
            org_id (string): The id of the org to update.
            name (string, optional): The new name of the org.
            max_seats (int, optional): The maximum number of users to be allowed
                in the org.
            notes (string, optional): New notes to attach to the org.
            enabled (bool, optional): Set this to True to enable the org,
                or False to disable the org.

        Returns:
            The updated Org object.
        """
        body = {
            'name': name,
            'maxSeats': max_seats,
            'notes': notes,
            'enabled': enabled
        }
        return self._put('/organizations/{}'.format(org_id), body)
