from __future__ import absolute_import, unicode_literals, division, print_function

import logging

from ayasdi.system_management import base

LOGGER = logging.getLogger(__name__)


class User(base.Resource):
    def __repr__(self):
        return '<User: {}>'.format(self.id)

    def delete(self):
        """
        Delete this user.

        Returns:
            True if successful
        """
        self.manager.delete(self.id)


class UserManager(base.Manager):
    resource_class = User

    def create(self, email, password, org_id, team_id=None, name='',
               locked=False, enabled=True):
        """
        Create a new user for a specific org and team.

        Args:
            email (string): The user's email address.
            password (string): The user's password.
            org_id (string): The id of the org the user will belong to.
            team_id (string, optional): The id of the team the user will belong to.
            name (string, optional): The user's name.
            locked (bool, optional): default False
            enabled (bool, optional): default True

        Returns:
            The new User object
        """
        body = {
            'email': email,
            'name': name,
            'password': password,
            'organization': {
                'id': org_id
            },
            'enabled': enabled,
            'locked': locked
        }

        if team_id:
            body['primaryTeam'] = {
                'id': team_id
            }

        return self._post('/users', body)

    def list(self, params=None):
        """
        Returns a list of users.

        Args:
            params (dict, optional): A dictionary of additional parameters
                to pass along with the request. Available parameters include:
                    - per_page (int): Number of results to show per page.
                    - page (int): The page of results to list.

        Returns:
            A list of User objects.
        """
        return self._list('/users', 'users', params=params)

    def get(self, user_id):
        """
        Get a specific user by id.

        Args:
            user_id (string): The id of the user to retrieve.

        Returns:
            a User object
        """
        return self._get('/users/{}'.format(user_id))

    def get_user_by_email(self, email):
        """
        Get a specific user by email address.

        Args:
            email (string): The email address of the user to retrieve.

        Returns:
            a User object
        """
        return self._get('/users', params={'email': email})

    def delete(self, user_id):
        """
        Delete a specific user by id.

        Args:
            user_id (string): The id of the user to be deleted.

        Returns:
            True if successful
        """
        self._delete('/users/{}'.format(user_id))

    def update(self, user_id, enabled=None, name=None, password=None):
        """
        Update a specific user's name, password, or status.

        Args:
            user_id (string): The id of the user to delete.
            enabled (bool, optional): Set this to True to enable the user,
                or False to disable the user.
            name (string, optional): The user's new name.
            password (string, optional): The user's new password.

        Returns:
            The updated User object
        """
        body = {}
        if name is not None:
            body['name'] = name
        if password is not None:
            body['password'] = password
        if enabled is not None:
            body['enabled'] = enabled

        return self._put('/users/{}'.format(user_id), body)

    def get_current_user(self):
        """Login with the user to get user details such as roles,
                rights, team, primaryTeam
            Args:
                None

            Returns:
                User object

            :Example:

            >>> connection = Client(host, username, password) # doctest: +SKIP
            >>> user = connection.users.get_current_user() # doctest: +SKIP
            >>> user.roles # doctest: +SKIP
            [{u'id': 3, u'name': u'user'}]
            >>> user.teams # doctest: +SKIP
            [{u'organization': {u'id': 3, u'name':
                                u'Organization for group admin'},
              u'isDefaultTeam': False, u'id': 9, u'name': u'test team'}]
            >>> user.primaryTeam # doctest: +SKIP
            {u'organization': {u'id': 3, u'name':
                               u'Organization for group admin'},
             u'isDefaultTeam': False, u'id': 9, u'name': u'test team'}
            >>> user.organization # doctest: +SKIP
            {u'id': 3, u'name': u'Organization for group admin'}
            >>> user.id # doctest: +SKIP
            10
            >>> user.oldId # doctest: +SKIP
            -9081290465210320811
            >>> user.isSiteAdmin # doctest: +SKIP
            false
            >>> user.isOrgAdmin # doctest: +SKIP
            false
            >>> user.enabled # doctest: +SKIP
            true
            >>> user.name # doctest: +SKIP
            test user
            >>> user.email # doctest: +SKIP
            test.user@ayasdi.com
            >>> user.locked # doctest: +SKIP
            false
            >>> user.settings # doctest: +SKIP
            {\"settings\":{\"mode\":\"normal\",\"theme\":\"dark\"}}
            >>> user.rights # doctest: +SKIP
            [{u'description': u'Real-time Prediction', u'id': 27,
              u'name': u'7032'}, {u'description': u'Legacy Site Admin',
                                  u'id': 23, u'name': u'7016'}]
            >>> user.createTimestamp # doctest: +SKIP
            2016-01-18T19:42:15Z
            >>> user.updateTimestamp # doctest: +SKIP
            2016-09-14T18:03:07.057Z

            """
        return self._get('/self')
