from __future__ import absolute_import, unicode_literals, division, print_function
import logging

from ayasdi.system_management import base

LOGGER = logging.getLogger(__name__)


class InternalManager(base.Manager):
    def create_site_admin(self):
        self.api.client.request('/internal/site-admin', 'POST')
