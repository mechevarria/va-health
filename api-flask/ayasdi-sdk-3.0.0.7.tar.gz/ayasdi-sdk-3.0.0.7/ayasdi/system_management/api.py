from __future__ import absolute_import, unicode_literals, division, print_function

import json
import logging
import os
import warnings

from requests.exceptions import SSLError

from ayasdi import session
from ayasdi.core.api import normalize_api_server_url
from ayasdi.core import creds
from ayasdi.system_management import internal
from ayasdi.system_management import jobs
from ayasdi.system_management import organizations
from ayasdi.system_management import rights
from ayasdi.system_management import roles
from ayasdi.system_management import teams
from ayasdi.system_management import users
from ayasdi.system_management import systemevents

LOGGER = logging.getLogger(__name__)


class Api(object):
    def __init__(self, username=None, password=None, save_password=False,
                 cookie_dict=None, cookie_domain="", url="", verify=True):
        """Instantiate a new Api connection.

           Args:

            url (str) : Url for the host to be connected
            username (str) : Your Ayasdi Core username
            password (str) :  Your Ayasdi Core password
            cookie_dict (dict) : Cookie based login for SSO
            cookie_domain (str) : Domain for cookie based login
            save_password (bool) : If True, saves the password to a keyring

           Returns:

            Client connection (:class:'Api') :  The Client connection

           :Example:
           >>> connection = Api(url=host, username=username, password=password)

        """

        self.is_connected = False
        if cookie_dict is None:
            ayasdi_cookie_json = os.environ.get('AYASDI_COOKIE')
            if ayasdi_cookie_json is not None:
                cookie_dict = json.loads(ayasdi_cookie_json)

        cookie_domain = cookie_domain or os.environ.get('AYASDI_COOKIE_DOMAIN', '')
        if url:
            self.CORE_LOGIN_STUB = normalize_api_server_url(url)
        else:
            self.CORE_LOGIN_STUB = 'https://platform.ayasdi.com/admin/'

        self.CORE_REQUEST_STUB = self.CORE_LOGIN_STUB + 'v1'
        self.session = session.Session()
        self.session.verify = verify

        if not cookie_dict:
            # If username is given, check creds for
            # this user's password on this server.
            # Else check creds for both username and password.
            # If both are given, save the password to be used with cli.
            if not username:
                username, password = creds.get_creds(self.CORE_LOGIN_STUB)
            elif not password:
                username, password = creds.get_creds(
                    self.CORE_LOGIN_STUB,
                    username=username)
            try:
                resp = self.session.post(
                    self.CORE_LOGIN_STUB + 'login',
                    data={"username": username,
                          "passphrase": password})

            except SSLError as e:
                error_message = "SSLError: %s" % e
                LOGGER.exception(error_message)
                warnings.warn(error_message)
                self.session.verify = False
                resp = self.session.post(
                    self.CORE_LOGIN_STUB + 'login',
                    data={"username": username,
                          "passphrase": password})
            # Did login work?
            if resp.status_code not in [200, 204]:
                resp.raise_for_status()
            self.is_connected = True
            if save_password:
                creds.save_creds(self.CORE_LOGIN_STUB,
                                 username, password)

        else:
            for name, value in cookie_dict.items():
                self.session.cookies.set(name, value,
                                         domain=cookie_domain)
            try:
                resp = self.session.get(
                    self.CORE_LOGIN_STUB + 'validateCookie'
                )
            except SSLError as e:
                error_message = "SSLError: %s" % e
                LOGGER.exception(error_message)
                warnings.warn(error_message)
                self.session.verify = False
                resp = self.session.get(
                    self.CORE_LOGIN_STUB + 'validateCookie'
                )

            if resp.status_code not in [200, 204]:
                self.session.cookies.clear()
                resp.raise_for_status()
            else:
                self.is_connected = True

        self.internal = internal.InternalManager(self)
        self.users = users.UserManager(self)
        self.orgs = organizations.OrgManager(self)
        self.teams = teams.TeamManager(self)
        self.rights = rights.RightsManager(self)
        self.roles = roles.RolesManager(self)
        self.jobs = jobs.JobManager(self)
        self.systemevents = systemevents.SystemEventsManager(self)
