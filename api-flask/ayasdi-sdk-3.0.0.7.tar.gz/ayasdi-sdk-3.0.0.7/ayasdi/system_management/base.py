from __future__ import absolute_import, unicode_literals, division, print_function

import logging

from ayasdi.core import json_funcs

LOGGER = logging.getLogger(__name__)


def getid(obj):
    try:
        return obj.id
    except AttributeError:
        return obj


class Resource(object):
    def __init__(self, manager, info):
        self.manager = manager
        self._add_details(info)

    def __getattr__(self, k):
        if k not in self.__dict__:
            raise AttributeError(k)
        else:
            return self.__dict__[k]

    def _add_details(self, info):
        for k, v in info.items():
            setattr(self, k, v)


class Manager(object):
    resource_class = None

    def __init__(self, api):
        self.api = api

    def __format_url(self, url):
        full_url = '{}{url_path}'.format(
            self.api.CORE_REQUEST_STUB, url_path=url)
        return full_url

    def _list(self, url, response_key, params=None):
        resp = json_funcs._get_(self.api.session,
                                self.__format_url(url),
                                params=params)
        resources = resp[response_key]
        return [self.resource_class(self, res) for res in resources]

    def _get(self, url, params=None):
        resp = json_funcs._get_(self.api.session,
                                self.__format_url(url),
                                params=params)
        return self.resource_class(self, resp)

    def _post(self, url, data):
        resp = json_funcs._post_(self.api.session,
                                 self.__format_url(url), data)
        return self._get(resp['url'])

    def _delete(self, url, params=None, data=None):
        return json_funcs._delete_(self.api.session,
                                   self.__format_url(url),
                                   data=data,
                                   params=params)

    def _put(self, url, body):
        data = json_funcs._put_(self.api.session,
                                self.__format_url(url),
                                body)
        return self._get(data['url'])

    def _get_json(self, url, params=None):
        return json_funcs._get_(self.api.session,
                                self.__format_url(url),
                                params=params)
