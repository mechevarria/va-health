from __future__ import absolute_import, unicode_literals, division, print_function

import logging

from ayasdi.system_management import base

LOGGER = logging.getLogger(__name__)


class Team(base.Resource):
    def __repr__(self):
        return '<Team: {}>'.format(self.id)

    def delete(self):
        """
        Delete this team.

        Returns:
            True if successful
        """
        self.manager.delete(self.id)

    def update(self, name=None, role_ids=None):
        """
        Update this team with a new name or roles.

        Args:
            name (string, optional): The new name for the team.
            role_ids (list, optional): A list of role ids to assign to the team.

        Returns:
            The updated Team object.

        """
        return self.manager.update(self.id, name=name, role_ids=role_ids)


class TeamManager(base.Manager):
    resource_class = Team

    def create(self, name, org_id, role_ids=None):
        """
        Creates a team with the name, org id, and roles.

        :param name (str): name of the new team.
        :param org (str): id of org that will manage the team.
        :param role_ids (list, optional): List of role ids to add to the team.
            Defaults to `user` role.
        :return: Team Object

        Example:
            >>> from ayasdi.sysmgmt.client import Client # doctest: +SKIP
            >>> connection = Client(host, username, password) # doctest: +SKIP
            >>> user = connection.users.get_current_user() # doctest: +SKIP
            >>> org_id = user.organization['id'] # doctest: +SKIP
            >>> connection.teams.create('team_name', \
                org_id, role_ids=[6, 7]) # doctest: +SKIP
        """
        if not role_ids:
            roles = []
        else:
            if not isinstance(role_ids, list):
                raise TypeError('roles_id must be a list of integers')
            roles = [{'id': id} for id in role_ids]

        body = {
            'name': name,
            'organization': {
                'id': org_id
            },
            'roles': roles
        }
        return self._post('/teams', body)

    def list(self, params=None):
        """
        Returns a list of all the teams in the system.

        Args:
            params (dict, optional): A dictionary of additional parameters
                to pass along with the request. Available parameters include:
                    - per_page (int): Number of results to show per page.
                    - page (int): The page of results to list.

        Returns:
            A list of Team objects.
        """
        return self._list('/teams', 'teams', params=params)

    def get(self, team_id):
        """
        Get a specific team by id.

        Args:
            team_id (string): The id of the team to retrieve.

        Returns:
            a Team object
        """
        return self._get('/teams/{}'.format(team_id))

    def delete(self, team_id):
        """
        Delete a specific team by id.

        Args:
            team_id (string): The id of the team to delete.

        Returns:
            True if successful
        """
        self._delete('/teams/{}'.format(team_id))

    def update(self, team_id, name=None, role_ids=None):
        """
        Updates a team's name and/or roles.

        :param team_id(int or str): ID of team that will be updated
        :param name (str, optional): New team name
        :param role_ids (list, optional): List of role ids that the team
            will be assigned.
        :return: Team Object

        Example:
            >>> team = connection.teams.list()[0] # doctest: +SKIP
            >>> connection.teams.update(team.id, name='new name', \
                role_ids=[1, 2]) # doctest: +SKIP
        """
        body = {}
        if not (name or role_ids):
            raise Exception(
                'Updating teams requires either a name or list of roles.')

        if name:
            body['name'] = name

        if role_ids:
            if not isinstance(role_ids, list):
                raise Exception('roles_id must be a list of integers')
            roles = [{'id': id} for id in role_ids]
            body['roles'] = roles

        return self._post('/teams/{}'.format(team_id), data=body)

    def add_user(self, team_id, user_id):
        """
        Add a user to a team.

        Args:
            team_id (string): The team to add to.
            user_id (string): The user to add.

        Returns:
            The updated Team object.
        """
        payload = {'actors': [{'id': user_id}]}
        self._post('/teams/{}/actors'.format(team_id), data=payload)

    def remove_user(self, team_id, user_id):
        """
        Remove a user from a team.

        Args:
            team_id (string): The team to add to.
            user_id (string): The user to add.

        Returns:
            True if successful
        """
        payload = {'actors': [{'id': user_id}]}
        self._delete('/teams/{}/actors'.format(team_id), data=payload)

    def list_users(self, team_id):
        return self._get_json('/teams/%s/users' % team_id)
