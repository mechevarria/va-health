from __future__ import absolute_import, unicode_literals, division, print_function
import logging
from ayasdi.system_management import base

LOGGER = logging.getLogger(__name__)


class Role(base.Resource):
    def __repr__(self):
        return '<Role: {}>'.format(self.id)


class RolesManager(base.Manager):
    resource_class = Role

    def create(self, name, rights):
        """Creates a new role and returns it.

        Args:
            name (string): the role name.
            rights (list): the list of rights to assign to the role.

        Returns:
            a Role object

        :Example:

        >>> connection = Client(host, username, password) # doctest: +SKIP
        >>> rights = [{'id': 3, 'name': 'update_self',
        ...            'description': 'Change Password' },
        ...           {'id': 7, 'name': 'PREDICT',
        ...            'description' : 'Access - Predict' }] # doctest: +SKIP
        >>> role = connection.roles.create(role_name, rights) # doctest: +SKIP

        """
        body = {
            'name': name,
            'rights': rights
        }
        return self._post('/roles', body)

    def list(self, params=None):
        """Returns a list of roles.

        Args:
            params (dict, optional): A dictionary of additional parameters
                to pass along with the request. Available parameters include:
                    - per_page (int): Number of results to show per page.
                    - page (int): The page of results to list.

        Returns:
            roles (list) : A list of Role objects.

        :Example:

        >>> connection = Client(host, username, password) # doctest: +SKIP
        >>> connection.roles.list() # doctest: +SKIP
        [<Role: 1>, <Role: 2>, <Role: 3>, <Role: 4>, <Role: 9>, <Role: 10>,
         <Role: 11>, <Role: 12>]
        >>> roles_list = connection.roles.list() # doctest: +SKIP
        >>> role = roles_list[0] # doctest: +SKIP
        >>> role.name # doctest: +SKIP
        'Workbench Access only'

        """
        return self._list('/roles?all=true&orderBy=id', 'roles', params=params)

    def get(self, role_id):
        """Return a role with a given role id.

        Args:
            role_id (string): the role id

        Returns:
            a Role object

        :Example:

        >>> connection = Client(host, username, password) # doctest: +SKIP
        >>> role = connection.roles.get(role_id) # doctest: +SKIP
        >>> role.name # doctest: +SKIP
        'Workbench Access only'
        >>> role.rights # doctest: +SKIP
        [{u'description': u'Access - Workbench', u'id': 4, u'name': u'CORE'}]

        """
        return self._get('/roles/{}'.format(role_id))

    def delete(self, role_id):
        """Deletes a role with a given role id.

        Args:
            role_id (string): the role id that needs to be deleted

        Returns:
            True if successful

        :Example:

        >>> role = connection.roles.delete(role_id) # doctest: +SKIP

        """

        self._delete('/roles/{}'.format(role_id))
