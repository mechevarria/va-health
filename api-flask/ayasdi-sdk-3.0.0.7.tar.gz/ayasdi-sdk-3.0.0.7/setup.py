#!/usr/bin/env python
import os
from distutils.core import setup
from distutils.command.install import INSTALL_SCHEMES

from ayasdi._version import __version__

package_loc = os.path.abspath(os.path.dirname(__file__))
requires = open(os.path.join(package_loc, 'requirements.txt')).readlines()
utils_deps = open(os.path.join(package_loc, 'utils-requirements.txt')).readlines()

package_dict = {'name': 'ayasdi-sdk',
                'version': __version__,
                'author': 'Ayasdi Inc.',
                'author_email': 'support@ayasdi.com',
                'scripts': ['bin/python-sdk-test',
                            'bin/care-sdk-test'
                           ],
                'packages': ['ayasdi',
                             'ayasdi.core',
                             'ayasdi.care',
                             'ayasdi.core.models',
                             'ayasdi.core.models.time_series_models',
                             'ayasdi.core.models.unsupervised',
                             'ayasdi.core.test',
                             'ayasdi.core.unsupervised_analysis',
                             'ayasdi.core.utilities',
                             'ayasdi.core.utilities.comparisons',
                             'ayasdi.core.utilities.networks',
                             'ayasdi.core.utilities.source',
                             'ayasdi.sysmgmt',
                             'ayasdi.sysmgmt.v1',
                             'ayasdi.system_management'
                            ],
                'namespace_packages': ['ayasdi'],
                'package_data': {
                    'ayasdi.core.test':
                    ["*", "ayasdi/core/test/*.txt"]
                },
                'url': 'http://www.ayasdi.com',
                'license': 'LICENSE.txt',
                'description': 'Python package to interact with the' +
                               'Ayasdi Core REST API.',
                'install_requires': requires,
                'extras_require': {
                    'utils': utils_deps
                }
               }


def run_setup():
    setup(**package_dict)


if __name__ == "__main__":
    for scheme in INSTALL_SCHEMES.values():
        scheme['data'] = scheme['purelib']
    run_setup()
