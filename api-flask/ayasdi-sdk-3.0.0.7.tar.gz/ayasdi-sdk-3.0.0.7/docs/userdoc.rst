SDK User Topics
===============

Topics of interest for SDK users, discussed at greater length than
possible in the :doc:`apidoc`:

.. toctree::
   :titlesonly:

   create_group_sets Overview </userdoc/create_group_set_supp_overview>
   create_network Supplemental Overview </userdoc/create_network_supp_overview>
   Custom Distance Metrics </userdoc/custom_distance_metrics>
   get_stats Supplemental Overview </userdoc/get_stats_supp_overview>
   Lenses Overview </userdoc/lenses_supp_overview>
   Logging </userdoc/logging>
   Topological Model Overview </userdoc/topo_model_overview>
   Tranformation Services Overview <transformationsdoc>