get_stats Supplemental Overview
===============================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.Source.source.get_stats` gets statistics on the data within an uploaded source.

To obtain statistics, invoke ``get_stats`` by specifying a dictionary for each column of interest, noting the
desired statistics and relevant metadata in json format.

.. figure:: lists_and_dictionaries.png

The result set supplies the requested statistics as a dictionary that is itself a list of dictionaries. The computed
value for each function is included with the "result" key.

.. figure:: result_set.png


get_stats Parameters
--------------------

The :class:`ayasdi.core.Source.source.get_stats` method is called directly on a source object, with the
following input parameters:

**params** (`[dict]`) -- list of nested dictionaries, one per column of interest. Each dictionary should
contain a column key (the name of the column of interest) and at least one function key (the statistics to
compute). You can also add other metadata, such as ``"ignore_nulls" : True``.

**group_id** (`int`) -- specifies a row group against which to compute statistics. (optional)

**complement** (`bool`) -- if True, selects all the other rows in the dataset that are not contained
in the specified group (its *compliment*). (optional with group_id)

**filter_set** -- if provided, selects rows that match this column-based filter set. See :func:`create_filter_set`.
(optional)

**group_ids** (`int`) -- If provided, directs the platform to compute statistics against a group, identified by a
list of ids. (optional)


Supported Functions
-------------------

Specified as a list of dictionaries, one for each function.

**Categorical** statistics supported include "count", histogram", "mode", "num_nulls", "num_uniques", and "uniques".

**Continuous** statistics supported include "avg", "count", "distribution", "histogram", "max", "median, "min",
"mode", "num_nulls", "num_uniques", "stddev", "sum", and "uniques".

.. Note::

    ``ignore_nulls`` is an optional parameter that specifies that nulls be ignored in a particular calculation.
    If not provided, the platform assumes ``ignore_nulls=False``.

    For ``stddev`` you must set ``ignore_nulls=True``. For all other parameters, you can either ignore nulls
    or include them.


**avg** -- Returns the average of all values found in the column. Use only for numeric column types.


**count** -- Returns the number of values found in the column.


**distribution** ([int]) -- Provides distribution curve data in list form, expressed as a list of ``ntiles`` -- 
    float values between 0.0 and 1.0 that specify what percentile of the column value should be returned. For 
    example, specifying 0.1 returns the value of the 10th percentile of the column value, specifying 0.6 returns 
    the value of the 60th percentile of the column value, etc.
    The value of the specified ``ntile`` is returned in the ``result`` parameter.
    If no distribution is specified, the function provides results of the 0th, 25th, 50th, 75th, and 100th
    percentiles by default.
    Use only for numeric column types.


**histogram** -- Returns the histogram of values in a column, in the form of boundaries and counts.
    Histogram statistics work on both numeric and string columns. For string columns, distinct values are 
    represented by the ``boundaries`` option.
    To determine the number of buckets used in the calculation, set the ``bin`` argument (default value=10).
    Use only for numeric column types.


**max** -- Returns the highest (maximum) value in the column. Use only for numeric column types.


**mean** -- Returns the average value in the column.


**median** -- Returns the middle value in the column. Use only for numeric column types.


**min** -- Returns the lowest (minimum) value in the column. Use only for numeric column types.


**mode** -- Provides most frequently-occurring value within a column, set of columns, filter set, or group of filter
    sets. Use only for numeric column types.


**num_nulls** -- Returns the count of null values within a column.


**num_uniques** -- Returns the number of unique values within a column.


**stddev** -- Returns the sample standard deviation from the mean. Requires ``ignore_nulls=True``. Use only for
    numeric column types.


**sum** -- Returns the sum of all the values in the column. Use only for numeric column types.


**uniques** -- Returns the distinct values with a column.


Sample Code
-----------
To get the average and median of a datasource column named "balance" and the median of a second column named "net_worth",
the code might look like this:

.. code-block:: python

        import ayasdi.core as ac
        import ayasdi.core.models as acm

        source = connection.get_source(id=820025710523744372)
        source.sync()
        results = source.get_stats([
                {
                    "column" : "balance",
                    "functions" : [
                        {"name" : "median"},
                        {"name" : "avg",}
                    ]
                },
                {
                    "column" : "net_worth",
                    "functions" : [
                        {"name" : "median",}
                    ]
                }
            ]
           )



Sample Output
-------------
The result set provides the requested statistics in the form of a dictionary that contains a list of dictionaries
for each column of interest.  The computed value for each function is included with the "result" key.

.. code-block:: python

        {u'complement': False,
         u'creation_time': None,
         u'creator_id': None,
         u'group_id': None,
         u'params': [{u'column': u'balance',
                      u'functions': [{u'bins': None,
                                      u'ignore_nulls': False,
                                      u'name': u'median',
                                      u'ntiles': None,
                                      u'result': [259.0],
                                      u'type': u'double'},
                                     {u'bins': None,
                                      u'ignore_nulls': False,
                                      u'name': u'avg',
                                      u'ntiles': None,
                                      u'result': [255.61606513454538],
                                      u'type': u'double'}]},
                     {u'column': u'net_worth',
                      u'functions': [{u'bins': None,
                                     u'ignore_nulls': False,
                                     u'name': u'median',
                                     u'ntiles': None,
                                     u'result': [310.5068644],
                                     u'type': u'double'}]}],
        u'warnings': None}


When `'bins` and`'ntiles'` were not specified, the dictionary notes their values as **None**.
