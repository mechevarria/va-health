============================
Lenses Supplemental Overview
============================

.. highlight:: python
   :linenothreshold: 2

This page provides comprehensive information about the use of lenses in data analysis.

For information about the use of lenses when specifying a params_dict, see :doc:`create_network_supp_overview`.

For use cases pertaining to lenses in data analysis, see the Ayasdi Support Community.

SDK Methods that get or specify lenses include:
    - :class:`ayasdi.core.source.Source.create_network`
    - :class:`ayasdi.core.source.Source.get_valid_lenses`
    - :class:`ayasdi.core.source.Source.outcome_lens_param_optimization`
    - :class:`ayasdi.core.unsupervised_analysis.auto_network_spec.AutoNetworSpec.lens_filter`


What is a Lens?
===============

A lens is a function that converts a dataset into a vector, where each row in the original dataset contributes
to a real number in the vector. A lens operation assigns a single number to every row. The lens determines how
the data is partitioned into bins for clustering. It helps bring various aspects of the data into focus".

There are two types of lenses: data lenses and computed lenses.

Data Lenses
-----------

A **data lens** is a pre-computed value that already exists in a specific column for a given row of data. For
example:

.. code-block:: python

    'lenses':[{'resolution':30,'gain':2,'equalize':True,'id':'L-Infinity Centrality'}]

There are continuous data lenses and categorical data lenses.

For a table of all lenses supported by the Ayasdi Python SDK, see "Lenses Quick Reference", later in this page.

Computed Lenses
---------------

A **computed lens** is computed from values in the data row, "on the fly", when they are specified in a code block:

.. code-block:: python

    {u'metric': {u'id': u'type_of_metric'},
    u'column_set_id': u'-id_number',
    u'lenses': [
        {u'resolution': nn, u'gain': n.nnnnnnnnnnnnnnnn, u'equalize': True|False, u'id': u'lens_type'}],
    u'clustering_algorithm':{'type':'sl_hermite'}}

Choosing A Lens
---------------

Lenses and data lenses are often used together in the same analysis. When you use multiple lenses for
an analysis, the platform handles them by considering their Cartesian product. Thus, two lenses map the
original dataset into two dimensional open covered space R, three lenses map the dataset into three dimensional
open covered space R , etc.

We recommend that you experiment with different choices of one lens or sets of lenses, and with different settings
for resolution and gain.

Lens Specification Parameters
=============================

The main components of a lens are its resolution, its gain, and its type. When you specify a lens you can also
direct it to equalize the groups created; that is, distribute the data points so all groups are approximately
the same size.

Resolution
----------
Resolution controls the number of groups that are created within the range of selected lens values.

To view only the most basic subpopulations in your data, create analyses with low resolution.

To create groups that are smaller and more distinct, with stronger associations between members, create analyses with high
resolution.

As resolution increases, structures in your data that wouldn't otherwise be visible, can become clear. However, as your
groups become smaller and more finely tuned, the number of singletons may also increase.

Resolution can be expressed as the number of groups in the data source after mapping.

Legal values for resolution can range from 1 to a number equal to the total number of rows in your analysis.


Gain
----

Gain is the extent to which group partitions overlap.

As gain increases, the number of edges (connectors) in the plot increases, leading to data oversampling. This oversampling
sometimes highlights relationships with the data.

Reducing the gain results in smaller groups of nodes, and more singletons.

Gain can be expressed as the percentage overlap between groups, where:

    pct_overlap = 1 - (1/gain)

Legal values for gain can range from 0 to 1.


Equalize
--------

Equalization creates groups have roughly the same number of rows. It is often useful when the data distribution is very skewed,
or non-uniform.

When equalize is set to True, the platform distributes the rows in the groups so that each group has an equal number of
rows. This creates groups that appear to be more uniform and evenly distributed.

When equalize is not set, or set to False, all groups are the same size, but (depending on the distribution of the
underlying data) may contain a drastically different number of rows.


Lenses Quick Reference
======================

+--------------------------------+-------------------------------+------------------------------+
| 'Approximate Kurtosis'         | 'Max'                         | 'Neighborhood Graph Lens'    |
+--------------------------------+-------------------------------+------------------------------+
| 'Entropy'                      | 'MDS coord 1'                 | 'Neighborhood Lens 1'        |
+--------------------------------+-------------------------------+------------------------------+
| 'Gaussian Density'             | 'MDS coord 2'                 | 'Neighborhood Lens 2'        |
+--------------------------------+-------------------------------+------------------------------+
| 'Isomap coord 1'               | 'Mean'                        | 'PCA coord 1'                |
+--------------------------------+-------------------------------+------------------------------+
| 'Isomap coord 2'               | 'Median'                      | 'PCA coord 2'                |
+--------------------------------+-------------------------------+------------------------------+
| 'L1 Centrality'                | 'Metric PCA coord 1'          | 'UMAP lens 1'                |
+--------------------------------+-------------------------------+------------------------------+
| 'L-Infinity Centrality'        | 'Metric PCA coord 2'          | 'UMAP lens 2'                |
+--------------------------------+-------------------------------+------------------------------+
| 'Raw Entropy'                  | 'Variance'                    |                              |
+--------------------------------+-------------------------------+------------------------------+

For summaries of each lens type, including each lens equation, see
https://ayasdicommunity.force.com/s/article/Knowledge-Using-Lenses.


Bibliography
============
https://ayasdicommunity.force.com/s/article/Knowledge-Configuring-Lens-Options

https://ayasdicommunity.force.com/s/article/Knowledge-Using-Lenses

https://ayasdicommunity.force.com/s/article/Knowledge-Using-data-lenses
