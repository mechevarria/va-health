==========================
create_group_set Overview
==========================

.. highlight:: python
   :linenothreshold: 2

This page provides in-depth information about how to create a group set using :class:`ayasdi.core.source.create_group_set`.

The create_group_set Method
============================
Creates a :class:`ayasdi.core.groupconfig.GroupSet` object; essentially, a dictionary with the following
accessible keys:
    - u'groups'
    - u'entity_uri'
    - u'creationTime'
    - u'creatorID'
    - u'id'
    - u'name'

The dictionary format reflects the types of groups included, how the group set was created, and (for
continuous_group_sets) the bucketing method.

You can create a group_set by simply specifying a list of ids, OR you can create any of the following types of
group sets:

    * categorical_group_set
    * continuous_group_set
    * network_based_sampled_group_set
    * sampled_group_set
    * stratified_sampled_group_set


categorical_group_set
=====================
A categorical group set is comprised of data that can divided into categories, such as race, sex, age group, and
educational level.

Categorical group sets return a dictionary with the following keys:

+-----------------------+--------------------------------------------------------------------------------+
| Key                   | Description                                                                    |
+-----------------------+--------------------------------------------------------------------------------+
| group_id              | id of the group against which analysis should be performed. If not provided,   |
|                       | analysis is performed against the entire dataset.                              |
+-----------------------+--------------------------------------------------------------------------------+
| categorical_column_id | specifies the id (index) of the categorical column.                            |
+-----------------------+--------------------------------------------------------------------------------+
| number_categories     | specifies the number of groups to create. (optional)                           |
|                       |                                                                                |
|                       | If you specify a number that is less than the number of unique categories      |
|                       | in the dataset, groups in the group_set are created based on the               |
|                       | categories with the largest counts.                                            |
|                       |                                                                                |
|                       | If you specify a number that is greater than or equal to the number of unique  |
|                       | categories in the dataset, groups in the group_set are created based on the    |
|                       | number of unique categories.                                                   |
|                       |                                                                                |
|                       | If you do not specify a number, the groups in the group_set are created        |
|                       | based on the number of unique categories.                                      |
+-----------------------+--------------------------------------------------------------------------------+


continuous_group_set
====================
A continuous group set is comprised of data that can be measured on a continuous scale, either qualitatively or
quantitatively.

Continuous group sets always return a dictionary with the following keys:

+---------------------------+--------------------------------------------------------------------+
| Key                       | Description                                                        |
+---------------------------+--------------------------------------------------------------------+
| group_id                  | id of the group against which analysis should be performed. If not |
|                           | provided, analysis is performed against the entire dataset.        |
+---------------------------+--------------------------------------------------------------------+
| rolling_direction_forward | specifies whether row indices should be grouped in ascending value |
|                           | order (True) or descending value order (False). Default=True       |
+---------------------------+--------------------------------------------------------------------+
| continuous_column_id      | specifies the index of the continuous column.                      |
+---------------------------+--------------------------------------------------------------------+
| max_group_count           | specifies the desired number of groups to create.                  |
|                           |                                                                    |
|                           | If not provided, defaults to 100.                                  |
+---------------------------+--------------------------------------------------------------------+

You must also specify a bucketing mode to be passed into the dictionary, creating buckets either
cumulatively or non-cumulatively.

**Cumulative Buckets**

Dictionary used to create buckets cumulatively. To specify a cumulative bucket you must provide a value for
``start_bucketing_value`` AND either (``first_bucket_size, incremental_bucket_size``) OR
(``first_bucket_width, incremental_bucket_width``).

+---------------------------+--------------------------------------------------------------------+
| Key                       | Description                                                        |
+---------------------------+--------------------------------------------------------------------+
| start_bucketing_value     | value in the continuous column where bucketing will start          |
+---------------------------+--------------------------------------------------------------------+
| first_bucket_size         | specifies the number of rows for the first group created           |
+---------------------------+--------------------------------------------------------------------+
| incremental_bucket_size   | specifies the number of rows to add to the bucket size for each    |
|                           | group subsequently created                                         |
+---------------------------+--------------------------------------------------------------------+
| first_bucket_width        | specifies the range of values for the first group  created         |
+---------------------------+--------------------------------------------------------------------+
| incremental_bucket_width  | specifies an amount to expand the range of values for each         |
|                           | group subsequetly created                                          |
+---------------------------+--------------------------------------------------------------------+


**Non-Cumulative Buckets**

Dictionary used to create buckets non-cumulatively. To specify a non-cumulative bucket you must provide
a value for EITHER ``bucket_size`` OR ``bucket_width``.

+---------------------------+--------------------------------------------------------------------+
| Key                       | Description                                                        |
+---------------------------+--------------------------------------------------------------------+
| start_bucketing_value     | value in the continuous column where bucketing will start          |
|                           | (optional)                                                         |
+---------------------------+--------------------------------------------------------------------+
| bucket_size               | specifies the number of rows per group set                         |
+---------------------------+--------------------------------------------------------------------+
| bucket_width              | specifies the range of values per group set                        |
+---------------------------+--------------------------------------------------------------------+
| overlap                   | specifies the amount of overlap in the value range for each        |
|                           | group (optional)                                                   |
+---------------------------+--------------------------------------------------------------------+


network_based_sampled_group_set
===============================
A network-based sampled group set is comprised of data sampled from the nodes of a network.

Network-based sampled groups sets return a dictionary with the following keys:

+---------------------------+--------------------------------------------------------------------+
| Key                       | Description                                                        |
+---------------------------+--------------------------------------------------------------------+
| network_id                | identifies the network to be sampled.                              |
+---------------------------+--------------------------------------------------------------------+
| specifications            | list of specifications, each of which is a dictionary. Includes    |
|                           | the following keys:                                                |
|                           |                                                                    |
|                           | num_rows_in_group -- target number of rows for the created group.  |
|                           | (The actual number of rows returned may be slightly different.)    |
|                           |                                                                    |
|                           | seed -- seed for the random number generator. Default=1234         |
|                           | (optional)                                                         |
+---------------------------+--------------------------------------------------------------------+
| disjoint                  | when True, creates sampled groups that do not overlap.             |
|                           | Default=False  (optional)                                          |
+---------------------------+--------------------------------------------------------------------+



sampled_group_set
=================
A sampled group set is comprised of rows randomly sampled from the dataset. To return a ``sampled_group_set``
you must specify EITHER ``num_rows_in_group`` OR ``percent_in_group``.

Sampled group sets return a dictionary with the following keys:

+---------------------------+--------------------------------------------------------------------+
| Key                       | Description                                                        |
+---------------------------+--------------------------------------------------------------------+
| group_id                  | id of the group against which analysis should be performed. If not |
|                           | provided, analysis is performed against the entire dataset.        |
+---------------------------+--------------------------------------------------------------------+
| num_rows_in_group         | target number of rows for the created group. (The actual number of |
|                           | rows returned may be slightly different.)                          |
+---------------------------+--------------------------------------------------------------------+
| percent_in_group          | an array of floats (0.0 - 1.0), one for each group to be created.  |
|                           | Each entry represents the percentage of the total rows to be       |
|                           | included in that group.                                            |
+---------------------------+--------------------------------------------------------------------+
| seed                      | seed for the random number generator. Default=1234 (optional)      |
+---------------------------+--------------------------------------------------------------------+


stratified_sampled_group_set
============================
A stratified sampled group set is comprised of stratified samplings from an outcome column, according to that column's
value distribution.

Stratified sampled group sets return a dictionary with the following keys:

+---------------------------+--------------------------------------------------------------------+
| Key                       | Description                                                        |
+---------------------------+--------------------------------------------------------------------+
| group_id                  | id of the group against which analysis should be performed. If not |
|                           | provided, analysis is performed against the entire dataset.        |
+---------------------------+--------------------------------------------------------------------+
| outcome_column_index      | specifies the index of the outcome column whose contents will form |
|                           | the basis of the group set.                                        |
+---------------------------+--------------------------------------------------------------------+
| specifications            | list of specifications, each of which is a dictionary. Includes    |
|                           | the following keys:                                                |
|                           |                                                                    |
|                           | num_rows_in_group -- target number of rows for the created group.  |
|                           | (The actual number of rows returned may be slightly different.)    |
|                           |                                                                    |
|                           | seed -- seed for the random number generator. Default=1234         |
|                           | (optional)                                                         |
+---------------------------+--------------------------------------------------------------------+
| disjoint                  | when True, creates sampled groups that do not overlap.             |
|                           | Default=False  (optional)                                          |
+---------------------------+--------------------------------------------------------------------+
