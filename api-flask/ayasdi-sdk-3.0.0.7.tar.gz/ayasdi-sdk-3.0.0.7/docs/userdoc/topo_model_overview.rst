==========================================
Topological Prediction with the Ayasdi SDK
==========================================

This page presents an overview of the Topological Prediction capability that is available with the Ayasdi Machine
Intelligence Platform (MIP) via the Ayasdi SDK.

We assume you are familiar with how to create Topological Models (a.k.a. Topological Networks) using the Ayasdi
platform. For a walk-through of that process, see the tutorial :doc:`tutorials/create_a_network`.

This document is intended to provide details on the available parameters beyond what we document in the :doc:`apidoc`.


Topological Prediction
======================

Prediction is at the heart of many value add use cases in business, academia and research. The Ayasdi Topological
Predict capability is a first of its kind in that it leverages the Topological Model that is created with the Ayasdi
platform itself.

As a refresher, remember that a Topological Model consists of a set of nodes, each of which may be connected to
another set of nodes by edges based on the underlying mathematics (i.e. as a result of the Topological Data Analysis
machinery).

Each node consists of a subset of the original rows or data points in the original data source (think: a subset of
the rows in the source CSV).

Furthermore, the Ayasdi Platform allows users to create Groups which consist of a subset of the nodes in the Model.

The prediction works by taking as input some form of query data, and returning among three types of data in the response:

  - A determination of which node of the Topological Model would contain this new incoming data point;
  - IDs for the nearest neighboring data points (or rows, i.e. the “nearest neighbors”), as well as groups and nodes that
    contain those nearest neighboring data points.
  - Optionally, a predicted value for some feature of the incoming data point (here "feature" is analogous to a column in
    the source CSV).

You can create a topological model using the Ayasdi Workbench or the Ayasdi Python SDK using a properly formatted data
source, then leverage the prediction capability that makes use of this topological model.

.. note::
    Today, this prediction capability is available only via the Ayasdi Python SDK.

The Topological Predict function is documented in our SDK at ``Network.topological_predict``.


Topological Predict Input Parameters
====================================

This section describes the input parameters for the Topological Predict function.

Query Data
----------

Prediction requires providing query data as input, that is, data that represents the incoming data point(s)
for which you’d like to make a prediction.

There are three parameters that are available to allow a user to specify query data as input to the
``topological_predict`` function. Only one of these three parameters is required for this function.

  - **data_point_array** -- Used to specify a list of data points. (One can think of this as a list of rows in
    a data source CSV.) The list returned is actually a “list of lists,” where each individual list represents
    a separate data point (or “row”).
    In other words, each incoming data point is itself input as a list of features into the predict function.

  - **data_point_row_ids** -- Used to specify the row ids of the underlying data source for which to apply the
    prediction(s). Helpful when the underlying data source from which the Topological Model was created
    to serve two purposes:
      -  as the source containing the data points from which to generate the topological model/network, and
      - as the source from which to obtain the incoming data points to apply prediction.

  - **data_point_group_id** -- Used in cases where there are existing groups for the current data source, and
    the user wants to obtain prediction for the data points (or rows) that are contained in these groups. This
    parameter provides a list of IDs of groups containing that query data.


Search in Groups/Group Sets
---------------------------

In addition to the input query data for prediction, users can specify which data to predict against from the
underlying data source.

A data source can contain both individual Groups (i.e. groups of nodes in the Topological Model or “Node
Groups”) or Group Sets which consist of groups of individual rows.

One of the following two optional parameters can be passed to specify which Groups or Group Sets to use when
applying the prediction algorithms (as opposed to say, simply predicting against the entire dataset:

  - **search_in_groupset_ids** – the list of ids for the groupsets that belong to the underlying data source
    for the Topological Model
  - **search_in_group_ids** - the list of ids for groups belonging to the underlying data source for the
    Topological Model


Neighbors: Minimum and Maximum Counts
-------------------------------------

Earlier we noted that a developer can use this function to not only retrieve the nearest neighbors and
their associated nodes and groups given the query data, but also to optionally predict values for a desired
set of features (i.e. columns) for the set of query data points.

When choosing to predict a value, there must be a minimum set of nearest neighbors that can be used as input i
nto the prediction mechanism. (This minimum number of neighbors corresponds to the data points, and not the
number of neighboring nodes.)

Relevant parameters:

  - **neighbors_count** - specifies the minimum set of nearest neighbors to return

  - **neighbors_count** - specfies the maximum number of qualified neighbors to return


Information Returned: Rows, Columns
-----------------------------------

  - **return_closest_rows** (`bool`) -- used in cases where the output of the topological prediction is only to be used in a
    streaming, near-real-time fashion, where it might not be necessary to return the IDs for the data points (i.e. rows)
    of the closest neighbors. (Default: False)

  - **return_closest_rows_column_set_id** -- used to specify a specific set of column to return for each of the nearest
    neighbors.


Information Returned: Groups and Nodes
--------------------------------------
When retrieving the nearest neighboring data points, the developer can optionally obtain the nodes and groups that contain
those individual data points. These will be returned in the function response by passing the following parameters as true (both are false by default):

  - **return_containing_nodes**
  - **return_containing_groups**


Prediction
----------
  - **predict_columns** - specify this option to predict an actual value for a specific feature or column. For
    each column to be predicted, include the following via a Python list:
      - *column_id* or *column_name* for each of the columns to be predicted, for each of the query data points
      - *calculation_method*, expressed as one of the following:
          - "mode" –- value that appears most often for that column for all of the nearest neighbors
          - "mean" -- the mean value for this column based on the values for all of the nearest neighbors
          - "median" -- the value at the mid-point of the values for all of the nearest neighbors
      - *interpolation_source* -- The neighbors to use as a basis for the prediction.
        Possible values:
          - “neighbor-rows”
          - “containing-nodes” – i.e. all of the data points that exist in each of the nodes that contain each of the
            nearest neighbors
          - “containing-groups” – i.e. all of the data points that exist in each of the groups that contain each of the
            nearest neighbors (in this sense, refers to Node Groups)


Predicting Against a Set of Groups
------------------------------------------------------

  - **selection_criteria** -- Used when the developer desires to predict against a set of groups, to specify which
    groups are to be included in the prediction calculation. Available options are passed as a string. They include:
      - *all* – predict against all available groups
      - *centrality* – predict against the group in which the query data point is most equidistant from all
        other data points
      - *biggest* – predict against the group with the most data points
      - *smallest* – predict against the group with the least number of data points
      - *mode* – predict against the group that contains the highest number of the total nearest neighbors that as determined
        by this utilizing this function

**Response**

The format of the response for this function can be found in the documentation for ``Network.topological_predict``.

Note that individual response parameters may depend on which of the optional input parameters were set.

**Lenses**

In general, Ayasdi recommends making use of this feature whenever the following lenses have been used in the generation of the Topological Model:

  - neighborhood lenses
  - neighborhood graph lenses

