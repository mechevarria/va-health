Logging
=======

.. highlight:: python
   :linenothreshold: 2

The EurekaAI Python SDK uses the `Python logging module
<https://docs.python.org/2/library/logging.html>`_ for logging
information, warning messages, and error messages.

The first step to enabling logging is to set set up your logger:

.. code-block:: python

    import logging
    LOGGER = logging.getLogger('ayasdi')


**If you would like to log all code** including your own, import the "root" logger:

.. code-block:: python

    import logging
    LOGGER = logging.getLogger()


**To create a handler to print log outputs to the console**, run:

.. code-block:: python

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setLevel(logging.DEBUG)
    LOGGER.addHandler(stream_handler)

**To save the log statements to a file**, you can also add a log handler. Run:

.. code-block:: python

    LOG_FILENAME = 'test_debug.log'
    # Set maxBytes to the maximum size of the file you would like to save
    file_handler = logging.handlers.RotatingFileHandler(LOG_FILENAME,
                                                        maxBytes=20000)
    file_handler.setLevel(logging.DEBUG)
    LOGGER.addHandler(file_handler)

**To log uncaught exceptions**, you can run the following code. This replaces sys.excepthook with your
own handler, which will write the traceback information to the logger.

.. code-block:: python

    import sys
    def uncaught_exception_handler(exc_type, exc_value, exc_traceback):
        LOGGER.error("Uncaught exception",
                     exc_info=(exc_type, exc_value, exc_traceback))

    sys.excepthook = uncaught_exception_handler

