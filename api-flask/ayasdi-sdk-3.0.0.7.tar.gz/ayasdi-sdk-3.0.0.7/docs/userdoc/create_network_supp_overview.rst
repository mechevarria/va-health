====================================
create_network Supplemental Overview
====================================

.. highlight:: python
   :linenothreshold: 2

This page provides in-depth information about aspects of topological network creation.

About Source.create_network
===========================

:class:`ayasdi.core.source.Source.create_network` enables you to create a topological network programmatically from
an underlying data source. It is analogous to what the UI offers in Workbench, with additional
advanced optional capabilities that are not available in Workbench.

The method is commonly specified with the required parameters name and params_dict. For example:

.. code-block:: python

    network_params_dict = {
                 'metric' : {'id' : 'Cosine'},
                  'column_set_id' : col_set['id'],
                  'lenses' : [{'resolution' : integer, 'gain' : integer,
                               'id' : 'string',
                               'equalize' : True|False}]}

    network = src.create_network('network_name', network_params_dict)

where ‘network_name’ specifies the name of the network (for instance, as it would appear in Workbench).

The network_params_dict provides the params_dict, i.e. the parameters required for network creation.

.. Note::
   When defining the column_set to be used in creating the network, we recommend you also use
   :class:`ayasdi.core.source.Source.get_valid_metrics` and :class:`ayasdi.core.source.Source.get_valid_lenses`. These
   methods return the list of metrics and lenses that are valid and compatible with the provided source and column
   set. You can then copy and paste from the returned list for convenience.

   For example, running

   .. code-block:: python

      column_set = src.get_column_set(name='output layer')
      src.get_valid_metrics(column_set = column_set)

   returns output similar to:

   .. code-block:: python

      [{u'id : u'Euclidean (L2)', u'source_id: None, u'specifications': None},
       {u'id : u'Variance Normalized Euclidean',
        u'source_id: None,
        u'specifications': None},
       {u'id': u'Cosine', u'source_id': None, u'specifications': None},
       .
       .
       .
       {u'id : u'Affine', u'source_id': None, u'specifications': None}]



Specifying the params_dict
==========================

A params_dict is a dictionary that specifies a set of desired network creation parameters.

The format of a params_dict definition is:

.. code-block:: python

    {u'metric': {u'id': u'type_of_metric'},
    u'column_set_id': u'-id_number',
    u'lenses': [
        {u'resolution': nn, u'gain': n.nnnnnnnnnnnnnnnn, u'equalize': True|False, u'id': u'lens_type'}],
    u'clustering_algorithm':{'type':'sl_hermite'}}

where:
    -  **metric** -- Measure of similarity. The SDK supports 18 different types of metrics; see "Available Metrics", below.
        - Key: u'id'
        - Value: (`str`)
    - **column_set_id** -- Numeric ID identifying a particular column set.
        - Key: u'column_set_id'
        - Value: (`str`)
    - **row_group_id** -- Numeric ID identifying a particular group.
        - Key: u'row_group_id'
        - Value: (`str`)
    - **lenses**
        - **Resolution** -- Controls the number of bin partitions that will be created within the range of selected lens values; clustering then takes place within these bins. Increasing resolution increases the number of nodes in the map.
            - Key: u'resolution'
            - Value: (`int`)
        - **Gain** -- Defines the amount of overlap between buckets after lens mapping. Increasing gain increases the number of edges in the map.
            - Key: u'gain'
            - Value: (`int`)
        - **Equalize**  -- When True, equalize directs the params_dict to create buckets that have roughly the same number of points in each bin. When False, bucketing/binning happens without regard for equalization.
            - Key: u'equalize'
            - Value: (`str`) True|False
        - **Type** -- The SDK supports 14 different types of lenses; see "Available Lenses", below.
            - Key: u'id'
            - Value (`str`): u'lens_type'
    - **clustering_algorithm** -- (optional) specifies the clustering technique to be used in network creation. Specified in the form of a dictionary. For further information see "Clustering Algorithm", below.
            - Key: clustering_algorithm
            - Value (`dict`): {type: sl_histogram|sl_hermite}
            - Key: type
            - Value (`str`): sl_histogram|sl_hermite


Available Metrics
-----------------

+------------------------------+------------------------------+---------------------------------+
| 'Absolute Correlation'       | 'Correlation'                | 'IQR Normalized Euclidean'      |
+------------------------------+------------------------------+---------------------------------+
| 'Affine'                     | 'Cosine'                     | 'Jaccard'                       |
+------------------------------+------------------------------+---------------------------------+
| 'Angle'                      | 'Distance Correlation'       | 'Manhattan (L1)'                |
+------------------------------+------------------------------+---------------------------------+
| 'Binary Jaccard'             | 'Euclidean'                  | 'Norm Angle'                    |
+------------------------------+------------------------------+---------------------------------+
| 'Categorical Cosine'         | 'Euclidean (L2)'             | 'Norm Correlation'              |
+------------------------------+------------------------------+---------------------------------+
| 'Chebyshev (L-Infinity)'     | 'Hamming'                    | 'Variance Normalized Euclidean' |
+------------------------------+------------------------------+---------------------------------+
|                              | 'Haversine'                  |                                 |
+------------------------------+------------------------------+---------------------------------+

Available Lenses
----------------

+--------------------------------+-------------------------------+------------------------------+
| 'Approximate Kurtosis'         | 'Max'                         | 'Neighborhood Graph Lens'    |
+--------------------------------+-------------------------------+------------------------------+
| 'Entropy'                      | 'MDS coord 1'                 | 'Neighborhood Lens 1'        |
+--------------------------------+-------------------------------+------------------------------+
| 'Gaussian Density'             | 'MDS coord 2'                 | 'Neighborhood Lens 2'        |
+--------------------------------+-------------------------------+------------------------------+
| 'Isomap coord 1'               | 'Mean'                        | 'PCA coord 1'                |
+--------------------------------+-------------------------------+------------------------------+
| 'Isomap coord 2'               | 'Median'                      | 'PCA coord 2'                |
+--------------------------------+-------------------------------+------------------------------+
| 'L1 Centrality'                | 'Metric PCA coord 1'          | 'UMAP lens 1'                |
+--------------------------------+-------------------------------+------------------------------+
| 'L-Infinity Centrality'        | 'Metric PCA coord 2'          | 'UMAP lens 2'                |
+--------------------------------+-------------------------------+------------------------------+
| 'Raw Entropy'                  | 'Variance'                    |                              |
+--------------------------------+-------------------------------+------------------------------+

.. Note::
    For further information about lenses, see :doc:`lenses_supp_overview`.


Example params_dict
-------------------
In this example we specify metric, column_set_id, and lenses:

.. code-block:: python

        {'metric':{'id':'Correlation'},
        'column_set_id':123456789,
        'lenses':[{'resolution':30,'gain':2,'equalize':True,'id':'L-Infinity Centrality'}]



Clustering Algorithm
====================

The clustering algorithm parameter in the params_dict is an option used to specify a clustering algorithm for use in Topological Model generation.

The clustering algorithm is also specified within the params_dict, in the form of a dictionary:

.. code-block:: python

        {type: sl_hermite|sl_histogram}


where:
    - **sl_histogram** -- The sl_histogram algorithm predates sl_hermite, and remains the default. (Specifying the clustering algorithm is optional.)
    - **sl_hermite** -- The sl_hermite algorithm (preferred) was introduced in version 6.7 of the platform, and helps to generate better networks than the original sl_histogram option when there is a significant amount of noise in the data source.

The following example shows a `create_network` method with sl_hermite specified as the clustering_algorithm:

.. code-block:: python

        {'metric':{'id':'Correlation'},
        'column_set_id':colset['id'],
        'lenses':[{'resolution':30,'gain':2,'equalize':True,'id':'L-Infinity Centrality'}],
        'clustering_algorithm':{'type':'sl_hermite'}}

For all in the points in the bucket to be clustered (gathering points that have lens values within a given interval), the Platform uses the metric defined by the user, to build a minimum spanning tree (MST). The Platform convolves the distances found in the MST with a Hermite function (the derivative of a Gaussian). This algorithm chooses the cut-off threshold to be the mean of the first two zero crossings of the described function.

Example code to be added:
    - Simple example
    - One with sampling_algorithm
    - One with clustering algorithm



See Also
========

    - For further information about lenses, see :doc:`lenses_supp_overview`.


