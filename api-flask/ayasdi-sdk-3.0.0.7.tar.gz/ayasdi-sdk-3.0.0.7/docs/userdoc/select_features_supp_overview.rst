========================
select_features Overview
========================

.. highlight:: python
   :linenothreshold: 2


:doc:`LABS feature <labs>` -- :class:`ayasdi.core.source.Source.select_features` enables Ayasdi Python SDK
users to pre-select a subset of features from an uploaded dataset to be used in analysis. By reducing the data to be
examined to those features that are most relevant to the goals of the analysis (removing those that are less
relevant), you can:

    * save significant computational resources during the actual analysis;
    * create models based on this feature subset more quickly and with improved performance; and
    * more seamlessly add new features to the analysis, such as :class:`ayasdi.core.transformations`.

select_features Method Overview
===============================

Most feature selection with ``Source.select_features``starts with the definition of a column set (the pre-selection):

.. code-block:: python

            src = dataset_name['src']
            columns_for_analysis = ['column name 1',
                                     'column name 2',
                                     'column name etc',
            candidate_column_set = \
                    src.create_column_set(column_list=columns_for_analysis, name='candidate_column_set')


You can specify both a metric and a selection_method to effect feature selection. If you don't specify a selection
method the SDK assigns one, based on whether or not an outcome column is specified:

    *  **if an outcome column is specified**, the SDK uses mRMR as the selection method algorithm
    *  **if no outcome column is specified**, the SDK uses Landmarking as the selection method algorithm

You can also run ``feature_selection`` against an entire dataset, without first specifying a selection column set.

``Source.select_features`` returns the requested features in the form of a dictionary that looks similar to the
following:

.. code-block:: python

        {u'all_scored_columnsets': None,
        u'column_indices': [3, 2, 0, 5, 4, 1],
        u'nearest_landmarks': None,
        u'recommended_columnset': None,
        u'scored_columns': None}



Selection Methods and Metrics
=============================

The **selection methods** you can specify depend on the type of data you are selecting.

+----------------------------------+------+----------+-------------+-----------+
|                                  |         Selection Method (Algorithm)      |
+----------------------------------+------+----------+-------------+-----------+
| Type of Data                     | mRMR | mRMR-mSMS| Landmarking | Laplacian |
+----------------------------------+------+----------+-------------+-----------+
| Continuous Data                  |  X   |    X     |     X       |           |
+----------------------------------+------+----------+-------------+-----------+
| Categorical Columns              |  X   |    X     |     X       |           |
+----------------------------------+------+----------+-------------+-----------+
| Categorical Outcome column_index |  X   |    X     |             |           |
+----------------------------------+------+----------+-------------+-----------+

where:

    **mRMR** = Min Redundancy Max Relevance

    **mRMR-mSMS** = Min Redundancy Max Relevance, Min Size Max Score -- runs mRMR and then prunes the results
    to favor the best predictive power-to-size ratio

    **Landmarking** -- algorithm that selects a representative feature from each *landmark*. (A landmark
    represents one of an evenly distributed collection of nodes from the topological network.)

    **Laplacian** -- algorithm that selects a feature based on its importance as evaluated by its power of
    *locality preservation*, independent of any learning algorithm.


The **metrics** you can specify depend on your preferred algorithm and the type of column you are selecting.

**Continuous columns** support any combination of selection_method and metric.

**Categorical columns** support the following metric/selection methods:

+------------------+--------------------------------------------------------+
|                  |                       Metrics                          |
+------------------+----+----+-------------+-----------+-----------+--------+
| Selection Method | MI | VI | Correlation | Gaussian  | Euclidean | Cosine |
+------------------+----+----+-------------+-----------+-----------+--------+
| mRMR             | OC |    |      X      |           |           |        |
+------------------+----+----+-------------+-----------+-----------+--------+
| mRMR-mSMS        | OC |    |             |           |           |        |
+------------------+----+----+-------------+-----------+-----------+--------+
| Landmarking      |    | X  |      X      |           |           |        |
+------------------+----+----+-------------+-----------+-----------+--------+
| Laplacian        |    |    |             |    AW     |    AW     |   AW   |
+------------------+----+----+-------------+-----------+-----------+--------+

*OC = requires a specified categorical outcome column; AW = adjacency weight function (Laplacian only)*

where:

    **MI** (Mutual Information) -- measures the mutual dependence between two random variables

    **VI** (Variation of Information) -- measures the distance between two clusters of data

    **Correlation** -- notes when two variables appear to be associated due to their proximity. For each datapoint,
    the average of all the coordinates  is subtracted from each coordinate to create a new dataset. The distance is
    then the cosine of the angle between the new (mean-centered) points.

    **Euclidean** -- finds the Greatest Common Divisor bewteen two datapoints. For each datapoint, subtracts
    the average of all the coordinates from each coordinate to create a new dataset. The distance is then the cosine
    of the angle between the new (mean-centered) points.

    **Cosine** -- computes the angular distance between two rows.


Parameters
==========

**selection_method** (`str`): specifies the method to be used to select features. The methods you can specify depend
on whether or not you specify a categorical outcome column. See the tables above for valid selection methods and
algorithms.


**metric** (`str`): specifies the metric to be used to select features. (see above for valid combinations)


**column_set_id** (`str`): if supplied, identifies the column_set from which to select features. If not supplied,
all columns in the datasource are reviewed. (In other words, if you don't indicate features that you think are of
special interest, ``select_features`` analyzes the entire dataset.)


**outcome_column_id** (`str`): specifies the index of of the outcome column.  Used for outcome-based feature
selection (**selection_method='mRMR'** or **selection_method='mRMR-mSMS'**) as an alternative to specifying the
outcome_column_name.

If ``Landmarking`` is the specified algorithm and neither **outcome_column_id** nor **outcome_column_name** is
provided, the SDK returns an error.


**outcome_column_name** (`str`): specifies the name of the outcome column. Used for outcome-based feature selection
(**selection_method='mRMR'** or **selection_method='mRMR-mSMS'**) as an alternative to specifying the
outcome_column_index.

If ``Landmarking`` is the specified algorithm and neither **outcome_column_id** nor **outcome_column_name** is
provided, the SDK returns an error.


**group_id** (`str`): identifies a group against which to run analysis. If not provided, analysis is run against
all the rows in the datasource. (In other words, if you don't indicate features that you think are of special
interest, ``select_features`` analyzes the entire dataset.)


**row_sampling** (`int`): specifies the maximum number of rows to sample during analysis. The number you specify
will be selected at random from the original dataset. If more are specified in the row group, the number you specify
may be sampled at random. Default=all rows


**max_columns** (`int`): specifies the maximum number of columns to sample from the dataset during analysis. If
not provided, 1000 columns are sampled.


**adjacency_weight_function** (`str`): For use with the Laplacian algorithm only. Specifies the kernel function for
adjacency weights between pairs of data points. Valid options:
    - *Gaussian*: weights are calculated applying a Gaussian kernel to the distance between the corresponding
      points. Default when metric = Euclidean.
    - *Cosine*: Weights are the cosine of the angle between the corresponding data points, considered as vectors.
      Only compatible with Cosine metric.
    - *Binary*: weights are 1 for all neighbor pairs, 0 otherwise.


**async_** (`bool`): when True, runs analysis asynchronously and returns an :class:`ayasdi.core.async_jobs.AsyncJob`
object. The object's ``result`` field is set to a dictionary that describes the result set. (For further information,
see the following section.)


Returns
=======

When ``async_=False``, returns a dictionary containing the following entries:

    +-----------------------------+-----+-----------+-------------+-----------+
    | Entry                       | All | mRMR-mSMS | Landmarking | Laplacian |
    +-----------------------------+-----+-----------+-------------+-----------+
    | column_indices              |  X  |           |             |           |
    +-----------------------------+-----+-----------+-------------+-----------+
    | nearest_landmarks           |     |           |      X      |           |
    +-----------------------------+-----+-----------+-------------+-----------+
    | recommended_columnset       |     |     X     |             |     X     |
    +-----------------------------+-----+-----------+-------------+-----------+
    | all_scored_columnsets       |     |     X     |             |           |
    +-----------------------------+-----+-----------+-------------+-----------+
    | scored_columns              |     |           |             |     X     |
    +-----------------------------+-----+-----------+-------------+-----------+


where:

    - **column_indices**: list of the selected column indices as long values. If mRMR and LaplacianFS
      were specified, these are ordered by score.

    - **nearest_landmarks**: a list of pairs of fields that shows column_index and landmark_index for each pair.

            * column_index (`long`): the index of one of the columns in the input set
            * landmark_index (`long`): the index of the landmark column nearest to the specified column

    - **recommended_columnset**: optimal subset of the first best-scoring column_indices, up to a threshold selected.
      If ``mRMR-mSMS`` was specified, it scores up to 90% of the max score among all column subsets, calculated using
      OAA metrics. If ``Laplacian`` was specified, it provides the best-scoring columns, up to the point where the
      "knee" occurs in the score curve.

      If the mRMR-mSMS algorithm fails to find any column subset with a score higher than a minimum quality threshold,
      the returned set will be empty.

    - **all_scored_columnsets**: a list of pairs of fields showing show size and score for each pair.

            * size (`int`): size of the subset formed by the first 'size' column_indices
            * score (`double`): OAA metric score calculated on the column subset

    - **scored_columns**: orders the list of select column indices as long values


Examples
========
All examples in this section assume that a subset of columns have been selected from the source ``extraglobs`` to
create a candidate column set for analysis:

.. code-block:: python

            >>> src = extraglobs['src'] #ignore-in-doc
            >>> columns_for_analysis = ['relative weight',
            ...                         'blood glucose',
            ...                         'insulin level',
            ...                         'insulin response',
            ...                         'steady state plasma glucose']
            >>> candidate_column_set = \
                    src.create_column_set(column_list=columns_for_analysis, name='candidate_column_set')
            >>> ########


Outcome-based Feature Selection With mRMR
-----------------------------------------

The following example shows feature selection using mRMR, without specifying a group. In this case, row_sampling
is set to 150, which is greater than the total number of rows in the dataset. Thus, all rows in the dataset will be
considered.

The metric used is MI.

.. code-block:: python

            >>> results = \
                    src.select_features(selection_method='mRMR',
            ...                         metric='MI',
            ...                         outcome_column_id='6',
            ...                         column_set_id=candidate_column_set['id'],
            ...                         row_sampling=150, max_columns=4)
            >>> sorted(results.keys())
            ['all_scored_columnsets', 'column_indices', 'nearest_landmarks', 'recommended_columnset', 'scored_columns']
            >>> column_indices = results['column_indices']
            >>> len(column_indices)
            4
            >>> # The id of the column first selected
            >>> column_indices[0]
            3
            >>> ########


Feature Selection with Landmarking and VI
-----------------------------------------

The following example selects features using the Landmarking algorithm with the VI metric. We do not specify an outcome
column.

.. code-block:: python

            >>> results = \
                    src.select_features(selection_method='Landmarking',
            ...                         metric='VI',
            ...                         column_set_id=candidate_column_set['id'],
            ...                         row_sampling=150, max_columns=3)
            >>> results['column_indices'] # List of landmarks
            [1, 2, 4]
            >>> nearest_landmarks = results['nearest_landmarks']
            >>> # key: ID from input; value: ID of nearest landmark
            >>> landmark_map = \
                    dict((lm['column_index'], lm['landmark_index'])
            ...          for lm in nearest_landmarks)
            >>> sorted(landmark_map.items())
            [(1, 1), (2, 2), (3, 2), (4, 4), (5, 1)]
            >>> ########


Feature Selection with mRMR and mSMS
--------------------------------------------------

This final example shows the use of mRMR with mSMS, providing additonal results to the mRMR case: in particular,
an optimal subset of features that combines high total score with small size.

.. code-block:: python

            >>> results = \
                    src.select_features(selection_method='mRMR-MSMS',
            ...                         metric='MI',
            ...                         outcome_column_id='6',
            ...                         column_set_id=
            ...                         candidate_column_set['id'],
            ...                         row_sampling=150, max_columns=4)
            >>> column_indices = results['column_indices']
            >>> len(column_indices)
            4
            >>> # The id of the column first selected
            >>> column_indices[0]
            3
            >>> # The optimal column set recommended by the mRMR-MSMS algorithm
            >>> results['recommended_columnset']
            [3, 2]
            >>> # All scored column subsets, with their size and
            >>> # corresponding OAA Metric-based scoring
            >>> scored_columnsets = results['all_scored_columnsets']
            >>> len(scored_columnsets)
            3
            >>> scored_columnsets[0]['size']
            2
            >>> round(scored_columnsets[0]['score'], 1)
            95.2
            >>> _ = src.delete_column_set('candidate_column_set') # ignore-in-doc

