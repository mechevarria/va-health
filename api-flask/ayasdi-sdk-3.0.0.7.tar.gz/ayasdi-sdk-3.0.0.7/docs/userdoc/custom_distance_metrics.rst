Custom Distance Metrics
=======================

.. highlight:: python
   :linenothreshold: 2

There are some situations where a user has a pre-defined notion of distance between rows in their dataset, that they would like to use as a metric.

For example, if each row is a protein sequence, then the distance between sequences (as computed using a sequence alignment algorithm) could be used as a metric. Or, if each row is a time series variable, then the Wasserstein (or earth-mover's) distance between normalized time series could be used as a metric.

Such metrics are computed by the user, stored in a distance matrix, and uploaded to the Ayasdi platform for use in analysis.

How to Use Custom Metrics
-------------------------

In short, a custom distance matrix is created in any manner that creates a symmetrical distance matrix. That distance matrix file is uploaded to Workbench like a traditional data file. It is then available for selection as a metric for the dataset from which it was derived in the metric selection step while creating a topological model.

The more detailed version of this process begins with the creation custom distance matrix. The mathematics behind creating a custom matrix are left as an exercise for the reader. Workbench matches distance matrices to their corresponding datasets by matching the row counts of the files. In order to create a matching matrix file the following criteria must be met:

* The number of rows in the distance matrix must exactly match the number of data rows (not including the header) in the original data file.
* The distance matrix must be symmetric.
* The matrix must not have headers or row identifiers. Instead it is essential the the row order in the matrix be the same as the row order in the original data file.
* The matrix must have zeros on the proper diagonal.
* The matrix can not be more than 5000 rows.

After a suitable distance matrix has been created, the file is uploaded in the traditional manner.

Example
-------

Here is a short example of using custom distance metrics. First, set up the connection.

.. code-block:: python

    import ayasdi.core as ac
    connection = ac.Api()

Next, upload the data source file and the custom distance metrics file as sources. Create a test column set.

.. code-block:: python

    source = connection.upload_source('my_source.txt')
    cdm = connection.upload_source('distance_metrics_source.txt')
    columns = ["relative weight", "blood glucose",
               "insulin level", "insulin response"]
    col_set = source.create_column_set(columns, "test_column_set")

Create the metric, and then create the network using that metric

.. code-block:: python

    my_metric = {'id': None,
                 'source_id': cdm.id,
                 'specifications': None}
    network = source.create_network("test_network1",
                                    {'metric': my_metric,
                                     'column_set_id': col_set['id'],
                                     'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
                                     'equalize': True, 'gain': 3.0},
                                     {'resolution': 30, 'id': 'MDS coord 2',
                                     'equalize': True, 'gain': 3.0}]})



For further information about using  Custom Distance Metrics in the Workbench, see:
https://support.ayasdi.com/hc/en-us/articles/201881290-Adding-Custom-Data-Metrics

