.. ayasdi documentation master file, created by
   sphinx-quickstart on Tue Feb 10 18:32:35 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. <Remove the text in this box for a warning>
   Current changes in the REST Endpoints renders this api
   unusable. This will be fixed ASAP.

=====================================
EurekaAI Python SDK Documentation Suite
=====================================

EurekaAI Platform version \ |version| \ is now available. For instructions on how to download the latest software and a
PDF version of the SDK Reference and Change Logs, see :doc:`Installation <installation>`.

   .. |link-pre| raw:: html

       <a href="http://10.168.3.163/pythomaton/internal/bootstrap/html/

   .. |link-post| raw:: html

       .html">this page.</a>

.. Note::
    SDK version mismatches with platform are not supported. If you upgrade your platform, please also upgrade
    the EurekaAI Python SDK.


**This documentation provides installation instructions, tutorials, in-depth information, and language reference
for the EurekaAI Python SDK.**

To **check your version** of the EurekaAI Python SDK, run:

.. code-block:: python

    from ayasdi._version import __version__
        print(__version__)


**Contents**

.. toctree::
   :titlesonly:

   installation
   apidoc
   userdoc
   tutorialsdoc
   labs
   changes
   license


**Indices**

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
