========================
ayasdi.core.creds module
========================

.. automodule:: ayasdi.core.creds
    :members:
    :undoc-members:
    :show-inheritance:
