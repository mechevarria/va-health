EurekaAI Python SDK Tutorials
---------------------------

.. highlight:: python
   :linenothreshold: 2

Welcome to the EurekaAI Python SDK Tutorials! Before you begin...

**Check Your SDK version**

SDK version mismatches with platform are not supported. To check your version of the EurekaAI Python
SDK, run:

.. code-block:: python

    from ayasdi._version import __version__
        print(__version__)


To install the latest version, see :doc:`installation`.

**Table of Contents**

.. toctree::
   :titlesonly:

   Getting Started <tutorials/getting_started>
   Your First Topological Network <tutorials/create_a_network>
   Intro to Groups and Autogrouping <tutorials/groups_autogroups>
   Autogrouping With AHCL <tutorials/autogroups_ahcl>
   Autogrouping With Connected Components <tutorials/connected_components>
   Comparing Groups <tutorials/comparing_groups>
   Creating Group Classifiers <tutorials/group_classifiers>
   Outcome Autoanalysis <tutorials/outcome_autoanalysis>
   Affine Metrics <tutorials/affine>
   Applying a Group Classifier <tutorials/topomodel>
   Asynchronous Jobs <tutorials/asynchronous_jobs>
   Metadata <tutorials/metadata>
   Batch Prediction <tutorials/batch_prediction>
   Text Transformations <tutorials/text_transformations>
   Sequential Data <tutorials/sequential_data>
   CSV Vector Data <tutorials/csv_vectors>
