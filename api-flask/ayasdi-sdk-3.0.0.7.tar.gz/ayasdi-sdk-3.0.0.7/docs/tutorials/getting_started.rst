Getting Started
===============

.. highlight:: python
   :linenothreshold: 2

This page describes how to download tutorial data and upload it to the EurekaAI platform, and explains how
to start a fresh EurekaAI notebook.

.. Note::

   We assume that you have already installed the latest version of the EurekaAI Python SDK, as described
   in :doc:`../installation`.

Download Your Tutorial Data
---------------------------

Each tutorial includes a link to the tutorial data. Before you begin the tutorial, click the appropriate link to
download your tutorial data to your desktop.

Create EurekaAI Notebook
-------------------------

1- Open the EurekaAI Workbench.

2- At the upper right corner, click your name. The Workbench displays a drop-down list.

3- Select **</> EUREKAAI NOTEBOOKS**.

4- Select **New > Notebook > Python2**. The Workbench displays a new EurekaAI (Python2) notebook with only
one line.

5- Click **File > Rename** and enter a new name for your notebook.

Note that your notebook is still open.


Upload Your Sample Data to the Platform
---------------------------------------
1- From within your open EurekaAI notebook, connect to the EurekaAI platform. Run:

.. code-block:: python

        import ayasdi.core as ac
        connection = ac.Api()


2- Now upload your sample data to the platform. Run:

.. code-block:: python

        source = connection.upload_source('source_file_name')


where 'source_file_name' is the full name of your data source file, including file extension.

Your data source is now listed on your Workbench Sources page.

3- To obtain the source you just uploaded, run:

.. code-block:: python

        source = connection.get_source(name="source_file_name")


4- To sync the uploaded data source with the EurekaAI platform, run:

.. code-block:: python

        source.sync()


Your data is now ready for use.

.. Note::
   If while getting your uploaded data source you see the message :file:`Your SDK version doesn't match the
   platform version. Please upgrade`, we recommend you upgrade soon. However, your tutorial will still
   execute properly.

