================================
Intro to Groups and Autogrouping
================================

.. highlight:: python
   :linenothreshold: 2

A group is a collection of rows to be analyzed. Logically grouping data points together is a
common task when analyzing a data set. Groups can be useful for a number of reasons, such as
creating a subsample of a dataset, or generating segments of subpopulations where individuals
in the segment are similar to each other, but different in some way from those in another
segment.

Groups can be created:
    - by specifying a set of individual rows to be included, or
    - by using an algorithm, which defines the criteria for including rows in a group.

This tutorial introduces you to the above techniques.

For information on how to use the Workbench to create groups, see "Creating and Modifying Groups"
in the *Ayasdi Workbench User Guide*.

.. Note::
    SDK methods used in this tutorial include:
        - :class:`ayasdi.core.networks.Network.autogroup_create`
        - :class:`ayasdi.core.source.Source.create_group`
        - :class:`ayasdi.core.source.Source.create_network`
        - :class:`ayasdi.core.source.Source.get_group`
        - :class:`ayasdi.core.source.Source.get_network`

About The Dataset
-----------------

:file:`db_test2.txt` provides sample data about 145 diabetes patients, with relevant columns.


Before You Begin
----------------

If you have not completed :doc:`create_a_network` and you need to create a new notebook and/or upload
:file:`db_test2.txt`, first :download:`click here <data/db_test2.txt>` to get the data set, then follow the
instructions in :doc:`getting_started`.

If you want a backup copy of the code in this page, download :download:`groups_autogroups_notebook.zip <data/groups_autogroups_notebook.zip>`.

After you have synchronized your data and connected to the Ayasdi platform, please begin the tutorial.


Connect to the Platform
-----------------------
All interactions between the user and the platform start with connecting to the platform:

.. code-block:: python

  import ayasdi.core as ac
  connection = ac.Api()

.. code-block:: python

    source = connection.get_source(name="db_test2.txt")
    source.sync()


Create a Group
--------------

The following steps create a group, drawing upon the :file:`db_test2.txt` dataset.

**(1) To define the data to be grouped, create a list of row indices.** We'll create a group based on
      rows 6 through 9 of your data.

.. code-block:: python

    list_of_row_indices = [6,7,8,9]


**(2) Create a group based on the indices you just defined,** using :class:`ayasdi.core.Source.source.create_group`.
      Run:

.. code-block:: python

    my_first_group = source.create_group('my_first_group',list_of_row_indices)


**(3) Display the contents of your new group.** Run:

.. code-block:: python

    print my_first_group


**Expected result:**

.. code-block:: python

    {u'row_indices': [6, 7, 8, 9], u'name': u'my_first_group', u'row_join_type': u'union',
    u'creationTime': u'1531264952037', u'row_specifications': [{u'row_indices': [6, 7, 8, 9]}],
    u'creatorId': u'-6118706300561986679', u'id': u'5239174'}

*Notice that the display of my_first_group artifacts includes the entry* **u'id: u'5239174'**. *That number is
the group ID.*

Another way to display the group ID is to run:

.. code-block:: python

    id = my_first_group['id']
    print id

To prove that we can retrieve the new group using its ID, run:

.. code-block:: python

    the_same_group_again = source.get_group(id=5239174)
    print the_same_group_again


**Expected result:**

.. code-block:: python

    {u'row_indices': [6, 7, 8, 9], u'name': u'my_first_group', u'row_join_type': u'union',
    u'entity_uri': u'/v1/sources/7909309112262036265/groups/5239174', u'creationTime':
    u'1531264952037', u'notes': [], u'custom_tags': [], u'row_specifications': [{u'row_indices':
    [6, 7, 8, 9]}], u'row_count': 4, u'creatorId': u'-6118706300561986679', u'id': u'5239174'}


Autogrouping
------------

Autogrouping uses one of a number of available algorithms to intelligently create groups for you. (The algorithm
you specify will depend on whether you want your analysis to be _supervised_ or _unsupervised_. For a brief
introduction to supervised vs unsupervised analysis, see "What Next?" at the end of this tutorial.)

Autogrouping is performed against a network produced by TDA.

In this example, we get the topological network created in :doc:`create_a_network` and use that
network to perform autogrouping. We'll use the Community algorithm to auto-generate the groups.

**(1) Get the existing network, First_Trials, and print the network name:**

.. code-block:: python

    new_network = source.get_network("First_Trials")
    print new_network.name


**Expected result:**

.. code-block:: python

    First_Trials

*Printing the network confirms that the previous line of code ran correctly.*

**(2) Create autogroups, using the Community algorithm:**

.. code-block:: python

    new_autogroups = new_network.autogroup_create(algorithm="Community",name="new_autogroups")


**(3) Retrieve a list of all autogroups you just created, plus any others that exist for this data set:**

.. code-block:: python

    new_list_of_groups = source.get_groups()

.. code-block:: python

    for group in new_list_of_groups:
        print group['name']

**Expected result:**

.. code-block:: python

    my_first_group
    new_autogroups_3
    new_autogroups_6
    new_autogroups_7
    new_autogroups_5
    new_autogroups_0
    new_autogroups_1
    new_autogroups_2
    new_autogroups_4
    new_autogroups_8
    new_autogroups_10
    new_autogroups_12
    new_autogroups_9
    new_autogroups_11
    new_autogroups_13

Setting A Minimum Size For Autogroups
-------------------------------------

We created 14 new groups, covering 145 records. We didn't set any minimum size for these groups, and we grouped
without regard for whether the groups included singletons (groups that are made from single nodes in the
topological network that do not have any connection to other nodes).


.. figure:: singletons.png


Let's use :class:`ayasdi.core.networks.Network.autogroup_create` and the **min_node_count** parameter to set a
minimum node count of 2. That will exclude singletons.

Run:

.. code-block:: python

    autogroups = new_network.autogroup_create(algorithm="Community",
                                              name="better_autogroups",min_node_count=2)

.. code-block:: python

    list_of_better_groups = source.get_groups()

.. code-block:: python

    for group in list_of_better_groups:
        print group['name']

**Expected result:**

.. code-block:: python

    my_first_group
    new_autogroups_3
    new_autogroups_6
    new_autogroups_7
    new_autogroups_5
    new_autogroups_0
    new_autogroups_1
    new_autogroups_2
    new_autogroups_4
    new_autogroups_8
    new_autogroups_10
    new_autogroups_12
    new_autogroups_9
    new_autogroups_11
    new_autogroups_13
    better_autogroups_1
    better_autogroups_2
    better_autogroups_4
    better_autogroups_6
    better_autogroups_0
    better_autogroups_5
    better_autogroups_7
    better_autogroups_3

Notice that in our first effort we created 14 groups; in our second effort, we created eight groups.

Now What?
---------
You have just created your first group and performed your first autogroup creation; you used the Community
algorithm to generate a set of groups.

The Community algorithm is used to support *unsupervised data analysis*. Most commonly, unsupervised analysis
is performed against a datasource where there is no labeled outcome column.

Now you're ready to try other autogroup algorithms, for *supervised data analysis*. Most commonly, supervised
analysis is performed against a datasource with a labeled outcome column.

Proceed to :doc:`autogroups_ahcl`.