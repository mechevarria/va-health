# Ayasdi Inc. Copyright 2014 - all rights reserved.

# Add necessary imports
from __future__ import absolute_import, division, print_function
import os

import ayasdi.core as ac


def test_affine(connection, data_dir):
    # Upload a file and sync the source
    print("Upload data")
    data_path = os.path.join(data_dir, 'breast_cancer.csv')
    source = connection.upload_source(data_path)
    source.sync()
    print("File uploaded")

    # Create column set and run one of auto analysis
    columns = ['clump_thickness', 'uniformity_of_cell_size',
               'uniformity_of_cell_shape', 'marginal_adhesion',
               'single_epithelial_cell_size', 'bare_nuclei', 'bland_chromatin',
               'normal_nucleoli', 'mitoses']
    euclidean_cols = ['clump_thickness', 'uniformity_of_cell_size',
                      'uniformity_of_cell_shape']
    correlation_cols = ['bare_nuclei', 'bland_chromatin', 'normal_nucleoli']

    overall_col_set = source.create_column_set(columns, "test_column_set")
    euclidean_col_set = \
        source.create_column_set(euclidean_cols, "euclidean_col_set")
    correlation_col_set = \
        source.create_column_set(correlation_cols, "correlation_col_set")

    network = source.create_network("AffineTest", {
        'metric': {'id': 'Affine',
                   'specifications': [{'metric_name': 'Euclidean (L2)',
                                       'column_set_id': euclidean_col_set['id'],
                                       'weight': .5},
                                      {'metric_name': 'Correlation',
                                       'column_set_id': correlation_col_set['id'],
                                       'weight':.5}]},
        'column_set_id': overall_col_set['id'],
        'lenses': [{'id': 'Mean', 'resolution': 30, 'gain': 3, 'equalize': True}]})
    network.show()
    connection.delete_source(id=source.id)


if __name__ == "__main__":
    # Enter your hostname here

    host = "https://platform.ayasdi.com/workbench"
    username = "MY USERNAME"
    password = "MY PASSWORD"

    connection = ac.Api(username=username,
                     password=password,
                     save_password=False,
                     url=host)
    data_dir = "PATH TO DATA FILES"
    test_affine(connection, data_dir)
