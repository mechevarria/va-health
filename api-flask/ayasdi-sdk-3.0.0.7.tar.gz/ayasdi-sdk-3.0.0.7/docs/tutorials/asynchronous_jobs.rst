Asynchronous Networks
=====================

.. highlight:: python
   :linenothreshold: 2

The code and data files are available here:
   - :download:`test_asynchronous_jobs.py <test_asynchronous_jobs.py>`.
   - :download:`breast_cancer.csv <data/breast_cancer.csv>`
   - :download:`db_test2.txt <data/db_test2.txt>`


The following example shows a workflow where a number of networks are created asynchronously. Checking
the status of individual jobs and determining whether these have completed is also covered. Similar
asynchronous endpoints also exist for model creation (:func:`ayasdi.core.models.create_group_classifier`).

Upload a Source and Obtain Column Sets
--------------------------------------

For an explanation of the code in this section, see :doc:`create_a_network`.


Code::

  import ayasdi.core as ac
  connection = ac.Api()
  print 'Connected'
  print 'Deleting Source'
  try:
     connection.delete_source(name="breast_cancer.csv")
  except:
     pass
  print "Uploading source"
  source = connection.upload_source("breast_cancer.csv")
  columns = ['clump_thickness','uniformity_of_cell_size','uniformity_of_cell_shape',
             'marginal_adhesion','single_epithelial_cell_size',
             'bare_nuclei','bland_chromatin','normal_nucleoli','mitoses']
  col_set = source.create_column_set(columns, "test_column_set")
  suggestions =  source.get_auto_analysis_suggestions(column_set_id=col_set['id'])
  source.sync()
  print "The source has %s networks." % len(source.get_networks())


Creating Networks Asynchronously
--------------------------------

Code::

    print "There are %s jobs currently running." % len(connection.get_jobs())
    running_jobs = []
    for ind, suggestion in enumerate(suggestions):
        network_name = 'Suggestion %s' % ind
        print "Starting %s." % network_name
        # Start a new job asynchronously. If a network with the same name exists, then that
        # network is returned, not an asynchronous job.
        # However, in this case, none of the networks are available.
        new_job = source.create_network(network_name, suggestion, async_=True)
        running_jobs.append(new_job)



- Line 1 - get a list of running jobs. Each object in this list is a
  job object (:mod:`ayasdi.core.jobs`).
- Line 2 - Create an empty container to hold running jobs.
- Line 3 to 10 - Create networks asynchronously and add to the list of
  running jobs. (key argument - `async` in **Line 9**).


Checking the Status of Asynchronous Jobs
----------------------------------------

Code::

    remaining_jobs = connection.get_jobs()
    print "%s jobs remaining!" % len(remaining_jobs)

    while remaining_jobs:
        # Check which jobs are completed. Remap remaining_jobs
        # to the uncompleted running jobs
        completed_jobs = []
        remaining_jobs = []
        for job in running_jobs:
        #Update the status of this job
        #Did this job just get completed
            job.sync()
            if job.status == 'complete':
                completed_jobs.append(job)
            else:
                remaining_jobs.append(job)
        print "Completed: %s " % ', '.join(completed_jobs)
        print "Remaining jobs: %s" % len(remaining_jobs)
        print "All running jobs: %s" % len(connection.get_jobs())
    source.show()

- Lines 1-2 - Get the current list of remaining jobs
- Line 4 - Run until the jobs are completed.
- Lines 7-19 - Check each job from the original list. If the job is
  completed, add its name to the completed list, else keep it in the
  list of running jobs.
  Print all completed jobs and the number of running jobs.
- When all jobs are completed, show the source webpage.
