============================================
Exporting Metadata Using the Ayasdi Core API
============================================

.. highlight:: python
   :linenothreshold: 2

   The code and data files are available here:

   - :download:`test_metadata.py <test_metadata.py>`.
   - :download:`db_test2.txt <data/db_test2.txt>`
   - :download:`db_metadata_test.txt <data/db_metadata_test.txt>`

.. _`api_connect`:

Obtain an API Connection
----------------------------------------------------------

.. code-block:: python

  import ayasdi.core as ac
  connection = ac.Api()


    -  If line 1 runs with no errors, then the ayasdi-sdk package has been installed correctly.

    - Line 2 creates a connection using the API class (``ayasdi.core.api``). The first time this
      is run, the user is prompted to enter a username and password. These are saved after the
      first run. If you'd like to explicitly provide the username and password, then use the keyword
      arguments ``username`` and ``password``::

    connection = Api(username=<username>, password=<password>)

Exporting Metadata
------------------

.. code-block:: python

    source = connection.get_source(name='db_test.txt')
    source.export_metadata('metadata.json')
    #Metadata saved.


    - Line 1 obtains a pre-existing source.
    - Line 2 saves the source metadata to the `metadata.json` file.

Importing Metadata to a New Source
----------------------------------

.. code-block:: python

    new_source = connection.upload_source('diabetes.txt')
    new_source.import_metadata('metadata.json')
    #Creating column sets
    #Creating analyses
    #Creating colorings
    #Creating node_groups
    #Creating Comparisons
    #Metadata applied.


    - Line 1 uploads a new dataset which is either identical to the pre-existing dataset or has
      the same column signature.
    - Line 2 applies pre-existing metadata onto this newly-uploaded dataset.


Verify Metadata Application
---------------------------
.. code-block:: python

    colorings = [i['name'] for i in source.get_colorings()]
    print colorings
    #[u'Rows per Node', u'Edges per Node', u'test']
    new_colorings = [i['name'] for i in new_source.get_colorings()]
    print new_colorings
    #[u'Rows per Node', u'Edges per Node', u'test']

    networks = [i.name for i in source.get_networks()]
    print networks
    #[u'test']
    new_networks = [i.name for i in new_source.get_networks()]
    print new_networks
    #[u'test']

    comparisons = [i['name'] for i in source.get_comparisons()]
    print comparisons
    #[u'Autogroup0 vs. Autogroup1 on All columns']
    new_comparisons = [i['name'] for i in new_source.get_comparisons()]
    print new_comparisons
    #[u'Autogroup0 vs. Autogroup1 on All columns']


    - Check whether colorings, networks, and comparisons are identical to the original dataset.

Display the New Source
-----------------------
.. code-block:: python

    new_source.show() #Open the core webpage and show the network


For the full signature of these methods, see the API documentation for ``Source.export_metadata``
and ``Source.import_metadata`.
