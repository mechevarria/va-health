import os

import ayasdi.core as ac


def test_csv_vectors(connection, data_dir):

    # Upload source file and create a column set that includes the CSV vector column
    source_name = 'providers_ls_items.csv'
    source_path = os.path.join(data_dir, source_name)
    src = connection.upload_source(source_path)

    column_set = src.create_column_set(column_list=['AyasdiCSV_line_service_items'],
                                       name='column_csv')
    print("Dataset loaded, column set with CSV vector column created")

    # Create network
    print("Creating network")
    network = src.create_network("test_network_seq",
                                 {'metric': {'id': 'CsvVector Jaccard'},
                                  'column_set_id': column_set['id'],
                                  'lenses': [{'resolution': 10, 'id': 'Gaussian Density',
                                              'equalize': True, 'gain': 3.0}]})

    # Compute comparisons
    src.create_group(name='g0', row_indices=list(range(10)))
    comparisons = src.compare_groups('g0', 'Rest', comparison_type='categorical_only')
    print("Comparisons computed")
    print(comparisons)


if __name__ == "__main__":
    # Enter your hostname here

    host = "https://platform.ayasdi.com/workbench"
    username = "MY USERNAME"
    password = "MY PASSWORD"

    conn = ac.Api(username=username,
                  password=password,
                  save_password=False,
                  url=host)
    data_directory = "PATH TO DATA FILES"
    test_csv_vectors(conn, data_directory)
