# Copyright (c) 2008-2018 Ayasdi, Inc. All Rights Reserved.

# Add necessary imports
from __future__ import absolute_import, division, print_function
import os
import time
import uuid

import ayasdi.core as ac
import ayasdi.core.models as acm


def test_topomodel(connection, data_dir):
    # Upload a file and sync the source
    print("Upload data")
    data_path = os.path.join(data_dir, 'breast_cancer.csv')
    source = connection.upload_source(data_path)
    source.sync()
    print("File uploaded")

    # Create column set and run one of auto analysis
    columns = ['clump_thickness', 'uniformity_of_cell_size',
               'uniformity_of_cell_shape',
               'marginal_adhesion', 'single_epithelial_cell_size',
               'bare_nuclei', 'bland_chromatin', 'normal_nucleoli', 'mitoses']
    col_set = source.create_column_set(columns, "test_column_set")
    suggestions = source.get_auto_analysis_suggestions(column_set_id=col_set['id'])
    network = source.create_network("test", suggestions[0])
    print("Network created")

    # Create a coloring and perform autogrouping
    coloring = source.create_coloring(name='test',
                                      column_name='class')
    coloring_values = network.get_coloring_values(id=coloring['id'])
    autogroups = network.autogroup_create()
    print("Autogroups created")
    # network.show()

    # Create a model
    autogroup_ids = [g['id'] for g in autogroups.groups]
    model = acm.GroupClassifier.create(connection,
                                   source_id=source.id,
                                   name='model_' + str(uuid.uuid4()),
                                   classification_group_ids=autogroup_ids,
                                   column_set_id=col_set['id'],
                                   async_=True)

    while not model.ready():
        time.sleep(1)
    print("Model created")

    test_group = source.create_group(name='test_group_1',
                                     row_indices=[5, 20, 117])

    # Predict using the new model
    source_subset = ac.SourceSubset(source_id=source.id, column_set_id=col_set['id'], group_id=test_group['id'])
    data_spec = ac.DataSpec(source_subset=source_subset)
    predictions = model.predict_proba(data_spec=data_spec)
    print(predictions)
    # prints
    # [[0.0023765788078308203, 0.0, 0.14029551911354066, ...],
    # [0.011501975417137156, 0.0, 0.04054761815071106, ...],
    # [0.048495625734329195, 0.0, 0.08172618871927262, ...]]

    connection.delete_source(id=source.id)


if __name__ == "__main__":
    # Enter your hostname here

    host = "https://platform.ayasdi.com/workbench"
    username = "MY USERNAME"
    password = "MY PASSWORD"

    connection = ac.Api(username=username,
                     password=password,
                     save_password=False,
                     url=host)
    data_dir = "PATH TO DATA FILES"
    test_topomodel(connection, data_dir)
