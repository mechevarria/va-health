import logging
import logging.handlers
import os
import pytest

try:
    from StringIO import StringIO
except ImportError:
    from io import StringIO

import ayasdi.core as ac

# TODO: Enable the log file to be set up using a command line option
LOG_FILENAME = 'tutorial_debug.log'
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.DEBUG)
logging_stream = StringIO()
stream_handler = logging.StreamHandler(logging_stream)
stream_handler.setLevel(logging.DEBUG)
LOGGER.addHandler(stream_handler)
file_handler = logging.handlers.RotatingFileHandler(LOG_FILENAME)
file_handler.setLevel(logging.DEBUG)
LOGGER.addHandler(file_handler)


def pytest_addoption(parser):
    parser.addoption("--data_dir", action="store", default=None)
    parser.addoption("--username", action="store", default="q")
    parser.addoption("--password", action="store", default="q")
    parser.addoption("--host", action="store",
                     default="http://nightly01.eng.ayasdi.com/workbench")


@pytest.fixture
def data_dir(request):
    data_dir = request.config.getoption("--data_dir")
    if data_dir is None:
        path = os.path.abspath(__file__)
        dir_path = os.path.dirname(path)
        data_dir = os.path.join(dir_path, 'data')
    return data_dir


@pytest.fixture
def username(request):
    return request.config.getoption("--username")


@pytest.fixture
def password(request):
    return request.config.getoption("--password")


@pytest.fixture
def host(request):
    return request.config.getoption("--host")


@pytest.fixture()
def connection(username, password, host):
    """
    This is the Api fixture that is passed into tests
    to allow them to make mocked-out requests defined
    by the requests_m fixture
    """
    connection = ac.Api(username=username,
                     password=password,
                     save_password=False,
                     url=host)
    yield connection
    try:
        connection.delete_source(name="db_test2.txt")
    except:
        pass
    try:
        connection.delete_source(name="breast_cancer.csv")
    except:
        pass
    try:
        connection.delete_source(name="db_metadata_test.txt")
    except:
        pass
