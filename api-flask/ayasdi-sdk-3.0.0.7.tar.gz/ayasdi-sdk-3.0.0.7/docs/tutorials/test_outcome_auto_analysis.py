# Ayasdi Inc. Copyright 2015 - all rights reserved.

from __future__ import absolute_import, unicode_literals, division, print_function
import os
import time

import ayasdi.core as ac


def test_outcome_auto_analysis(connection, data_dir):
    source_name = 'db_test2.txt'
    source_path = os.path.join(data_dir, source_name)

    # Upload a file and sync the source
    print("Load dataset")
    source = connection.upload_source(source_path)
    source.sync()

    columns = ["relative weight", "blood glucose",
               "insulin level"]
    col_set = source.create_column_set(columns, "test_column_set")

    outcome_spec=ac.OutcomeSpec(outcome_column_name="clinical classification")
    running_jobs = source.outcome_auto_analysis(name="test_outcome",
                                                column_set_id=col_set['id'],
                                                outcome_spec=outcome_spec)
    remaining = len(running_jobs)
    start = time.time()
    while remaining:
        for ind, job in enumerate(running_jobs):
            job.sync()
            if job.status == "complete":
                remaining -= 1
                running_jobs.pop(ind)
                break
        print('Rem: %s, Elapsed: %ss' %
              (remaining, time.time() - start), chr(27) + '[A')
    print('Done')

    source.sync()
    networks = source.get_networks()
    outcome_networks = [i for i in networks if i.name.startswith('test_outcome')]
    print(len(outcome_networks))

    running_jobs = \
        source.outcome_lens_param_optimization(name="test_params",
                                               column_set_id=col_set['id'],
                                               metric='Euclidean (L2)',
                                               lenses=['Gaussian Density'],
                                               outcome_spec=outcome_spec)
    remaining = len(running_jobs)
    start = time.time()
    while remaining:
        for ind, job in enumerate(running_jobs):
            job.sync()
            if job.status == "complete":
                remaining -= 1
                running_jobs.pop(ind)
                break
        print('Rem: %s, Elapsed: %ss' %
              (remaining, time.time() - start), chr(27) + '[A')
    print('Done')

    source.sync()
    networks = source.get_networks()
    outcome_param_networks = [i for i in networks
                              if i.name.startswith('test_params')]
    print(outcome_param_networks)
    connection.delete_source(id=source.id)


if __name__ == "__main__":
    # Enter your hostname here

    host = "https://platform.ayasdi.com/workbench"
    username = "MY USERNAME"
    password = "MY PASSWORD"

    connection = ac.Api(username=username,
                     password=password,
                     save_password=False,
                     url=host)
    data_dir = "PATH TO DATA FILES"
    test_outcome_auto_analysis(connection, data_dir)
