Autogrouping With Connected Components
======================================

.. highlight:: python
   :linenothreshold: 2

In this tutorial we perform autogrouping with the Conected Components algorithm to isolate groups that don't
have any overlapping data points. This is done by grouping based on regions of a topological network where
nodes are interconnected with each other, but are NOT connected (i.e. share no edges) with the rest of the
network.

It can be useful to study distinct populations such as these for a number of reasons, including distinct
treatment groups for a pharmaceutical drug, distinct transaction types that may or may not be fraudulent, or
predicting how a particular voter population might vote.

We generate autogroups from the :file:`db_test_connected.txt` dataset using the Connected Components algorithm.

For detailed information about all the algorithms Ayasdi provides to support data analysis, see
``Networks.autogroup_create`` in the *SDK Reference*.

For information on how to perform autogrouping using the Workbench, see "Creating and Modifying Groups" in the *Ayasdi Workbench User Guide*.

.. Note::
    SDK Methods used in this tutorial include:
        - :class:`ayasdi.core.networks.Network.autogroup_create`
        - :class:`ayasdi.core.source.Source.create_network`
        - :class:`ayasdi.core.source.Source.create_column_set`
        - :class:`ayasdi.core.source.Source.get_auto_analysis_suggestions`


About The Dataset
-----------------

:file:`db_test_connected.txt` is a renamed copy of :file:`db_test2.txt`. It provides sample data about 145 diabetes patients, with relevant columns.

Before You Begin
----------------

Download a copy of :download:`db_test_connected.txt <data/db_test_connected.txt>`.

If you need to create a new notebook, follow the instructions in :doc:`getting_started`.

If you want a backup copy of the code in this page, download :download:`connected_components_notebook.zip <data/connected_components_notebook.zip>`.

Once you have synchronized your data and connected to the Ayasdi platform, please begin the tutorial.

Connect to the Platform
-----------------------

All interactions between the user and the platform start with connecting to the platform:

.. code-block:: python

    import ayasdi.core as ac
    connection = ac.Api()

.. code-block:: python

    source = connection.upload_source("db_test_connected.txt")

.. code-block:: python

    source = connection.get_source(name="db_test_connected.txt")

.. code-block:: python

    print source.name

**Expected:**

.. code-block:: python

    db_test_connected.txt

Finally, run:

.. code-block:: python

    source.sync()


Create a New Network
--------------------

The following steps create a new network, drawing upon :file:`db_test_connected.txt`. The process is described in
detail in :doc:`create_a_network`.

To summarize:

    1. View the columns in your data source
    2. Specify a column list
    3. Create the column set
    4. Obtain a set of recommendations/specify a params_dict
    5. Create the topological network

.. code-block:: python

    print source.column_names

**Expected:**

.. code-block:: python

    [u'ID', u'relative weight', u'blood glucose', u'insulin level', u'insulin response', u'steady state plasma
     glucose', u'clinical classification']


Next:

.. code-block:: python

    connected_column_list = ['relative weight','insulin level','insulin response','clinical classification']

    connected_col_set = source.create_column_set(connected_column_list, "data_islands")

    suggestions = source.get_auto_analysis_suggestions(column_set_id=connected_col_set['id'])

    print suggestions[1]


**Expected:**

.. code-block:: python

    {u'metric': {u'id': u'Norm Correlation'}, u'column_set_id': u'6614750599361473344',
     u'lenses': [{u'resolution': 30, u'gain': 3.0000000000000004, u'equalize': True,
     u'id': u'L-Infinity Centrality'}]}


Finally, run:

.. code-block:: python

    network = source.create_network("Data_Islands", suggestions[0])

    print network.name

**Expected:**

.. code-block:: python

    Data_Islands


*(Printing the network name confirms that the previous line of code ran correctly.)*

Running network.autogroup_create
--------------------------------

We're going to create groups of connected components -- if any exist in this dataset -- with the name "Data Islands".
Our minimum group size will be 2.

.. code-block:: python

    autogroups = network.autogroup_create(algorithm='connected_components',
                                          name='Distinct_Populations', min_node_count=2)

    isolated_groups = source.get_groups()
    for group in isolated_groups:
        print group['name']

**Expected:**

.. code-block:: python

    Distinct_Populations_1
    Distinct_Populations_3
    Distinct_Populations_2
    Distinct_Populations_0


Viewing Your Connected Components
---------------------------------

You just created the Data Islands network and isolated four Distinct_Populations groups from the dataset
db_test_connected.txt. To view your results:

    (1) Open the :file:`db_test_connected` dataset in the Workbench.
    (2) Click **Topological Models**.
    (3) View the data islands.

You can see four distinct "islands" within the Data Islands Topological Model. These are what we mean by connected
components: each set of interconnected nodes shares no edges with any other part of the network.

.. figure:: View_Your_Topological_Model.png

Notice the variation in size between all the data islands. If we had set a different minimum size, or not set any
minimum size at all, our results might have looked different.

To examine each data island further, click **Groups**, then click the data island of interest.

.. figure:: View_Groups.png

Now What?
---------

Now it's time to compare your groups!

Proceed to :doc:`comparing_groups`.
