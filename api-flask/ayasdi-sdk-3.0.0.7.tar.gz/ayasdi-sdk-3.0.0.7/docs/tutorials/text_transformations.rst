=============================
Text Transformations Tutorial
=============================

.. highlight:: python
   :linenothreshold: 2


All the instructions below assume that the pythomaton package has been installed according to instructions that were
provided in the Installations page.

This tutorial guides you through uploading a data source to the Ayasdi Platform and applying text transformations
to the data.

For detailed information about :class:`ayasdi.core.transformations.TransformationConfiguration`, and options for this and
other transformations, see the :doc:`transformationsdoc`.

.. Note::
    SDK methods used in this tutorial include:
      -  :class:`ayasdi.core.api.Api.get_source`
      -  :class:`ayasdi.core.api.Api.upload_source`
      -  :class:`ayasdi.core.source.Source.column_names`
      -  :class:`ayasdi.core.transformations.TextFeatureExtractionTransformationStep`
      -  :class:`ayasdi.core.transformations.TransformationConfiguration`


Before You Begin
----------------

Download a copy of the tutorial data set, :download:`complaints.csv <data/complaints.csv>`.

If you want a backup copy of the code in this page, download :download:`text_transform_notebook.zip <data/text_transform_notebook.zip>`.

(1) Create an Ayasdi Notebook
-----------------------------

**(a)** At the upper right corner, click your name. Workbench displays a drop-down list.

**(b)** Select **</> AYASDI NOTEBOOKS**.

**(c)** Select **New > Notebook > Python2**.

The Workbench displays a new Ayasdi (Python2) notebook with only one line.

**(d)** Click **File > Rename** and enter a new name for your notebook.

Note that your notebook is still open.

(2) Connect to the Ayasdi Platform
----------------------------------

**Connect to the Ayasdi platform** from within your open Ayasdi notebook. Run:

.. code-block:: python

  import ayasdi.core as ac
  from ayasdi.core import transformations 
  connection = ac.Api()


(3) Upload Your Data Set to the Ayasdi Platform
-----------------------------------------------

**Now upload your sample data to the platform.**

First use the Workbench UI to physically upload your sample data to the platform. Your data source is now listed
on your Workbench Sources page.

Then, from within your Ayasdi notebook, run:

.. code-block:: python

  source = connection.upload_source('complaints.csv')


**To obtain the source you just uploaded, run:**

.. code-block:: python

  source = connection.get_source(name="complaints.csv")


**To sync the uploaded data source with the Ayasdi platform, run:**

.. code-block:: python

  source.sync()


You're now ready to start working with your data.

(4) Apply Text Transformation
-----------------------------

The TextFeatureExtractionTransformationStep is one of many transformations available to you
through the SDK. The text transformer is unique in that it can parse large amounts of free
text and convert it into new columns that are meaningful to a machine learning processor.
These new columns represent new features which you can use in other steps of
your data analysis, models, and prediction workflows.


**(a) View the columns in your data set.**

To view the name of all the columns in your uploaded dataset, run:

.. code-block:: python

  print source.column_names


**Expected output:**

.. code-block:: python

  [u'Date received',u'Product',u'Sub-product',u'Issue',u'Sub-issue',
    u'Consumer complaint narrative',u'Company public response',u'Company',u'State',
    u'ZIP code',u'Tags',u'Consumer consent provided?',u'Submitted via',
    u'Date sent to company',u'Company response to consumer',u'Timely response?',
    u'Consumer disputed?',u'Complaint ID']


Notice that all column names returned are prepended with a "u". The column of interest 
here is the 'Consumer complaint narrative'. Note that these are randomly selected rows 
from a publicly available dataset, and any company names here are also randomly included. 

**(b) Create a transformation step.**

Please review the options available for TextFeatureExtractionTransformationStep in the
documentation. This is one of the more complex transforms available. 

To create the transform step, run the following:

.. code-block:: python

  t = transformations.TextFeatureExtractionTransformationStep(
    description='description',
    column_name='Consumer complaint narrative',
    max_columns=10,
    max_ngram_length=1)

This creates a transformation step which will apply the text feature extraction on the
Consumer complaint narrative column. Since man_ngram_length is set to 1, only phrases
which contain one word will be considered. As max_columns is set to 10, it will only output
the top 10 phrases which it determines are statistically significant.

**(c) Apply the transformation.**

Now we apply the transform to the source:

.. code-block:: python

  tc = transformations.TransformationConfiguration.create(connection, 'description', t)
  tc.apply(source_id=source.id, new_source_name=None)
  source.sync()

*NOTE: By setting new_source_name to None, you are telling the system to add the new columns
to the same source. If you had set an actual name there, then a new source would have been
created and a reference returned from the tc.apply() function.*

**Expected output:**

Now if you look at the new columns with print(source.column_names), you'll see:

.. code-block:: python

  [u'Date received', u'Product', u'Sub-product', u'Issue', u'Sub-issue', u'Consumer complaint narrative',
    u'Company public response', u'Company', u'State', u'ZIP code', u'Tags', u'Consumer consent provided?',
    u'Submitted via', u'Date sent to company', u'Company response to consumer', u'Timely response?',
    u'Consumer disputed?', u'Complaint ID', u'Consumer complaint narrative_keep',
    u'Consumer complaint narrative_resolve', u'Consumer complaint narrative_police',
    u'Consumer complaint narrative_spoken', u'Consumer complaint narrative_dime',
    u'Consumer complaint narrative_stolen', u'Consumer complaint narrative_affidavit',
    u'Consumer complaint narrative_identity', u'Consumer complaint narrative_agency',
    u'Consumer complaint narrative_help']

Notice that the new columns have the original column name as a prefix, and the selected word or
phrase as the suffix, like "Consumer complaint narrative_stolen". If you inspect the data in
these new columns, much of it will be 0.0. This is to be expected in such a small dataset with
short text phrases without a significant overlap in words.

(5) Other Parameters
--------------------
There are many other parameters available to the text transformer. Following is a brief 
explanation of what each parameter means:

**new_column_name** (str): This is the prefix to use if you don't want to use the source column name.

**algorithm** (str): specifies the algorithm to be used to extract features from unstructured text. 
You can ignore this, the only accepted value today is the default "log_likelihood"

**max_columns** (int): the maximum number of new columns (most important NGrams) that will be added. Default=50

**max_ngram_length** (int): the maximum length of the NGram. Legal values are 1, 2, 3, and 4. Default=3.
Note that longer NGrams takes longer to process, so larger values may take significantly longer to run.

**use_stemmer** (bool): if True, the transformation utilizes word stemming. Default=True

**use_tfidf** (bool): if True, the transformation utilizes TF/IDF word selection. Default=True.
If false, will generate a binary 1 or 0 if the term is present or not in the text.

**allowed_ngram_length_list** ([num]): list of ngram lengths to be considered.  For example, [1,3,4] means only
consider ngrams of length 1, 3, or 4; discard all ngrams whose length is 2. To consider all ngram lengths
up to max_ngram_length, specify None.

**use_stop_words** (bool): if True, the transformation uses an internal stopword list and
calculates additional stopwords based on text frequency and the other parameters specified here. Default=False

**max_skips** (int): the maximum number of stopwords that can be skipped and still create an ngram.  For example,
if maxSkips is 0, then a stopword always causes the next valid word to start a new ngram. Default=0

**stop_word_knee_ratio** (float): the larger the ratio, the more words are kept (fewer stop words), the smaller
the ratio, the fewer words are kept (more stop words). 1.0 seems best when using ngrams, 2.5 seems best if
you are just using single words. Default=2.5

**stop_word_min_cutoff** (int): specifies the number of times (or fewer) a word must appear in the corpus, to make
it a stop word. Default=3. This means a word will only be considered a stop word if it appears 3 or fewer
times in the entire corpus.

**stop_word_list** ([char]): list of words that must never be included in an ngram. If None or empty, an internal
set is used. Default=None

**start_word_list** ([char]): list of words that must never be used as stopwords. If None or empty, an internal
set is used. Default=None

**virtual** (bool): if True, specifies that the transformation is virtual. If False or omitted, the transformation
is physical. Default=False. Setting a transformer to Virtual means no physical data is stored on disk, but rather 
it is calculated from metadata when the data is read later in your workflow. Consider using virtual if the dataset
is very large or you are producing a large number of columns; it may help improve performance.

