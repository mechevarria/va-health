Outcome Autoanalysis
====================

.. highlight:: python
   :linenothreshold: 2

Outcome autoanalysis is *supervised analysis* that enables the user to generate a set of topological networks without
having to specify mathematical parameters such as metric and lens. This greatly simplifies the analysis process.

Outcome autoanalysis can only be performed against a datasource with an outcome column.

The user specifies a single column of interest against a specified column set. The Ayasdi platform then uses the
specified column and column set to create a number of networks via auto-analysis. The user can examine each of these
networks, and select one or more that are of special interest.

This tutorial walks you through the performance of outcome auto-analysis.


.. Note::
    SDK methods used in this tutorial include:
        - :class:`ayasdi.core.api.Api.upload_source`
        - :class:`ayasdi.core.api.Api.get_source`
        - :class:`ayasdi.core.outcome_spec.OutcomeSpec`
        - :class:`ayasdi.core.source.Source.sync`
        - :class:`ayasdi.core.source.Source.create_column_set`
        - :class:`ayasdi.core.source.Source.get_networks`
        - :class:`ayasdi.core.source.Source.outcome_auto_analysis`

**About The Dataset**

:file:`breast_cancer.csv` is a datasource in the public domain. It contains data for 700 breast cancer tumor samples.


**Before You Begin**

Download a copy of the tutorial data source, :download:`data/breast_cancer.csv`.

If you need to create a new notebook, follow the instructions in :doc:`getting_started`.

If you want a backup copy of the code in this page, download :download:`data/outcome_autoanalysis_notebook.zip`.

Once you have assembled your tutorial data, please begin the tutorial.


Connect to the Platform
-----------------------

All interactions between the user and the platform start with connecting to the platform:

.. code-block:: python

    import ayasdi.core as ac
    connection = ac.Api()

.. code-block:: python

    source = connection.upload_source('breast_cancer.csv')

.. code-block:: python

    source.sync


Create the Column Set
---------------------
The first thing we need to do  is to get the datasource.

If necessary, run:

.. code-block:: python

    source = connection.get_source (name="breast_cancer.csv")

.. code-block:: python

    source.sync

**Expected:**

.. code-block:: python

   <bound method Source.sync of <Source 'breast_cancer.csv'>>


Now we choose the columns to be incorporated in the column set. In this datasource the outcome column is "class",
so we omit it from the column set.

Run:

.. code-block:: python

    columns = ['clump_thickness','uniformity_of_cell_size','uniformity_of_cell_shape',
               'marginal_adhesion','single_epithelial_cell_size',
               'bare_nuclei','bland_chromatin','normal_nucleoli','mitoses']


Now we're ready to create the column set, which we'll call "test_column_set".

Run:

.. code-block:: python

    col_set = source.create_column_set(columns, "test_column_set")


We're going to need the column set ID in a moment, so let's get it.

Run:

.. code-block:: python

    print col_set


**Expected:**

.. code-block:: python

    {u'name': u'test_column_set', u'entity_uri': u'/v1/sources/2314618135722393097/column_sets/-20327441994305950
    53', u'immutable': False, u'column_indices': [1, 2, 3, 4, 5, 6, 7, 8, 9], u'type': u'Mixed', u'id': u'-203274
    4199430595053'}


As we can see, the column set ID is **2032744199430595053**.

We also need to create an OutcomeSpec object that contains the information about the outcome column
to be used by the supervised analysis algorithm.

Run:

.. code-block:: python

    outcome_spec = ac.OutcomeSpec(outcome_column_name=\"class\")


Perform Outcome Autoanalysis
----------------------------
Having created the column set, we're ready to perform outcome autoanalysis.

The following code specifies that the new networks to be created should have the prefix "test_outcome".

This analysis is considered to be supervised because our datasource has an outcome column ("class"), but we're
not creating new networks with a preference for a particular outcome.

Run:

.. code-block:: python

    running_jobs = source.outcome_auto_analysis(name=\"test_outcome\",column_set_id=\"2032744199430595053\",
                                                outcome_spec=outcome_spec)



To get the new networks, we first get all the networks for the source, then all the "prefixed" networks
that we just created via OAA.

.. code-block:: python

    source.sync()
    networks = source.get_networks()
    outcome_networks = [i for i in networks if i.name.startswith('test_outcome')]


To display the networks you just created, print them.

Run:

.. code-block:: python

    for network in outcome_networks:
        print network.name


**Expected:**

.. code-block:: python

    test_outcome 1
    test_outcome 2
    test_outcome 3
    test_outcome 4
    test_outcome 5
    test_outcome 6


What Next?
----------
Use the Workbench to examine the networks you just created, with the lenses and metrics that were
supplied during autoanalysis. Once you isolate networks that contain an outcome of interest, you can
further hone these results via lens parameterization if desired, to more precisely localize their
outcome.

Watch this space for the upcoming Lens Parameterization tutorial!

Meanwhile, for more about supervised vs unsupervised analysis, see :doc:`groups_autogroups`."