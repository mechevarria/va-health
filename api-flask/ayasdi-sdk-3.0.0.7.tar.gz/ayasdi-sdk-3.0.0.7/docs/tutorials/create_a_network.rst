==============================
Your First Topological Network
==============================

.. highlight:: python
   :linenothreshold: 2


All the instructions below assume that the pythomaton package has been installed according to instructions that were
provided in the Installations page.

This tutorial guides you through uploading a data source to the Ayasdi Platform and creating a basic
Topological Network for viewing your data.

For detailed information about :class:`ayasdi.core.source.Source.create_network`, and options for creating a
parameters dictionary, see the :doc:`/userdoc/create_network_supp_overview`.

.. Note::
    SDK methods used in this tutorial include:
      -  :class:`ayasdi.core.api.Api.get_source`
      -  :class:`ayasdi.core.api.Api.upload_source`
      -  :class:`ayasdi.core.source.Source.create_column_set`
      -  :class:`ayasdi.core.source.Source.create_network`
      -  :class:`ayasdi.core.source.Source.get_auto_analysis_suggestions`


Before You Begin
----------------

Download a copy of the tutorial data set, :download:`db_test2.txt <data/db_test2.txt>`.

If you want a backup copy of the code in this page, download :download:`create_network_notebook.zip <data/create_network_notebook.zip>`.

(1) Create an Ayasdi Notebook
-----------------------------

**(a)** At the upper right corner, choose your name. Workbench displays a drop-down list.

**(b)** Select **</> AYASDI NOTEBOOKS**.

**(c)** Select **New > Notebook > Python2**.

The Workbench displays a new Ayasdi (Python2) notebook with only one line.

**(d)** Choose **File > Rename** and enter a new name for your notebook.

Note that your notebook is still open.

(2) Connect to the Ayasdi Platform
----------------------------------

**Connect to the Ayasdi platform** from within your open Ayasdi notebook. Run:

.. code-block:: python

  import ayasdi.core as ac
  connection = ac.Api()


(3) Upload Your Data Set to the Ayasdi Platform
-----------------------------------------------

**Now upload your sample data to the platform.**

First use the Workbench UI to physically upload your sample data to the platform. Your data source is now listed
on your Workbench Sources page.

Then, from within your Ayasdi notebook, run:

.. code-block:: python

  source = connection.upload_source('db_test2.txt')


**To obtain the source you just uploaded, run:**

.. code-block:: python

  source = connection.get_source(name="db_test2.txt")


**To sync the uploaded data source with the Ayasdi platform, run:**

.. code-block:: python

  source.sync()


You're now ready to start working with your data.

(4) Set the Parameters For Your Topological Network
---------------------------------------------------

A Parameters Dictionary provides definitions for creating your Topological Network. There are many parameters you
can supply to make your Topological Network very specific (see the :doc:`/userdoc/create_network_supp_overview`).

In this tutorial we're only going to specify which columns of data you want to include.

**(a) View the columns in your data set.**

To view the name of all the columns in your uploaded dataset, run:

.. code-block:: python

  print source.column_names


**Expected output:**

.. code-block:: python

  [u'ID', u'relative weight', u'blood glucose', u'insulin level', u'insulin response',
    u'steady state plasma glucose', u'clinical classification']


Notice that all column names returned are prepended with a "u".

**(b) Create a column set.**

To create the column set, you specify the names of the columns you want in your numerical column list,
as defined in a column set; then use :class:`ayasdi.core.source.Source.create_column_set` to construct the
actual column set.

To create the numerical column list, run:

.. code-block:: python

  my_column_list = ['blood glucose','insulin level','insulin response','clinical classification']


Your list of identified columns is held in memory as long as the session is active.

Now create the column set. (We'll name the column set "clinicals".) Run:

.. code-block:: python

  col_set = source.create_column_set(my_column_list, "clinicals")


*NOTE: If you see NameError: name 'my_column_list' is not defined, try re-running the
my_column_list creation step, above, then re-run the col_set definition step.*

Like the column list, your column set is held in memory as long as the session is active
(your notebook is running).

**(c) Obtain a set of params_dicts.**

Constructing a full-blown params_dict is beyond the scope of this tutorial. (For full
documentation on how to do this, see :doc:`/userdoc/create_network_supp_overview`.) For now, we'll use
the Python ``suggestions`` method to obtain a set of parameter dictionaries. The data returned
should provide recommended auto-analyses for your uploaded data set, :file:`db_text2.txt`.

Run:

.. code-block:: python

  suggestions = source.get_auto_analysis_suggestions(column_set_id=col_set['id'])


You can view any number of the recommended auto analysis param_dicts by displaying (printing) them.

Run the following command, supplying a 0 within the brackets to get the first item in the list of
suggestions, a 1 to get the second item, etc.

Run:

.. code-block:: python

  print suggestions[0]


**Expected output:**

.. code-block:: python

  {u'metric': {u'id': u'Norm Correlation'}, u'column_set_id': u'-5862399318784740757',
  u'lenses': [{u'resolution': 30, u'gain': 3.0000000000000004, u'equalize': True,
  u'id': u'MDS coord 1'}, {u'resolution': 30, u'gain': 3.0000000000000004, u'equalize':
  True, u'id': u'MDS coord 2'}]}


Now you're ready to create the topological network!

(5) Create The Topological Network
----------------------------------

To create a topological network named Trials, run:

.. code-block:: python

  network = source.create_network("Trials", suggestions[0])


To confirm the network name, run:

.. code-block:: python

  print network.name


To view the topological network, return to the Workbench Sources tab and double-click :file:`db_test8.txt`.

Your data displays as a topological map, showing 70 nodes and 145 rows.

To the left you can see the name of your network and your column set (Clinicals). (After you complete the next tutorial, you will also be able to see any groups you've created thus far.)

.. figure:: First_TDN.png


What Next?
----------

You have just created your first topological network!

Now you're ready to explore other ways of creating groups from your data set.

Proceed to :doc:`groups_autogroups`.
