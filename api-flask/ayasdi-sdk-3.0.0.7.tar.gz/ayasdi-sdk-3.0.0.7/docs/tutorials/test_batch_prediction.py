from __future__ import absolute_import, unicode_literals, division, print_function

import os

import ayasdi.core as ac


def test_batch_prediction(connection, data_dir):
    print("Load dataset")
    source_name = 'db_test2.txt'
    source_path = os.path.join(data_dir, source_name)
    source = connection.upload_source(source_path)
    columns = ["relative weight", "blood glucose",
               "insulin level", "insulin response"]
    col_set = source.create_column_set(columns, "test_column_set")
    print("Create network")
    network = \
        source.create_network("test_network1", {
               'metric': {'id': 'Norm Correlation'},
               'column_set_id': col_set['id'],
               'lenses': [{'resolution': 30,
                           'id': 'MDS coord 1',
                           'equalize': True, 'gain': 3.0},
                          {'resolution': 30, 'id': 'MDS coord 2',
                           'equalize': True, 'gain': 3.0}]})

    # Upload the query source and create a column set
    query_source_name = "diabetes_test_points.txt"
    query_source_path = os.path.join(data_dir, query_source_name)
    query_source = connection.upload_source(query_source_path)
    qcol_set = query_source.create_column_set(columns, "query_column_set")
    col_predict = [{'column_name': 'clinical classification',
                                              'calculation_method': 'mode'}]
    predictions = network.topological_predict(query_source_id=query_source.id,
                                            query_columnset_id=qcol_set['id'],
                                            predict_columns=col_predict,
                                            return_closest_rows=True,
                                            neighbors_count=2)                                            
    print(predictions[0])
    # {'row_id': 0, 
    #  'closest_row_ids': [0, 5], 
    #  'predicted_columns': [{'column_id': 6, 
    #                         'predicted_values': [3.0], 
    #                         'prediction_prevalence': 2}]}

    # Clean up
    connection.delete_source(id=query_source.id)
    connection.delete_source(id=source.id)


if __name__ == "__main__":
    # Enter your hostname here

    host = "https://platform.ayasdi.com/workbench"
    username = "MY USERNAME"
    password = "MY PASSWORD"

    connection = ac.Api(username=username,
                     password=password,
                     save_password=False,
                     url=host)
    data_dir = "PATH TO DATA FILES"
    test_batch_prediction(connection, data_dir)
