Comparing Groups
================

.. highlight:: python
   :linenothreshold: 2

In this tutorial we introduce the :class:`ayasdi.core.source.Source.compare_groups` method, and show you how to perform a very basic group
comparison.

For the purpose of this tutorial we illustrate the process using groups that have previously been created while
performing the :doc:`connected_components` tutorial, from the dataset :file:`db_test_connected.txt`. However, we strongly
recommend that you try this yourself, comparing groups you have already created, based on a dataset you have already
uploaded to the Ayasdi platform.

For detailed information about :class:`ayasdi.core.source.Source.compare_groups`, see the *SDK Reference*..

For information on how to compare groups using the Workbench, see "Comparing Groups" in the *Ayasdi Workbench User
Guide*.

.. Note::

    SDK methods used in this tutorial include:
        -  :class:`ayasdi.core.source.Source.compare_groups`
        -  :class:`ayasdi.core.source.Source.get_network`
        -  :class:`ayasdi.core.source.Source.print_network`
        -  :class:`ayasdi.core.source.Source.sync`


About the Dataset
-----------------

We use the dataset :file:`db_test_connected.txt`, from the tutorial  :doc:`connected_components`, to
illustrate the process of comparing groups. However, we strongly recommend that you use another dataset that
you have already uploaded, and groups that you have already defined.

If you have not yet uploaded a dataset, see :doc:`getting_started`.


Before You Begin
----------------

If you need to create a new notebook, follow the instructions in :doc:`getting_started`.

If you want a backup copy of the code in this page, download :download:`data/comparing_groups_notebook.zip`.

Once you have connected to the Ayasdi platform, please begin the tutorial.


Connect to the Platform
-----------------------

All interactions between the user and the platform start with connecting to the platform.

For this tutorial, you connect to the datasource for groups you want to compare.

In the following code, please substitute the name of your own dataset for "db_test_connected.txt":


.. code-block:: python

    import ayasdi.core as ac
    connection = ac.Api()


.. code-block:: python

    source = connection.get_source(name="db_test_connected.txt")


.. code-block:: python

    print source.name

**Expected:**

.. code-block:: python

    the_name_of_your_datasource


Connect to an Existing Network
------------------------------

Connect to the network that contains the groups you want to compare.

The network we use here for the sake of illustration is named "Data_Islands".

.. code-block:: python

    network = source.get_network("Data_Islands")


.. code-block:: python

    print network.name

**Expected:**

.. code-block:: python

    the_name_of_your_network


*(Printing the network name confirms that the previous line of code ran correctly.)*

Running Source.compare_groups()
-------------------------------

The format of the ``source.compare_groups()`` command is:

.. code-block:: python

    comparison_name = source.compare_groups("group_1_name", "group_2_name", column_set_id=None,
                                            comparison_type="type",async_=False)


where:

    -  ``comparison_name`` is the variable that calls the result set
    -  ``group_1_name`` specifies the first group in the comparison
    -  ``group_2_name`` specifies the second group in the comparison; other legal options are "all" (compares group_1
        to all the source data, including the primary group) and "rest"(all the source data, including the primary
        group; default).
    -  ``name`` is an optional name for the comparison to be created
    -  ``column_set_id`` specifies a column set that is the basis for the comparison; if omitted, the method compares
        whole group to whole group
    -  ``comparison_type`` can be categorical, continuous, or catetorical_and_continuous (default)
    -  ``async`` specifies that the comparison be performed asynchronously; if omitted, defaults to False


For this first comparison we'll compare two groups in their entirety, without sorting on a particular shared column
set.

To show you the full range of possible results we will omit the comparison_type parameter. This will provide both
categorical and continuous explainers.

.. code-block:: python

    compare_1_and_2 = source.compare_groups("Data_Islands_1", "Data_Islands_2")

    print compare_1_and_2

**Our results:**

The platform returns the following dictionary:

.. code-block:: python

    {u'name': u'Data_Islands_1 vs. Data_Islands_2 on All columns', u'column_set_id': u'-2971117142235426232',
    u'continuous_explainers': [{u'p_value': 0.002853945596376972, u'name': u'ID', u'secondary_group_mean':
    34.25, u'group1_percent_null': 0.0, u'diff_means': 93.97222222222226, u'primary_group_mean':
    128.22222222222226, u'ks_score': 1.0, u'quartiles': [[111.0, 116.0, 132.0, 140.0, 145.0], [16.0, 23.0,
    24.0, 74.0, 74.0]], u'group0_percent_null': 0.0, u'column_index': 0, u't_test_p_value':
    0.004736611869578975, u'ks_sign': u'+'}, {u'p_value': 0.0209199095402387, u'name': u'relative weight',
    u'secondary_group_mean': 0.965, u'group1_percent_null': 0.0, u'diff_means': -0.06611111111111101,
    u'primary_group_mean': 0.898888888888889, u'ks_score': 0.8333333333333336, u'quartiles': [[0.74, 0.85,
    0.9, 0.92, 1.06], [0.95, 0.96, 0.97, 0.98, 0.98]], u'group0_percent_null': 0.0, u'column_index': 1,
    u't_test_p_value': 0.004369539833243071, u'ks_sign': u'-'}, {u'p_value': 0.002853945596376972, u'name':
    u'blood glucose', u'secondary_group_mean': 89.5, u'group1_percent_null': 0.0, u'diff_means':
    162.61111111111111, u'primary_group_mean': 252.11111111111111, u'ks_score': 1.0, u'quartiles': [[114.0,
    213.0, 275.0, 303.0, 353.0], [80.0, 90.0, 93.0, 95.0, 95.0]], u'group0_percent_null': 0.0,
    u'column_index': 2, u't_test_p_value': 6.978026399415236e-08, u'ks_sign': u'+'}, {u'p_value':
    0.002853945596376972, u'name': u'insulin level', u'secondary_group_mean': 360.75, u'group1_percent_null':
    0, u'diff_means': 828.3611111111111, u'primary_group_mean': 1189.111111111111, u'ks_score': 1.0,
    u'quartiles': [[557.0, 1001.0, 1354.0, 1468.0, 1568.0], [327.0, 347.0, 376.0, 393.0, 393.0]],
    u'group0_percent_null': 0.0, u'column_index': 3, u't_test_p_value': 2.2563091584542137e-09, u'ks_sign':
    u'+'}, {u'p_value': 0.005770175151050827, u'name': u'insulin response', u'secondary_group_mean': 193.25,
    u'group1_percent_null': 0.0, u'diff_means': -125.58333333333333, u'primary_group_mean': 67.66666666666667,
    u'ks_score': 0.9444444444444448, u'quartiles': [[10.0, 28.0, 45.0, 83.0, 232.0], [184.0, 192.0, 195.0,
    202.0, 202.0]], u'group0_percent_null': 0.0, u'column_index': 4, u't_test_p_value': 4.148661596049731e-08,
    u'ks_sign': u'-'}, {u'p_value': 0.005770175151050827, u'name': u'steady state plasma glucose',
    u'secondary_group_mean': 105.75, u'group1_percent_null': 0.0, u'diff_means': 203.91666666666674,
    u'primary_group_mean': 309.66666666666674, u'ks_score': 0.9444444444444444, u'quartiles': [[100.0, 253.0,
    303.0, 382.0, 480.0], [91.0, 102.0, 106.0, 124.0, 124.0]], u'group0_percent_null': 0.0, u'column_index':
    5, u't_test_p_value': 3.0552511019098534e-07, u'ks_sign': u'+'}, {u'p_value': 0.002853945596376972,
    u'name': u'clinical classification', u'secondary_group_mean': 3.0, u'group1_percent_null': 0.0,
    u'diff_means': -1.9444444444444442, u'primary_group_mean': 1.0555555555555558, u'ks_score':
    1.0000000000000002, u'quartiles': [[1.0, 1.0, 1.0, 1.0, 2.0], [3.0, 3.0, 3.0, 3.0, 3.0]],
    u'group0_percent_null': 0.0, u'column_index': 6, u't_test_p_value': 2.7656098283136736e-17, u'ks_sign':
    u'-'}], u'categorical_explainers': [{u'percent_in_group': [0.9444444444444444, 0.7727272727272727, 0.0],
    u'column_index': 6, u'name': u'clinical classification = 1', u'hypergeometric_p_values':
    [0.0006835269993164736, 0.9993164730006835]}, {u'percent_in_group': [0.05555555555555555,
    0.045454545454545456, 0.0], u'column_index': 6, u'name': u'clinical classification = 2',
    u'hypergeometric_p_values': [0.8181818181818182, 0.18181818181818177]}, {u'percent_in_group': [0.0,
    0.18181818181818182, 1.0], u'column_index': 6, u'name': u'clinical classification = 3',
    u'hypergeometric_p_values': [0.00013670539986329494, 0.9998632946001367]}, {u'percent_in_group':
    [0.05555555555555555, 0.045454545454545456, 0.0], u'column_index': 1, u'name': u'relative weight =
    0.74', u'hypergeometric_p_values': [0.8181818181818182, 0.18181818181818177]}, {u'percent_in_group':
    [0.05555555555555555, 0.045454545454545456, 0.0], u'column_index': 1, u'name': u'relative weight = 0.81',
    u'hypergeometric_p_values': [0.8181818181818182, 0.18181818181818177]}, {u'percent_in_group':
    [0.05555555555555555, 0.045454545454545456, 0.0], u'column_index': 1, u'name': u'relative weight = 0.83',
    u'hypergeometric_p_values': [0.8181818181818182, 0.18181818181818177]}, {u'percent_in_group':
    [0.16666666666666666, 0.13636363636363635, 0.0], u'column_index': 1, u'name': u'relative weight = 0.85',
    u'hypergeometric_p_values': [0.52987012987013, 0.47012987012986995]}, {u'percent_in_group':
    [0.1111111111111111, 0.09090909090909091, 0.0], u'column_index': 1, u'name': u'relative weight = 0.86',
    u'hypergeometric_p_values': [0.6623376623376624, 0.33766233766233755]}, {u'percent_in_group':
    [0.1111111111111111, 0.09090909090909091, 0.0], u'column_index': 1, u'name': u'relative weight = 0.9',
    u'hypergeometric_p_values': [0.6623376623376624, 0.33766233766233755]}, {u'percent_in_group':
    [0.1111111111111111, 0.09090909090909091, 0.0], u'column_index': 1, u'name': u'relative weight = 0.91',
    u'hypergeometric_p_values': [0.6623376623376624, 0.33766233766233755]}, {u'percent_in_group':
    [0.1111111111111111, 0.09090909090909091, 0.0], u'column_index': 1, u'name': u'relative weight = 0.92',
    u'hypergeometric_p_values': [0.6623376623376624, 0.33766233766233755]}, {u'percent_in_group':
    [0.05555555555555555, 0.045454545454545456, 0.0], u'column_index': 1, u'name': u'relative weight = 0.93',
    u'hypergeometric_p_values': [0.8181818181818182, 0.18181818181818177]}, {u'percent_in_group': [0.0,
    0.045454545454545456, 0.25], u'column_index': 1, u'name': u'relative weight = 0.95',
    u'hypergeometric_p_values': [0.18181818181818185, 0.8181818181818181]}, {u'percent_in_group': [0.0,
    0.045454545454545456, 0.25], u'column_index': 1, u'name': u'relative weight = 0.96',
    'hypergeometric_p_values': [0.18181818181818185, 0.8181818181818181]}, {u'percent_in_group': [0.0,
    0.045454545454545456, 0.25], u'column_index': 1, u'name': u'relative weight = 0.97',
    u'hypergeometric_p_values': [0.18181818181818185, 0.8181818181818181]}, {u'percent_in_group': [0.0,
    0.045454545454545456, 0.25], u'column_index': 1, u'name': u'relative weight = 0.98',
    u'hypergeometric_p_values': [0.18181818181818185, 0.8181818181818181]}, {u'percent_in_group':
    [0.05555555555555555, 0.045454545454545456, 0.0], u'column_index': 1, u'name': u'relative weight = 1.03',
    u'hypergeometric_p_values': [0.8181818181818182, 0.18181818181818177]}, {u'percent_in_group':
    [0.05555555555555555, 0.045454545454545456, 0.0], u'column_index': 1, u'name': u'relative weight = 1.05',
    u'hypergeometric_p_values': [0.8181818181818182, 0.18181818181818177]}, {u'percent_in_group':
    [0.05555555555555555, 0.045454545454545456, 0.0], u'column_index': 1, u'name': u'relative weight = 1.06',
    u'hypergeometric_p_values': [0.8181818181818182, 0.18181818181818177]}], u'row_sets': [{u'row_count': 18,
    u'name': u'Data_Islands_1'}, {u'row_count': 4, u'name': u'Data_Islands_2'}], u'id': u'6195325452763541525'}


Making Sense Of Your Results
----------------------------

``Source.compare_groups()`` returns its results in the form of a dictionary. Since we didn't specify that we only
wanted one type of explainer, our dictionary contains both types:

**Continuous**

Compares columns that contain continuous variation within some numerical range. In our dictionary we see:

    - **Shared columns:** clinical classification, ID, blood glucose, insulin level, insulin response,
        steady state plasma glucose, relative weight
    - **Explainers:** p-value, t-test p-value, group 0% null, group 1 %null, distribution, ks score, ks sign,
        diff in means

**Categorical**

Compares columns that contain data comprised of a fixed number of categories; for example, state name abbreviations or
months of the year. In our dictionary we see:

    - **Column names:** clinical classification = 1, clinical classification = 3, relative weight = 0.9,
        relative weight = 0.86, relative weight = 0.91, relative weight = 0.95 relative weight - 0.96,
        relative weight = 0.97, relative weight = 0.98
    - **Explainers:** p-value, %in Data_Islands_1/Data_Islands_2, second p-value, adjusted p-value, grp1 count,
        grp2 count


Honing Your Results
-------------------

Now we'll compare the same two groups again. This time, to optimize efficiency, we'll specify a comparison_type
of ``continuous_only``.

.. code-block:: python

    continuous_compare_1_and_2 = source.compare_groups("Data_Islands_1", "Data_Islands_2",
                                                       comparison_type="continuous_only")

    print continuous_compare_1_and_2

**Our results this time:**

The platform returns the following dictionary:

.. code-block:: python

    {u'name': u'Data_Islands_1 vs. Data_Islands_2 on All columns', u'column_set_id': u'-2971117142235426232',
    u'continuous_explainers': [{u'p_value': 0.002853945596376972, u'name': u'ID', u'secondary_group_mean': 34.25,
    u'group1_percent_null': 0.0, u'diff_means': 93.97222222222226, u'primary_group_mean': 128.22222222222226,
    u'ks_score': 1.0, u'quartiles': [[111.0, 116.0, 132.0, 140.0, 145.0], [16.0, 23.0, 24.0, 74.0, 74.0]],
    u'group0_percent_null': 0.0, u'column_index': 0, u't_test_p_value': 0.004736611869578975, u'ks_sign': u'+'},
    {u'p_value': 0.0209199095402387, u'name': u'relative weight', u'secondary_group_mean': 0.965,
    u'group1_percent_null': 0.0, u'diff_means': -0.06611111111111101, u'primary_group_mean': 0.898888888888889,
    u'ks_score': 0.8333333333333336, u'quartiles': [[0.74, 0.85, 0.9, 0.92, 1.06], [0.95, 0.96, 0.97, 0.98, 0.98]],
    u'group0_percent_null': 0.0, u'column_index': 1, u't_test_p_value': 0.004369539833243071, u'ks_sign': u'-'},
    {u'p_value': 0.002853945596376972, u'name': u'blood glucose', u'secondary_group_mean': 89.5,
    u'group1_percent_null': 0.0, u'diff_means': 162.61111111111111, u'primary_group_mean': 252.11111111111111,
    u'ks_score': 1.0, u'quartiles': [[114.0, 213.0, 275.0, 303.0, 353.0], [80.0, 90.0, 93.0, 95.0, 95.0]],
    u'group0_percent_null': 0.0, u'column_index': 2, u't_test_p_value': 6.978026399415236e-08, u'ks_sign': u'+'},
    {u'p_value': 0.002853945596376972, u'name': u'insulin level', u'secondary_group_mean': 360.75,
    u'group1_percent_null': 0.0, u'diff_means': 828.3611111111111, u'primary_group_mean': 1189.111111111111,
    u'ks_score': 1.0, u'quartiles': [[557.0, 1001.0, 1354.0, 1468.0, 1568.0], [327.0, 347.0, 376.0, 393.0, 393.0]],
    u'group0_percent_null': 0.0, u'column_index': 3, u't_test_p_value': 2.2563091584542137e-09, u'ks_sign': u'+'},
    {u'p_value': 0.005770175151050827, u'name': u'insulin response', u'secondary_group_mean': 193.25,
    u'group1_percent_null': 0.0, u'diff_means': -125.58333333333333, u'primary_group_mean': 67.66666666666667,
    u'ks_score': 0.9444444444444448, u'quartiles': [[10.0, 28.0, 45.0, 83.0, 232.0], [184.0, 192.0, 195.0, 202.0,
    202.0]], u'group0_percent_null': 0.0, u'column_index': 4, u't_test_p_value': 4.148661596049731e-08, u'ks_sign':
    u'-'}, {u'p_value': 0.005770175151050827, u'name': u'steady state plasma glucose', u'secondary_group_mean': 105.75,
    u'group1_percent_null': 0.0, u'diff_means': 203.91666666666674, u'primary_group_mean': 309.66666666666674,
    u'ks_score': 0.9444444444444444, u'quartiles': [[100.0, 253.0, 303.0, 382.0, 480.0], [91.0, 102.0, 106.0, 124.0,
    124.0]], u'group0_percent_null': 0.0, u'column_index': 5, u't_test_p_value': 3.0552511019098534e-07, u'ks_sign':
    u'+'}, {u'p_value': 0.002853945596376972, u'name': u'clinical classification', u'secondary_group_mean': 3.0,
    u'group1_percent_null': 0.0, u'diff_means': -1.9444444444444442, u'primary_group_mean': 1.0555555555555558,
    u'ks_score': 1.0000000000000002, u'quartiles': [[1.0, 1.0, 1.0, 1.0, 2.0], [3.0, 3.0, 3.0, 3.0, 3.0]],
    u'group0_percent_null': 0.0, u'column_index': 6, u't_test_p_value': 2.7656098283136736e-17, u'ks_sign': u'-'}],
    u'categorical_explainers': [], u'row_sets': [{u'row_count': 18, u'name': u'Data_Islands_1'}, {u'row_count': 4,
    u'name': u'Data_Islands_2'}], u'id': u'-1635651129568650947'}


Notice that this dictionary, which contains only continuous explainers, is considerably shorter than the first one you got.
