# Ayasdi Inc. Copyright 2015 - All Rights Reserved.
"""
A simple workflow showcasing top utilized features
from the ayasdi.core.python package
"""
from __future__ import absolute_import, unicode_literals, division, print_function
import os

import ayasdi.core as ac


def test_simple_workflow(connection, data_dir):
    source_name = 'db_test2.txt'
    source_path = os.path.join(data_dir, source_name)

    print("Load dataset")
    source = connection.upload_source(source_path)
    source.sync()

    columns = ["relative weight", "blood glucose",
               "insulin level"]
    col_set = source.create_column_set(columns, "test_column_set")
    suggestions = source.get_auto_analysis_suggestions(column_set_id=col_set['id'])
    print(suggestions[0])

    print("Create network")
    network = source.create_network("test", suggestions[0])
    print("Create coloring")

    coloring = source.create_coloring(name='test',
                                      column_name='clinical classification')
    coloring_values = network.get_coloring_values(id=coloring['id'])

    print("Create autogroups")
    autogroups = network.autogroup_create()

    print("Compare Group#1 and Group#2")
    comparison = source.compare_groups(autogroups.groups[0]['name'], autogroups.groups[1]['name'])
    print(comparison)
    print("Open analysis in WebUX")
    network.show()
    connection.delete_source(id=source.id)


if __name__ == "__main__":
    # Enter your hostname here

    host = "https://platform.ayasdi.com/workbench"
    username = "MY USERNAME"
    password = "MY PASSWORD"

    connection = ac.Api(username=username,
                     password=password,
                     save_password=False,
                     url=host)
    data_dir = "PATH TO DATA FILES"
    test_simple_workflow(connection, data_dir)
