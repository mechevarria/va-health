Batch Prediction
================

.. highlight:: python
   :linenothreshold: 2

The code in this page is available :download:`here <test_batch_prediction.py>` as a single python script.

The code and data files are available here:

   - :download:`test_batch_prediction.py <test_batch_prediction.py>`.
   - :download:`db_test2.txt <data/db_test2.txt>`
   - :download:`diabetes_test_points.txt <data/diabetes_test_points.txt>`

.. _`api_connect`:

    For further information, see :doc:`create_a_network`.


The basic steps highlighted below are:

Create a Connection
-------------------

Code::

    import ayasdi.core as ac
    connection = ac.Api()

Upload a File and Create a Network
----------------------------------

Code::

    source = connection.upload_source('db_test2.txt')
    columns = ["relative weight", "blood glucose",
    ...        "insulin level", "insulin response"]
    col_set = source.create_column_set(columns, "test_column_set")
    network = source.create_network("test_network1",
                                    {'metric': {'id': 'Norm Correlation'},
                                     'column_set_id': col_set['id'],
                                     'lenses': [{'resolution': 30, 'id': 'MDS coord 1',
                                     'equalize': True, 'gain': 3.0},
                                     {'resolution': 30, 'id': 'MDS coord 2',
                                     'equalize': True, 'gain': 3.0}]})

Upload the Query Source, Create a Column Set, and Predict
---------------------------------------------------------

Code::

    query_source = connection.upload_source("diabetes_test_points.txt")
    qcol_set = query_source.create_column_set(columns, "query_column_set")
    col_predict = [{'column_name': 'clinical classification'
                    'calculation_method': 'mode'}]
     predictions = network.topological_predict(query_source_id=query_source.id,
                                        query_columnset_id=qcol_set['id'],
                                        predict_columns=col_predict,
                                        return_closest_rows=True,
                                        neighbors_count=2)
                                         
    print(predictions[0])
    # {'row_id': 0, 
    #  'closest_row_ids': [0, 5],
    #  'predicted_columns': [{'column_id': 6,
    #  'prediction_prevalence': 2}]} 
    #          'nodes': [7, 81, 84, 89, 94, 125, 133, 138, 140, 182]},
    #     87: {u'clinical classification': 2, 'nodes': [198]},
    #     136: {u'clinical classification': 1,
    #           'nodes': [14, 26, 151, 166, 179, 183]}},
    # 1: {1: {u'clinical classification': 3, 'nodes': [172]},
    #     26: {u'clinical classification': 3, 'nodes': [32, 63, 149, 196, 204]},
    #     42: {u'clinical classification': 3, 'nodes': [100, 111, 118, 151]},
    #     56: {u'clinical classification': 3, 'nodes': [25, 189, 193]},
    #     83: {u'clinical classification': 3, 'nodes': [12, 14, 20, 26, 165, 179]}},
    # 2: {2: {u'clinical classification': 3, 'nodes': [198]},
    #     39: {u'clinical classification': 3,
    #          'nodes': [6, 44, 46, 50, 57, 80, 110, 188, 202]},
    #     43: {u'clinical classification': 3, 'nodes': [7, 59, 72, 90, 157, 182]},
    #     50: {u'clinical classification': 3, 'nodes': [18, 154, 185]},
    #     51: {u'clinical classification': 3,
    #          'nodes': [62, 70, 76, 77, 98, 107, 108, 113, 119]}}}
