# Ayasdi Inc. Copyright 2015 - all rights reserved.

from __future__ import absolute_import, unicode_literals, division, print_function

import os
import time

import ayasdi.core as ac


def test_asynchronous_jobs(connection, data_dir):
    source_name = 'db_test2.txt'
    source_path = os.path.join(data_dir, source_name)
    source = connection.upload_source(source_path)
    columns = ["relative weight", "blood glucose",
               "insulin level", "insulin response"]
    col_set = source.create_column_set(columns, "test_column_set")
    suggestions = source.get_auto_analysis_suggestions(column_set_id=col_set['id'])
    source.sync()
    print("The source has %s networks." % len(source.get_networks()))

    print("There are %s jobs currently running." % len(connection.get_jobs()))
    running_jobs = []
    for ind, suggestion in enumerate(suggestions):
        network_name = 'Suggestion %s' % ind
        print("Starting %s." % network_name)
        # Start a new job asynchronously. If a network with the same name
        # exists, then that network is returned, not an asynchronous job.
        # However, in this case, none of the networks are available.
        new_job = source.create_network(network_name, suggestion, async_=True)
        running_jobs.append(new_job)

    print("%s jobs remaining!" % len(running_jobs))

    while running_jobs:
        # Check which jobs are completed. Remap remaining_jobs
        # to the uncompleted running jobs
        completed_jobs = []
        remaining_jobs = []
        for job in running_jobs:

            # Update the status of this job
            # Did this job just get completed
            job.sync()
            if job.status == 'complete':
                completed_jobs.append(job)
            else:
                remaining_jobs.append(job)
        running_jobs = remaining_jobs
        time.sleep(1)
        print("Completed: %s " % ', '.join(str(v) for v in completed_jobs))
        print("Remaining jobs: %s" % len(remaining_jobs))
        print("All running jobs: %s" % len(connection.get_jobs()))
    source.show()
    connection.delete_source(id=source.id)


if __name__ == "__main__":
    # Enter your hostname here

    host = "https://platform.ayasdi.com/workbench"
    username = "MY USERNAME"
    password = "MY PASSWORD"

    connection = ac.Api(username=username,
                     password=password,
                     save_password=False,
                     url=host)
    data_dir = "PATH TO DATA FILES"
    test_asynchronous_jobs(connection, data_dir)
