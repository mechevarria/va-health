====================================
Autogrouping With the AHCL Algorithm
====================================

.. highlight:: python
   :linenothreshold: 2

In this tutorial, we perform autogrouping on the :file:`db_test_AHCL.txt` dataset using the AHCL
algorithm, for supervised analysis.

For a brief description of the difference between supervised analysis and unsupervised analysis,
see our :doc:`groups_autogroups` tutorial.

For detailed information about all the algorithms Ayasdi provides to support data analysis, see
:class:`ayasdi.core.networks.Network.autogroup_create`.

For information on how to perform autogrouping using the Workbench, see "Creating and Modifying
Groups" in the *Ayasdi Workbench User Guide*.

.. Note::
    SDK methods used in this tutorial include:
        - :class:`ayasdi.core.networks.Network.autogroup_create`
        - :class:`ayasdi.core.networks.Network.get_coloring_values`
        - :class:`ayasdi.core.source.Source.create_coloring`
        - :class:`ayasdi.core.source.Source.create_column_set`
        - :class:`ayasdi.core.source.Source.create_network`
        - :class:`ayasdi.core.source.Source.get_auto_analysis_suggestions`


About The Dataset
-----------------

:file:`db_test_AHCL.txt` is a renamed copy of :file:`db_test2.txt`. It provides sample data about 145 diabetes
patients, with relevant columns.

Before You Begin
----------------

Download a copy of :download:`data/db_test_AHCL`.

If you need to create a new notebook, follow the instructions in "Getting Started".

If you want a backup copy of the code in this page, download :download:`data/supervised_analysis_AHCL_notebook.zip`.

Once you have synchronized your data and connected to the Ayasdi platform, please begin the tutorial.

Connect to the Platform
-----------------------

All interactions between the user and the platform start with connecting to the platform:

.. code-block:: python

    import ayasdi.core as ac
    connection = ac.Api()

After connecting:

We upload the source if necessary, then get the source. To confirm that we've got the right source,
we print the source name. Once we know we have the right source, we sync with the platform.

.. code-block:: python

    source = connection.upload_source("db_test_AHCL.txt")

.. code-block:: python

    source = connection.get_source(name="db_test_AHCL.txt")

.. code-block:: python

    print source.name

**Expected:**

.. code-block:: python

    db_test_AHCL.txt


Finally:

.. code-block:: python

    source.sync()

Create a New Network
--------------------

The following steps create a new network, drawing upon :file:`db_test_AHCL.txt`. The process is
described in detail in :doc:`create_a_network`.

To summarize:

    1. View the columns in your data source
    2. Specify a column list
    3. Create the column set
    4. Obtain a set of recommendations/specify a params_dict
    5. Create the topological network

.. code-block:: python

    print source.column_names


**Expected:**

.. code-block:: python

    [u'ID', u'relative weight', u'blood glucose', u'insulin level', u'insulin response', u'steady state plasma glucose', u'clinical classification']


Next:

.. code-block:: python

    AHCL_column_list = ['blood glucose','steady state plasma glucose','clinical classification']

.. code-block:: python

    AHCL_col_set = source.create_column_set(AHCL_column_list, "clinicals_supervised")

.. code-block:: python

    suggestions = source.get_auto_analysis_suggestions(column_set_id=AHCL_col_set['id'])

\To confirm:

.. code-block:: python

    print suggestions[1]

**Expected:**

.. code-block:: python

    {u'metric': {u'id': u'Norm Correlation'}, u'column_set_id': u'2104621910551258066', u'lenses': [{u'resolution': 30, u'gain': 3.0000000000000004, u'equalize': True, u'id': u'L-Infinity Centrality'}]}

Finally:

.. code-block:: python

    network = source.create_network("ACHL_Trials", suggestions[1])
    print network.name

**Expected:**

.. code-block:: python

    ACHL_Trials


*(Printing the network name confirms that the previous line of code ran correctly.)*

Now we're ready to set up coloring values for our groups!


Setting Up Coloring Values
--------------------------

The ACHL algorithm divides a model into groups that have similar color values. Therefore,
before we can run **Network.autogroup_create** (which references both cutoff_strength and
coloring_values), we need to define the coloring parameter.

The first action creates a variable named ACHL_coloring by creating a coloring scheme ('class')
based on the “clinical classification” column of the dataset:

.. code-block:: python

    ACHL_coloring = source.create_coloring(name='class',column_name='clinical classification')


The next action gets the coloring values for your coloring scheme:

.. code-block:: python

    coloring_values_class = network.get_coloring_values(name='class')


Running network.autogroup_create
--------------------------------

We're going to perform this autogrouping using a minimum group size of 2 so we can avoid groups that are
comprised of singletons. We will specify a high cutoff strength parameter, which will produce groups that
cluster together strongly.

.. code-block:: python

    autogroups = network.autogroup_create(algorithm='AHCL', cutoff_strength=1,coloring_values=coloring_values_class,
                                          name='AHCL_groups_', min_node_count=2)

    supervised_groups = source.get_groups()
    for group in supervised_groups:
        print group['name']

**Expected:**

.. code-block:: python

    AHCL_groups__4
    AHCL_groups__0
    AHCL_groups__1
    AHCL_groups__5
    AHCL_groups__3
    AHCL_groups__2
    AHCL_groups__6


The autogrouping created seven groups.

Now What?
---------

You have just performed your first autogrouping for supervised analysis using the AHCL algorithm.

Now let's try auto-generating groups with Connected Components.

Proceed to :doc:`connected_components`.
