from __future__ import absolute_import, division, print_function

import os

import ayasdi.core as ac
import ayasdi.core.models as acm
import matplotlib.pyplot as plt
import numpy as np


def config_source(connection, csv_file, csv_file_name):
    src = connection.upload_source(csv_file)
    src = connection.get_source(name=csv_file_name)
    src.sync()
    return src


def plot_roc(stats):
    x_array = np.array([point.x for point in stats.receiver_operating_characteristic_curve.points])
    y_array = np.array([point.y for point in stats.receiver_operating_characteristic_curve.points])
    plt.plot(x_array,y_array)
    plt.show()


def config_model(classifier, connection, src, name=None, col_set=None, outcome_column_name=None, group=None):
    model = classifier.create(connection,
                              source_id=src.id,
                              name=name,
                              outcome_column_index=src.colname_to_ids[outcome_column_name],
                              column_set_id=col_set['id'],
                              group_id=group['id'])
    return model


def config_stats(model,src,col_set=None,outcome_column_name=None,group=None):
    stats = model.generate_validation_statistics(src.id,
                                                 column_set_id=col_set['id'],
                                                 outcome_column_index=src.colname_to_ids[outcome_column_name],
                                                 group_id=group['id'])
    return stats


def test_roc_curve(connection, data_dir):
    print('Upload File')
    data_name = 'creditcard.csv'
    data_path = os.path.join(data_dir, data_name)
    source = config_source(connection, data_path, data_name)
    print('File Uploaded')

    print('Creating train-test groups')
    train_test_split = 0.8
    dataset_group = source.create_group(name='data_set')
    train_group_set = source.create_group_set(name='train_set',
                                              stratified_sampled_group_set={
                                                  'group_id':dataset_group['id'],
                                                  'outcome_column_index':source.colname_to_ids['Class'],
                                                  'specifications':[{'num_rows_in_group':int(source.row_count*train_test_split)}]
                                              }
                                             )
    train_group = source.get_group(id=train_group_set.groups[0]['id'])
    row_indices_set = set(list(range(source.row_count)))
    train_indices_set = set(list(train_group['row_indices']))
    test_indices_set = list(row_indices_set - train_indices_set)
    test_group = source.create_group(name='test_set',row_indices=test_indices_set)
    groups = source.get_groups()
    print('Groups present:' + str([str(group['name']) for group in groups]))
    
    print('Training model')
    features_col_list = source.create_column_set(column_list=source.column_names[:-1],name='features')
    print('Columns present:' + str([str(cols) for cols in source.column_names[:-1]]))

    model = config_model(acm.GBDT,
                         connection,
                         source,
                         name='GBDTree',
                         col_set=features_col_list,
                         outcome_column_name='Class',
                         group=train_group)
    print('Model Trained')
    
    print('Preparing Stats')
    stats = config_stats(model,
                         source,
                         col_set=features_col_list,
                         outcome_column_name='Class',
                         group=test_group)
    print('Stats Prepared, plotting ROC curve')
    plot_roc(stats)
    connection.delete_source(id=source.id)


if __name__ == "__main__":
    host = "https://platform.ayasdi.com/workbench"
    username = "USERNAME"
    password = "PASSWORD"
    conn = ac.Api(username=username, password=password, save_password=False, url=host)
    data_dir = "DATA DIR"
    test_roc_curve(conn, data_dir)