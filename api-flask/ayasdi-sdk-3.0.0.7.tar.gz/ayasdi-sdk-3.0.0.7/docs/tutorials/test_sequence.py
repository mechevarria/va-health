from __future__ import absolute_import, unicode_literals, division, print_function
import os

import ayasdi.core as ac

def test_sequence(connection, data_dir):

    # Upload sequence file 1 and create a column set containing only the sequence column
    print("Load dataset 1")
    source_name = 'clicks.txt'
    source_path = os.path.join(data_dir, source_name)
    src = connection.upload_source(source_path)

    column_set = src.create_column_set(column_list=["AyasdiSeq_event_json"], name='columns_sequence')
    print("Dataset 1 loaded, column set with sequence column created")

    # Upload sequence file 2 and update the type of the sequence column
    print("Load dataset 2")
    source_name2 = 'clicks_noseq.txt'
    source_path2 = os.path.join(data_dir, source_name2)
    src2 = connection.upload_source(source_path2)
    sequence_column_index = 1
    src2.update_columns(columns=[{'column_index': sequence_column_index, 'variable_type': 'sequence'}])
    print("Dataset 2 loaded, datatype for sequence column updated")
    print(src2.columns[sequence_column_index]["data_type"])

    # Create network with source 1
    print("Creating network from source 1")
    network = src.create_network("test_network_seq",
                             {'metric': {'id': 'DTW Needleman Wunsch'},
                              'column_set_id': column_set['id'],
                              'lenses': [{'resolution': 10, 'id': 'Gaussian Density', 'equalize': True, 'gain': 3.0}]})

    # Compute comparisons
    src.create_group(name='g0', row_indices=list(range(10)))
    comparisons = src.compare_groups('g0', 'Rest', comparison_type='categorical_only')
    print("Comparisons computed")
    print(comparisons)

if __name__ == "__main__":
    # Enter your hostname here

    host = "https://platform.ayasdi.com/workbench"
    username = "MY USERNAME"
    password = "MY PASSWORD"

    connection = ac.Api(username=username,
                     password=password,
                     save_password=False,
                     url=host)
    data_dir = "PATH TO DATA FILES"
    test_sequence(connection, data_dir)
