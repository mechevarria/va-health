Comma-separated-value (CSV) Vectorial Data
===============

.. highlight:: python
   :linenothreshold: 2


In addition to standard data type such as integers, doubles, or strings, the Ayasdi platform code can also handle
data representing collections of comma-separated values, where each value is represented by a String.

Examples of such data may be a list of symptoms or conditions experienced by a patient, or a list of product IDs
purchased by a customer. Then, the user may want to analize these data based on common entities among the various
data points.

The Ayasdi platform can handle CSV vector data, providing compatible Metrics and Lenses that can be used to create
Topological Models, and categorical explains based on the CSV vector columns.

Before You Begin
----------------

Download a copy of the tutorial data set, :download:`providers_ls_items.csv <data/providers_ls_items.csv>`.

Download a full running copy of the tutorial script, :download:`test_csv_vectors.py <test_csv_vectors.py>`.

How to Use CSV Vector Data
--------------------------

This tutorial guides you through uploading a data source with a column containing CSV vector data to the Ayasdi
Platform, and generating a Topological Model and explains based on that column.

CSV vector Data Format
----------------------

A column can be automatically recognized by the Ayasdi Platform as containing CSV vector data if its column header
contains either the prefix `AyasdiCSV_` or the suffix `_AyasdiCSV`. The data type of any column can be also
updated manually if the header does not contain such substrings.

The CSV vector data is represented as a string made of comma-separated substrings. For the data to be parsed correctly
during upload, it is suggested to either use tabs to separate columns in the source file, or to include the entire
CSV vector within quote marks.  These are the current validation rules:
 - Vectors must have less than 1,000,000 elements.
 - If **CsvVector Hamming** is used as Metric to build Topological Models, all vectors must have the same length.

For an example of a CSV vector file, see :download:`providers_ls_items.csv <data/providers_ls_items.csv>`.

Available Metrics
-----------------

Two specialized metrics for CSV vector data are available:
    - **CsvVector Jaccard**: a Jaccard-type measure of similarity, where CSV vectors are interpreted as sets of
        elements, and the metric depends on the size ratio between intersection and union of the two sets.
        Duplicate elements in each vector and their order do not affect the metric. This allows to compare
        vectors with variable lengths.
    - **CsvVector Hamming**: a Hamming-type measure of how similar two arrays are to each other. This measure
        requires all vectors to be of the same length, as it compares vectors element by element in the order
        they appear. Therefore, duplicate elements in each vector will affect the metric.


Example
-------

Here is a short example of working with a sequential data source. First, set up the connection.

.. code-block:: python

    import ayasdi.core as ac
    connection = ac.Api()


Next, upload the data source file. Create a column set containing the column with sequential data, usually marked by a
prefix **AyasdiSeq_**.

.. code-block:: python

    src = connection.upload_source('providers_ls_items.csv')
    column_set = src.create_column_set(column_list=["AyasdiCSV_line_service_items"], name='column_csv')


In case the CSV vector column cannot be automatically detected by the Ayasdi Platform (because its header does not
contain the standard substring **AyasdiCSV**), its data type can be updated manually to data type **csv_vector**.

Create the network using one of the available metrics, **CsvVector Jaccard** or **CsvVector Hamming**. As a Lens,
you can use any of the lenses that are built using the underlying Metric: for instance, **Gaussian Density**,
**L1 Centrality**, or **Neighborhood (LSNE)**.

.. code-block:: python

    network = src.create_network("test_network_csv",
                                     {'metric': {'id': 'CsvVector Jaccard'},
                                      'column_set_id': column_set['id'],
                                      'lenses': [{'resolution': 10, 'id': 'Gaussian Density',
                                                  'equalize': True, 'gain': 3.0}]})


Create a group and obtain categorical explains that include the CSV vector column

.. code-block:: python

    src.create_group(name='g0', row_indices=list(range(10)))
    comparisons = src.compare_groups('g0', 'Rest', comparison_type='categorical_only')

