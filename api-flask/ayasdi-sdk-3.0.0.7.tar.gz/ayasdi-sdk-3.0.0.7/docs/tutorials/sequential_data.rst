Sequential Data
===============

.. highlight:: python
   :linenothreshold: 2


In addition to standard data type such as integers, doubles, or strings, the Ayasdi platform code can also handle data
representing ordered sequences of objects.

Examples of such sequential data may be the Carepath of a patient, consisting of all the detailed events (drug
prescription, labs, doctor's visit) taking place during their treatment; or the sequence of pages visited by a
user on a website.

The Ayasdi platform can handle such data, providing compatible Metrics and Lenses that can be used to create
Topological Models, and categorical explains based on the sequential columns.

Before You Begin
----------------

Download a copy of the tutorial data sets, :download:`clicks.txt <data/clicks.txt>` and
:download:`clicks_noseq.txt <data/clicks_noseq.txt>`.

Download a full running copy of the tutorial script, :download:`test_sequence.py <test_sequence.py>`.

How to Use Sequential Data
--------------------------

This tutorial guides you through uploading a data source with a column containing sequential data to the Ayasdi
Platform, and generating a Topological Model and explains based on that column.

Sequential Data Format
----------------------

A column can be automatically recognized by the Ayasdi Platform as containing sequential data if its column header
contains either the prefix `AyasdiSeq_` or the suffix `_AyasdiSeq`. The data type of any column can be also
updated manually if the header does not contain such substrings.

The sequential data is represented as a Json-serialized string, where each sequence is represented as a list of
dictionaries. These are the current validation rules:
 - Each sequence element must have `code` and `time` fields; any other field is optional.
 - Code value is always treated as string; time value must be a numeral.
 - No sequence longer than 5000 elements.
 - No more than 20000 unique code values in all sequences.

Each dictionary MUST have a String key `code` that uniquely identifies the event in the sequence: for instance,
where the sequence represents the webpages visited by a website user, `code` may be the URL of each visited page.

For an example of a sequential file, see :download:`clicks.txt <data/clicks.txt>`.


Example
-------

Here is a short example of working with a sequential data source. First, set up the connection.

.. code-block:: python

    import ayasdi.core as ac
    connection = ac.Api()


Next, upload the data source file. Create a column set containing the column with sequential data, usually marked by a
prefix **AyasdiSeq_**.

.. code-block:: python

    src = connection.upload_source('clicks.txt')
    column_set = src.create_column_set(column_list=["AyasdiSeq_event_json"], name='columns_sequence')


In case the sequential column cannot be automatically detected by the Ayasdi Platform (because its header does not
contain the standard substring **AyasdiSeq_**), its data type can be updated manually to data type **sequence**.

.. code-block:: python

    src2 = connection.upload_source('clicks_noseq.txt')
    sequence_column_index = 1
    src2.update_columns(columns=[{'column_index': sequence_column_index, 'variable_type': 'sequence'}])


Create the network using the available sequence metric, **DTW Needleman Wunsch**.

.. code-block:: python

    network = src.create_network("test_network_seq",
                                     {'metric': {'id': 'DTW Needleman Wunsch'},
                                      'column_set_id': column_set['id'],
                                      'lenses': [{'resolution': 10, 'id': 'Gaussian Density',
                                                  'equalize': True, 'gain': 3.0}]})


Create a group and obtain categorical explains that include the sequential column

.. code-block:: python

    src.create_group(name='g0', row_indices=list(range(10)))
    comparisons = src.compare_groups('g0', 'Rest', comparison_type='categorical_only')

