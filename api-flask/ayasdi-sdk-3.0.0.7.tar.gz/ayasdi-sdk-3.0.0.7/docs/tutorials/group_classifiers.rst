Creating a Group Classifier
===========================

.. highlight:: python
   :linenothreshold: 2

Each group you derive from a dataset is useful on its own, but it's also powerful to treat these groups as classes
into which we can classify future incoming data. This enables us to predict the new data's behavior or outcome.

If you want to use your groups to help predict behaviors or outcomes of new incoming data, you can build a
*group classifier*, incorporating groups of interest. You can then evaluate new incoming data against that
classifier. (Note: The new incoming data should have the same columns as the original data set used to create the
classifier.)

This tutorial walks you through the process of creating a group classifier and using it to classify new incoming data.

.. Note::
    SDK Methods used in this tutorial include:
        - :class:`ayasdi.core.models.Models.ClassificationModel.predict_proba`
        - :class:`ayasdi.core.models.Models.LogisticRegressionSpec`
        - :class:`ayasdi.core.models.Source.create_network`
        - :class:`ayasdi.core.models.Source.get_auto_analysis_suggestions`


About The Dataset
-----------------

We illustrate group classifier creation using groups that have previously been created while performing the tutorial
:doc:`autogroups_AHCL`, which uses :download:`db_test_AHCL.txt <data/db_test_AHCL.txt>`.
We illustrate the classification of new incoming data using a new file, :download:`new_patients_Q3.txt<data/new_patients_Q3.txt>`.

If you have not yet uploaded a dataset, see :doc:`getting_started`.

Before You Begin
----------------

If you need to create a new notebook, follow the instructions in :doc:`getting_started`.

If you want a backup copy of the code in this page, download :download:`new_patients_Q3.txt<data/new_patients_Q3.txt>`.

If you want to follow along with us, download :download:`group_classifiers_notebook.zip<data/group_classifiers_notebook.zip>`.

Once you have connected to the Ayasdi platform, please begin the tutorial.

Connect to the Platform
-----------------------

All interactions between the user and the platform start with connecting to the platform.

In this case, we also import all classes in the ayasdi.core.models module, which we'll need to create the group classifier.

Run:

.. code-block:: python

    import ayasdi.core as ac
    import ayasdi.core.models as acm
    connection = ac.Api()


Get the datasource that contains the groups you want to classify. In this case, we'll use :file:`db_test_AHCL.txt`.

Run:

.. code-block:: python

    source = connection.get_source(name="db_test_AHCL.txt")



Check to ensure you got the right source.

Run:

.. code-block:: python

    print source.name


**Expected:**

.. code-block:: python

    db_test_AHCL.txt


Synchronize your source with the platform.

Run:

.. code-block:: python

    source.sync()


Get Groups
----------

To get a list of all groups that have been created against this data source, assign that information to the
variable "isolated_groups" via :func:`source.get_groups`, then get the group names and IDs.

Run:

.. code-block:: python

    isolated_groups = source.get_groups()
    for group in isolated groups:
        a = group[‘name’] + “  “ + group[‘id’]
        print(a)


**Expected:**

.. code-block:: python

    AHCL_groups__4 5518186
    AHCL_groups__0 5518187
    AHCL_groups__1 5518188
    AHCL_groups__5 5518190
    AHCL_groups__3 5518191
    AHCL_groups__2 5518196
    AHCL_groups__6 5518197


.. Note::
    :func:`print group ['name']` returns *all* groups that were ever created against :file:`db_test_AHCL.txt` in your
    instance, so your list of returned groups might include additional groups besides those shown above. For this
    tutorial, we are only interested in the "AHCL_groups" groups.


Examine the existing groups. Which groups do you think are interesting enough to turn into a group classifier?

Create the Group Classifier
---------------------------

A group classifier is constructed using a model specification, available through the Ayasdi platform.
(We imported all model specifications earlier in this procedure.)

We're going to base our group classifier on the :func:`LogisticRegressionSpec` from the SDK models module.

Run:

.. code-block:: python

    import ayasdi.core.models as acm

    lr_spec = acm.LogisticRegressionSpec()


Now we create the group classifier: a model for classifying new incoming data points. We're going to base our
group classifier on AHCL_groups_2 and AHCL_groups_6.

Run:

.. code-block:: python

    import ayasdi.core.models as acm

    my_gc = acm.GroupClassifier.create(
        connection,
        source_id=source.id,
        name="my_gc",
        classification_group_ids=[5518196, 5518197],
        model_spec=lr_spec
    


You've just created a group classifier based on two interesting groups in your existing dataset. You can create
as many group classifiers as you like, according to your evaluation needs.

Once you create a group classifier, it is permanent in the platform. You can reuse it any time.

Now we'll use the new group classifier to evaluate new incoming data.

Evaluate New Incoming Data
--------------------------

First we need to upload our new incoming data, contained in the file :file:`new_patients_Q3.txt`.

Run:

.. code-block:: python

    source = connection.upload_source('new_patients_Q3.txt')


.. code-block:: python

    source = connection.get_source(name='new_patients_Q3.txt')


.. code-block:: python

    print (source)


**Expected:**

.. code-block:: python

    <Source 'new_patients_Q3.txt'>


Get the source's ID; you're going to need it in a few more steps.

Run:

.. code-block:: python

    source.id


**Expected:**

.. code-block:: python

    u'4103299516281655866'


Synchronize the new source.

Run:

.. code-block:: python

    source.sync


**Expected:**

.. code-block:: python

    <bound method Source.sync of <Source 'new_patients_Q3.txt'>>


Now we'll use the group classifier you just built, to classify the new data.

The platform returns predictions about how closely the new data conforms to the classifier.

Run:

.. code-block:: python


    import ayasdi.core as ac

    predictions = my_gc.predict_proba(
        data_spec=ac.SourceSubset(4103299516281655866)
    )

.. code-block:: python

    print (predictions)


**Expected:**

.. code-block:: python

    [[0.11563106666288765, 0.11478425457629675], [0.05689160705724688, 0.00382644902321084]]


What is returned is a list of lists, where each list represents classifications for a data point. The order of
the values for a single datapoint, matches the order of the classes property of the group classifier object.

To see which predictions apply to what classes, print your classifications.

Run:

.. code-block:: python

    print (my_gc.classes)


**Expected:**

.. code-block:: python

    [u'AHCL_groups_2', u'AHCL_groups_6']


You see that the first bracketed prediction applies to the new data's similarity to AHCL_groups_2, and the second
bracketed prediction applies to the new data's similarity to AHCL_groups_6.


What's Next?
------------

Our next set of tutorials will walk you through using the **predict_decisions** method with other classifier
types.
