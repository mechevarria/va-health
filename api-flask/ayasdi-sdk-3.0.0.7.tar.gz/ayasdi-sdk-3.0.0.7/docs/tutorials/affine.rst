Analysis Using Affine Metrics
=============================

.. highlight:: python
   :linenothreshold: 2


Before You Begin
----------------

Download a copy of the tutorial data set, :download:`breast_cancer.csv <data/breast_cancer.csv>`.

Download a full running copy of the tutorial script, :download:`test_affine.py <test_affine.py>`.

Workflow
--------

.. Note::

    A single column set that contains the union of all these columns needs to be provided as an argument
    during this process. See pt. 4 in the example below.


Use affine metrics if you'd like to use separate metrics on different column sets. For instance, in the
example below, the Euclidean metric is used on one set of columns (`clump_thickness`, `uniformity_of_cell_size`,
`uniformity_of_cell_shape`), and the Correlation metric on another set of columns (`bare_nuclei`, `bland_chromatin`,
`normal_nucleoli`, `mitoses`).


Create a Connection and Import Models
----------------------------------------

.. code-block:: python

    import ayasdi.core as ac
    connection = ac.Api()


Delete a Pre-existing Data Source
----------------------------------------

.. code-block:: python

    try:
    ... connection.delete_source(name='breast_cancer.csv')
    except IndexError:
    ... pass


Upload a File and Sync the Source
----------------------------------------

.. code-block:: python

    source = connection.upload_source(
    'breast_cancer.csv')
    source.sync()


Create Column Sets for Analysis
----------------------------------------

.. code-block:: python

    columns = ['clump_thickness','uniformity_of_cell_size','uniformity_of_cell_shape',
    ...        'marginal_adhesion','single_epithelial_cell_size',
    ...        'bare_nuclei','bland_chromatin','normal_nucleoli','mitoses']
    euclidean_cols = ['clump_thickness','uniformity_of_cell_size','uniformity_of_cell_shape']
    correlation_cols = ['bare_nuclei','bland_chromatin','normal_nucleoli','mitoses']
    overall_col_set = source.create_column_set(columns, "test_column_set")
    euclidean_col_set = source.create_column_set(euclidean_cols, "euclidean_col_set")
    correlation_col_set = source.create_column_set(correlation_cols, "correlation_col_set")


Analysis Using Affine Metrics
----------------------------------------

.. code-block:: python

    network = source.create_network("AffineTest", {
        'metric': {'id': 'Affine',
                   'specifications': [{'metric_name': 'Euclidean (L2)',
                                       'column_set_id': euclidean_col_set['id'],
                                       'weight': .5},
                                      {'metric_name': 'Correlation',
                                       'column_set_id': correlation_col_set['id'],
                                       'weight':.5}]},
        'column_set_id': overall_col_set['id'],
        'lenses': [{'id': 'Mean',
                    'resolution': 30,
                    'gain': 3,
                    'equalize': True}]})


Viewing the Network in the Web App
----------------------------------

.. code-block:: python

    network.show()
