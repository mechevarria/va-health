Generating an ROC Curve
=======================

.. highlight:: python
   :linenothreshold: 2

A receiver operating characteristic curve, or ROC curve, is a graphical plot of the true positive rate(TPR) against the false positive rate(FPR) that illustrates the diagnostic ability of a binary classifier system as its discrimination threshold is varied. 

This tutorial walks you through the process of splitting a dataset into train and test groups respectively followed by training a classifier and using it on the test group to generate the ROC curve.

.. Note::
    SDK Methods used in this tutorial include:
        - :class:`ayasdi.core.models.gbdt.GBDT.create`
        - :class:`ayasdi.core.models.gbdt.GBDT.generate_validation_statistics`
        - :class:`ayasdi.core.source.create_group_set`


About The Dataset
-----------------

We illustrate ROC curve generation using :download:`creditcard.csv <data/creditcard.csv>` dataset. It's a binary-label dataset and provides information of fraudulent credit card transactions represented as a matrix of (85,442 x 32). 

The last column is the binary class(1/0 where 1 means the transaction is fraudulent). 


Before You Begin
----------------

If you need to create a new notebook, follow the instructions in :doc:`getting_started`.

If you want a backup of the code in the page and follow along with us, download :download:`roc_curve_notebook.zip <data/roc_curve_notebook.zip>`.

Once you have connected to the Ayasdi platform, please begin the tutorial.

Connect to the Platform
-----------------------

All interactions between the user and the platform start with connecting to the platform.

In this case, we also import all classes in the ayasdi.core.models module, which we'll need to create the group classifier.

Run:

.. code-block:: python

    import ayasdi.core as ac
    import ayasdi.core.models as acm
    connection = ac.Api()

Let's write few helper functions to make things easier

Run:

.. code-block:: python


    def config_source(connection,csv_file,csv_file_name):
        src = connection.upload_source(csv_file)
        src = connection.get_source(name=csv_file_name)
        src.sync()
        return src

    def config_model(classifier,connection,src,name=None,col_set=None,outcome_column_name=None,group=None):
        model = classifier.create(connection,
                                  source_id=src.id,
                                  name=name,
                                  outcome_column_index=src.colname_to_ids[outcome_column_name],
                                  column_set_id=col_set['id'],
                                  group_id=group['id'])
        return model

    def config_stats(model,src,col_set=None,outcome_column_name=None,group=None):
        stats = model.generate_validation_statistics(src.id,
                                                     column_set_id=col_set['id'],
                                                     outcome_column_index=src.colname_to_ids[outcome_column_name],
                                                     group_id=group['id'])
        return stats


Get the datasource, in our case :file:`creditcard.csv`.

Run:

.. code-block:: python

    source = config_source(connection,'data/creditcard.csv','creditcard.csv')

Check to ensure you got the right source.

Run:

.. code-block:: python

    print(source.name+'\n')
    print(source.column_names)


**Expected:**

.. code-block:: python

    creditcard.csv

    [u'scaled_amt', u'scaled_time', u'scaled_time_elapsed', u'V1', u'V2', u'V3', u'V4', u'V5', u'V6', u'V7', u'V8', u'V9', u'V10', u'V11', u'V12', u'V13', u'V14', u'V15', u'V16', u'V17', u'V18', u'V19', u'V20', u'V21', u'V22', u'V23', u'V24', u'V25', u'V26', u'V27', u'V28', u'Class']

Create appropriate column set
-----------------------------

The last column is the label column and has to be removed to get the feature set for prediction.

Run:

.. code-block:: python

    features_col_list = source.create_column_set(column_list=source.column_names[:-1],name='features')
    print(features_col_list['column_indices'])

**Expected:**

.. code-block:: python

    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30]

Make Groups
-----------

To split the datasource into corresponding train and test groups, we use functions such as :func:`source.create_group_set` and :func:`source.create_group`

Run:

.. code-block:: python

    train_test_split = 0.8
    dataset_group = source.create_group(name='dataset')

    # Make a group set containing 80% of the total dataset
    group_set = source.create_group_set(name='train_set',
                                              stratified_sampled_group_set={
                                                  'group_id':dataset_group['id'],
                                                  'outcome_column_index':source.colname_to_ids['Class'],
                                                  'specifications':[{'num_rows_in_group':int(source.row_count*train_test_split)}]
                                              })

    # Fetch train and test data groups
    row_indices_set = set(list(range(source.row_count)))
    train_group = source.get_group(id=group_set.groups[0]['id'])
    train_indices_set = set(list(train_group['row_indices']))
    test_indices_set = list(row_indices_set - train_indices_set)
    test_group = source.create_group(name='test_set',row_indices=test_indices_set)

    print([group for group in group_set.groups])
    print('\n'+'Total_row_count: '+str(len(row_indices_set)))
    print('Train_row_count: '+str(len(train_indices_set)))
    print('Test_row_count: '+str(len(test_indices_set)))

**Expected:**

.. code-block:: python

    [{u'entity_uri': u'/v1/sources/8280682560409176253/groups/9914273', u'row_count': 227845, u'id': u'9914273', u'name': u'train_set_227845_1234'}]

    Total_row_count: 85442
    Train_row_count: 68353
    Test_row_count: 17089

Training a GBDT classifier
--------------------------

Let's train our classifier based on train_group and features_col_list. We're going to use the helper functions written before to configure and train the model, this may take few seconds.

Run:

.. code-block:: python

    model = config_model(acm.GBDT,
                     connection,
                     source,
                     name='GBDTree',
                     col_set=features_col_list,
                     outcome_column_name='Class',
                     group=train_group)

Generating ROC curve using validation statistics
------------------------------------------------

The :func:`model.generate_validation_statistics` is a method defined in the SDK to provide information about a models performance. It returns a :class:`ayasdi.core.models.multiclass_statistics.MulticlassStatisticsobject` for a multi class model, a :class:`ayasdi.core.models.classification_statistics.ClassificationStatistics` object, or a :class:`ayasdi.core.models.regression_statistics.RegressionStatistics` object for a regression model

In our case the :func:`stats.receiver_operating_characteristic_curve.points` is used to get x,y coordinates to plot the ROC curve. Lets build a helper function that gets the task done.

Run:

.. code-block:: python

    def plot_roc(stats):
        x_array = np.array([point.x for point in stats.receiver_operating_characteristic_curve.points])
        y_array = np.array([point.y for point in stats.receiver_operating_characteristic_curve.points])
        plt.plot(x_array,y_array)
        plt.show()

    stats = config_stats(model,
                     source,
                     col_set=features_col_list,
                     outcome_column_name='Class',
                     group=test_group)

    print(stats)                 
    plot_roc(stats)

**Expected:**

.. code-block:: python

    {'_ClassificationStatistics__ready': True,
     '_accuracy': 0.9997659313008368,
     '_area_under_receiver_operating_characteristic_curve': 0.9832893682708647,
     '_condition_negative': 17059,
     '_condition_positive': 30,
     '_decision_threshold': 0.18118813633918762,
     '_f1Score': 0.9310344827586207,
     '_f1_score': 0.9310344827586207,
     '_fallOut': 5.86200832405182e-05,
     '_fall_out': 5.86200832405182e-05,
     '_false_negative': 3,
     '_false_positive': 1,
     '_precision': 0.9642857142857143,
     '_recall': 0.9,
     '_receiver_operating_characteristic_curve': Two dimensional curve of 54 points,
     '_specificity': 0.9999413799167595,
     '_true_negative': 17058,
     '_true_positive': 27,
     'async_job': None,
     'connection': <ayasdi.core.api.Api object at 0x7fffec10cfd0>,
     'f1Score': 0.9310344827586207,
     'fallOut': 5.86200832405182e-05,
     'model_type': u'GBDT'}

.. figure:: roc.png


.. Note::
    The output of print(stats) is truncated on purpose as the removed part has coordinate information of 54 (x,y) points and would take up space unnecessarily.

