# Ayasdi Inc. Copyright 2014 - all rights reserved.

# Add necessary imports
from __future__ import absolute_import, division, print_function
import os


def test_affine(connection, data_dir):

    source_name = 'db_test2.txt'
    source_path = os.path.join(data_dir, source_name)

    print("Load dataset")
    source = connection.upload_source(source_path)
    source.sync()

    columns = ["relative weight", "blood glucose",
               "insulin level"]
    col_set = source.create_column_set(columns, "test_column_set")
    suggestions = source.get_auto_analysis_suggestions(column_set_id=col_set['id'])
    print(suggestions[0])

    print("Create network")
    network = source.create_network("test", suggestions[0])
    print("Create coloring")

    coloring = source.create_coloring(name='test',
                                      column_name='clinical classification')
    coloring_values = network.get_coloring_values(id=coloring['id'])

    print("Create autogroups")
    autogroups = network.autogroup_create()

    print("Compare Group#1 and Group#2")
    comparison = source.compare_groups(autogroups.groups[0]['name'], autogroups.groups[1]['name'])
    print(comparison)

    # Create a macro that encapsulates the current state of source.
    source.export_metadata('macro.json')

    # Upload a new source and apply the macro to it.
    new_source_name = 'db_metadata_test.txt'
    new_source_path = os.path.join(data_dir, new_source_name)

    print("Load dataset")
    new_source = connection.upload_source(new_source_path)
    new_source.import_metadata('macro.json')

    # Check that the column sets, networks, colorings,
    # and comparisons are identical
    colorings = [i['name'] for i in source.get_colorings()]
    print(colorings)
    new_colorings = [i['name'] for i in new_source.get_colorings()]
    print(new_colorings)

    networks = [i.name for i in source.get_networks()]
    print(networks)
    new_networks = [i.name for i in new_source.get_networks()]
    print(new_networks)

    comparisons = [i['name'] for i in source.get_comparisons()]
    print(comparisons)
    new_comparisons = [i['name'] for i in new_source.get_comparisons()]
    print(new_comparisons)
