ayasdi.core.utilities package
=============================

Using Utilities
---------------

In order to use some of these utility modules, such as
ayasdi.core.utilities.comparisons, you must install a few additional
dependencies. This can be done in the following manner:

    $ pip install ayasdi-sdk-\ |version|\ .tar.gz[utils]

Subpackages
-----------

.. toctree::

    ayasdi.core.utilities.comparisons
    ayasdi.core.utilities.export
    ayasdi.core.utilities.networks

Submodules
----------

.. toctree::

   ayasdi.core.utilities.lib

Module contents
---------------

.. automodule:: ayasdi.core.utilities
    :members:
    :undoc-members:
    :show-inheritance:
