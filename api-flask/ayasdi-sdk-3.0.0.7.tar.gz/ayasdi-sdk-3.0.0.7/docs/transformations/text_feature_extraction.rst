===========================================
Text Feature Extraction Transformation Step
===========================================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.TextFeatureExtractionTransformationStep` is a physical or virtual transformation
that enables you to extract features from unstructured text that resides within a single column in the datasource.
Features can be extracted three ways:

    - **Specify an extraction algorithm input parameter** defining the logic for extracting the text, such as
      log_likelihood.
    - **Specify an allowed_ngram_length_list parameter** of ngrams lengths to be considered. For example, [1,3,4]
      means only consider ngrams of 1, 3 or 4 and all 2-length will be discarded.  This can include None as an
      option, which means consider all lengths up to max_ngram_length.
    - **Specify a custom stop_word_list and a start_word_list**. Stop Word Lists specify words that should not
      be used to create columns; such lists remove common and overly frequently used words from consideration.
      Start Word Lists specify words that should not be excluded (never used as Stop Words).

.. Note::
    If the Start Word List is null or empty, the platform uses a default internal set.

Developers can use this transform to identify distinctive features in their unstructured text or corpora, and even
use this transform to distinguish one group of texts from another group of texts.

Use Case
--------

Specify an extraction algorithm such as log_likelihood which processes text by extracting words and N-grams (series
of N adjacent words) from the column of text.  It then computes the log likelihood for each word and N-Gram across
the corpus and selects those that are most significant to be the new columns (features) added to the data.

The row value calculated is the Term Frequency/Inverse Document Frequency (TF/IDF), which provides a measure of
term importance calculated by dividing the number of times a given token (i.e. word or N-Gram) appears in a given
document by the inverse number of documents the token appears in.

The numerator puts more weight on terms that are more common in the given document, while the denominator reduces
the weight of terms that are extremely common across all documents.

Often, the row text data represents the text extracted from a single document, such as a customer feedback form,
and all the row values in the column are considered the corpus of the text data. For example, perhaps the text corpus
is simply a list of repeating numbers such as:

.. code-block:: python

    one two three four one two three four one


Performing a Text Feature Extraction Transformation might return the following term frequencies
(TF/IDF values) for the tokens (one, two, three, four), given the various 3-gram word series:

+----------------+------+------+-------+------+
| Original       | one  | two  | three | four |
+----------------+------+------+-------+------+
| one two three  | 0.33 | 0.33 | 0.33  |      |
+----------------+------+------+-------+------+
| two three four |      | 0.33 | 0.33  | 0.33 |
+----------------+------+------+-------+------+
| three four one | 0.33 |      | 0.33  | 0.33 |
+----------------+------+------+-------+------+


How Ayasdi’s Text Feature Extraction Process is Unique
------------------------------------------------------

What is interesting about Ayasdi’s feature extraction over other NLP systems is the Ayasdi system will perform a
dynamic Stop Word List generation based on statistics in the whole source.  This Automatic Stop Word List is
created from distribution of words throughout the columns being used for the next transformation duing the text
transformation step.

For example, before specifying Stop Words columns such as "resection_of", "course_he" or "were_clear" might show
up as candidate features.  Once a Stop Words list is defined, the columns that contain "of", "he" and "were" can
be removed and replaced with columns that are potentially more important as features.

Example
-------
.. code-block:: python

    transform_step = transformations.TextFeatureExtractionTransformationStep(
                                                                             description='description',
                                                                             column_name='Original',
                                                                             max_columns=4,
                                                                             max_ngram_length=1,
                                                                            virtual=True)

    # Set up the transformation configuration
    tc = TransformationConfiguration.create(
                                            'description',
                                            transform_step)
    tc.validate(connection)
    new_source = tc.apply(source_id=src.id, new_source_name= “not required”)
    new_source.sync()







