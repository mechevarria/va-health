==========================
Sequencing Transformations
==========================

.. highlight:: python
   :linenothreshold: 2

**See Also**

    - :doc:`intro`
    - :doc:`quickref`
    - :doc:`in-place`
    - :doc:`trainable`


Data transformations can be chained together (sequenced) to increase a datasource’s predictive and descriptive power.

To chain a number of transformations:

        (1) Define each individual TransformationStep to perform.
        (2) To create a TransformationConfiguration, call :class:`ayasdi.core.transformations.TransformationConfiguration.create`
            function with the datasource and the sequence of the TransformationSteps specified in the appropriate order.
        (3) To validate the transformation, call :class:`ayasdi.core.transformations.TransformationConfiguration.validate`.
        (4) To apply the transformation, call :class:`ayasdi.core.transformations.TransformationConfiguration.apply`
            and pass in both the `source_id` and `new_source_name` as appropriate.

You can chain together as many transformation steps as you require, configuring your data to extract the most valuable
insights.

Example
-------

The following shows chaining two transformation steps -- lagging and squaring -- to obtain a linear relationship model
for blood glucose data.

.. code-block:: python

        # Create two transformation steps
        lag_transform_step = LagTransformationStep(
                                                   description='step description',
                                                   column_name='blood glucose',
                                                   new_column_name='blood glucose lag',
                                                   lag_count=2)
        sqr_transform_step = SquareTransformationStep(
                                                      description='step description',
                                                      column_name='blood glucose lag',
                                                      new_column_name='blood glucose lag squared',
                                                      virtual=True)

        # Set up the transformation configuration
        tc = TransformationConfiguration.create(
                                                connection,
                                                'description',
                                                lag_transform_step,
                                                 sqr_transform_step)

        # Apply the transformation configuration
        new_source = tc.apply(source_id=src.id,
                              new_source_name='db_test2_new')
        new_source.sync()
        new_source.name
        'db_test2_new'
        new_source.column_names[7]
        'blood glucose lag'
        new_source.column_names[8]
        'blood glucose lag squared'

