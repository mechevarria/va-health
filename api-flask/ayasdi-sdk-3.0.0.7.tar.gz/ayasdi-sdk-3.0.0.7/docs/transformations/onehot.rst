.. Jorge: this was missing from the original 7.11 SDK Reference version, and
   neither of us ever caught it. I only caught it while finishing up my work for
   Ayasdi on 3/14/2019. For shame! -- FS

==================================
One Hot Encode Transformation Step
==================================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.OneHotEncodeTransformationStep` is a virtual-only transformation that
converts date/time data into a format is more compatible with classification and regression algorithms.

For example, in a dataset that contains information about building types you could transform the data into several
boolean columns, sorting the data into Residential,  Business, and Rental categories. You could then use the values
of these columns can be used to dictate specific fraud detection rules depending on whether or not a particular
property is a rental.

OneHotEncoding transformations do not require the user to declare a new_source_name. The user defines the maximum
number of encoded columns to be created and the nulls boolean parameter enables them to binarize the value according
to whether or not it was a null value.


Example
-------

The following code transforms a table that includes (but does not highlight) car colors, into a table that identifies
and highlights that data.

.. code-block:: python

    t1 = transformations.OneHotEncodeTransformationStep(
                                                        description='One Hot Encoding',
                                                        column_name='Car Color',
                                                        max_columns=6000)

    tc = transformations.TransformationConfiguration.create(connection, 'description', t1)
    new_source = tc.apply(source_id=src.id, new_source_name=None)
