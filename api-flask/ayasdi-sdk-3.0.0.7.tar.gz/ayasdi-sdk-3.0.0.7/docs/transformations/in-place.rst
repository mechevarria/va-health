========================
In-place Transformations
========================

.. highlight:: python
   :linenothreshold: 2

**See Also**

    - :doc:`intro`
    - :doc:`quickref`
    - :doc:`trainable`
    - :doc:`sequencing`


A datasource is associated with a number of artifacts, such as networks and comparisons. When you transform a
datasource and create a new datasource, that new datasource does not inherit the associations of the original
datasource. If you want to apply transformations without having to create a new datasource, you can perform data
transformations "in place", directly on an already-loaded datasource.

In-place transformations are virtual, that is, they do not permanently add data to the existing datasource.

In a typical in-place transformation, the transformation is called via the transformation apply function without
specifying a `new_source_name` (which physically adds transformed columns to the existing source). This adds the
new transformed columns to the original source and retains existing topological networks, comparisons, groups,
column sets, or colorings already associated with the in-place datasource.

Exceptions to this (requiring both the `virtual=True` and `new_source_name` parameters) include:
    - :doc:`groupby`
    - :doc:`join`
    - :doc:`pivot`
    - :doc:`transpose`
    - :doc:`union`


Use Cases
=========

Single in-place transformation
------------------------------
The following example shows the application of :class:`ayasdi.core.tranformations.SquareTransformationStep`
against the datasource **diabetes.txt** with `new_source_name=None`.

.. code-block:: python

    Src = connection.upload_Source("diabetes.txt")

    t3 = transformations.SquareTransformationStep(
    	                                        Description='description',
    	                                        New_column_name='sqr virtual',
	                                            Column_name='blood glucose',
	                                            Virtual=True)

    tc = transformations.TransformationConfiguration.create(connection, 'description', t3)
    new_source = tc.apply(source_id=src.id, new_source_name=None)


The original datasource now has a new virtual column, `blood glucose`, but retains its original associated
topological networks. No new source was created.



A series of in-place transformations
------------------------------------

The following example illustrates performing a series of in-place datasource transformations against the
datasource **diabetes.txt** to create a new source without having to reload any data. The Python code:

(1) Defines a new column, sq1, that transforms the column blood glucose using the
    :class:`ayasdi.core.transformations.SquareTransformationStep` object.

(2) Defines a new column, log1, that transforms the column sq1 using the
    :class:`ayasdi.core.transformations.LogarithmTransformationStep` object.

(3) Applies the transformations to the in-place datasource via
    :func:`ayasdi.core.transformations.TransformationConfiguration.create`.

(4) Declares a `new_source_name` via the tc.apply() method.

The newly-created transformed source is displayed in EurekaAI Workbench after browser refresh.

.. code-block:: python

    import os
    import ayasdi.core as ac

    os.environ["AYASDI_APISERVER"] = "https://localhost/workbench/"
    connection = ac.Api('username','password',ignore_version=True)
    filename = "diabetes.txt"
    src = connection.upload_source(filename)

    # create a transform config and apply it, getting a new source reference back
    t = ac.SquareTransformationStep(
                                                 description='description',
                                                 new_column_name='sqr1',
                                                 column_name='blood glucose')

    t2 = ac.LogarithmTransformationStep(
                                                     description='description',
                                                     new_column_name='log1',
                                                     column_name='sqr1')

    # virtual transforms currently need to use generic step and set the function name

    t3 = ac.TransformationStep(
                                            description='description',
                                            new_column_name='sqr2',
                                            column_name='log1')
        t3.function = 'sqr_v'

    t4 = ac.TransformationStep(
                                            description='description',
                                            new_column_name='log2',
                                            column_name='sqr2')
        t4.function = 'log_v'

    tc = ac.TransformationConfiguration.create(connection, 'description', t, t2, t3, t4)
    tc._serialize_steps()
    tc.validate()

    new_source = tc.apply(src.id, "new_source_name")
