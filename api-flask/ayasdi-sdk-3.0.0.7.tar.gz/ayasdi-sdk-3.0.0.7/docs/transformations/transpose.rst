=============================
Transpose Transformation Step
=============================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.TransposeTransformationStep` is a physical or virtual transformation that
transposes a datasource's rows and columns, enabling you to literally view your data from a new perspective.
This new perspective can also help you understand relationships between different variables in your data.

Use Cases
=========

Simple transposition
--------------------

Let's say your datasource contains all word count data for Wikipedia. The data might have columns for each page and
rows for each word. Such a dataset would help you analyze and compare how word usage varies across Wikipedia pages.

However, if you'd like to analyze how different specific words appear on different Wikipedia pages, you could
transpose that datasource's rows and columns and then analyze the transposed data space:


.. figure:: transpose_trans1.png


Feature selection
-----------------

Sometimes it's difficult to understand which variables in your data are highly correlated without first transforming
that data. Although it is possible to apply coloring to a topological network and view correlated variables that way,
it may be more efficient to transpose the data first to create a network showing highly correlated variables
together in the nodes.

Let's say you set up coloring in your network such that the variables "shark attacks" and "ice cream sales" show
the same coloring. This seems to indicate that these two variables are related, but are they really? By transposing
the data you might learn that "temperature" is also highly correlated with shark attacks and ice cream sales. Thus,
when you construct a model from these data you might choose to include the "temperature" variable.


Example
=======

.. code-block:: python

       # Create a transformation step
       transform_step = TransposeTransformationStep(
                                                    description='step description')

       # Set up the transformation configuration
       tc = TransformationConfiguration.create(
                                               connection,
                                               'description',
                                               transform_step)
       new_source = tc.apply(source_id=src.id, new_source_name='new source')


