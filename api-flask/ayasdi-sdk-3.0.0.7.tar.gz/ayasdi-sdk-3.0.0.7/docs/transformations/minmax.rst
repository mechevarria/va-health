===================================
Min/Max Scaling Transformation Step
===================================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.MinMaxScalingTransformationStep` is a virtual-only transformation that can be
used to normalize a column’s values into a specified range, with a defined lower and upper range value.

MinMax scaling transformations are useful for comparing data that comes from different sources that had different
scaling or scoring ranges. Often the data can be normalized with a range between 0 and 1.

For a description of legal parameters, see :class:`ayasdi.core.transformations.MinMaxScalingTransformationStep`.

Example
=======

In the following examples, we use the feature_range parameter of the MinMax scaling transformation to define the lower
(0) and upper (1) boundary of a datasource's blood glucose column. The transformed output will include a new
column, blood glucose minmax, scaled as a decimal between 0 and 1.

.. code-block:: python

    filename = "diabetes.txt"
    src = connection.upload_source(filename)

    # create a transform config and apply it, getting a new source reference back
    minmaxscaler = transformations.MinMaxScalingTransformationStep(
            description='MinMaxScaler transformation',
            column_name='blood glucose',
            feature_range=(0, 1),
            new_column_name='blood glucose minmax')

    tc = transformations.TransformationConfiguration.create(
                                                            connection,
                                                            'description',
                                                            minmaxscaler)
    print tc._serialize_steps()
    tc.validate()
    new_source = tc.apply(src.id, 'new_source_mm')
