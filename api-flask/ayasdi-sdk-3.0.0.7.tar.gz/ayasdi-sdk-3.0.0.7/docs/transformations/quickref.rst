.. The table in this page needs to be updated with all the transformations that were added
   after v. 7.11. To identify the newer transformations, see trans_updates.rst.

====================================================
Ayasdi Transformation Services Quick Reference Table
====================================================

.. highlight:: python
   :linenothreshold: 2

**See Also**

    - :doc:`intro`
    - :doc:`in-place`
    - :doc:`trainable`
    - :doc:`sequencing`

The following table provides thumbnail descriptions of each supported transformation type supported in **Ayasdi Python
SDK v. 7.11**, alphabetized by transformation type.

**Key:**
    - V = virtual-only method; does not require the declaration of a `new_source_name`
    - P = physical-only method
    - P or V = method is physical by default, but can be made virtual (see transformation method parameter description)


+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Transformation Type    | Description                           | Transform | Transformation Method                   |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Binarize               | Creates a binary column (value        | V         | BinarizeTransformationStep              |
|                        | for a given row could be 0 or 1),     |           |                                         |
|                        | based on a threshold provided         |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Date-time              | Creates 10 new columns, slicing       | P or V    | DateTimeTransformationStep              |
|                        | the date value into various aspects   |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Group By               | Specifies a particular                | P         | GroupByTransformationStep               |
|                        | congregation of rows                  |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Join multiple datasets | Creates a JOIN by columns, of two     | P         | JoinTransformationStep                  |
|                        | datasources                           |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Lag and Lag Difference | Specifies either a lag amount or a    | P         | LagTransformationStep                   |
|                        | lag difference amount to apply  to a  |           | LagDifferenceTransformationStep         |
|                        | column                                |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Logarithm              | Converts values into their log        | P or V    | LogarithmTransformationStep             |
|                        | equivalent values in order to         |           |                                         |
|                        | reduce skewness                       |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Mathematical &         | Perform an operation on two columns,  | V         | OperatorTransformationStep              |
| string operation       | creating a virtual transformation     |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Null imputation        | Specifies replacement of null         | V         | NullImputationTransformationStep        |
|                        | values                                |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| One-hot encoding       | Converts categorical values into      | V         | OneHotEncodeTransformationStep          |
|                        | binary value columns per              |           |                                         |
|                        | categorical value                     |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Pivot                  | Rotates the orientation of a          | P         | PivotTransformationStep                 |
|                        | table's rows and columns so the       |           |                                         |
|                        | data can be viewed from a             |           |                                         |
|                        | different perspective                 |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Prepend                | Prepends a string of characters to    | P or V    | PrependTransformationStep               |
|                        | the value, transforming the value     |           |                                         |
|                        | into a string datatype                |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Principal component    | Extracts principal components         | P         | PCATransformationStep                   |
| analysis               | (features) from a dataset, ordered    |           |                                         |
|                        | in decreasing order of relevance      |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Square                 | Squares a value on a column           | P or V    | SquareTransformationStep                |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Text feature           | Extracts features from                | P or V    | TextFeatureExtractionTransformationStep |
| extraction             | unstructured text                     |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Transpose              | Transposes a file's rows and columns  | P         | TransposeTransformationStep             |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Union                  | Creates a UNION by rows, of two       | P         | UnionTransformationStep                 |
|                        | datasources                           |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+
| Z-scoring              | Specifies standard scaling of data    | V         | StandardScalingTransformationStep       |
|                        | data column                           |           |                                         |
+------------------------+---------------------------------------+-----------+-----------------------------------------+