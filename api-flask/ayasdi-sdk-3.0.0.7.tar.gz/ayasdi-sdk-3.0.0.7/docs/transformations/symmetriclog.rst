=================================
Symmetric Log Transformation Step
=================================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.SymmetricLogTransformationStep` is a virtual transformation that performs
a symmetric logarithm operation against a numeric column’s values, transforming the data such that it
represents a logarithmic curve passing through 0,0 and is symmetric on both sides.

The calculation used is:

    Y= log(X+1.0) for X>=0
    Y=–log(-X+1.0) for X<0

Although logarithmic transformations are helpful for transforming (positive only) data that has both large and
small components that are significant, such as neutron scattering data, the symmetric logarithmic transformations
can transform data with a wide range of both positive and negative values.

Taking a value's symmetric logarithm is similar to taking the value's logarithm, except that a symmetric log
centers the graph so that it crosses through the (0,0) intercept and allows for the valid transformation of
negative X values:

**Jorge, please check the following table, which I copied exactly as I found it in the Platform Release Notes**

+-----------------------+-------------------+---------------------------+
| Value of interest (X) | LOG               | SYMMETRIC LOG             |
|                       | Y=Logarithm(X)    | Y=Logarithm(X+1) if X>0   |
|                       |                   | Y=-logarithm(-X+1) if X<0 |
+-----------------------+-------------------+---------------------------+
| -4                    | undefined         | -0.698970004              |
+-----------------------+-------------------+---------------------------+
| -3                    | undefined         | -0.602059991              |
+-----------------------+-------------------+---------------------------+
| -2                    | undefined         | -0.477121255              |
+-----------------------+-------------------+---------------------------+
| -1                    | undefined         | -0.301029996              |
+-----------------------+-------------------+---------------------------+
| 0                     | undefined         | 0                         |
+-----------------------+-------------------+---------------------------+
| 1                     | 0                 | 0.301029996               |
+-----------------------+-------------------+---------------------------+
| 2                     | 0.301029996       | 0.477121255               |
+-----------------------+-------------------+---------------------------+
| 3                     | 0.477121255       | 0.602059991               |
+-----------------------+-------------------+---------------------------+
| 4                     | 0.602059991       | 0.698970004               |
+-----------------------+-------------------+---------------------------+
| 5                     | 0.698970004       | 0.77815125                |
+-----------------------+-------------------+---------------------------+

.. Note::
    Symmetric logarithmic transformations are helpful for handling cases where there are
    zero or negative values, which a normal logarithmic transformation cannot handle. 
    Since adding the value of "1" in the calculation does affect the data for small
    values, if your source data only has positive values, it might be better to use a 
    logarithmic transformation.


Example
=======

In this example we use a symmetric log transformation to calculate the symmetric log of
a datasource's blood glucose column. The transformation returns a new blood glucose symmetric log
column with a logarithmic base of 2.

.. code-block:: python

    filename = "db_test2.txt"
    src = connection.upload_source(filename)

    # create a transform config and apply it, getting a new source reference back
    transform_step = transformations.SymmetricLogarithmTransformationStep(
        description='step description',
        column_name='blood glucose',
        new_column_name='blood glucose symmetric log',
        base=2)

    # Set up the transformation configuration
    tc = transformations.TransformationConfiguration.create(connection,
                                                                       'description',
                                                                       transform_step)
    print tc._serialize_steps()
    tc.validate()

    new_source = tc.apply(source_id=src.id, new_source_name='db_test2_new')
    new_source.sync()