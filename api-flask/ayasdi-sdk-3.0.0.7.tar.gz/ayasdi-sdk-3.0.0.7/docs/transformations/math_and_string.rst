============================
Operator Transformation Step
============================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.OperatorTransformationStep` is a virtual-only transformation that enables
you to either perform mathematical operations on a set of columns (for creating ratios, sums, differences, etc.),
or to concatenate strings or numeric values between multiple columns.

The operation to be performed is specified by the `operator` parameter. Valid operator values are add, subtract, multiply,
divide, +, -, x, /, and concatenate.


Use Cases
=========

Performing mathematical operations
----------------------------------

Performing mathematical operations across data columns helps transform the data into a more useful format for certain
machine learning algorithms.

For example, if an existing source has columns for both originator and beneficiary financial transaction data, combining
information from the two columns into overall transaction-related ratios can uncover insights as follows:

    -  The banking institution could aggregate the amount of financial transactions by the loan originator over the last
       30 days in one column and aggregate another column by the beneficiary transactions.

    -  The combined amount that each customer (either as an originator or as a beneficiary) contributed to the transaction
       pool is an interesting feature which the OperatorTransformationStep function could sum to create a new virtual
       combined_transactions_30 column.

    -  A similar summation column could be created for the two most recent days of transactions. Then a ratio calculation
       between these two columns (combined_transactions_2/combined_transactions_30) could prove useful as an alert for
       sudden unusual transactional activity (i.e. alert if ratio > 1).

Concatenation
-------------
Let’s say the data source contains a RISK column (with possible values 1,2,3) and a COUNTRY column (US or Canada).  You
could concatenate the RISK and COUNTRY columns and then pivot the table. This would result in a table with columns for
every customer, counting the number of times the customer performed risky transactions in the US.

Essentially you would concatenate the RISK and COUNTRY columns, then pivot based on RISK_COUNTRY.

Example
=======

The following example code applies the OperatorTransformationStep method with three Operator functions.
The first Operator adds the blood glucose and insulin level column values together to form a new virtual
blood_glucose_insulin_level_added column.  The next Operator divides blood glucose by insulin level and the
third Operator concatenates name and gender string columns, as follows:

.. code-block:: python

    # Create a transformation step
    transform_step = OperatorTransformationStep(
        description='OperatorTransformation',
        functions = [
                     {'primary_column_name': ‘blood glucose’,
                      'secondary_column_names' : [‘insulin level’],
                      'operator' : ‘+’,
                      'new_column_name' : ‘blood_glucose_insulin_level_added’},
                     {'primary_column_name': ‘blood glucose’,
                      'secondary_column_names' : [‘insulin level’],
                      'operator' : ‘/’,
                      'new_column_name' : ‘blood-glucose_insulin_level_divided’},
 	                 {'primary_column_name': ‘name’,
                      'secondary_column_names' : [‘gender’],
                      'operator' : ‘concatenate’,
                      'new_column_name' : ‘concat_name_gender’,
	                  'separator' : ‘_8_’, },])

    # Set up the transformation configuration
    tc = TransformationConfiguration.create(
                                            'description',
                                            transform_step)
    tc.validate(connection)
    new_source = tc.apply(source_id=src.id, new_source_name=None)
    new_source.sync()

