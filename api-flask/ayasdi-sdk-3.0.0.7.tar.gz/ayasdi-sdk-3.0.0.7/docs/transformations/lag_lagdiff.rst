===========================================
Lag and Lag Difference Transformation Steps
===========================================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.DateTimeTransformationStep` is a physical or virtual transformation that converts
date/time data into a useful format for analysis purposes.

When date and time information has been exported from external systems as strings, use DateTimeTransforationStep to convert
the strings (in a date_time column) into 10 segmented components representing the individual data elements:

    - date
    - yearmonth
    - year
    - month
    - day of month
    - day of week
    - weekend
    - secondofday
    - timezone
    - DT error

Breaking the date_time data into specific components facilitates modeling off the relevant feature. Time series
modeling typically involves DateTime Transformations, in order to obtain the appropriate time interval for the
feature space.

The following shows a example row of transformed Date Time data:

+--------------------+----------+-----------+------+-------+------------+-----------+---------+-------------+----------+----------+
| SOURCE_DATE        | Date     | YearMonth | Year | Month | DayOfMonth | DayOfWeek | Weekend | SecondOfDay | Timezone | DT_Error |
+--------------------+----------+-----------+------+-------+------------+-----------+---------+-------------+----------+----------+
| 1954:02-08T0630:44 | 19540208 | 195402    | 1954 | 2     | 8          | 2         | 0       | 44444       | -05:00   |  OK      |
+--------------------+----------+-----------+------+-------+------------+-----------+---------+-------------+----------+----------+

By default, DateTimeTransformationStep accepts datetime data in the ISO 8601 format (e.g. 2016-12-31T23:00:00-08:00).
If you prefer not to use ISO 8601 format you can use an optional format parameter with basic java date time notation
to specify the format for the source data’s date-time strings.

For example, to omit time zone information, specify:

.. code-block:: python

    yyyy-MM-dd HH:mm:ss


(When no time zone is specified, the platform assumes the Server's time zone.)


Example
-------

.. code-block:: python

    transform_step = transformations.DateTimeTransformationStep(
                                                                description='Convert/transform a date',
                                                                column_name='date_of_event',
                                                                format="yyyy-MM-dd HH:mm:ss")

    # Set up the transformation configuration
    tc = TransformationConfiguration.create(
                                            'description',
                                            transform_step)
    tc.validate(connection)
    new_source = tc.apply(source_id=src.id, new_source_name= “not required”)
    new_source.sync()







