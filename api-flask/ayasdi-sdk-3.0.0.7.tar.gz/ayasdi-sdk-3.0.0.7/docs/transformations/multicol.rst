===============================
Multicolumn Transformation Step
===============================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.MultiColumnTransformationStep` is a virtual-only transformation that enables you
to apply a function across several columns on the data in each row.

This transformation is similar to
:class:`ayasdi.core.transformations.OperatorTransformationStep`, except that Operator transformations apply a
function across only two columns of data and supports division, which requires a primary/secondary column designation.
Multicolumn transformations accept more than two columns at a time, and does not need the distinction between primary
and secondary columns.

Multicolumn transformations are also capable of specifying lists of column names or indices, and can use wildcards and
index ranges to avoid having to name every column for inclusion. For complete information about legal parameters,
see :class:`ayasdi.core.transformations.MultiColumnTransformationStep`.

Example
-------

The following code illustrates various ways columns can be specified for multicolumn transformations using the
``geometric_mean`` function across the column values in each row. They can be referenced as a range of columns
[‘0-6’], specifically listed as [1,2,3,4,5,6], using a wildcard reference to select columns with an i value [‘\*i\*’],
or specifically named [‘relative_weight’, ‘blood glucose’], as follows:


.. code-block:: python

    connection = Api('q','q',ignore_version=True)
    filename = 'diabetes.txt'
    src = connection.upload_source("/Users/user/pySDK/" + filename)

    # Create a transformation step
    t = transformations.MultiColumnTransformationStep(
    description='description',
    column_name=None,
    new_column_name='MCF',

    # column_indices=['0-6'],
    # column_indices=[1,2,3,4,5,6],
    # column_names=['*i*'],
    column_names=['relative weight','blood glucose'],
    function_name='geometric_mean')

    # Set up the transformation configuration
    tc = transformations.TransformationConfiguration.create
        (connection,'description',t)
    tc.apply(source_id=src.id, new_source_name='MYSOURCE1')
