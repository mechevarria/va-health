===================================
Null Imputation Transformation Step
===================================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.NullImputationTransformationStep` is a virtual-only transformation that enables
you to convert null data values into a statistical calculation or value you provide.

The replacement of null values in a datasource during transformation helps ensure the integrity of the model by
eliminating missing values in source data (which compromise the statistical power of an analysis) and eliminating possible
bias in the results which can skew the data.

In this way, null imputation transformations both improve the reliability of your results, and eliminate skewed
data that can cause overestimation or underestimation.

The stat_function_replacement parameter specifies which operation to perform (avg, median, max, min, z-score, or mode)
against the column to replace the null values.  In lieu of stat_function_replacement you can specify a
user_defined_replacement value.

Use cases
---------

If a column contains null values that would be better for analysis with a real value, you can use a null imputation
transformation to automatically replace null values with the average, mean, minimum, maximum, median, mode, or z-score
value of the original column.

For example, if weight data is collected as an important explanatory variable and some values are missing, it will
skew the sample so the average weight could be used to replace the nulls and to avoid skewing the results.

As another example, if the missing data is for the customer satisfaction level column it might be assumed that some
unhappy customers left the satisfaction value null on purpose.  With this knowledge about the source data, the null
values could be replaced with an explicitly set value of 0.

The following shows the different results depending on which option was chosen, average or 0:

.. figure:: null_trans1.png

 
Example
-------

The following example replaces null values found in the insulin level column with three different statistics calculations:
avg, median and user-defined value 0.  In this case, three new virtual columns are created.

.. code-block:: python

    # Create a transformation step
    transform_step = NullImputationTransformationStep(
                                                      description='Replace nulls in insulin level column',
                                                      column_name='insulin level',
                                                      stat_function_replacement=[
                                                        {'name' : 'avg',
                                                            'new_column_name' : 'avg_filled_insulin_level'},
                                                        {'name' : 'median',
                                                            'new_column_name' : 'median_filled_insulin_level'}]
                                                      user_defined_replacement =[
                                                        {'value' : 0,
                                                            'new_column_name' : 'zero_filled_insulin_level'}])

    # Set up the transformation configuration
    tc = TransformationConfiguration.create(
                                            'description',
                                            transform_step)
    tc.validate(connection)
    new_source = tc.apply(source_id=src.id, new_source_name=None)
    new_source.sync()

