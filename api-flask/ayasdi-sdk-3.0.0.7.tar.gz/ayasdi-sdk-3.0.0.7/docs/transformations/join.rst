======================
JoinTransformationStep
======================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.JoinTransformationStep` is a physical-only transformation that merges a primary
source with any number of secondary sources. The new combined datasource will contain all the columns from the primary
source , plus the columns you specified from the secondary sources.

The ``join_type`` parameter specifies what type of table join to perform: INNER, LEFT_OUTER, or FULL_OUTER.

.. Note::

    In most cases JoinTransformationStep produces a new datasource. If you don't want a new datasource, specify either a
    LEFT_OUTER or a FULL_OUTER join, and leave the ``new_source_name`` parameter blank. The transformation appends the
    new information to the original datasource.


The ability to join multiple datasets for combined analysis is a key feature engineering ability. Like
:doc:`union`, JoinTransformationStep combines data from one or more sources into a single datasource. However, unlike
UnionTransformationStep, which only joins two datasources, JoinTransformationStep can add columns (features) not present
in the original datasource. Thus, JoinTransformationStep increases the feature space.

Example
-------
The following example shows customer transactional data being joined with customer profile data in a LEFT_OUTER join,
in order to increase the potential explanatory variables.

.. code-block:: python

    transform_step = JoinTransformationStep (
        description= 'Join transactions with customers',
        primary_source_key='beneficiary_id',
        secondary_sources=[{
            'id' : secondary_src.id,
            'key' : 'customer_id'
        }],
        join_type='LEFT_OUTER')

    # Set up the transformation configuration
    tc = TransformationConfiguration.create(connection,
        'description',
        transform_step)
    new_source = tc.apply(source_id=src.id, new_source_name="JoinedData")
    new_source.sync()


