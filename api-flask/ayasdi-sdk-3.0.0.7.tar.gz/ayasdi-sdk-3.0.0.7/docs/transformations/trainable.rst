=========================
Trainable Transformations
=========================

.. highlight:: python
   :linenothreshold: 2

**See Also**

	- :doc:`intro`
	- :doc:`quickref`
	- :doc:`in-place`
	- :doc:`sequencing`


The Ayasdi Python SDK supports the “training” of a transformation on one datasource, exporting the transformation
configuration, and then applying (exporting) the trained transformation to a second source. The second source inherits
the internal state from the first source, and shows the same generated column names as the first source.

“Trainable” transformers can be created for transformation methods that have an learned internal state as a result of
running the transformation against the first datasource, which we call the "training dataset". The
:class:`ayasdi.core.source.Source.get_transformation_config` method exports a number of parameters for use in subsequent
transformations.

Types of transformations that can be "trained" include:

	- :doc:`onehot`
	- :doc:`null`
	- :doc:`z-scoring`
	- :doc:`text_feature_extraction`


How "training" occurs
=====================

For each of the following transformations, running the transformation against the training datasource results in some
sort of learned internal state.

**Feature Extraction Transformations:**  The internal state learned is the most frequent ngrams or words extracted from
the training corpus.  These same words are then be applied by the "Trained Transformer" (exported transformation
configuration) to new datasoures. When the trained transformation is run against a new dataset, the output ngram columns
will be consistent with the training dataset.

**Null Imputation Transformations:** The internal state learned is, for example, the median value of the training
dataset’s transformed column. When the trained transformation is run against a new dataset, instead of calculating a new
median value for the transformation of a new dataset, the "learned" median value of the trained transformation is
applied.

**One Hot Encoding Transformations:** The unique values in the training dataset are transformed into new columns whose
value is either 0 or 1, depending on whether or not that value was present. When applied to a new dataset, the trained
transformer only uses the columns created during the training transformation. If there is a value in the new dataset
that was not seen during training it is ignored and a column is not created for it.

**Standard Scaling Transformations:** Similar to trained Null Imputation Transformations, any value such as min, max, or
avg calculated during the training, is applied to the new dataset.


Implementation
==============

To implement a trainable transformation:

	(1) Create a Transformation Configuration (t) applied to the training source.
	(2) To retrieve and export the saved internal stage of that transformation (t_config),
	    call :class:`ayasdi.core.source.Source.get_transformation_config`.
	(3) Upload a second source.
	(4) Apply the exported “trained” transformation (t_config) to the second source.

The following example code illustrates this process.


Example
=======

.. code-block:: python

	filename = 'clinicalnotes.txt'
	filename2 = 'clinicalnotes2.txt'

	src = connection.upload_source(filename)

	t = transformations.TextFeatureExtractionTransformationStep(
				description='description',
				column_name='text',
				max_columns=10,
				max_ngram_length=2,
				virtual=True)

	tc = transformations.TransformationConfiguration.create(connection, 'description', t)

	# new_source_name is blank, means apply to itself without creating new source
	tc.apply(source_id=src.id, new_source_name='')
	src.sync()

	# export the transformation
	t_config = src.get_transformation_config()
	print(t_config._serialize())

	# upload a second source
	src2 = connection.upload_source(filename2)

	# apply the tranforms (including trained configuration) to second source
	t_config.apply(source_id=src2.id, new_source_name='')
