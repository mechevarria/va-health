===========================
GroupBy Transformation Step
===========================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.GroupByTransformationStep` is a physical-only transformation that enables you to
aggregate individual instances of a variable into groups, by based on a specified variable(s)’ values. Once
aggregated, data can then be grouped by specified columns.

.. note::
    When stringing multiple transformations together, reference the transformed new_source_name, and not the
    original datasource name, to apply any subsequent transformations.

The GroupBy transformation specifies functions for aggregating the data based on a designated
group_by_column and aggregation_functions (sum, avg, count, median, max, and min) to apply to the column’s data
values. Multiple group_by_columns are allowed; there must be a minimum of one.

GroupBy Transformations provide a very convenient way of summarizing the frequency distribution shape of the data.
It can help improve the efficiency of data model estimations, provide a greater balancing of testing the data
across groups, and highlight the more significant subpopulations of the data. You can also change the unit of interest
for the data.

For details about legal parameters, see :class:`ayasdi.core.transformations.GroupByTransformationStep`, in the
SDK Reference.

Examples
========

Simple GroupBy transformation
-----------------------------

The following example code groups the transformed source by the columns "clinical classification" and "insulin
level". The aggregation_functions ``count`` and ``median`` are applied against the clinical classification
column; the aggregation_function ``avg`` is applied against the blood glucose column.

.. code-block:: python

    # Create a transformation step
    transform_step = GroupByTransformationStep(
        description='Group by class and insulin level',
        group_by_columns=['clinical classification', 'insulin level'],
        aggregation_functions=[
                               {'column': 'clinical classification',
                                'functions': [
                               {'name': 'count',
                                'new_column_name': 'count_clinical_classification',
                                'ignore_null': true
                                },
                               {'name': 'median',
                                'new_column_name': 'median_clinical_classification'}]},
                               {'column': 'insulin level’,
                                'functions': [
                                              {'name': 'avg',
                                               'new_column_name': 'avg_insulin_level'}]}])

    # Set up the transformation configuration
    tc = TransformationConfiguration.create(
        connection,
        'description',
        transform_step)
    new_source = tc.apply(source_id=src.id, new_source_name='diabetes2')
    new_source.sync()


GroupBy transformation with Mode function
-----------------------------------------

GroupBy transformations with ``mode`` return the most common or frequently-occurring value in the newly-transformed
column. To bypass null row values, specify ``ignore_null``.

The following example shows calling the GroupByTransformationStep function with the aggregation_function set to
``mode``, and employing the ``ignore_null`` option.

.. code-block:: python

    src = connection.upload_source("./test/diabetes_test_points.txt")
    # Create a transformation step
    transform_step = GroupByTransformationStep(
    description='Group by class and insulin level',
    group_by_columns=['clinical classification', 'insulin level'],
    aggregation_functions=[
                           {'column' : 'clinical classification',
                            'functions' : [
                           {'name' : 'mode:IGNORE_NULL',
                            'new_column_name' : 'mode_clinical_classification'}]}])
    # Set up the transformation configuration
    tc = TransformationConfiguration.create(
        connection,
        'description',
        transform_step)
    new_source = tc.apply(source_id=src.id, new_source_name='diabetes2')
    new_source.sync()


GroupBy transformation support for unique value count
-----------------------------------------------------

Many use cases involve understanding how many unique values have occurred within a data column. For example, for risk
analysis use cases, understanding the number of times a given customer has transacted with countries that are in
different assigned risk levels could be very useful.

In order to enable such analysis capability, use the GroupBy transformation's ``unique_value_count`` aggregation
option against categorical columns for grouping the data. This function creates a new column with the specified
new_column_name_prefix name prepended to the unique value being counted.

The following example shows a GroupBy transformation to group customer data by beneficiary_country_risk_level, using
``unique_value_count`` to identify each unique value in that column:

.. code-block:: python

    transform_step = GroupByTransformationStep(
    description=‘Get counts of transactions by risk level’,
    group_by_columns=['customer_id'],
    aggregation_functions=[
                           {'column': 'beneficiary_country_risk_level',
                            'functions': [
                           {'name' : 'unique_value_count',
                            'new_column_name_prefix’: 'country_risk_level'}]}])




.. VERBOSE MODE OFF!!! (mic drop)