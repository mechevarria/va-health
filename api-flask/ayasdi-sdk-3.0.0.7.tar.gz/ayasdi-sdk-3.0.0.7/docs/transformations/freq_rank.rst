===========================================
Frequency Rank Encoding Transformation Step
===========================================

.. highlight:: python
   :linenothreshold: 2


:class:`ayasdi.core.transformations.FrequencyRankEncodingTransformationStep` is a physical transformation that encodes
categorical variables based on the ranking of the most frequent values: the most frequent encoded with a "1", the
second-most frequent with a "2", etc. Essentially, it creates an ordinal “popularity column”.

Frequency Rank Encoding of categorical data is often used to improve model performance. For example, adding an order
to categorical data enables tree-based classification models to learn effective splits over the data by encoding a
categorical variable as a continuous rank variable.

Example
-------

In this example we transform a datasource's blood glucose column using DENSE tie-breaking strategy, ranking the top
eight most common blood glucose level values:

.. code-block:: python

    source = connection.upload_source(source_path)
    source.sync()

    # Create a transformation step
    transform_step = FrequencyRankEncodingTransformationStep(
        description='Frequency Rank transform',
        column_name='blood glucose',
        new_column_name='ranked_blood_glucose',
        strategy='DENSE',
        max_labels=8,
        ignore_nulls=True)

    # Set up the transformation configuration
    tc = TransformationConfiguration.create(
        connection,
        'Frequency Rank Transformation',
        transform_step)
    new_source = tc.apply(source_id=source.id, new_source_name="freq_rank")
