============================
Binarize Transformation Step
============================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.BinarizeTransformationStep` is a virtual-only transformation that takes in a
single numeric column, identified either by name or index, and creates a binary column based on a provided
threshold value. (Legal threshold values includ nulls; legal operator values include the standard supported
mathematical operators.) Values equal to or above the threshold are set to "1", and values below the threshold are
set to "0". If the threshold is greater than or less than the column’s max/min values, the Ayasdi platform returns
a validation error.

BinarizeTransformationStep is similar to :class:`ayasdi.core.transformations.OneHotEncodeTransformationStep` except
that Binarize only works with numeric columns with a threshold value applied.

Thresholding or binarization of data based on the value of a numeric column has many applications.  For example,
it is particularly useful for color coding data for certain target outcomes, creating groups from a numeric
column, or for machine learning methods that excel with binary variables. Another interesting application of
binarization of data is the encoding of images to change real-valued features of an image into binary codes,
enabling the identification of the image by a set of binary code values.


Example
=======

In the following examples, we create two new virtual columns for the datasource, ``bgluc_gt_100`` and
``ins_is_null``. We specify both a threshold and a mathemetical operator.

.. code-block:: python

    filename = 'diabetes.txt'
    src = connection.upload_source(filename)

    t = transformations.BinarizeTransformationStep(
                                                   description='description',
                                                   column_name='blood glucose',
                                                   new_column_name='bgluc_gt_100',
                                                   threshold=100,
                                                   operator='>=')

    t2 = transformations.BinarizeTransformationStep(
                                                    description='description',
                                                    column_name='insulin level',
                                                    new_column_name='ins_is_null',
                                                    threshold='null',
                                                    operator='=')

    tc = transformations.TransformationConfiguration.create(connection, 'description',t, t2)
    src2 = tc.apply(source_id=src.id, new_source_name='MY_BINARIZED_SOURCE')

    src2.sync()
    print(src2.columns)

