======================================
New Category Count Transformation Step
======================================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.CategoryCountTransformationStep` is a physical transformation that generates a
categorical count of the frequency of values within a defined time_step.

The new Category Count Transformation Service creates a column with the number of unique values or categories within
the analyzed column. This enables the statistical analysis of the data within a specified time range.


Example
-------

The following code shows applying the CategoryCountTransformationStep method to a financial transaction dataset,
counting the number of different beneficiary_id values within a future 60 day time_step. The new column will provide
the count of unique beneficiary IDs in the time range specified.

This information could be useful in understanding what percentage of the transactions were performed by the same
beneficiaries versus different beneficiaries.

.. code-block:: python

    t = transformations.CategoryCountTransformationStep(
        description='description',
        time_step = 60*24*60*60,
        time_stamp_column="transaction_timestamp",
        category_column="beneficiary_id")

    tc = transformations.TransformationConfiguration.create(connection,
        'description', t)

    tc._serialize_steps()
    tc.validate()
    new_source = tc.apply(source_id=source.id, new_source_name=new_source_name)
    new_source.sync(