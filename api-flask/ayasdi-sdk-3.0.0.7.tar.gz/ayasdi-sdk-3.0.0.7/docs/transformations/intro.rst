==============================================
Introduction to Ayasdi Transformation Services
==============================================

.. highlight:: python
   :linenothreshold: 2

**See Also**

    - :doc:`quickref`
    - :doc:`in-place`
    - :doc:`trainable`
    - :doc:`sequencing`


Ayasdi Transformation Services provide a suite of transformations that can be applied to a datasource during upload.
The transformations are either **physical** (creating a new physical column on disk) or **virtual** (calculated only
when needed; the actual values are not stored on disk).

Transformations are generally applied by the creation of TransformationStep objects. Each specific
TransformationStep inherits from a base TransformationStep class.

One or more chained transformations can be configured and stored as a TransformationConfiguration object.


.. figure:: trans_config.png



Why Transform Data?
===================
Data transformations are a critical step in any machine learning exercise, allowing for a better understanding of the
data and the creation of models that are more predictive.

Basic data transformations replace a variable with a function of that variable, such as replacing the X variable
with the square of X.  Most of the standard transformations change the distribution shape or relationships within a
data source.

Choosing which transformation service to use depends primarily on deciding what works with specific data.   It is
important to consider what makes sense in terms of limiting the range of the data as values get very small or very
large, which might, for example, lead to the use of logarithm transformations.

You might choose to transform data...

**A main motive for data transformation is greater ease of description.** However, a transformation can achieve other
objectives, as described below; in fact, they can achieve more than one of them at the same time. (For example, a
single transformation operation can both reduce skewness and produce a nearly linear relationship.)

Other reasons for transforming data include...

**To discern its distribution shape.** Rather than trying to glean insights about data in its raw form, you can use
:doc:`groupby` to discern its distribution shape. This provides a convenient way to describe and discuss the source
data, enabling insight.

**For convenience.** Transforming data can make it more convenient to use for analysis purposes.  For example,
converting a data value to a percentage or standardizing the spread between the minimum and maximum value in a column
by scaling the values could make the data more convenient for analysis.

Also, performing :doc:`in-place transformations <in-place>` is more convenient than having to transform the data
externally and reload it each time a transformation is desired.

**To reduce data skewness.** Symmetrical distributions are easier to handle and interpret than skewed distributions.
Transforming the data to have a normal, or Gaussian, distribution is ideal for statistical modeling.  For example,
many biological variables (such as weight, height and blood sugar) follow a normal distribution; this makes it easier
to analyze them. When other variables are mixed in that may not have normal distributions (such as antibody titre),
transforming them in a way that reduces data skewness is helpful for analysis.

One simple test for detecting data skewness is to compare the mean compared to the Standard Deviation. If the mean
is less than twice the standard deviation, then the distribution is likely skewed. *Left skewness* (negative skew)
has a longer tail on the left of the distribution (negative skew); *right skewness* (positive skew) has a longer
tail on the right of the distribution.

.. figure:: Skewness.png

A common practice for reducing right skewness is to take the logarithm value of a column; for reducing left skewness,
take the squares of a column.

**To produce equal spreads of data.** When comparing data of very different scales, it is easier to handle and
interpret by transforming it to have equal spreads, or homoscedasticity (data with the same spread or variability).

**To find linear relationshps.** Transformations help identify and interpret relationships between variables.  It is
easier to understand relationships between variables that are linear.  For example, plotting the logarithm of a
variable often uncovers a more linear relationship with other variables.

**To find additive relationships.** One can often uncover relationships between data elements by transforming data
through the addition of a constant or by converting multiplicative relationships to additive.
