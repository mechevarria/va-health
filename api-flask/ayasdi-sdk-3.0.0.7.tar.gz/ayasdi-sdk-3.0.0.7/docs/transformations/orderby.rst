===========================
OrderBy Transformation Step
===========================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.OrderByTransformationStep` is a physical transformation that sorts source data
by specifying a column or columns to sort against, and a sort direction of either ascending or descending order.
No new columns are created in the transformed data; the data is merely rearranged.

OrderBy trasformations work on both string and numeric data. The transformation produces a list of dictionaries,
where each dictionary contains a column name and order direction (ascending or descending).

Example
-------

In this example we apply :class:`ayasdi.core.transformations.OrderByTransformationStep` to financial transactional
data, ordering it by transaction ID in descending order, and by beneficiary bank country in ascending order.

.. code-block:: python

    # apply OrderByTransformationStep
    t = transformations.OrderByTransformationStep(
        description='description',
        order_by_columns=[{'name': 'transaction_id', 'direction': 'desc'},
            {'name': 'beneficiary_bank_country', 'direction': 'asc'}
            ])
    tc = transformations.TransformationConfiguration.create(connection,
            'description', t)
    tc._serialize_steps()
    tc.validate()

    new_source = tc.apply(source_id=source.id,
    new_source_name='time_series_order.csv’)
    new_source.sync(
