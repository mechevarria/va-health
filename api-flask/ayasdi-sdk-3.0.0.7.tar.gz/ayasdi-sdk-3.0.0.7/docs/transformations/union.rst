=========================
Union Transformation Step
=========================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.UnionTransformationStep` is a physical-only transformation that merges data from two
or more sources with an overlapping same column name and column type. The transformation creates no new columns in the
datasource; it only adds more rows (from the other datasource) with overlapping data features.

Most organizations have data obtained and stored in the same format, but in disparate locations.  When merged together,
the bigger dataset increases the usefulness of all the data and provides greater insight into the data and its causal
variables. The following diagram shows the union of US and Canada transactional data:


.. figure:: union_trans1.png


Other possible use cases:
    - Joining a datasource with transaction originators information with a datasource with beneficiary information, for
      an Anti-Money Laundering application
    - Merging transactional data from 2015 with data from 2016 to produce a two-year data source
    - Creating the union of a list of student birthdays and a list of teacher birthdays to create a master list with the
      birthdays of all students and teachers


Example
-------

The following example codes shows applying the UnionTransformationStep method to aggregate multiple data
sources:

.. code-block:: python

    # Create a transformation step
    transform_step = UnionTransformationStep(
                                             description='UnionTransformation',
                                             secondary_sources=[
                                                                {"id": <source1_id>},
                                                                {"id": <source2_id>},
                                                                {"id": <source3_id>}, ...])

    # Set up the transformation configuration
    tc = TransformationConfiguration.create(
                                            'description',
                                            transform_step)
    tc.validate(connection)
    new_source = tc.apply(source_id=src.id, new_source_name= “MergedData”)
    new_source.sync()







