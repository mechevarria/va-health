================================================
Standard Scaling (Z-scoring) Transformation Step
================================================

.. highlight:: python
   :linenothreshold: 2

:class:`ayasdi.core.transformations.StandardScalingTransformationStep` is a virtual-only transformation performed
against numeric data, that supports standard scaling of a data column (Z-scoring). StandardScalingTransformationStep
provides two standard scaling options: standard deviation (relative weight and mean. The desired standard scaling
option is specified by setting at least one of the with_mean or with_std parameters to True. If both are set to True,
then two new virtual columns are created.

.. Note::
     Within the Ayasdi Workbench, Z-Scores can visually display variable normalization using color schemes. This makes
     them appear more Gaussian, which is very useful for variables that have an exponential-like distribution in the
     raw data.

Z-scoring is a standard practice for transforming numerical columns prior to applying any machine learning method.
This transformation is especially useful:
     - when columns have different scales and you want to align them for more effective comparisons, or
     - when the raw data does not immediately indicate if the value is an expected or “normal” (comparing the
       measurement values to the entire sample of measurements provides more meaningful data for analysis)
     - for biological analysis, as a promiscuity score for binding assays

Z-Scores can be either positive or negative, depending on whether the data point is larger than the mean (positive)
or less than the mean (negative).


Use Case
--------

The Iris flower’s Petal Length variable can be converted to a Z-Score showing terms of how many standard deviations
each value is from the mean using the following procedure:

     (1) Calculate the mean
     (2) Calculate the deviation from the mean
     (3) Square the deviation from the mean
     (4) Calculate the sum of squares
     (5) Calculate the variance (SumOfSquares(n-1))
     (6) Calculate the standard deviation (SQRT of variance)


.. figure:: stdscaling_1.png


The following graphs of the Petal Length value vs. its scaled Z-Score shown below, show how scaling the data can
highlight the degree of variance from the average:


.. figure:: stdscaling_2.png



Example
-------

In the following code we call StandardScalingTransformationStep for the columns, blood_glucose and clinical
classification, and using both scaling transformation options:

.. code-block:: python

     # Create a transformation step
     bg_std_scaled_step = StandardScalingTransformationStep(
                                                           description='step description',
                                                           column_name='blood glucose',
                                                           new_column_name='blood glucose std scaled',
                                                           with_mean=True,
                                                           with_std=True)

     cc_std_scaled_step = StandardScalingTransformationStep(
                                                           description='step description',
                                                           column_name='clinical classification',
                                                           new_column_name='clinical classification std scaled',
                                                           with_mean=True,
                                                           with_std=True)

     # Set up the transformation configuration
     tc = TransformationConfiguration.create(connection,
                                             'description',
                                             bg_std_scaled_step, cc_std_scaled_step)
     new_source = tc.apply(source_id=src.id, new_source_name='New1')
     new_source.sync()


Large numbers of columns
------------------------
There may be many hundreds of columns that need to be transformed with the
standard scaling transform. Instead of adding one step per column, a single step with the
'column_names' or 'column_indices' parameter can be used. This significantly reduces internal processing time,
making the entire transformation much faster.

A quick example of how the parameter is used:

.. code-block:: python

     # build up a list of column names
     names_list = ['col1', 'col2', 'col3', 'col4']
     
     # Create a transformation step
     t = transformations.StandardScalingTransformationStep(
       description='description',
       column_names=names_list,
       new_column_name='scaled',
       with_std=True,
       with_mean=True)

     tc = transformations.TransformationConfiguration.create(connection, 'description', t)

In this example, the parameter 'new_column_name' will be prefixed to the new column names, meaning columns will
look like 'scaled_col1', 'scaled_col2', etc.
