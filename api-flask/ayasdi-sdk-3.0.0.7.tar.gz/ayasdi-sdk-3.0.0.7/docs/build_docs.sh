#!/bin/bash -xe

PUBLISH_DIR="publish"
PYTHONPATH=../

mkdir -p "$PUBLISH_DIR"
rm -rf "$PUBLISH_DIR/*"

# Create PDF and EPUB first. Then copy these artifacts into _static
# so that the htmltgz docs` links to them will be satisfied.
make clean latexpdf epub

cp _build/epub/EurekaAIPythonSDK.epub "$PUBLISH_DIR/"
cp _build/epub/EurekaAIPythonSDK.epub _static/

cp _build/latex/EurekaAIPythonSDK.pdf "$PUBLISH_DIR/"
cp _build/latex/EurekaAIPythonSDK.pdf _static/

make clean htmltgz

cp _build/htmltgz/EurekaAIPythonSDK.tar.gz "$PUBLISH_DIR/"
