Transformation Configurations
=============================

.. note::
   This page is deprecated, and will be removed in Ayasdi Platform Release 7.15. Please see the user topic
   :doc:`transformationsdoc` instead.



Transformation of data is supported during the upload of a data source. The transformation is specified as an
input to the ``upload_source()`` function via the new “upload_config” parameter. It is a JSON-formatted string
which contains the name of the transformer, the source column, and any additional parameters needed.

Also included below is a list of the currently supported transformations and examples of how to use them.

Generally speaking, the transformations will add one or more columns to the uploaded file. Unless otherwise
specified, all transformations support only a single source column in their configuration.

Basic upload_config Usage
-------------------------

Example::

   >>> src = connection.upload_source("diabetes.txt", upload_config=
   >>> {
   >>> "transformation_config": {
   >>> "description":"Great transformation",
   >>> "transformation_steps": [
   >>> 	 {
   >>> 		"function": "sqr",
   >>> 			"description": "Blood Glucose Square",
   >>> 			"new_column_name": "blood glucose sqr",
   >>> 			"columns": [
   >>> 			   {
   >>> 				  "name": "blood glucose",
   >>> 				  "index": 2
   >>> 			   }
   >>> 			]
   >>> 		 }
   >>> 	  ]
   >>>    }
   >>>  })


Transformation Types
--------------------

sqr
~~~
	* This squares a value on a column. This function takes in one column name and squares the value.
	* Additional Parameters: *none*

Example::

      >>> 		"transformation_config": {
      >>> 		"transformation_steps": [{
      >>> 			"function": "sqr",
      >>> 			"description": "Blood Glucose Square",
      >>> 			"new_column_name": "blood glucose sqr",
      >>> 			"columns": [{
      >>> 				"name": "blood glucose",
      >>> 				"index": 2
      >>> 			}]
      >>> 		}]
      >>> 		}

log
~~~
	* This performs logarithmic function on column value.
	* Additional Parameters:
		* **base** - specify base for logarithm. Param value has to be an integer.

lag
~~~
	* Creates a new value that is equal to a previous row's value on the same column.
	* Additional Parameters:
		* **lagCount** - Specify the amount of lag. Integer. When specified, the column value lags by this amount. For example, if lagCount is 3, transformed value will be equal to 3rd previous value.

lagdif
~~~~~~
	* Creates a new value that is equal to the difference between current value and a previous value on the same column.
	* Additional Parameters:
		* **lagCount** - Specify the amount of lag. Integer. When specified, the column value lags by this amount. For example, if lagCount is 3, current value will be equal to difference between current value and 3rd previous value.

datetime
~~~~~~~~
	* Creates 10 new columns, slicing the date value into various aspects:

For example, the following Original column value "2016-12-31T23:00:00-08:00" is transformed into the following new columns and values:

================ =================
New Column Names New Column Values
================ =================
New_Date         20161231
New_YearMonth    201612
New_Year         2016
New_Month        12
New_DayOfMonth   31
New_DayOfWeek    6
New_Weekend      1
New_SecondOfDay  82800
New_Timezone     -08:00
New_DT_Error     OK
================ =================

prepend
~~~~~~~
	* Prepends a literal string to the value, transforming the new value into a string data type
	* Additional Parameters:
		* **prefix** - the literal value that will be prepended to the column value.

======== ===========
Original Transformed
======== ===========
42       value_42
0.5      value_0.5
======== ===========

Config Example::

    >>> {
    >>> "function":"prepend",
    >>> "columns":[ { "name":"column name"}],
    >>> "params":[
    >>>    {"name":"prefix", "value":"value_"}
    >>> ]}

onehotencode
~~~~~~~~~~~~
	* Transform a column of categorical values into separate columns with a 1 or 0 if the value matches
	* Additional Parameters:
		* **max** - (Default: 50) the maximum number of columns that will be created.  cutoff is frequency in the dataset.
		* **other** - (Default: true) if true, will create an extra column that will capture if the value was "some other value" than the max (ie 50).
		* **nulls** - (Default: false) if true, will create an extra column that will capture if the value was a null, empty string, or NaN.  If nulls is selected, these values are not included in the "other" category.  If nulls are not selected, nulls will show in the "other" column.

======== ============= ============ ====================
Original Original_Blue Original_Red Original_OTHERVALUES
======== ============= ============ ====================
Blue     1             0            0
Red      0             1            0
Yellow   0             0            1
======== ============= ============ ====================

Config Example::

   >>> {  
   >>>    "transformation_config": {
   >>>       "description": "Great transformation",
   >>>       "transformation_steps": [
   >>>          {
   >>>             "function": "onehotencode",
   >>>             "columns": [ { "name":"Original"} ],
   >>>             "params": [
   >>>                       {"name": "max", "value": "2"},
   >>>                       {"name": "other", "value": "true"}
   >>>                      ]
   >>>          }
   >>>       ]
   >>>    }
   >>>}

transpose
~~~~~~~~~
	* Transpose a file's rows and columns
	* Additional Parameters: **none**


text_feature_extraction
~~~~~~~~~~~~~~~~~~~~~~~
	* Extract features from unstructured text
	* Requires an Additional Parameter **algorithm**.  **See below** for supported text processing algorithms; currently only one is supported, "log_likelihood".
	* Each algorithm may require additional parameters.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~
algorithm : "log_likelihood"
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	* Processes text by selecting words based on the log likeliness over an entire corpus of documents or rows.   Will add each NGram term as a separate column into the source; each row will have the score value.  NGrams are series of adjacent words.
	* Supports only one source column
	* Additional Parameters:
		* **maxColumns** - the maximum number of new columns (most important NGrams) that will be added.
		* **maxNGramLength** - the maximum length of NGram; practically this shouldn't go more than 4.
		* **useStemmer** - true / false.  If true, will utilize word stemming
		* **useTFIDF** - true / false.  If true, will utilize TF/IDF word selection.
		* **allowedNgramLengths** - Comma-separated list of ngram lengths to be considered.  For example, "1,3,4" means only consider ngrams of length 1, 3 or 4, and all 2-length will be discarded. Can be null, which means consider all lengths up to maxNGramLength.
		* **useStopWords** - true / false.  If true, will use stopwords and calculate additional stopwords based on text frequency and the following parameters. (Default false)
		* **maxSkips** - The number of stopwords that can be skipped and still create an ngram.  For example, if maxSkips is 0, then a stopword will always cause the next valid word to start a new ngram. (Default 0)
		* **stopWordKneeRatio** - Details are complicated to explain in a short summary, but larger means keep more words (have fewer stop words), smaller means more stop words. 1.0 seems best when using ngrams, 2.5 seems best if just using single words. (Default 2.5)
		* **stopWordMinCutoff** - If a word appears <= this number of times in corpus, make it a stop word (Default 3)
		* **stopWordList** - Comma-separated list of words to never include in an ngram.  If null or empty, will use an internal set.
		* **startWordList** - Comma-separated list of words to never use as stopwords.  If null or empty, will use an internal set.

============== ============ ============== =============
Original       Original_two Original_three Original_four
============== ============ ============== =============
one two three  0.222        0.222          0.0
two three four 0.222        0.222          0.222
three four one 0.0          0.22           0.222
============== ============ ============== =============

(Note that these values are not actual calculated values, but are here just as an example)

Config Example::

   >>> {
   >>>   "transformation_config": {
   >>>     "description":"Great transformation",
   >>>     "transformation_steps": [
   >>>       {
   >>>         "function": "text_feature_extraction",
   >>>         "columns": [ { "name": "Original"}],
   >>>         "params": [
   >>>           {"name": "algorithm", "value": "log_likelihood"},
   >>>           {"name": "maxColumns", "value": "3"},
   >>>           {"name": "maxNGramLength", "value": "1"}
   >>>         ]
   >>>       }
   >>>      ]
   >>> }