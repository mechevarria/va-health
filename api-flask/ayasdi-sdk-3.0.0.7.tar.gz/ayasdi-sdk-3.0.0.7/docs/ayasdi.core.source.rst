=========================
ayasdi.core.source module
=========================

.. automodule:: ayasdi.core.source
    :members: Source
    :undoc-members:
    :show-inheritance:
