=============
SDK Reference
=============

.. highlight:: python
   :linenothreshold: 2

**See also:**
    - :doc:`userdoc`
    - :doc:`tutorialsdoc`


**Contents**

.. toctree::
    API module <ayasdi.core.api>
    Async module <ayasdi.core.async_jobs>
    Autoanalysis module <ayasdi.core.unsupervised_analysis>
    Models module <ayasdi.core.models>
    Time Series Models module <ayasdi.core.models.time_series_models>
    Network module <ayasdi.core.networks>
    Score module <ayasdi.core.score>
    Source module <ayasdi.core.source>
    Transformations module <ayasdi.core.transformations>
    Unsupervised models <ayasdi.core.models.unsupervised>

    Data Point List class <ayasdi.core.data_point_list>
    Data Spec class <ayasdi.core.data_spec>
    Outcome Spec class <ayasdi.core.outcome_spec>
    OAA Algorithm Spec class <ayasdi.core.oaa_algorithm_spec>
    Source Subset class <ayasdi.core.source_subset>
    Top Explainers Filter Spec class <ayasdi.core.top_explainers_filter_spec>


Check Your SDK version
----------------------
**SDK version mismatches with platform are not supported. If you upgrade your platform, please also upgrade
the EurekaAI Python SDK.**

To identify which version of the EurekaAI Python SDK is running at your installation, run:

.. code-block:: python

    from ayasdi._version import __version__
        print(__version__)

To install the latest version, see :doc:`installation`.    



How to Use EurekaAI Python SDK
--------------------------------
All use of the SDK begins with an API connection. (See :class:`ayasdi.core.api`.)

Once you obtain a successful connection, you can get a list of sources (:class:`ayasdi.core.api.Api.get_sources`)
or add a new source (:class:`ayasdi.core.api.Api.upload_source`).

To obtain analysis suggestions for any source, run the ``get_auto_analysis_suggestions``
function. You can then use the obtained suggestions to generate networks
(``Source.create_network``), where colorings (``Network.get_coloring_values``),
autogroups (``Network.autogroup_create``), and node_groups (``Network.create_node_group``)
can be generated.

For a walk-through of some of the above procedures, see the tutorials :doc:`tutorials/create_a_network` and
:doc:`tutorials/groups_autogroups`.   



Utilities
---------
The utility modules extend the base SDK functionality with the help of external dependencies, to simplify
some common data science tasks.

To install the utilities, unpack, and execute:

    $ pip install ayasdi-sdk-\ |version|\ .tar.gz[utils]

To use them, see:

    - :doc:`ayasdi.core.utilities.comparisons`
    - :doc:`ayasdi.core.utilities.networks`

