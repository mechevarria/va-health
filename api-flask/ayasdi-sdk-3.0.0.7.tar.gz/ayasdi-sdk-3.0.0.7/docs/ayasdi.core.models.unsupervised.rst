ayasdi.core.models.unsupervised.anomaly module
=========================

**Contents**

.. toctree::
   Anomaly detection model <ayasdi.core.models.unsupervised.anomaly>
