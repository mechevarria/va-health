ayasdi.core.score module
========================

.. automodule:: ayasdi.core.score
    :members:
    :undoc-members:
    :show-inheritance:
