ayasdi.core.models.time_series_models module
=========================

This module explains the time series forecasting analysis in EurekaAI.
The following can be performed using this module:
  - Sarimax (Seasonal AutoRegressive Integrated Moving Averages with eXogenous regressors)
  - Prophet (see `Prophet <https://facebook.github.io/prophet/>`_)
  - Time series decomposition

**AVAILABLE CLASSES**

**Base classes**:
   These base classes are not directly instantiated but their methods and attributes are found in all inherited classes.

.. autosummary::
   ayasdi.core.models.time_series_models.time_series_model_base.TimeSeriesModelBase

**Time series models**:

.. autosummary::
   ayasdi.core.models.time_series_models.sarimax.Sarimax
   ayasdi.core.models.time_series_models.prophet.Prophet
   ayasdi.core.models.time_series_models.decompose.TSDecompose

================
**BASE CLASSES**
================

.. automodule:: ayasdi.core.models.time_series_models.time_series_model_base
    :members: TimeSeriesModelBase
    :undoc-members:
    :show-inheritance:
    :no-undoc-members:

==========================
**TIME SERIES MODELS**
==========================

.. automodule:: ayasdi.core.models.time_series_models.sarimax
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.time_series_models.sarimax_spec
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.time_series_models.prophet
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.time_series_models.prophet_spec
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.time_series_models.decompose
    :members:
    :undoc-members:
    :show-inheritance:
