ayasdi package
==============

Subpackages
-----------

.. toctree::

    ayasdi.core

Module contents
---------------

.. automodule:: ayasdi
    :members:
    :undoc-members:
    :show-inheritance:
