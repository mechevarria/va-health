========================================
ayasdi.core.unsupervised_analysis module
========================================
:doc:`LABS Feature <labs>` -- Autoanalysis generalizes the concept of automated analysis that was introduced by the
Outcome AutoAnalysis (OAA) method. Although OAA requires an outcome column in the source data, this module provides
methods for generating networks without requiring an outcome column.

This module includes Ayasdi Python SDK methods for obtaining a "topological score" of a network. This score
can be used to rank networks against each other based on the network's structure.

Classes that support the autogeneration of networks include:
    * :class:`ayasdi.core.unsupervised_analysis.auto_analysis.AutoAnalysis`
    * :class:`ayasdi.core.unsupervised_analysis.auto_network_spec.AutoNetworkSpec`
    * :class:`ayasdi.core.unsupervised_analysis.analysis_method.AnalysisMethod`
    * :class:`ayasdi.core.unsupervised_analysis.name_filter_spec.NameFilterSpec`


AutoAnalysis
============
.. automodule:: ayasdi.core.unsupervised_analysis.auto_analysis
    :members:
    :undoc-members:
    :show-inheritance:

AutoNetworkSpec
===============
.. automodule:: ayasdi.core.unsupervised_analysis.auto_network_spec
    :members:
    :undoc-members:
    :show-inheritance:

AnalysisMethod
==============
.. automodule:: ayasdi.core.unsupervised_analysis.analysis_method
    :members:
    :undoc-members:
    :show-inheritance:

NameFilterSpec
==============
.. automodule:: ayasdi.core.unsupervised_analysis.name_filter_spec
    :members:
    :undoc-members:
    :show-inheritance:
