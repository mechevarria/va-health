==============================
EurekaAI Python SDK Installation
==============================

.. toctree::
   :titlesonly:

.. _obtaining_package:


Obtaining the Package
=====================

A pre-created package is available from the `EurekaAI Support Community
<https://ayasdicommunity.force.com/s/topic/0TO0P000000oU0bWAE/ayasdi-sdk?tabset-3500c=2>`_

To install this package, you need python v2.7 or higher (supported versions are: 2.7, 3.5, 3.6, and 3.7). Install the package by issuing the following command:

    .. parsed-literal::

       $ pip install -U ayasdi-sdk-\ |version|\ .tar.gz

Installing Utils Dependencies
=============================

In order to use some of the EurekaAI SDK utility modules, such as ayasdi.core.utilities.comparisons, you must
install a few additional dependencies. Issue the following command:

    .. code-block:: bash

       $ pip install ayasdi-sdk-\ |version|\ .tar.gz[utils]


Setting the Location of the Platform
====================================

If you are connecting to an non-standard EurekaAI platform instance, set the AYASDI_APISERVER variable. This becomes
particularly important in an on-premise installation.

    .. code-block:: bash

       $ export AYASDI_APISERVER="<url-of-the-webapp>"

Uninstalling the SDK
====================

To uninstall the SDK, run:

    .. code-block:: bash

       $ pip uninstall ayasdi-sdk

Upgrading to a New Version
==========================

If you are on a machine with internet access, download the sdk tar.gz that you want to upgrade to, and run:

    .. code-block:: bash

       $ pip install -U <sdk tar.gz>

If your machine is protected, you need to uninstall the sdk as above, and then
install the new version. For example:

    .. code-block:: bash

       $ pip uninstall ayasdi-sdk
       $ pip install -U ayasdi-sdk-\ |version|\ .tar.gz

Upgrading From python-sdk
=========================

If you have the old 'python-sdk' installed and want to upgrade to 6.1 or later:

    .. code-block:: bash

       $ pip uninstall python-sdk
       $ pip install <sdk tar.gz>


Resetting the Password
======================

If you have saved an incorrect password, correct the situation by removing the .ayasdiapi/creds file that is stored in your
home directory.

    .. code-block:: bash

       $ rm ~/.ayasdiapi/creds


Dependencies
============

For users using SDK locally, we currently support **Python 3.6+**

Starting with **v8.8**, users will have to upgrade to **Python 3** to use the Anomaly Detection feature.

Users will not be able to install SDK without upgrading to **Python 3.6+**. 

Also please note that this change will have no impact on Ayasdi Notebooks. 

The current dependencies are `requests
<http://docs.python-requests.org/en/latest/>`_ and `keyring <https://pypi.python.org/pypi/keyring>`_.

These dependencies are automatically installed if you follow the above pip install procedure.


Running the SDK Without Pip Installing
======================================

We strongly recommend installing the SDK if at all possible. If you are unable to pip install the Ayasdi SDK
package due to permissions issues, there is a workaround:

#. Download the sdk tar.gz as above

#. Download the required external packages
    * `requests 2.5.1 <https://pypi.python.org/pypi/requests/2.5.1/>`_

    * `requests-toolbet 0.6.0 <https://pypi.python.org/pypi/requests-toolbelt/>`_

#. Copy all of the tar.gz files to your working directory and untar them

#. Copy the requests toolbelt files to the sdk directory

    .. parsed-literal::

       cp -Rf requests-toolbelt-0.6.2\/requests_toolbelt ayasdi-sdk-\ |version|\ \/

#. Set the environment variables

    .. code-block:: bash

        export PYTHONPATH=<unzipped sdk full path>:$PYTHONPATH

    To test this, run:

    .. code-block:: bash

        PYTHONPATH=<unzipped sdk full path>:$PYTHONPATH python -c "from ayasdi._version import __version__; print __version__"

    which should output the version of the SDK that you've just unpacked.

#. Now run your script:

    .. code-block:: bash

        PYTHONPATH=<unzipped sdk full path>:$PYTHONPATH python <script.py>


