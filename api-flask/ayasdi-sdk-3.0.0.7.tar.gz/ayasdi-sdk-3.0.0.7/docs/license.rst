.. |copy|   unicode:: U+000A9 .. COPYRIGHT SIGN
==========
LICENSE
==========

 |copy| 2021 Symphony CrescendoAI LLC.  Use of this software is governed by the Software License Agreement entered into by your company.   This software is considered Symphony CrescendoAI LLC Confidential Information.
