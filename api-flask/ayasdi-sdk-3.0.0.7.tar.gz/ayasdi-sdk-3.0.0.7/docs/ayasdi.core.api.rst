======================
ayasdi.core.api module
======================

.. automodule:: ayasdi.core.api
      :members: Api
      :undoc-members: 
      :show-inheritance:
