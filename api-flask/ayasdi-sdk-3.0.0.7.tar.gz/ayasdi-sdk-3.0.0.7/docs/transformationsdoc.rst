.. The first paragraph on this page should always be updated with the correct version number.

=======================================
EurekaAI Transformation Services Overview
=======================================

.. highlight:: python
   :linenothreshold: 2

This Transformation Services Overview provides an introduction to EurekaAI Transformation Services, and details about
all Transformations supported as of EurekaAI Platform **version 7.14**.

It is meant to be used in conjunction with the SDK Reference (see :class:`ayasdi.core.transformations`), which
provides nuts-and-bolts information about transformation services method parameters.

We assume that you are familiar with the EurekaAI Python SDK, and have a good understanding of your source data and
its transformation requirements.

**Table of Contents**

.. toctree::
   :titlesonly:

    Recent Updates <transformations/trans_updates>
    Intro to Transformation Services <transformations/intro>
    Binarize <transformations/binarize>
    DateTime and DateTime Lag <transformations/datetime>
    Frequency Rank Encoding <transformations/freq_rank>
    GroupBy  <transformations/groupby>
    Join <transformations/join>
    Lag and LagDifference <transformations/lag_lagdiff>
    Logarithm <transformations/log>
    Math and String Operators <transformations/math_and_string>
    Min/Max Scaling <transformations/minmax>
    Multicolumn <transformations/multicol>
    New Category Count <transformations/newcat>
    Null Imputation <transformations/null>
    OneHotEncode  <transformations/onehot>
    Order By <transformations/orderby>
    Principal Component Analysis (PCA) <transformations/pca>
    Pivot <transformations/pivot>
    Prepend <transformations/prepend>
    Square <transformations/square>
    Standard Scaling (Z-Scoring) <transformations/z-scoring>
    Symmetric Log <transformations/symmetriclog>
    Text Feature Extraction <transformations/text_feature_extraction>
    Transpose <transformations/transpose>
    Union <transformations/union>

.. Ported out of Microsoft Word, edited/rewritten with care, and maintained by Freda Salatino until 3/17/2019