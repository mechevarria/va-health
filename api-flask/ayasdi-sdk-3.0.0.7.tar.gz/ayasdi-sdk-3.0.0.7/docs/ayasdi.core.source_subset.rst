ayasdi.core.source_subset
=========================

.. automodule:: ayasdi.core.source_subset
    :members:
    :undoc-members:
    :show-inheritance:
