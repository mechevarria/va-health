ayasdi.core.jobs module
=======================

.. automodule:: ayasdi.core.jobs
    :members:
    :undoc-members:
    :show-inheritance:
