ayasdi.core.models module
=========================

This module fulfils the supervised machine learning needs of the Ayasdi SDK.
Four types of modeling can be performed using this module:
  - Classification Models
  - Regression models
  - Group classification models
  - Ensemble models

**AVAILABLE CLASSES**

**Base classes**:
   These are not directly instantiated, but the methods and attributes of these base classes
   are found in all inherited classes.

.. autosummary::
   ayasdi.core.models.model_base.ModelBase
   ayasdi.core.models.classification_model.ClassificationModel
   ayasdi.core.models.regression_model.RegressionModel
   ayasdi.core.models.validation_statistics.ValidationStatistics
   ayasdi.core.models.model_spec.ModelSpec
   ayasdi.core.models.curve2d.Curve2D
   ayasdi.core.models.point2d.Point2D


**Classification models**:
   These classes perform classifications on either the entire :class:`source <ayasdi.core.source.Source>` or a group.
   They can alternatively also be used as group_classifiers.

.. autosummary::
   ayasdi.core.models.decision_tree.DecisionTree
   ayasdi.core.models.logistic_regression.LogisticRegression
   ayasdi.core.models.random_forest.RandomForest
   ayasdi.core.models.gbdt.GBDT
   ayasdi.core.models.neural_network.NeuralNetwork

**Regression models**:

.. autosummary::
   ayasdi.core.models.linear_regression.LinearRegression
   ayasdi.core.models.random_forest.RandomForest
   ayasdi.core.models.gbdt.GBDT
   ayasdi.core.models.neural_network.NeuralNetwork

**GroupClassifier**:

.. autosummary::
   ayasdi.core.models.group_classifier.GroupClassifier

**EnsembleModel**:

.. autosummary::
   ayasdi.core.models.ensemble_model.EnsembleModel

**ModelHelper**:

.. autosummary::
   ayasdi.core.models.model_helper.ModelHelper

**RandomForestMetric**:
   A transformation that generates columns based on tree based votings from a random forest.

.. autosummary::
   ayasdi.core.models.random_forest_metric.RandomForestMetric

**Statistics**:
   Statistics generated from each of the modeling methods.

.. autosummary::
   ayasdi.core.models.classification_statistics.ClassificationStatistics
   ayasdi.core.models.multiclass_statistics.MulticlassStatistics
   ayasdi.core.models.regression_statistics.RegressionStatistics
   ayasdi.core.models.regression_coefficient_statistics.RegressionCoefficientStatistics

================
**BASE CLASSES**
================

.. automodule:: ayasdi.core.models.model_base
    :members: ModelBase
    :undoc-members:
    :show-inheritance:
    :no-undoc-members:

.. automodule:: ayasdi.core.models.classification_model
    :members: ClassificationModel
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.regression_model
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.model_spec
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.curve2d
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.point2d
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.model_helper
    :members:
    :undoc-members:
    :show-inheritance:

==========================
**CLASSIFICATION AND REGRESSION MODELS**:
==========================

.. automodule:: ayasdi.core.models.decision_tree
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.decision_tree_spec
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.random_forest
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.random_forest_spec
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.gbdt
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.gbdt_spec
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.neural_network
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.neural_network_spec
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.linear_regression
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.linear_regression_spec
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.logistic_regression
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.logistic_regression_spec
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.group_classifier
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.group_classifier_spec
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.ensemble_model
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.legacy
    :members: MLModel
    :undoc-members:
    :show-inheritance:
    
.. automodule:: ayasdi.core.models.random_forest_metric
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.problem_spec
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.model_outcome_spec
    :members:
    :undoc-members:
    :show-inheritance:

==========================
**STATISTICS**:
==========================

.. automodule:: ayasdi.core.models.classification_statistics
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.multiclass_statistics
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.regression_coefficient_statistics
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.regression_statistics
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: ayasdi.core.models.validation_statistics
    :members:
    :undoc-members:
    :show-inheritance:
