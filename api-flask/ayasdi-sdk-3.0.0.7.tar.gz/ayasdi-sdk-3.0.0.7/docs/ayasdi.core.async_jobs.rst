=============================
ayasdi.core.async_jobs module
=============================

.. automodule:: ayasdi.core.async_jobs
    :members:
    :undoc-members:
    :show-inheritance:
