ayasdi.core.outcome_spec
=====================

.. automodule:: ayasdi.core.outcome_spec
    :members:
    :undoc-members:
    :show-inheritance:
