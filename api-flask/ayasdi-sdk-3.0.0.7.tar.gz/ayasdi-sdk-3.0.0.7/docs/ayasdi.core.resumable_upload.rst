ayasdi.core.resumable_upload module
===================================

.. automodule:: ayasdi.core.resumable_upload
    :members:
    :undoc-members:
    :show-inheritance:
