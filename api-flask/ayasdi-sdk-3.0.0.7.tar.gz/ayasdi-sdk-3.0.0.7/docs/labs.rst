============
Lab Features
============

.. _obtaining_package:

New Features
------------

EurekaAI is excited to introduce the concept of "Lab Features" to our customers.

A Lab Feature is one that we believe brings value to customers, but we need further validation from real use-cases.
Those features are typically "algorithmically challenging" and not necessarily precise, given the nature of
topological models and machine learning algorithms that we develop.

Instead of delaying their release to verify whether they are always "right", we explicitly label such features
as "lab features" so that customers can utilize them and even incorporate them in their workflows, providing valuable
feedback to Symphony CrescendoAI LLC and confirming whether or not those features should "graduate" to regular features.

Given customer feedback, Symphony CrescendoAI LLC will explicitly indicate whether a Lab Feature has "graduated". If we
decide to remove it from the product, we will advise customers one release ahead of its removal, so
customers can voice concerns and/or re-work their workflows.
